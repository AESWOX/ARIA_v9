---
status: archived
tags: [archive]
---
# Требует твоего решения — не трогал без подтверждения

## 1. GODTIER V8 Project Spec.md — НЕ дубль, как я думал раньше
Прочитал целиком: это отдельный проект мониторинг-дашборда (WebSocket monitor + B2 upload + n8n), а не то же самое, что GODTIER V8.md (пайплайн генерации) или Workflow Spec (ComfyUI-воркфлоу). Финал v1.0 от 2026-06-23, но **все Acceptance Criteria не отмечены** — похоже, проект дашборда либо брошен, либо завершён без обновления файла.
→ Дашборд жив? Если нет — в архив. Если да — обновить статус.

## 2. PIPELINE/ vs COMFY-KB/ — не полный дубль, разное качество метаданных
COMFY-KB/ структурирована по папкам (nodes/params/models/...), но **вообще без frontmatter** (я добавил tags+status механически, по названию папки — не выдумывал факты).
PIPELINE/ — плоская, но с датами/тегами. После архивации Big Love и PuLID там осталось 14 файлов: ComfyUI.md, ComfyUI_Workflow_Nodes.md, Checkpoint Parameters.md, Checkpoint_Merging.md, DoRA_Parameters.md, LoRA_Parameters.md, LoRA Dataset Guide.md, Dataset_Captioning.md, FaceFusion.md (помечен "stub"), Generation_Parameters.md, Template-vs-No-Template.md, Upscalers.md, VRAM_Optimization_3090.md, Vision Fallback (LLM).md, AI Видео Генерация.md.
→ Что-то из этого списка дублирует COMFY-KB по факту (не по названию)? Нужно свериться попарно — я не читал каждую пару построчно на предмет содержательного пересечения.

## 3. B2-кластер — 6 файлов, разные снапшоты по датам
STACK/B2 Storage.md, STACK/B2 Database Inventory.md (26.06), STACK/Storage_B2_Structure.md, PROJECTS/B2 Readiness Report.md (27.06, "PRE-PRODUCTION"), PROJECTS/AI-Influencer/05-B2-Backup.md (07.07, "63GB залиты"), 03-PROJECTS/AI-Influencer/audit-b2-2026-07-13.md (13.07, "ЧЕРНОВИК, ожидает approve").
→ Не стал архивировать сам — если audit-b2-2026-07-13 ещё "ЧЕРНОВИК" (не approved), убирать более старые снапшоты рано.

## 4. "stub"-файлы — 6 штук, сам автор пометил как незаконченные
VAULT/Линковка.md, STACK/SELF_HOSTING.md, STACK/RAILWAY_DEPLOYMENT.md, STACK/DOCKER_TROUBLESHOOTING.md, STACK/N8N_DEPLOYMENT.md, PIPELINE/FaceFusion.md
→ Дописать или снести? Тег "stub" уже есть, значит кто-то (ты или агент) сам знал, что не закончено.

## 5. n8n — весь трек может быть мёртв
Оставил STACK/n8n-MCP проект.md как единственную (после архивации дубля), но в migration-package n8n-скиллы (`n8n-local-setup`, `n8n-influencer-orchestrator`) были явно исключены из переноса агенту.
→ Если n8n-проект заброшен целиком — в архив и этот файл тоже.

## 6. Decision-Log — два лога, разный охват
DECISIONS/Decision-Log.md (общий, есть запись про Big Love) и PROJECTS/AI-Influencer/07-Decision-Log.md (проектный, есть запись про PuLID).
→ Оставил как есть — похоже на намеренное разделение (общее/проектное), но если это просто забыли объединить — скажи, сольём в один.
