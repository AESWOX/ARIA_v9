---
status: archived
tags: [archive]
---
# Почему эти файлы в архиве

## SDXL Big Love.md
- Было: `PIPELINE/SDXL Big Love.md`
- Причина: Decision-Log.md 2026-07-06: 'Big Love окончательно удалён' — файл описывает мёртвую модель как текущую

## SDXL Big Love Prompts.md
- Было: `PIPELINE/SDXL Big Love Prompts.md`
- Причина: то же — Big Love удалён, промпты под мёртвую модель

## ControlNet_IPAdapter_PuLID.md
- Было: `PIPELINE/ControlNet_IPAdapter_PuLID.md`
- Причина: 07-Decision-Log.md 2026-07-07: 'PuLID = кал — ПОЛНОСТЬЮ ОТМЕНЁН'

## RunPod.md
- Было: `STACK/RunPod.md`
- Причина: RunPod-Playbook.md (более новый, 02.07) сам себя называет 'рабочая версия', RunPod.md — черновик от 27.06

## n8n-MCP.md
- Было: `STACK/n8n-MCP.md`
- Причина: дубль STACK/n8n-MCP проект.md (тот же день создания, тот же проект, проект.md подробнее)

