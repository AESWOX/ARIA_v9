---
created: 2026-06-27
updated: 2026-06-28
tags: [n8n, mcp, workflow, orchestration]
source: WORK/AI/n8n-mcp/
---

# n8n-MCP

> n8n + Model Context Protocol — AI-оркестрация. Проект на WORK/AI/n8n-mcp/

## Статус
- **Версия:** v2.59.2 (bundles n8n 2.26.2) ✅
- n8n 2.26.6 на localhost:5678 ✅
- n8n-mcp: 127.0.0.1:3100 /mcp — 200 OK ✅
- Набор skills для n8n (node configuration, validation, expression syntax, Python code, workflow patterns)
- **Новое в v2.59.2:** `MULTI_TENANT_ALLOW_CONCURRENT_SESSIONS` — поддержка конкурентных сессий
- **Новое в v2.59.0:** `n8n_get_workflow mode="filtered"` — чтение отдельных нод без полного workflow

## Competitive Analysis (2026-06-19)
Подробное сравнение n8n-mcp vs официальный n8n MCP в `docs/competitive-analysis-june-2026.md` (28KB).
**Ключевое:** official догоняет по diff-редактированию (2.27.0 source), но n8n-mcp сохраняет преимущество в templates, community nodes, credentials CRUD, audit, version history, multi-instance, patchNodeField.

## Документация (20+ файлов)
Расположена в `WORK/AI/n8n-mcp/docs/`:
- CLAUDE_CODE_SETUP.md, CODEX_SETUP.md, CURSOR_SETUP.md — setup для разных AI-агентов
- N8N_DEPLOYMENT.md, HTTP_DEPLOYMENT.md, RAILWAY_DEPLOYMENT.md — деплой
- SECURITY_HARDENING.md, THREAT_MODEL.md — безопасность
- DATABASE_CONFIGURATION.md, DEPENDENCY_UPDATES.md
- DOCKER_TROUBLESHOOTING.md
- README_CLAUDE_SETUP.md

## Skills (7 штук)
- `n8n-workflow-patterns` — паттерны: webhook, scheduled, HTTP API, database, AI agent
- `n8n-validation-expert` — валидация + ERROR_CATALOG + FALSE_POSITIVES
- `n8n-node-configuration` — настройка нод + OPERATION_PATTERNS
- `n8n-mcp-tools-expert` — MCP инструменты
- `n8n-expression-syntax` — выражения
- `n8n-code-python` — Python в n8n

## Статус в GODTIER V8
- Проект spec (P1) — настройка credentials + workflow Telegram → Instagram
- Нужно: завести credentials, создать workflow

## Связи
- [[GODTIER V8 Project Spec]] — часть проекта
- [[Hermes Agent]] — интеграция через MCP
