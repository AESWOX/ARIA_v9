---
created: 2026-06-27
updated: 2026-07-02
tags: [sdxl, prompts, generation, biglust, lustify]
---

# Промпты для Lustify APEX V8

> Big Love family удалена (02.07.2026). Промпты переписаны для Lustify APEX V8.

---

## Базовые константы

**Negative Prompt (общий):**
```
smooth skin, airbrushed, porcelain skin, wax skin, worst quality, low quality,
blurry, deformed, bad anatomy, extra limbs, fused fingers, mutated hands,
plastic skin, doll-like, waxy skin, oversmoothed, artifact, mosaic,
noise pattern, cartoon, 3d render, painting, illustration,
oversharpened, grain, noisy
```

**Default стек:**
- Sampler: DPM++ 2M SDE Karras
- Resolution: 1024×1280 (4:5)
- Steps: 35 (APEX)
- CFG: 4.5 (APEX)
- Hires: 4x-UltraSharp 1.55x, denoise 0.28
- Detail Daemon: 0.4 (APEX)
- FaceDetailer: 0.24 (APEX)

**Триггер Lustify_apexV8:** `(score_9,score_8_up,score_7_up:0.5)`

---

## 👧 Girl SFW (универсальные промпты)

### Base prompt (рабочий, 01.07.2026)
```
photorealistic, raw photo, 8k uhd, film grain, realistic skin texture,
visible pores, subtle skin imperfections, subsurface scattering,
detailed iris, cinematic soft natural lighting, golden hour,
shot on Canon EOS R5, 85mm lens, beautiful young woman, natural makeup,
sharp focus, ultra realistic, candid portrait, depth of field,
(masterpiece:1.1), (best quality:1.1), extremely detailed skin,
micro skin details, realistic freckles if any, natural subsurface scattering,
sharp detailed eyes with catchlight, realistic textures, natural skin,
soft rim lighting, volumetric light
```

### Вариации (добавки к Base)

| Тип | Добавка в Positive |
|-----|-------------------|
| Full body standing | `full body shot, standing, entire body visible, (from head to toe:1.1), elegant pose` |
| Bust portrait | `bust portrait, shoulders and above, intimate close-up` |
| Half body | `half body shot, from waist up` |
| Close up | `close up face portrait, (detailed face:1.2), extreme close-up` |
| Medium shot | `medium shot, from hips up` |
| Fashion | `fashion editorial, high fashion, designer outfit, dramatic pose` |
| Casual | `casual wear, relaxed pose, everyday look` |
| With freckles | `+(freckles:0.6)` |
| With eyelashes | `+(detailed eyelashes:1.1)` |

---

## Варианты параметров для тестов

### Lustify_apexV8 — proven (01.07.2026)

| Вариант | CFG | DD | Denoise | FaceDetailer | Размер |
|---------|-----|----|---------|-------------|--------|
| Без FD | 5.0 | 0.35 | 0.25 | — | 3.9 MB |
| С FD | 5.0 | 0.35 | 0.25 | 0.21 | 3.9 MB |

### Lustify APEX V8 — proven (01.07.2026)

| Вариант | CFG | DD | Denoise | FaceDetailer | Размер |
|---------|-----|----|---------|-------------|--------|
| С FD | 4.5 | 0.4 | 0.28 | 0.24 | 4.0-4.2 MB |
