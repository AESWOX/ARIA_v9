---
created: 2026-06-27
updated: 2026-06-29
tags: [runpod, gpu, deploy, automation]
source: WORK/WAR333_GODTIER_OMNI/docs/GODTIER_V8_DEPLOY_PLAN.md
---

# RunPod

> GPU-поды для генерации SDXL. Golden pod template + deploy стратегия.

## Golden Pod

| Параметр | Значение |
|---|---|
| **Template** | `d1zgyr7rjh` (ALEX WORK PONY) |
| **Image** | `runpod/pytorch:2.2.1-py3.10-cuda12.1.1-devel-ubuntu22.04` |
| **Ports** | 8888 (Jupyter) + 8188 (ComfyUI) + 22 (SSH) — TCP |
| **GPU** | N/A через API первые 2-3 мин — ЖДАТЬ! |
| **Cost** | $0.00/hr symptom — если GPU N/A |

## Deploy

- **Скрипт:** `deploy.sh v8.6` (3635 строк) — на WORK/ШОТ/
- Устанавливает: ComfyUI + OneTrainer + все custom nodes + Big Love чекпоинты с [[B2 Storage]]

## Deploy Стратегия (оптимизация времени)

| Вариант | Время | Описание |
|---|---|---|
| **Вариант 1: Golden archive + sync** ⚡ | **~12-15 мин** | b2 download golden_pod_light.tar.gz (515 MB) → распаковка → b2 sync чекпоинтов |
| **Вариант 2: Docker образ** 🚀 | **~4-5 мин** | Свой шаблон на RunPod с ComfyUI + всё внутри |
| **Вариант 3: Постоянный под 24/7** 🎯 | **~2 мин** | Под живёт всегда, ComfyUI уже запущен, модели загружены |

**Что есть на B2 для быстрого старта:**
| Компонент | Размер | Статус |
|---|---|---|
| golden_pod_light.tar.gz (A1 — venv + ComfyUI) | 515 MB | ✅ |
| comfy_nodes_33.tar.zst (старый, 33 ноды) | 394 MB | 🟡 устарел |
| deploy.sh v8.6 | 174 KB | ✅ |
| Чекпоинты SDXL (photo5, Lustify_apexV8, insta1...) | ~6.6 GB каждый | ✅ |
| VAE, CLIP, ControlNet, IP-Adapter, PuLID | — | ✅ |
| LoRA (DMD2 + новые) | — | ✅ |

## Queue-based Generation

ComfyUI поддерживает очередь. Можно закинуть 10-20 промптов за раз:

```
Сейчас:     Отправить 1 → ждать → получить → отправить 2 → ждать → ...
            = 20 тестов × 30 сек = 10 минут

Можем:     Отправить 1,2,3...20 одной пачкой → ComfyUI сам очередь
            = 1 тест × 30 сек + 19 × 2 сек (overhead) = 68 сек
```

**Для массовой генерации:**
```
Закинуть 100 промптов в очередь
↓
ComfyUI очередь обрабатывает сама
↓
Параллельно закидываем следующую 100
```

**Или batch gen** — batch_size=4:
```
1 промпт × batch_size=4 = 4 изображения за 35 сек
= 100 изображений за ~15 мин
```

## Pod Config для продакшна

```
Pod: 4090 (24GB) / A100 (80GB)
Template: ComfyUI + все модели на B2
Container: comfyui:latest
Volume Mount: /workspace (persistent)
Cost: $0.39-$1.49/hr
```

## 3-Mode Pod Manager (v3, 2026-06-29)

Создан Python-менеджер подов `WORK/runpod_manager.py` (275 строк) с 3 режимами:

| Режим             | GPU                               | Цель                                          |
| ----------------- | --------------------------------- | --------------------------------------------- |
| 🔵 **TRANSFER**   | A5000 ($0.27/h) → A6000 ($0.49/h) | Скачать модель → залить в B2 → TERMINATE      |
| 🟢 **GENERATION** | A5000 ($0.27/h) → A6000 ($0.49/h) | SDXL ComfyUI генерация (порты 8888, 8188, 22) |
| 🟡 **TRAINING**   | 4090 ($0.69/h) → A6000 ($0.49/h)  | LoRA обучение, OneTrainer                     |

**Precheck:** Проверяет активные поды → TERMINATE если costPerHr=0.0 или idle > 15 мин

**Создание:** Определяет dataCenterId через GraphQL `lowestPrice(secureCloud:true) { stockStatus }` → ждёт costPerHr > 0 (3 мин таймаут) → GPU:N/A → failback → TERMINATE

**Спецификация:** `2026-06-29-runpod-3-modes-spec` (детали в 00-RAW)

## Killswitch (v2, работает каждые 3 мин)

```python
Проверка всех RUNNING подов
↓
costPerHr == 0.0 → TERMINATE (GPU не выделен)
Idle > 5 мин → TERMINATE (утечка бюджета)
↓
Лог: имя, id, idle минут, стоимость сессии
```

Запущен как cron: `runpod-killswitch` (every 3m, скрипт `runpod_killswitch.py`)

## Диагностика GPU N/A

### Персистентная проблема (подтверждено 3 тестами)
| Дата | Попытка | Результат |
|------|---------|-----------|
| 26 июня | A5000, template d1zgyr7rjh, SECURE | ✅ **GPU выделен** (Golden Pod собран) |
| 27 июня | 3090/A5000/A4000, SECURE/COMMUNITY/ALL | ❌ Все GPU:N/A |
| 29 июня | A5000 ($0.27) → A6000 ($0.49) | ❌ **Оба** GPU:N/A |

### RunPod AI Agent диагноз (2026-06-29)
> "Pod RUNNING, GPU:N/A, costPerHr=$0.00 — это **0-GPU Pod**. Причина: GPU не может быть выделен на хосте к которому привязан аккаунт."

Рекомендация AI: проверить через `lowestPrice(secureCloud: true)` и `stock`.

### 🔑 КОРЕННАЯ ПРИЧИНА: ПРОСРОЧЕННЫЙ API КЛЮЧ (29 июня, финальный диагноз)

Полное расследование: `00-RAW/статьи/2026-06-29-diagnostic-report.md`

**Реальная причина GPU:N/A — старый API ключ был просрочен/ограничен:**

| Ключ | Результат |
|------|-----------|
| `rpa_TQTM...` (старый) | Все поды GPU:N/A |
| `rpa_4EGL...` (новый, создан 29 июня) | ✅ RTX 4090 выделяется мгновенно |

**Дополнительные проблемы:**

1. **REST API `/v1/pods/{id}` врёт** — показывает GPU:N/A ДАЖЕ когда GPU реально выделен. Использовать **GraphQL**: `myself { pods { machine { gpuType } } }`
2. **A5000 — SUPPLY_CONSTRAINT** с 29 июня. GPU нет в наличии ни в SECURE, ни в COMMUNITY Cloud (временный дефицит)
3. **`get_gpus()` — мёртвые данные** — используй `get_gpu("NVIDIA RTX A5000", 1)`

**Работающие GPU с новым ключом:** RTX 4090 ✅, RTX 3090 ✅, RTX A6000 ✅

### Что исправлено
| Что | Статус |
|-----|--------|
| API ключ обновлён в РАНПОД.txt | ✅ |
| API ключ обновлён в runpod_manager.py | ✅ |
| runpod_manager.py использует рабочие GPU (4090/A6000/3090) | ✅ |
| A5000 stock monitor — крон каждую минуту | ✅ |
| killswitch — работает (чистит idle, costPerHr=0.0) | ✅ |
| precheck — убивает зомби | ✅ |
| Chrome НЕ убиваем | ✅ |
| MEDIA только из WORK/SECOND_BRAIN | ✅ |

### Ключевые уроки
1. **Не доверяй REST API** — `/v1/pods` показывает GPU:N/A даже когда GPU есть. Используй GraphQL.
2. **API ключи протухают** — если поды перестали работать, создай новый ключ.
3. **get_gpus() — мёртвый** — всегда используй `get_gpu("ID", count)`.
4. **SUPPLY_CONSTRAINT ≠ проблема аккаунта** — это просто GPU нет в наличии, временно.
5. **A5000** — out of stock с 29 июня (проверять кроном)

### Стоп-лист
- ❌ `get_gpus()` — мёртвые данные
- ❌ `STOP` — только `TERMINATE`
- ❌ Рестарт пода с GPU:N/A
- ❌ `create` без `dataCenterId`
- ❌ `gpu_count=0`
- ❌ Несколько попыток без смены датацентра

## Автоматизация

`runpod-automation` skill — создание подов, запуск, мониторинг.

## Связи
- [[GODTIER V8]] — пайплайн
- [[GODTIER V8 Workflow Spec]] — workflow
- [[ComfyUI]] — рендер
- [[B2 Storage]] — чекпоинты
- [[SDXL Big Love]] — модели
- [[STACK/RunPod GPU Deployment History]] — история тестов
- `2026-06-29-session-report` — полный отчёт сессии
- `2026-06-29-diagnostic-report` — расследование GPU:N/A (API key, REST lies, A5000 stock)
