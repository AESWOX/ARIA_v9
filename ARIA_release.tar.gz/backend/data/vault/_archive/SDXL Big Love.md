---
created: 2026-06-27
updated: 2026-07-02
tags: [sdxl, checkpoint, models, biglust, lustify]
---

# SDXL Чекпоинты

> **Big Love family удалена (02.07.2026).** Остался только **Lustify APEX V8**.

---

## Активные чекпоинты

| Модель | Размер | Цена | Рейтинг | Назначение |
|--------|--------|------|---------|------------|
| **Lustify APEX V8** | 6.6 GB | Free | ⭐⭐⭐⭐ | NSFW, детализация |

---

## Lustify_apexV8 (основной)

Мерж bigASP + LUSTIFY. Лучший для NSFW explicit. Pony-совместимый триггер.

**Триггер:** `(score_9,score_8_up,score_7_up:0.5)`
**Production промпты:** `photo (medium), cinematic, 8k, [subject], [pose]`

### Рабочий стек (утверждён 01.07.2026)

| Параметр | Значение |
|----------|----------|
| **Sampler** | DPM++ 2M SDE |
| **Scheduler** | Karras |
| **CFG** | 5.0 |
| **Steps base** | 40 |
| **Resolution** | 1024×1280 (4:5) |
| **Hires upscale** | 4x-UltraSharp model → 1.55x (1587×1984) |
| **Hires steps** | 22 |
| **Denoise** | 0.25 |
| **Detail Daemon** | 0.35 |
| **FaceDetailer** | 0.21 |

### Результаты FaceDetailer

| Версия | Denoise | DD | FD | Размер |
|--------|---------|----|-----|--------|
| BL_final_v1 (без FD) | 0.25 | 0.35 | — | 3.9 MB |
| BL_final_v2 (без FD) | 0.25 | 0.35 | — | 3.9 MB |
| BL_fd_v1 (с FD) | 0.25 | 0.35 | 0.21 | 3.9 MB |

---

## Lustify APEX V8

NSFW-ориентированный чекпоинт с другой цветопередачей.

### Рабочий стек

| Параметр | Значение |
|----------|----------|
| **Sampler** | DPM++ 2M SDE |
| **Scheduler** | Karras |
| **CFG** | 4.5 |
| **Steps base** | 35 |
| **Resolution** | 1024×1280 (4:5) |
| **Hires upscale** | 4x-UltraSharp model → 1.55x (1587×1984) |
| **Hires steps** | 22 |
| **Denoise** | 0.28 |
| **Detail Daemon** | 0.4 |
| **FaceDetailer** | 0.24 |

### Результаты FaceDetailer (01.07.2026, RunPod RTX 3090)

| Версия | Denoise | DD | FD | Размер |
|--------|---------|----|-----|--------|
| LX_fd_v2 (с FD) | 0.28 | 0.4 | 0.24 | 4.0-4.2 MB |

---

## Проверенные LoRA (31 файл на поде, активные)

| LoRA | Файл | Вес |
|------|------|-----|
| Detail | StS_PonyXL_Detail_Slider_v1.4_iteration_3 | 0.55-0.7 |
| Skin Zib | skin texture style zib v2.1 | 0.5-0.6 |
| Faces | SDXL_BetterFaces-LoRA_v1 | 0.6-0.7 |
| Polyhedron | polyhedron_all_sdxl-000004 | 0.4-0.5 |
| Eyes | DetailedEyes_V3 | 0.5-0.6 |
| Cute | subtle-cuteness2-xl3 | 0.35-0.4 |
| Light | subtle-lighting2-xl3 | 0.45-0.6 |

**Расширенные:** RealSkin_xxXL_v1, Realism_Lora, SDXLHighDetail_v6, eye_concept_SDXL_v1, add-detail-xl, openxl_handsfix, subtle-ultrares1-xl25, ClearHand-V2, HandFixer_pdxl_Incrs_v1, Perfect_Eyes и др.

### LoRA тестинг — 3 раунда

- **Round 1 — Core:** detail(0.55-0.7) + faces(0.6-0.7) + skin_zib(0.5-0.6), DD 0.3-0.5
- **Round 2 — Extended:** core + poly(0.4-0.5) + eyes(0.5-0.6), DD 0.4
- **Round 3 — Full stack:** detail + faces + skin_zib + poly + eyes + cute + light (7 LoRA), DD 0.35-0.4

---

## Anti-Plastic формула (Negative)

```
smooth skin, airbrushed, porcelain skin, wax skin, worst quality, low quality,
blurry, deformed, bad anatomy, extra limbs, fused fingers, mutated hands,
plastic skin, doll-like, waxy skin, oversmoothed, artifact, mosaic,
noise pattern, cartoon, 3d render, painting, illustration,
oversharpened, grain, noisy
```

---

## Хранение на B2

- **Bucket:** `ALEX.STORAGE/models/sdxl/checkpoints/`
- **Lustify_apexV8.safetensors** — ✅ на B2
- **LoRA:** `ALEX.STORAGE/models/sdxl/loras/` — 31 файл
- **База:** `B2_DATABASE`

---

## Удалённые чекпоинты (Big Love family)

Все фото/ультра/инста варианты Big Love удалены 02.07.2026 по решению пользователя.
- ~~bigLove_photo4, photo5, photo6~~
- ~~bigLove_ultra3, ultra5~~
- ~~bigLove_insta1~~
- ~~bigLove_lust1~~ (был битый)

---

## Связи

- [[GODTIER V8]] — пайплайн
- [[B2 Storage]] — хранилище
- [[ComfyUI]] — рендер
- [[RunPod]] — запуск
