---
status: archived
tags: [project, archive, ai-influencer]
---
## 2026-07-13 — Phase A V5: 4 tar.zst архива на B2 + restore

**Контекст:** Полный рефакторинг деплоя Phase A. Вместо pip install и rclone sync моделей — **4 tar.zst архива** с zstd -10.

**Что сделано:**
- Идентифицированы пути на поде: `COMFY_BASE=/workspace/runpod-slim/ComfyUI`, модели реально в `/workspace/ComfyUI/models/` (через symlink)
- Установлены: zstd, rclone, PyTorch 2.5.1+cu124, ultralytics, segment-anything, clip_vision_g (3.7 GB с B2)
- Созданы 4 архива и залиты на B2:
  - `comfyui-models.tar.zst` — 34.2 GB (bigLust, VAE, IPAdapter, InstantID, ControlNet, LoRA 27 шт, YOLO, antelopev2, clip_vision)
  - `comfyui-venv.tar.zst` — 4.1 GB (9.4 GB site-packages + python3.12 + pip3, сжато zstd -10)
  - `comfyui-engine.tar.zst` — 75 MB (ComfyUI main.py + 8 custom_nodes: Impact, InstantID, IPAdapter, KJNodes, Manager)
  - `phaseA-full.tar.zst` — 103 MB (28 скриптов + cui.log + 39 output-файлов)

**Восстановление:** ~86 секунд на новом поде. CUDA True, bigLust на месте, HTTP 200.

**Найденные ошибки:**
- SSH таймауты создают орфаны tar → lock-файлы обязательны
- `fuser -k 8188/tcp` убивает RunPod proxy → только `kill $(pgrep -f "python3 main.py")`
- zstd -19 медленный → zstd -10
- Hairstyles дают `HTTP Error 400` — не диагностировано до конца (предположительно `comfy.ldm.models` или разный набор нод в workflow)

**Терминировано:** 2 пода (`1u0x2kw6vcnmpb`, `c31fh6ggdmzlb0`) + 1 мгновенно (`2kk5d6bmwgcmgs`)
**Сожжено:** ~$0.50-0.70 (списание — забыл терминейтнуть первый под вовремя)

**Ключевые файлы:**
- B2: `b2:ALEX.STORAGE/deploy/archives/` — 4 архива
- Локально: `~/Desktop/dataset_prep/` — все скрипты Phase A
- Локально: `~/Desktop/WORK/SECOND_BRAIN/03-PROJECTS/AI-Influencer/` — проектная документация
