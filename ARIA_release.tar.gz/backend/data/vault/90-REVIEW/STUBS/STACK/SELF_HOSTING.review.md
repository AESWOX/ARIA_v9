---
created: 2026-07-06
status: stub
tags: [n8n, mcp, deploy, stub]
---

# SELF_HOSTING — n8n-mcp Self-Hosting

> **Stub** — документация проекта находится во внешней директории.

**Источник:** `WORK/AI/n8n-mcp/docs/`
**Основные способы:** npx, Docker, Railway

**TODO:**
- [ ] Перенести ключевые шаги из внешней документации
- [ ] Проверить актуальность

**Связанные заметки:**
- [[n8n-MCP проект]]
- [[N8N_DEPLOYMENT]]
- [[RAILWAY_DEPLOYMENT]]
- [[DOCKER_TROUBLESHOOTING]]
