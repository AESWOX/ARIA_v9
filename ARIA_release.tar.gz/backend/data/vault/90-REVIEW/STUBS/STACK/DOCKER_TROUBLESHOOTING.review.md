---
created: 2026-07-06
status: stub
tags: [n8n, mcp, docker, troubleshooting, stub]
---

# DOCKER_TROUBLESHOOTING

> **Stub** — документация проекта находится во внешней директории.

**Источник:** `WORK/AI/n8n-mcp/docs/`

Известные проблемы Docker-развёртывания n8n-mcp и их решения.

**TODO:**
- [ ] Перенести ключевые шаги

**Связанные заметки:**
- [[n8n-MCP проект]]
- [[SELF_HOSTING]]
