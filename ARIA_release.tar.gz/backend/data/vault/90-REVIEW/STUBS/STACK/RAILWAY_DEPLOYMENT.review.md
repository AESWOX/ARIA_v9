---
created: 2026-07-06
status: stub
tags: [n8n, mcp, deploy, cloud, stub]
---

# RAILWAY_DEPLOYMENT — Railway Cloud

> **Stub** — документация проекта находится во внешней директории.

**Источник:** `WORK/AI/n8n-mcp/docs/`

Деплой n8n-mcp на Railway cloud.

**TODO:**
- [ ] Перенести ключевые шаги

**Связанные заметки:**
- [[n8n-MCP проект]]
- [[SELF_HOSTING]]
