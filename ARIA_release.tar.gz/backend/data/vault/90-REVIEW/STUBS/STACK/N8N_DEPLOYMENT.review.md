---
created: 2026-07-06
status: stub
tags: [n8n, mcp, deploy, stub]
---

# N8N_DEPLOYMENT — Production Deployment

> **Stub** — документация проекта находится во внешней директории.

**Источник:** `WORK/AI/n8n-mcp/docs/`

Production-развёртывание n8n-mcp сервера.

**TODO:**
- [ ] Перенести ключевые шаги
- [ ] Проверить актуальность

**Связанные заметки:**
- [[n8n-MCP проект]]
- [[SELF_HOSTING]]
