---
created: 2026-06-27
tags: [godtier, v8, project-spec, monitoring, b2, n8n]
source: WORK/WAR333_GODTIER_OMNI/docs/GODTIER_V8_PROJECT_SPEC.md
---

# GODTIER V8 Project Spec

> Полный проект: мониторинг в реальном времени + B2 Uploads + n8n интеграция.
> Версия 1.0 (final), дата: 2026-06-23.

## Архитектура

```
Hermes Agent ←WS→ hermes_monitor (FastAPI:8765) → UI (7890)
     ↕
B2 Uploader (b2 CLI)
     ↕
n8n (localhost:5678) → Telegram/Instagram/Threads/X/Reddit
```

## Компоненты

### 1. Мониторинг (P0)
- Backend WS: `hermes_monitor/server.py` — FastAPI + WebSocket
- Event bus: `hermes_monitor/event_bus.py`
- State: `hermes_monitor/state.py` — TaskEvent + TTL
- Клиент: `hermes_monitor/monitor_client.py` — асинхронный клиент
- Фронт: `static/index.html` — vanilla JS + dagre-d3 SVG
- **Статус:** черновик есть, state.py + клиент + фронт не созданы

### 2. B2 Uploads (P0)
- Рабочее: `b2 upload_file ALEX.STORAGE <local> <b2_path> --threads 1`
- Проблемы: rclone multi-thread не на Windows, скорость 100-470 kB/s
- Дубликаты: были в root/ и work/zips/ — очищено

### 3. n8n (P1)
- n8n 2.26.6 на localhost:5678
- n8n-mcp: 127.0.0.1:3100 /mcp — 200 OK
- Нужно: credentials + workflow Telegram → Python → Instagram

### 4. SDXL модели (P1)
- Блокер: CivitAI 401/403 на файлы
- Доступные: HuggingFace (`huggingface-cli download`)
- [[B2 Database Inventory]] — полный список

### 5. VPS/RunPod (P2)
- Ключи есть, не использовались
- Нужно: создать под, настроить туннель, загрузить модели

## Acceptance Criteria
- [ ] Монитор: WS → full_state, прогресс, stale/hung, kill
- [ ] B2: все ZIP загружены, без дублей
- [ ] n8n: Telegram → Instagram end-to-end
- [ ] SDXL: все модели на B2

## Связи
- [[GODTIER V8]] — пайплайн генерации
- [[B2 Storage]] — хранилище
- [[Командный Центр CC v3]] — merged
- [[Hermes Agent]] — интеграция
