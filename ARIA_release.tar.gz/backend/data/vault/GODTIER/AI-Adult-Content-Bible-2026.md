---
status: working
tags: [godtier]
---
# AI Adult Content Bible 2026 — Расширенная база

> **Источники:** Full_Compilation_AI_Adult.md, AI_Erotic_Genres_Overview.md, Trans_Futa_Details.md  
> **Расширено:** Реальными параметрами GODTIER Pipeline, ComfyUI стеком, LoRA тренировкой, B2 деплоем  
> **Дата создания:** 2026-07-07  

---

## 1. ТРИ ОСНОВНЫЕ НИШИ (с фактическими параметрами генерации)

### 1.1 GFE / Realistic (Girlfriend Experience)

**Топ типажи (100% проверенные):**
1. Sweet Girl Next Door — innocent look, long hair, soft smile
2. Playful College Babe — youthful, casual, playful poses
3. Seductive Office Lady — glasses, business attire → naughty
4. Beach Fitness Goddess — tanned, athletic, bikini
5. Cozy Home Tease — sweater, leggings, bedroom

**Наш production стек для GFE:**

| Параметр | Значение |
|----------|----------|
| **Модель** | Lustify_apexV8.safetensors (6.77GB, CivitAI 575395) |
| **Sampler** | DPM++ 2M SDE |
| **Scheduler** | Karras |
| **Steps** | 35-45 |
| **CFG** | 5.0-6.0 |
| **Resolution** | 1024×1280 (4:5 portrait, жёстко) |
| **Hires Fix** | 1.6x nearest-exact, denoise 0.32-0.38 |
| **Detail Daemon** | 0.45-0.55 |

**SDXL LoRA стек (верифицирован через CivitAI API):**

| LoRA | Вес | CivitAI ID |
|------|-----|------------|
| Touch of Realism V2 | 0.5-1.0 | 1705430 |
| ClearHandsXL v2 | 0.55-0.65 | 132884 |
| Perfect Eyes XL | 0.5-0.6 | 118427 |
| Skin Texture XL v4 | 0.5-0.55 | 580857 |
| DetailN_XL | 0.55-0.65 | 1317134 |
| Polyhedron_all | 0.4-0.55 | 135160 |

**Enriched prompt (проверено):**
```
photorealistic, raw photo, 8k, film grain, skin texture, pores,
detailed eyes, subsurface scattering, cinematic lighting,
soft natural light, shot on Canon EOS R5, beautiful woman,
natural makeup, sharp focus, ultra realistic, candid expression
```

**Anti-plastic negative (обязательно):**
```
smooth skin, airbrushed, porcelain skin, wax skin, plastic skin, digital art,
(worst quality, low quality, blurry, deformed, bad anatomy,
extra limbs, fused fingers, mutated hands, plastic skin)
```

**Хештеги:**
#AIGirlfriend #NSFWAI #AIPorn #AIInfluencer #FanvueAI #GFE #BigTitsAI #RealisticAI #AIGirl #VirtualGirlfriend #AICreator #HyperRealisticNSFW

**Ежедневный контент-план (5-7 постов):**
1. Morning bed selfie in lingerie, soft lighting
2. Gym workout — sports bra, sweat, ass focus
3. Shower / wet body tease, water droplets
4. Kitchen cooking in apron only (from behind)
5. Mirror selfie in new outfit, full body
6. Bedroom strip tease sequence
7. Beach / pool bikini photos
8. Office roleplay — skirt up, bent over desk
9. Cosplay light version (maid, nurse)
10. Yoga / flexible poses emphasizing curves
11. Night time lingerie + candle light
12. Custom request fulfillment (user-chosen outfit)
13. Seasonal (Christmas, Halloween themed)
14. Before/after or transformation tease
15. ASMR style close-up face and body

---

### 1.2 Futa / Trans / Shemale

**Топ типажи (100% виральные):**
1. Busty Feminine Futa Girl — feminine face, gigantic breasts, huge cock
2. Thick Ass Shemale — massive ass focus, thick thighs, dominant
3. Bimbo Trans — exaggerated lips, blonde, hyper curves + massive dick
4. Athletic Futa Dom — muscular yet feminine, tall, commanding
5. Exotic Asian Futa — petite upper body, extreme lower assets

**Структуры тел (масштабируемые):**

| Зона | Параметры |
|------|-----------|
| **Лицо** | 100% feminine — big doe eyes, full plump lips, soft jawline, makeup. Вариации: soft natural / hyper bimbo |
| **Грудь** | Gigantic J-K+ or larger, heavy, round, perky or natural sag |
| **Ягодицы** | Massive bubble butt, wide hips 120cm+, thick thighs |
| **Член** | 30-45+ cm, very thick (forearm+), veiny, throbbing, heavy balls, dripping pre-cum |
| **Тело** | extreme hourglass — tiny waist, flawless skin, long legs |

**Наш production стек для Futa/Trans:**

| Параметр | Значение |
|----------|----------|
| **Модель** | Lustify_apexV8.safetensors (единственная NSFW модель) |
| **Sampler** | DPM++ 2M SDE **или** 3M SDE |
| **Scheduler** | Exponential / Karras |
| **Steps** | 30-40 |
| **CFG** | 4.2-5.5 (никогда ниже 4.0!) |
| **Hires Fix** | 1.5x, denoise 0.35-0.42 |
| **Detail Daemon** | 0.5-0.6 |
| **ADetailer** | Face 0.35-0.4 + Hand 0.42 |

**Detail Daemon + LyingSigmaSampler цепочка:**
```
KSamplerSelect → DetailDaemonSamplerNode → LyingSigmaSampler → SamplerCustom
```
BasicScheduler с `denoise: 1.0` **обязательно** (иначе HTTP 400).
DetailDaemonSamplerNode требует ВСЕ поля: exponent, start_offset, end_offset, fade, smooth, cfg_scale_override.

**LoRA стек для Futa:**
- Те же SDXL LoRA что и для GFE
- PuLID SDXL (pulid_sdxl.safetensors) weight 0.5-0.8 для тяжёлых поз
- IP-Adapter-FaceID-Plus-v2 weight 0.85 — альтернатива PuLID
- InstantID (antelopev2) для bootstrap датасета

**futa-specific хештеги:**
#FutaAI #TransAI #ShemaleAI #BigDickFuta #HugeTitsFuta #MassiveAssTrans #Futanari #FutaOnFemale #HyperFuta #FutaDom #ThickFuta #BimboFuta #AICock #BulgeTease #FutaStroke #TransCreampie #GiganticFutaCock

**Топ 15 идей для ежедневной генерации:**
1. Panties bulge tease — close-up on massive cock outline
2. Slow stroking session with both hands
3. Bent over showing massive ass + cock hanging
4. Titjob with gigantic breasts
5. Mirror selfie full nude with erection
6. Dominating pose on bed
7. Shower scene with water on body and cock
8. Lingerie set with visible bulge and breasts
9. Ahegao face while stroking
10. Paizuri (breast sex) focus
11. Ass focus + cock between cheeks
12. Outdoor / public risky tease
13. Cosplay futa (succubus, maid with cock)
14. Cumshot / orgasm sequence
15. Interaction with female character (futa on girl)

**Ежедневный план (4-6 постов):**
- 2 tease (bulge/ass)
- 2 action (stroking)
- 1-2 extreme

---

### 1.3 Hentai / Anime Waifu

**Топ типажи:**
1. Classic Anime Schoolgirl — uniform, pigtails, innocent but seductive
2. Busty Demon Waifu — horns, tail, red skin, massive curves
3. Catgirl Nekomimi — ears, tail, playful expression
4. Tentacle Monster Girl — fantasy elements, multiple limbs
5. Futuristic Cyber Waifu — neon hair, tech implants, shiny body

**Lustify_apexV8 поддерживает Pony-совместимые score теги:**
```
(score_9,score_8_up,score_7_up:0.5), photo (medium), cinematic, 8k...
```

**Хештеги:** #AIWaifu #HentaiAI #AnimeNSFW #NSFWArt #DigitalWaifu #Futanari

---

## 2. НАШ ПОЛНЫЙ PRODUCTION СТЕК

### 2.1 Checkpoint Manifest

| Модель | Версия | Размер | CivitAI ID | Назначение |
|--------|--------|--------|------------|------------|
| **Lustify_apexV8** 🏆 | v8 | 6.6 GB | 573152 | NSFW explicit (альтернатива) |
| **Lustify_apexV8** | v8 | 6.6 GB | 573152 | NSFW explicit (альтернатива) |

**Lustify_apexV8** — основная production модель (заменила Big Love Photo6).

### 2.2 Сравнение параметров (подтверждено тестами)

| Сценарий | Sampler | Steps | CFG | Scheduler |
|----------|---------|-------|-----|-----------|
| GFE/Portrait | DPM++ 2M SDE | 35-45 | 5.0-6.0 | Karras |
| Futa/Explicit | DPM++ 2M/3M SDE | 30-40 | 4.2-5.5 | Exponential/Karras |
| Preview тест | Euler | 8 | 1.0 | LCM Exponential |

**Топ-5 ключевых слов по влиянию на качество:**
1. **"8k"** — макс детализация (файл 2.5MB vs 2.0MB)
2. **"soft shadows"** — объём, глубина
3. **"photorealistic" + "detailed skin texture"** — кожа не пластик
4. **"pores"** — микротекстура
5. **"detailed eyes"** — живой взгляд

**Производственные тайминги (A5000 24GB):**

| Конфиг | Время/ген | 100 генов | $ |
|--------|-----------|-----------|----|
| Production (50 steps) | 20-25 сек | 33 мин | $0.11 |
| Standard (28 steps) | 8-10 сек | 17 мин | $0.04 |
| Preview (8 steps) | 3-5 сек | 8 мин | $0.02 |

### 2.3 Post-Processing Chain

```
Base Gen (Lustify_apexV8)
    ↓
Detail Daemon (0.45-0.55)
    ↓
VAE Decode
    ↓
FaceDetailer (yolov8x-face, denoise 0.3)
    ↓
4x-UltraSharp upscale
    ↓
B2 Upload → gen_tests/{date}/ или generations/{char}/{date}/
```

Альтернативы: SUPIR IncreDetail, Clarity Upscaler (открытый Magnific ⭐5K), FaceFusion (⭐28.8K).

### 2.4 SDXL LoRA Stack — полная верификация

**Проверено через CivitAI API. Только SDXL 1.0.**

| LoRA | Вес | CivitAI ID | Загрузки | Эффект |
|------|-----|-----------|----------|--------|
| Touch of Realism V2 | 0.5-1.0 | 1705430 | ~19K | 🔥 Реализм |
| ClearHandsXL v2 | 0.55-0.65 | 132884 | — | 🔥 Руки |
| Perfect Eyes XL | 0.5-0.6 | 118427 | — | Глаза |
| Polyhedron_all SDXL | 0.4-0.55 | 135160 | — | Комбо |
| Add Detail - Slider SDXL | 0.55-0.65 | 1333749 | ~10K | Детализация |
| DetailN_XL | 0.55-0.65 | 1317134 | — | Детализация |
| Skin Texture style | 0.5-0.55 | 580857 | ~28K | Кожа |
| Detailed Perfection | 0.45-0.55 | 411088 | ~124K | 🔥 Гиперреализм |
| Hand Fixer XL | 0.5-1.0 | 845407 | — | Руки |

**НЕ SDXL (не использовать):**
- nsfw_master (Flux)
- aesthetic_quality_modifiers (Pony)
- body_type_slider (Pony)
- ReaLora (SD1.5)
- RealSkin_xxXL_v1 (Pony)
- eye_concept_SDXL_v1 (Pony)
- Detail_Slider (Pony)

### 2.5 Face LoRA Bootstrap

**Цель:** 35-50 изображений для LoRA.

**Стек бутстрапа:**
- InstantID (ip=1.0, cn=0.7)
- IP-Adapter FaceID Plus v2 (ip=0.5, fid=1.2)
- Lustify_apexV8, CFG=4.0, 832×1216, нейтральный промпт

**Параметры тренировки Face LoRA:**

| Параметр | Face LoRA | Body LoRA |
|----------|-----------|-----------|
| rank | 48 | 64 |
| alpha | 24 | 64 |
| LR UNet | 8e-5 | 5e-5 |
| LR TE | 0 | — |
| Датасет | 25-40 отобранных | 90-120 |
| Регуляризация | 80-150 | — |
| Resolution | 1024×1024 | 832×1216 |
| Batch size | 2-4 | 1-2 |

**Финал identity weights (06 Jul 2026):** `fd05_12` = ip_weight=0.5, weight_faceidv2=1.2

---

## 3. ИТЕРАТИВНЫЙ ПРОТОКОЛ ГЕНЕРАЦИИ

**Жёсткое правило: НИКОГДА не батчить 50+.**

```
Цикл: Gen 1 → CHECK → adjust → Gen next → repeat
```

**Временные рамки:**
- Генерация: ~30 секунд
- Анализ: ~5 секунд
- Общий цикл: <60 секунд

**Правила:**
- Random seeds (`random.randint(1, 999999)`), никогда не 42/69/100
- Менять промпт каждые 2-3 генерации
- Макс разрешение 1024×1280 (4:5)
- На лучших результатах → пост-процессинг → B2
- Никаких "а давай забатчим 50 и проверим" — только парами

---

## 4. B2 GOLDEN ARCHIVE STRUCTURE

**Bucket:** `ALEX.STORAGE`

```
deploy_bundle/
├── golden_comfyui_base.tar.zst   — 240MB  (ComfyUI код + Python deps)
├── golden_nodes.tar.zst          — 144MB  (Impact Pack + WAS + KJNodes)
├── golden_models.tar.zst         — 23.5GB (Lustify_apexV8 + LoRA + VAE + CLIP)
├── golden_deploy.sh              — 4KB
└── golden_config.md              — SFW/NSFW стек, PuLID patch
```

**Generation output structure:**
```
b2://ALEX.STORAGE/
├── generations/{character}/{date}/
│   ├── raw/
│   ├── upscaled/
│   ├── final/
│   └── metadata.json
└── gen_tests/{date}/
```

**Deploy timeline (A5000, B2 CDN ~300MB/s):**
1. rclone config: 2s
2. Download base+nodes parallel: 5s (375MB)
3. Download models: 60-90s (23.5GB)
4. Extract archives: 20-40s
5. Verify + start ComfyUI: 5s
**TOTAL: ~2 min to production-ready ComfyUI** 🚀

---

## 5. МАСШТАБИРУЕМЫЕ СТРАТЕГИИ

### 5.1 Multi-Character Production

**3+ персонажа (girl + milf + trans):**
- Total face images: ~240
- Total body images: ~300
- Total time: 24-36 hours
- RunPod cost: ~$2-4

### 5.2 RunPod Пул

| GPU | $/ч | Назначение |
|-----|-----|-----------|
| **A5000 24GB** | $0.16 | **Основной** (ComfyUI inference) |
| RTX 3090 24GB | $0.22 | Резерв |
| RTX 4090 24GB | $0.34 | Только LoRA training |

**Template:** `2lv7ev3wfp`, image `runpod/comfyui:cuda13.0`, cloud `COMMUNITY`, disk 50GB.

**Деплой ТОЛЬКО через deploy_pod.py, терминация ТОЛЬКО через terminate_pod.py.** Никаких SDK/curl/stop_pod ad-hoc.

### 5.3 Vision QA Workflow

После каждой батч-генерации — качественный контроль через Gemini 2.5 Flash:

```
rate_faces.py pipeline:
  1. Каждое изображение → Gemini 2.5 Flash vision API
  2. Рейтинг 1-10 (10 = идеальный AI референс)
  3. Сортировка по папкам /my_gens_ratings/{rating}/
  
  Ожидаемое распределение (~110 images):
    7-8: основная масса (60%)
    9-10: топ (10-15%)
    1-5: брак (25%)
```

### 5.4 Виральная контент-стратегия

Из анализа @zoomergirls__ и @0xKiyoro:

| Фактор | Вес |
|--------|-----|
| Первый пост (алгоритмический буст) | ⭐⭐⭐⭐⭐ |
| Частота постинга 5+/день | ⭐⭐⭐⭐ |
| Минимум текста (1-5 слов) | ⭐⭐⭐ |
| **Смена формата каждые 60 дней** | ⭐⭐⭐⭐⭐ |
| Comparative framing ("X moggs Y") | ⭐⭐⭐⭐⭐ |
| Geo-diversity (разные этносы) | ⭐⭐⭐ |

**Decay trap:** @zoomergirls__ упал с 64K до 400 лайков (-99.4%) за 8 месяцев — аудитория устаёт от одного формата.

### 5.5 Монетизационная воронка

```
X/TikTok/IG → Telegram (free) → Telegram (premium) → Fanvue/Boosty
```

**Цены:**

| Уровень | Цена | Контент |
|---------|------|---------|
| Free | $0 | Размытые превью, общение |
| Low | $4.99-7.99/мес | Полная лента + базовый чат |
| Premium | $9.99-14.99/мес | Эксклюзивы + PPV |
| VIP | $19.99-49.99/мес | Весь контент + custom |

**PPV:**
- Фото: $3-10
- Сет (5-10): $10-25
- Видео 1-3мин: $10-20
- Custom фото: $25-50
- Custom видео: $50-150

---

## 6. ТЕХНИЧЕСКИЕ ПИТФОЛЛЫ (из реальных сессий)

### ComfyUI API
- **BasicScheduler** обязательно с `denoise: 1.0` — иначе HTTP 400 `required_input_missing, denoise`
- **DetailDaemonSamplerNode** требует ВСЕ поля: `exponent, start_offset, end_offset, fade, smooth, cfg_scale_override`
- **LatentUpscale** обязательно с `crop: "disabled"` — иначе HTTP 400
- **SamplerCustom** требует ALL полей: model, add_noise, noise_seed, cfg, positive, negative, sampler, sigmas, latent_image

### LoRA
- Файлы < 1MB (особенно 0-byte) — битые (106-byte rate-limit ответ), удалять из стека
- Clip strength = model_strength * 0.8
- Порядок загрузки LoRA важен — UNet обрабатывает top-to-bottom

### Модели
- DMD2 (8 steps, CFG 1.0) — ТОЛЬКО для быстрых превью/тестов. НЕ для production.
- Lustify_apexV8 поддерживает Pony scores (`score_9, score_8_up`)

### Безопасность
- **Все картинки → B2 FIRST** — никогда только локально
- CapCut: Crop edges → Add grain 2-5% → Bump brightness +10% → Bump sharpness +15%
- ExifTool — стрип метаданных обязательно
- Stripping metadata = защита от детекта AI платформами

---

**Связанные страницы в Vault:**
- 01-WIKI/AI Influencer Pipeline.md
- 01-WIKI/Checkpoint Parameters.md
- 01-WIKI/ControlNet_IPAdapter_PuLID.md
- 01-WIKI/ComfyUI.md
- 01-WIKI/B2 Storage.md
- 03-PROJECTS/2026-07-06-face-lora-bootstrap.md
