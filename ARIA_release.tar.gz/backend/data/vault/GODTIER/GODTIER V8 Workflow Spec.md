---
tags: [wiki, runpod, sdxl, lora, godtier, n8n, b2, deploy, comfyui]
created: 2026-07-06
---
# GODTIER V8 — ComfyUI Workflow Spec

> Полный пайплайн генерации. SDXL Big Love стек.
> Версия: 1.0
> Дата: 2026-06-27

---

## 📐 Архитектура воркфлоу

```
                    STAGE 0 — ПРЕПРОДАКШН
┌─────────────────────────────────────────────┐
│ 360° датасет (110+ фото) → Depth/OpenPose   │
│ → Face embeddings → Captioning (WD14+Florence)│
│ → Character Sheet (3-5 эталонных листа)     │
└─────────────────────────────────────────────┘
                         ↓
┌─────────────────────────────────────────────┐
│           PHASE A — ОБУЧЕНИЕ LoRA           │
│ Face LoRA (rank=32) + Body LoRA (rank=64)   │
│ + DMD2 LoRA → Валидация 10 промптов         │
└─────────────────────────────────────────────┘
                         ↓
Stage 1 ──────────┐
BASE GENERATION    │
(Big Love SDXL)    │
                   ▼
Stage 2 ──────────┐
CONTROLNET STACK  │
(Zoe+OpenPose     │
+Canny+Tile)      │
                   ▼
Stage 3 ──────────┐
FACE PRESERVATION │
(PuLID+IPAdapter  │
+FaceDetailer)    │
                   ▼
Stage 4 ──────────┐
LoRA STACK        │
(face+body+hands  │
+skin+body_slider │
+nsfw+dmd2)       │
                   ▼
Stage 5 ──────────┐
POST-PROCESSING   │
(Detailer+Clarity │
+FaceFusion+Color)│
                   ▼
Stage 6 ──────────┐
CONTENT PIPELINE  │
(кадрирование под │
соцсети+caption)  │
                   ▼
              ⚡ OUTPUT
```

---

## 📦 Stage 1: Base Generation

**Цель:** Генерация базового изображения

### Ноды
```
[1] Checkpoint Loader
  ├─ ckpt_name: bigLove_photo6.safetensors
  ├─ (альтернативы: bigLove_photo5, bigLove_ultra3, Lustify_apexV8)
  └─ output: MODEL, CLIP, VAE

[2] CLIP Text Encode (Positive)
  ├─ text: "biglove_photo, (masterpiece, best quality:1.2),
  │         photorealistic, detailed skin texture,
  │         [subject], [pose], [expression],
  │         cinematic lighting, soft shadows, Depth of field"
  └─ input: CLIP → [1]

[3] CLIP Text Encode (Negative)
  ├─ text: "worst quality, low quality, blurry, ugly,
  │         distorted, deformed, bad anatomy,
  │         extra limbs, fused fingers, watermark, text"
  └─ input: CLIP → [1]

[4] KSampler
  ├─ model: MODEL → [1]
  ├─ positive: → [2]
  ├─ negative: → [3]
  ├─ latent_image: Empty Latent Image
  ├─ sampler_name: dpmpp_2m_karras
  ├─ scheduler: karras
  ├─ steps: 28
  ├─ cfg: 4.5
  ├─ denoise: 1.0
  ├─ seed: random
  └─ width: 832 | height: 1216
  └─ output: LATENT

[5] VAE Decode
  ├─ samples: LATENT → [4]
  ├─ vae: VAE → [1]
  └─ output: IMAGE

[6] Empty Latent Image
  ├─ width: 832
  ├─ height: 1216
  └─ batch_size: 1
```

**Production параметры (из тестов CivitAI — подтверждённые):**
| Параметр | DMD2 (быстрая gen) | SDXL Production | Photo5 (DMD2) |
|---|---|---|---|
| Sampler | dpmpp_2m_sde_gpu | **DPM++ 2M SDE** ❗ | LCM |
| Steps | 4-8 | **50** ❗ | 8 |
| CFG | 1.0 | **7** ❗ | 1 |
| Resolution | 1024×1496 | **1024×1496** ❗ | — |
| Scheduler | — | Exponential | Exponential |
| FreeU V2 | b1=1.3, b2=1.4, s1=0.9, s2=0.2 | b1=1.3, b2=1.4, s1=0.9, s2=0.2 | — |

> ⚠️ **Критично:** Без SDE кожа пластиковая. 25 steps не хватает — нужно 50. CFG 4.5 слишком низкий — 7 даёт контраст. 832×1216 мелко — 1024×1496 минимум.

---

## 📦 Stage 2: Multi-ControlNet

**Цель:** Контроль позы, композиции, глубины

### Ноды
```
[7] ControlNetLoader
  ├─ control_net_name: xinsirUnionProMax_v10.safetensors
  └─ output: CONTROL_NET

[8] ZoeDepth Preprocessor
  ├─ image: reference_image
  └─ output: IMAGE (depth)

[9] OpenPose Preprocessor
  ├─ image: reference_image  
  └─ output: IMAGE (pose)

[10] Canny Preprocessor
  ├─ image: reference_image
  ├─ low_threshold: 100
  ├─ high_threshold: 200
  └─ output: IMAGE (edge)

[11] ControlNetApply (Depth)
  ├─ conditioning: → [2]
  ├─ control_net: → [7]
  ├─ image: → [8]
  ├─ strength: 0.6
  └─ output: CONDITIONING

[12] ControlNetApply (Pose)
  ├─ conditioning: → [11]
  ├─ control_net: → [7]
  ├─ image: → [9]
  ├─ strength: 0.8
  └─ output: CONDITIONING

[13] ControlNetApply (Canny)
  ├─ conditioning: → [12]
  ├─ control_net: → [7]
  ├─ image: → [10]
  ├─ strength: 0.3
  └─ output: CONDITIONING → [4]
```

**ControlNet веса:**
| Модель | Weight | Назначение |
|---|---|---|
| ZoeDepth | 0.6 | Контроль глубины, композиции |
| OpenPose | 0.8 | Контроль позы (самый важный) |
| Canny | 0.3 | Края, структура |
| Tile (upscale) | 0.5 | Только для апскейла |

---

## 📦 Stage 3: Face Preservation

**Цель:** Сохранение лица персонажа (3 слоя)

### Ноды
```
[14] PuLID Loader
  ├─ model: pulid_sdxl.safetensors  
  ├─ clip: → [1] (CLIP)
  └─ output: PuLID_MODEL

[15] PuLID Apply
  ├─ model: → [14]
  ├─ conditioning: → [2]
  ├─ image: face_reference
  ├─ weight: 0.5-0.8
  ├─ mode: "Fidelity"
  └─ output: CONDITIONING → [4]
       (или → [11] после CLIP)

[16] IPAdapter FaceID Loader
  ├─ model: ip-adapter-faceid-plusv2_sdxl.safetensors
  ├─ lora: ip-adapter-faceid-plusv2_sdxl_lora.safetensors
  └─ output: IPADAPTER_MODEL

[17] IPAdapter Apply
  ├─ model: → [16]
  ├─ image: face_reference
  ├─ weight: 0.7-1.0
  ├─ weight_type: "original"
  └─ output: → [4] (samples)

[18] FaceDetailer (Post-Gen)
  ├─ image: → [5] or final IMAGE
  ├─ detector: face_yolov8m.pt
  ├─ model: CodeFormer (fidelity: 0.7-0.9)
  ├─ guide_size: 512
  ├─ max_size: 1024
  ├─ noise: 0.25
  ├─ mask_dilation: 20
  └─ output: IMAGE (fixed face)
```

**Слои защиты лица:**
| Слой | Инструмент | Вес | Точность |
|---|---|---|---|
| 1 | PuLID SDXL | 0.5-0.8 | 90-95% |
| 2 | IP-Adapter FaceID | 0.7-1.0 | 95-98% |
| 3 | FaceDetailer CodeFormer | 0.7-0.9 | 99%+ |

---

## 📦 Stage 4: LoRA Stack

**Цель:** Персонажные и вспомогательные LoRA

### Ноды
```
[19] LoRALoader (char_face)
  ├─ model: MODEL → [1]
  ├─ lora_name: {char}_face_lora_v1.safetensors
  ├─ strength_model: 0.6-0.8
  ├─ strength_clip: 0.6-0.8
  └─ output: MODEL, CLIP

[20] LoRALoader (char_body)
  ├─ model: → [19] MODEL
  ├─ lora_name: {char}_body_lora_v1.safetensors
  ├─ strength_model: 0.4-0.6
  ├─ strength_clip: 0.4-0.6
  └─ output: MODEL, CLIP

[21] LoRALoader (hands)
  ├─ model: → [20] MODEL
  ├─ lora_name: hands_xl.safetensors
  ├─ strength_model: 0.6-0.8
  └─ output: MODEL

[22] LoRALoader (skin)
  ├─ model: → [21] MODEL
  ├─ lora_name: realistic_skin_texture.safetensors
  ├─ strength_model: 0.4-0.6
  └─ output: MODEL

[23] LoRALoader (body_slider)
  ├─ model: → [22] MODEL
  ├─ lora_name: body_type_slider_pony_v1.safetensors
  ├─ strength_model: 0.5-1.0 (0=худой, 1=полный)
  └─ output: MODEL

[24] LoRALoader (nsfw)
  ├─ model: → [23] MODEL
  ├─ lora_name: nsfw_master.safetensors
  ├─ strength_model: 0.5-0.8
  └─ output: MODEL

[25] LoRALoader (dmd2)
  ├─ model: → [24] MODEL
  ├─ lora_name: dmd2_lora.safetensors
  ├─ strength_model: 1.0 (только для 8-шаговой gen)
  └─ output: MODEL → [4]
```

**LoRA стек (порядок важен!):**
| Очерёдность | LoRA | Strength | Назначение | Источник |
|---|---|---|---|---|
| 1 | char_face_lora | 0.6-0.8 | Лицо персонажа | Обучение |
| 2 | char_body_lora | 0.4-0.6 | Тело персонажа | Обучение |
| 3 | hands_xl (⭐289K) | 0.6-0.8 | Качество рук | CivitAI |
| 4 | realistic_skin_texture (⭐166K) | 0.4-0.6 | Детализация кожи | CivitAI |
| 5 | body_type_slider_pony_v1 (⭐70.9K) | 0.5-1.0 | Контроль телосложения | CivitAI |
| 6 | nsfw_master (⭐202K) | 0.5-0.8 | Усиление NSFW | CivitAI |
| 7 | dmd2_lora | 1.0 | 8-шаговая gen (опц.) | CivitAI |

> ⚠️ **Важно:** `aesthetic_quality_modifiers` и `nsfw_master` (старый) **НЕ РАБОТАЮТ** под SDXL 1.0 (см. [[LoRA Dataset Guide]]). Используй `nsfw_master` только если он SDXL-версия. ДЛЯ SDXL: `touch_of_realism_v2` для реализма.

---

## 📦 Stage 5: Post-Processing

**Цель:** Апскейл, фикс деталей, цветокоррекция

### Ноды
```
[24] DetailDaemon
  ├─ image: → [5] or Stage1 output
  ├─ strength: 0.3-0.5
  ├─ radius: 2
  └─ output: IMAGE

[25] Tile ControlNet Apply (Upscale)
  ├─ conditioning: → [2]
  ├─ image: → [24]
  ├─ strength: 0.5
  └─ scene: latent upscale

[26] Ultimate SD Upscale
  ├─ image: → [25]
  ├─ model: 4x-UltraSharp.pth
  ├─ scale: 2
  ├─ tile_width: 512
  ├─ tile_height: 512
  └─ output: IMAGE (2x upscaled)

[27] FaceDetailer (Post-Upscale)
  ├─ image: → [26]
  ├─ detector: face_yolov8m.pt
  ├─ fidelity: 0.7-0.9
  └─ output: IMAGE (final)

[28] ColorMatch
  ├─ image: → [27]
  ├─ reference: reference_image
  ├─ strength: 0.3
  └─ output: IMAGE → SAVE
```

**Post-processing цепочка:**
```text
RAW gen → DetailDaemon (0.3-0.5) → Tile CN → 2x UltraSharp
    → FaceDetailer (CodeFormer 0.8) → ColorMatch
    → (NEW) Clarity Upscaler (2-4x) → (NEW) FaceFusion Face Restore
    → (NEW) Кадрирование под соцсети (X: 1200×675, IG: 1080×1080)
    → (NEW) Caption (стиль: 1-5 слов)
    → FINAL
```

### Новые компоненты (из V8 Deploy Plan)

**Clarity Upscaler** ⭐5K (GitHub) — open-source Magnific аналог
- ComfyUI нод: `ComfyUI-ClarityAI`
- Легче SUPIR (~2 GB vs 6 GB)
- Качество выше SUPIR в некоторых случаях

**FaceFusion** ⭐28.8K (GitHub) — замена CodeFormer
- Face Enhance + Color Transfer
- Face Swap (Reference лицом)
- Активен, обновляется
- Установка: `git clone https://github.com/facefusion/facefusion`

---

## ⚙️ Параметры по типам контента

### Girl (девушка, SFW/soft)
| Параметр | Значение |
|---|---|
| Checkpoint | Big Love Photo6 |
| Resolution | 832×1216 |
| Sampler | DPM++ 2M Karras, 28 steps, CFG 4.5 |
| LoRAs | char_face 0.7, char_body 0.5, hands 0.7, skin 0.5, aesthetic 0.8 |
| ControlNet | Depth 0.6, OpenPose 0.8, Canny 0.3 |

### Milf
| Параметр | Значение |
|---|---|
| Checkpoint | Big Love Photo6 или Lustify_apexV8 |
| Resolution | 832×1216 |
| Sampler | DPM++ 2M Karras, 25 steps, CFG 4.0 |
| LoRAs | char_face 0.6, char_body 0.5, skin 0.6, aesthetic 0.7 |

### Trans (NSFW explicit)
| Параметр | Значение |
|---|---|
| Checkpoint | **Lustify_apexV8** (лучший для explicit) |
| Resolution | 1600×2048 или 1024×1536 |
| Sampler | DPM++ 2M Karras, 28 steps, CFG 4.5 |
| LoRAs | char_face 0.7, char_body 0.6, hands 0.8, nsfw_master 0.6 |

### Portrait (лицо крупно)
| Параметр | Значение |
|---|---|
| Checkpoint | Big Love Photo6 |
| Resolution | 1024×1024 (square) |
| Sampler | DPM++ 2M Karras, 30 steps, CFG 5.0 |
| LoRAs | char_face 0.8, aesthetic 0.9 |
| ControlNet | Depth 0.4, OpenPose 0.5 (мягче) |

---

## 🏗️ Структура генерации

```
📁 generations/
  ├── girl_01/
  │   ├── raw/           ← до пост-процессинга
  │   ├── upscaled/      ← после апскейла
  │   ├── final/         ← готовые к публикации
  │   └── metadata.json  ← промпты, seed, параметры
  ├── milf_01/
  │   └── ...
  └── trans_01/
      └── ...
```

---

## 🔄 Mass Gen Pipeline (для сотен изображений)

```python
# Псевдокод для массовой генерации
for character in [girl_01, milf_01, trans_01]:
    for pose in poses_database:
        for expression in expressions:
            # 1. Загрузить референс (позу, лицо)
            # 2. Сгенерировать через ComfyUI API
            # 3. Проверить качество (FaceDetailer score)
            # 4. Сохранить: raw / upscaled / final
            # 5. Записать metadata
            pass
    
    # После набора dataset → OneTrainer LoRA
    # face_lora = train(face_dataset)
    # body_lora = train(body_dataset)
```

**Скорость:** ~15 сек/image на RTX 4090 (production)
**Стоимость:** ~$0.01/image на RunPod (бесплатно на локальном ПК)

---

## 🎬 Stage 6: Video Generation (WAN2.1 + PuLID)

**Из воркфлоу `FACE to VIDEO_WAN2.1.json` (90 нодов):**

```
=== PuLID блок (3 нода) ===
PulidFluxModelLoader → pulid_flux_v0.9.0.safetensors
PulidFluxInsightFaceLoader → InsightFace (детекция лица)
PulidFluxEvaClipLoader → CLIP vision для лица
ApplyPulidFlux → ПРИМЕНЯЕТ PuLID к генерации

=== WAN Video блок ===
UnetLoaderGGUFDisTorchMultiGPU → UNet (GGUF/Q8_0)
WanImageToVideo → из фото → видео
WanVideoTeaCacheKJ → TEA CACHE (ускорение на 40%)
RIFE VFI → интерполяция кадров
CFGZeroStar → Zero Star (улучшение анатомии)
SkipLayerGuidanceWanVideo → слой-by-слой управление
TorchCompileModelWanVideo → компиляция для скорости

=== Пост-процессинг ===
UpscalerTensorrt → TRT апскейл
```

**Необходимые модели для видео:**
- Wan2.1-I2V-14B-480P GGUF (city96/HF)
- pulid_flux_v0.9.0.safetensors
- umt5_xxl_fp8_e4m3fn_scaled.safetensors (CLIP)
- clip_vision_h.safetensors

---

## 🤖 Automation Tools (из V8 Deploy Plan)

| Инструмент | ⭐ | Назначение | Установка |
|---|---|---|---|
| **ECC (everything-claude-code)** | 116K | Агент-харнес: skills + instincts + security | `git clone affaan-m/everything-claude-code` |
| **Free Claude Code** | 18.8K | Claude API бесплатно (OpenRouter/DeepSeek) | `git clone Alishahryari1/free-claude-code` |
| **n8n-MCP** | 16.9K | Claude → n8n через MCP бэкенд | `git clone czlonkowski/n8n-mcp` |
| **Crawl4AI** | 67.4K | Веб-краулер → чистый Markdown | `pip install crawl4ai` |
| **BROWSER-USE** | — | Claude управляет браузером | browser-use.com |
| **FaceFusion** | 28.8K | Замена CodeFormer | `git clone facefusion/facefusion` |
| **Clarity Upscaler** | 5K | Magnific аналог | ComfyUI нод |

---

## 📝 Content Pipeline (для соцсетей)

После генерации каждое изображение проходит:
1. **Кадрирование** под соцсети (X: 1200×675, IG: 1080×1080)
2. **Добавление подписи** в стиле @zoomergirls__ (1-5 слов)
3. **Сохранение** в `/output/{char}/{date}/`
4. **Заливка** на B2 (rclone)

Форматы caption:
- `"random (ethnicity) girl moggs all of them"`
- `"concept: (style descriptor)"`
- `"growing really fond of (outfit) selfies lately"`
- `"sucks to be u"`
- `"(name) >"`

---

## Связи
- [[GODTIER V8]] — пайплайн
- [[SDXL Big Love]] — чекпоинты
- [[ComfyUI]] — ноды, фиксы
- [[RunPod]] — где запускается
- [[B2 Storage]] — хранение
- [[GODTIER V8 Project Spec]] — проект мониторинга
- [[AI Видео Генерация]] — сравнение видео-моделей
