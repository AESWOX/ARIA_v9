---
status: archived
tags: [legacy-audit]
---
# Legacy RUNTIME (Flux/PuLID) — Архив

> Полный аудит старого Flux-пайплайна из `RUNTIME.rar`.  
> **Историческая справка** — для возможного реюза отдельных функций.  
> **Актуальный стек: SDXL, InstantID, Big Love.**

- [`01-runtime-legacy-audit-full.md`](01-runtime-legacy-audit-full.md) — часть 1: orchestrator, stage0, phaseA, phaseB, ref_regen
- [`02-runtime-legacy-audit-part2-full.md`](02-runtime-legacy-audit-part2-full.md) — часть 2: конфиги, GPU profiles, патчи, различия с SDXL
