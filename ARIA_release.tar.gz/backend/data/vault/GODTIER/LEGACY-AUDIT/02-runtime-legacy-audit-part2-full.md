---
status: archived
tags: [legacy-audit]
---
# runtime_legacy_audit_part2

Источник: `RUNTIME.rar` (`https://www.genspark.ai/api/files/s/7kDVE7DP`) + первый проход `runtime_legacy_audit.md` (`https://www.genspark.ai/api/files/s/aAh4qMWq`).

Область: только фактическое поведение кода/конфигов legacy-пайплайна. Без повторного разворачивания anatomy/explicit prompt-builder веток, явно исключённых в ТЗ.

## Ограничения чтения архива

- `phaseA_face_lora.py` в распакованном архиве синтаксически обрезан на конце: исходник читается до строки `5421`, после `parse_args()` файл обрывается; `ast.parse` падает на `unterminated string literal` в хвосте файла.
- Из-за этого блок завершения `phaseA_face_lora.py` (последние строки `parse_args()/entrypoint/main`) описан по наблюдаемым вызовам, логам и доступным функциям, а не по целому хвосту исходника.
- `MASTER-POD-CHECKLIST.md` в архиве отсутствует. Найдены только `INSIGHTFACE_FIX_GUIDE.md` и `SETUP_FIRST.md`; отдельного checklist-файла нет.
- В этом проходе зафиксированы только проверяемые факты из текущего архива, логов и уже извлечённых фрагментов.

## 1) godtier_v7_core.py — недоразобранные сущности

### [choose_interactively]
- **Назначение:** ручной выбор одного файла-кандидата из списка путей.
- **Триггер:** вызывается в `stage0_references.py`, когда `auto_select == False` для `ref_face`, `ref_hands`, `ref_body_sfw`, `ref_body_nsfw`.
- **Вход → выход:** `Sequence[Path]`, `title` → один `Path`.
- **Побочные эффекты:** печать списка в stdout; циклический `input()` до корректного выбора.
- **Магические числа / константы:** нумерация с `1`; пустой ввод = взять первый путь.
- **Edge cases:**
  - пустая строка не означает «reject all», а автоматически возвращает `paths[0]`; ручного «отклонить всех кандидатов» режима нет;
  - невалидный индекс/нечисловой ввод печатает `Invalid input. Try again.` и повторяет цикл;
  - при ручном режиме блок не перегенерируется автоматически: функция только выбирает из уже существующего списка.

### [best_candidate]
- **Назначение:** автоматический ранжирующий выбор лучшего PNG-кандидата.
- **Триггер:** Stage0 (`face/hands/body_sfw/body_nsfw`) и Phase B (`selected_image, scoring_table = best_candidate(...)`).
- **Вход → выход:** `candidates`, `InsightFaceEngine scorer`, `logger`, опционально `reference_path`, `similarity_weight` → `(best_path, sorted_table)`.
- **Побочные эффекты:** логирование полной JSON-таблицы кандидатов.
- **Критерий скоринга:**
  - база — `scorer.score_quality(path)`;
  - если передан `reference_path` и файл существует, добавляется `scorer.similarity(candidate, reference)`;
  - итог: `quality*(1-similarity_weight) + similarity*similarity_weight`; без `reference_path` итог = `quality`;
  - отдельного CLIP-скоринга нет; явного `embedding distance` нет — используется нормализованный dot product между embedding-ами InsightFace, т.е. cosine-подобная similarity.
- **Что именно входит в `quality`:** вычисляется `InsightFaceEngine.score_quality()` и уже содержит `det_score`, `sharpness`, `symmetry`, `size_ratio`, `center_score`, `eye_level_score`, плюс информационные `yaw_balance`, `pitch_ratio`, `face_count`.
- **Пороги / отсечение:** внутри `best_candidate()` жёсткого rejection-threshold нет; функция всегда сортирует и возвращает top-1. Пропуск/ремонт/отбраковка происходят уровнем выше (`verification_similarity_threshold`, `face_correction_similarity_threshold`, QC в `ref_regen.py`, SFW skin gate в bust-ветке).
- **Edge cases:**
  - пустой список кандидатов → `PipelineError`;
  - ошибка similarity для отдельного файла только логируется warning-ом, кандидат остаётся в таблице с `similarity=None`;
  - ручного повторного прогона при плохом результате сама функция не делает.

### [VramGovernor]
- **Назначение:** лёгкий VRAM-gate между тяжёлыми стадиями.
- **Внутреннее состояние (`self.*`):**
  - `self.comfy` — `ComfyUIClient`, задаётся в `__init__`;
  - `self.logger`;
  - `self.min_free_mb` — целевой порог свободной VRAM;
  - `self.sleep_seconds` — стандартный sleep после flush;
  - `self.gpu_id` — номер GPU для `nvidia-smi`.
- **Источник данных о VRAM:** только `nvidia-smi --query-gpu=memory.free`; ни `torch.cuda.memory_*`, ни `/system_stats` ComfyUI для измерения free VRAM класс не использует.
- **Публичные методы:**
  - `flush(next_stage)` — общий pre-stage flush.
- **`flush()` делает последовательно:**
  1. `self.comfy.free_memory()`;
  2. если доступен CUDA: `torch.cuda.empty_cache()`, `torch.cuda.ipc_collect()`, попытка `torch.cuda.reset_peak_memory_stats()`;
  3. `gc.collect()`;
  4. `sleep(self.sleep_seconds)`;
  5. один замер через `_query_free_vram()`;
  6. если VRAM ниже порога — wait-loop до `120` секунд, шаг `10` секунд, на каждом шаге снова `free_memory()/empty_cache()/ipc_collect()/gc.collect()/sleep(10)` и новый замер.
- **`flush("phaseB")` vs обычный flush:** специальной ветки по имени стадии нет; аргумент используется только в лог-сообщении `preparing stage ...`.
- **Недостижение `vram_min_free_mb`:** после `120` секунд логируется error `proceeding anyway`; динамического снижения batch/candidates/steps класс не делает.
- **Retry/throttling:** не число попыток, а time-based loop: до `12` циклов по `10` секунд после первичной очистки.
- **Edge cases:** сбой `nvidia-smi` → warning и немедленный выход без блокировки; исключения CUDA cleanup не фатальны.

### [InsightFaceEngine]
- **Назначение:** обёртка над InsightFace для детекции лиц, эмбеддингов, similarity, quality-score и face-mask generation.
- **Внутреннее состояние (`self.*`):** `model_name`, `logger`, `ctx_id`, `provider`, `_app` (lazy-loaded `FaceAnalysis`).
- **Модель и загрузка:** `FaceAnalysis(name=self.model_name, providers=[...])`, `prepare(det_size=(640,640), det_thresh=0.15)`. Дефолтное имя модели выше по стеку — `cfg["models"].get("face_analysis_model", "buffalo_l")`; жёстко зашитой `antelopev2` в этом классе нет.
- **CPU/GPU provider:** конфигурируемый. Если `provider == "CUDA"`, используются `CUDAExecutionProvider + CPUExecutionProvider`, иначе только `CPUExecutionProvider`.
- **Публичные методы:**
  - `detect(image_bgr)` — multi-attempt detection: base, resize до `1280`, padding `0.12/0.20/0.30`, плюс resize+padded варианты;
  - `read_image(path)`;
  - `largest_face(image_bgr)`;
  - `embedding_from_path(path)` — берёт largest face, нормализует embedding;
  - `similarity(source_path, target_path)` — `np.dot(a, b)` между нормализованными embedding-ами;
  - `score_quality(path)` — quality метрика для `best_candidate`;
  - `create_face_mask(...)` — маска для face/body inpaint.
- **Использование в скоринге:** `best_candidate()` использует `score_quality()` и опционально `similarity()`; сам класс не знает порогов, пороги задают вызывающие скрипты.
- **Формула `score_quality`:** `(det_score*0.26 + sharpness*0.25 + symmetry*0.16 + min(area_ratio/0.20,1.0)*0.10 + center_score*0.12 + eye_level_score*0.11) * face_count_penalty`.
- **`score_quality` info-only поля:** `yaw_balance`, `pitch_ratio`, `face_count`.
- **Edge cases:** отсутствие лица → нулевой словарь метрик; отсутствующий embedding → `PipelineError`; fallback detection логирует, если сработал не base-case.

### [build_flux_workflow]
- **Назначение:** базовый Flux txt2img-builder для Stage0/простых reference-generation веток.
- **Вход → выход:** config + positive/negative + size/seed/steps/guidance + LoRA/PuLID опции → `workflow: Dict[str, Any]` для ComfyUI.
- **Полный граф нод (по порядку):**
  1. `DualCLIPLoader` (`clip_l`, `t5xxl`, type=`flux`);
  2. `UNETLoader` (`models["flux_dev_unet"]`, `weight_dtype="default"`);
  3. `VAELoader`;
  4. `CLIPTextEncodeFlux` positive (`clip_l=short_clip_text(positive)`, `t5xxl=positive`, `guidance=guidance`);
  5. `CLIPTextEncodeFlux` negative (`guidance=1.0`);
  6. `EmptyLatentImage` (`batch_size=1`);
  7. `KSampler` (`cfg=1.0`, sampler/scheduler из `cfg.stage0.generation`, `denoise=1.0`);
  8. `VAEDecode`;
  9. `SaveImage`.
- **LoRA-цепочка:** поверх `UNETLoader` последовательно, если заданы: `detail_lora` → `face_lora` → `bust_breast_lora` → `extra_lora`; каждый через `LoraLoaderModelOnly`, обновляя `model_input` для `KSampler`.
- **PuLID-интеграция:** если `reference_image_name` не пустой и `pulid_weight > 0`, добавляются:
  - `LoadImage(reference)`;
  - `PulidFluxModelLoader(pulid_file=models["pulid_model"])`;
  - `PulidFluxEvaClipLoader()`;
  - `PulidFluxInsightFaceLoader(provider=cfg.models.insightface_provider|CPU)`;
  - `ApplyPulidFlux(model=model_input, pulid_flux, eva_clip, face_analysis, image, weight, start_at, end_at)`.
- **Face/hands vs body(SFW) различие:** внутри `build_flux_workflow()` отдельных веток `face/hands/body` нет; различие задают параметры вызова (prompt, negative, LoRA set, `pulid_weight`, size, steps). Для full-body pose generation в Phase B используется уже не эта функция, а отдельный `build_body_union_workflow()`.

## 2) ref_regen.py — полный доступный разбор

### [RefRegen.__init__]
- **Назначение:** инициализация standalone reference-regeneration сценария.
- **Внутреннее состояние (`self.*`):** `args`, `cfg`, `ref`, `out`, `logger`, `comfy`, `governor`, `scorer`. `self.ref` и `self.out` резолвятся сразу, `self.out` создаётся на диске.
- **Триггер:** `RefRegen(args).run()`.
- **Побочные эффекты:** создаёт output-dir, логгер, подключается к ComfyUI, ждёт `wait_ready()`, логирует LoRA stacks.
- **Магические числа:** `timeout_seconds` default `2400`, `poll_interval` `1.5`, `vram_min_free_mb` fallback `10000`, sleep fallback `8`.
- **Edge cases:** отсутствующий референс → `PipelineError`.

### [RefRegen.phase_esrgan]
- **Назначение:** подготовка исходного референса: ESRGAN 4x + square crop до `1024x1024`.
- **Триггер:** `run()` при фазе `all` либо явной части, где нужен base image.
- **Вход → выход:** `self.ref` → `out/esrgan_4x.png` (после `_smart_square_crop` тот же путь перезаписывается).
- **Побочные эффекты:** upload исходника в ComfyUI, workflow `_esrgan_workflow`, flush `"ESRGAN"`, запись PNG.
- **Edge cases:** если файл уже существует и `--force` не задан — reuse без перегенерации.

### [RefRegen._smart_square_crop]
- **Назначение:** центрированный square-crop по лицу после ESRGAN.
- **Логика:** ищет лицо через `self.scorer.detect`; при успехе центрует квадрат по `face_cy`, иначе берёт центральный crop; затем resize в `1024x1024` через `INTER_LANCZOS4` и перезаписывает исходный файл.
- **Edge cases:** `cv2.imread == None` → возвращает путь без изменений; отсутствие лица не фатально.

### [RefRegen._face_detail_pass / _tight_face_detail_pass]
- **Назначение:** два последовательных detail-pass по лицу после txt2img варианта.
- **Широкий pass:** padding примерно `0.9 * face_w/h`, crop → `1024x1024`, workflow `_face_detail_workflow(mode="detail")`.
- **Tight pass:** padding примерно `0.45 * face_w/h`, crop size из `ref_regen.tight_crop_size` (default `896`), workflow `_face_detail_workflow(mode="tight")`.
- **Возврат:** тот же `src_path`, перезаписанный refined-версией через `_paste_face_back()`.
- **Побочные эффекты:** временные `_crop_*`, `_out_*`, `_tcrop_*`, `_tout_*` файлы; их удаление после успеха.
- **Edge cases:** отсутствие лица, ошибка ComfyUI, нечитаемый tmp output → только warning и skip refinement.

### [RefRegen.phase_variants]
- **Назначение:** standalone генерация цифровых face-вариантов из референса через PuLID txt2img; это не дубликат `stage0.generate_candidates()`, а отдельный сценарий «digitize/regen real photo».
- **Когда запускается относительно Stage0/PhaseA/PhaseB:** по `RUN_MARCO.sh all` идёт **до** Stage0 (`Step 1/4: ref_regen`, затем `stage0`, `phaseA`, `phaseB`). Отдельно доступен и через UI endpoint `/api/run/ref_regen`.)
- **Вход → выход:** `count` (default `20`) → список rows по `variants/variant_XX.png`.
- **Промпт:** `_build_positive_prompt(cfg)` собирает строку из `filmfotos`, `ref_regen.skin_pores`, `character.hair`, `character.eyes`, `character.lips`, `character.face_shape`, `character.skin`, `ref_regen.lighting`, `ref_regen.clean`, `ref_regen.quality`; negative = `cfg.ref_regen.negative` (default `""`).
- **QC-критерии:** `_qc_check()` использует `score_quality()`, порог `MIN_QC_SCORE = 0.38`; bad flags = `{"blurry", "weak_detection", "face_too_large", "over_smoothing"}`. Если `score >= 0.38` и bad flags нет → вариант считается OK.
- **Retry:** до `MAX_RETRIES = 3` попыток на каждый индекс; при fail сохраняется лучший score среди попыток, даже если QC не пройден.
- **После выбора лучшей попытки:** копирование во `variant_XX.png`, затем подряд `_face_detail_pass()` и `_tight_face_detail_pass()` с новыми random seed.
- **Edge cases:** если все попытки провалились — row с `path=None`, `score=0.0`, `qc_ok=False`.

### [RefRegen.phase_final_upscale]
- **Назначение:** финальный upscale только для `qc_ok` вариантов.
- **Вход → выход:** `variants_rows` → `upscaled/up_variant_XX.png` rows.
- **Апскейл-метод:** внутренний `_flux_controlnet_upscale_workflow()` с `FLUX.1-dev-ControlNet-Union-Pro-2.0.safetensors`, task-type upscale, x2-path; параметры по умолчанию: `upscale_denoise=0.38`, `upscale_steps=28` из `ref_regen` блока конфига.
- **Побочные эффекты:** workflow dump в `_debug_wf_*.json`, flush на каждый upscale.
- **Edge cases:** если нет ни одного `qc_ok`, upscale целиком пропускается.

### [RefRegen.run / CLI]
- **CLI аргументы:** `--char`, `--ref`, `--config`, `--out`, `--phase {all,variants,upscale}`, `--count`, `--force`.
- **Несоответствие с launcher:** `RUN_MARCO.sh` вызывает `python3 ref_regen.py --config $CONFIG --character $CHAR`, тогда как `parse_args()` в самом `ref_regen.py` знает аргумент `--char`, а не `--character`. В текущем архиве это наблюдаемый CLI mismatch.
- **Manifest:** `regen_manifest.json` с полями `variants`, `variants_total`, `qc_pass`, `qc_fail`, `upscaled`; stdout summary печатает `out/manifest/total/qc_pass/qc_fail`.

## 3) Legacy GPU-профили и плавающие настройки

### [phaseA_face_lora._detect_gpu]
- **Источник детекции:** только `torch.cuda` (`get_device_name`, `get_device_properties.total_memory`). `nvidia-smi` fallback для определения профиля здесь не используется.
- **Сначала match по имени карты, затем fallback по VRAM:** H100/A100/A6000/A5000/4090/3090 и др. распознаются по `name_upper`; если не совпало — profile назначается порогами `>=75000`, `>=38000`, `>=28000`, `>=22000`, `>=14000`, `>=10000` MB.
- **Явные карты из ТЗ:**
  - `A5000` → profile `rtx_24gb`;
  - `3090` / `3090 Ti` → `rtx_24gb`;
  - `4090` → `rtx_24gb`;
  - `A100` < `70000` MB → `a100_40`, иначе `h100`;
  - `H100` → `h100`.

### [phaseA_face_lora._GPU_PROFILES]
| profile | карты/класс | vram_min_free_mb | sleep_between_heavy_models_seconds | post_run_sleep_s | sfw_nsfw_transition_sleep_s | bust_steps | bust_guidance | bust_candidates | detail_lora_strength | pulid_gen_weight |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| h100 | H100 / A100 80GB | 20000 | 4 | 1 | 3 | 35 | 3.6 | 4 | 0.24 | 0.56 |
| a100_40 | A100 40GB / A6000 | 16000 | 5 | 2 | 4 | 35 | 3.6 | 4 | 0.23 | 0.56 |
| rtx_24gb | 3090 / 4090 / A5000 | 12000 | 12 | 3 | 8 | 38 | 3.75 | 3 | 0.13 | 0.50 |
| rtx_20gb | 20GB-class | 10000 | 14 | 4 | 10 | 30 | 3.5 | 3 | 0.20 | 0.52 |
| rtx_16gb | 3080 Ti / 4080 / 5070 Ti / A4000 | 8000 | 16 | 5 | 12 | 28 | 3.4 | 2 | 0.18 | 0.50 |
| rtx_10gb | 3080 / 4070 Ti / 5070 / 10–12GB | 5000 | 20 | 6 | 15 | 26 | 3.3 | 2 | 0.16 | 0.48 |
| low_vram | <10GB | 3000 | 25 | 8 | 20 | 24 | 3.2 | 1 | 0.14 | 0.46 |
| cpu | CPU | 0 | 5 | 2 | 5 | 20 | 3.0 | 1 | 0.14 | 0.46 |
- **Где применяются:** `apply_gpu_profile(cfg)` патчит `cfg["orchestrator"]`, `cfg["phaseA"]["generation"]`, `cfg["phaseA"]["bust"]`, `cfg["models"]`, а также кэширует весь набор в `cfg["_gpu_profile"]`.
- **Динамика по реальному VRAM:** кроме стартового выбора профиля по `torch`-объёму и runtime flush-проверки в `VramGovernor`, автоматического runtime-downgrade `candidates/steps/batch` по факту текущего free VRAM нет.

## 4) phaseA_face_lora.py — доступный разбор всего файла

### [Общий состав блоков]
- **Явные generation blocks:** `run_emotions`, `run_orbitals`, `run_hairstyles`, `run_bust`, плюс ручные сервисные entry-points `run_inpaint_faces`, `run_inpaint_body`, `run_regen_prompts`.
- **CLI `--block` допускает:** `none | emotions | orbitals | hairstyles | bust | bust_sfw | bust_nsfw | all`.
- **По логам завершения Phase A:** итоговый датасет суммируется по категориям `bust SFW`, `bust NSFW`, `emotions`, `orbitals`, `hairstyles`; после полного прогона экспортируется `exports/face_lora_config.json`.

### [build_face_prompt]
- **Назначение:** основной prompt-builder для face-блоков.
- **Порядок конкатенации:** `eye_lock` → `identity` → `expression_allowance` → `emotion_hint` → `hairstyle` → `extra_details` → `quality_tail`.
- **Особые ветки:** `rolled_eyes`, `lip_bite`, `tongue_out`, `mouth_heavy` меняют lock-логику и expression constraints; при отсутствии hairstyle выбирается случайный character hairstyle.

### [build_orbit_prompt]
- **Назначение:** prompt для orbital-angle блока.
- **Порядок/ветки:** определяется флагами `is_no_face`, `is_side`, `is_angle`; всегда использует `_compose_orbit_camera_lock`, `torso_sync_hint`, quality tail, а в зависимости от типа кадра либо убирает face-priority (rear), либо усиливает side/angle identity constraints.

### [run_emotions]
- **Назначение:** генерация face-датасета по эмоциям.
- **Источник пресетов:** эмоции из YAML (`paths.emotions_file` / `gather_emotions`).
- **Кандидаты:** base default `candidates_per_preset=3`, для heavy/intense эмоций default `4`.
- **PuLID по блоку:** default `pulid_gen_weight = 0.78`; для heavy/calm эмоций пороги прохождения различаются: heavy `0.48`, calm `0.55` similarity.
- **После генерации:** выбирается лучший face candidate, пишется в passed/rejected buckets, caption-ится, добавляется row в manifest.

### [run_orbitals]
- **Назначение:** dataset по углам головы/камеры.
- **Кандидаты:** default `3` на preset.
- **PuLID-логика по типам ракурса:**
  - `back_pure` → `pw = 0.0`;
  - `profile` → `0.22`;
  - `45°` → `0.30`;
  - `high/low angle` → `0.28`;
  - иначе default блока `0.78`.
- **Негативы:** отдельные negative-строки для profile / 45 / high / low / back.
- **После генерации:** best-candidate selection, optional inpaint, caption, manifest row.

### [run_hairstyles]
- **Назначение:** отдельный блок под hairstyle variants.
- **Условия:** если у персонажа нет списка hairstyles — блок пропускается.
- **Параметры:** `pulid_gen_weight` default `0.78`, но внутри bounded `pulid_w ~ 0.34..0.38`; `n >= 4` кандидатов; отдельный `neg_hair` negative.
- **После генерации:** лучший кандидат отбирается similarity-aware ранкером и caption-ится.

### [run_bust]
- **Назначение:** waist-up / bust dataset, включая отдельные SFW и NSFW подпотоки.
- **Важное ограничение по ТЗ:** anatomy/explicit prompt texts не разворачиваются ниже; фиксируются только механика и численные параметры.
- **Доступные по коду механики:**
  - собственный candidate scoring с учётом `det_score`, quality, similarity и skin-ratio;
  - GPU-profile overrides: для 24GB-class код использует шаги/CFG выше, чем для low/16GB классов;
  - SFW nudity-gate: default skin threshold `0.18`, hard cap `0.35`, дополнительные условия `chest_spot <= 0.006`, `lower_skin <= 0.020`; если кандидаты не проходят, запускается reinforced retry с более жёстким opaque-clothing prompt;
  - seed diversification через список праймов `[0, 7919, 15731, 24593, 49157, 98317]`;
  - optional HiRES pass: upscale `x2`, fallback на исходный `832x1216` кадр при ошибке.
- **Структура блоков внутри bust:** код явно содержит SFW пресеты (`14` ключей) и NSFW пресеты (`8` ключей), плюс дополнительные orbital/legs/toy ветки; по логам итоговая Phase A суммаризация выводит отдельные счётчики `bust SFW` и `bust NSFW`.
- **PuLID/identity weights в bust:**`)
- Базовые body weights в начале блока: `pbw_sfw_base = 0.42`, `pbw_nsfw_base = 0.52`.
- Для orbit-углов bust есть `_BUST_ORBIT_ANGLES` с `pulid_face`: `front 0.58`, `left/right_45 0.32`, `left/right_profile 0.24`, `high/low_angle 0.30`, `left/right_rear_135 0.14`, `back_half 0.10`, `back_pure 0.0`.
- `_cap_bust_face_weight()` дополнительно режет face-weight по типу референса: отдельные cap-таблицы для emotion-ref и orbit-ref; например emotion `front 0.52`, `left_45 0.36`, `back_pure 0.0`; orbit caps ещё ниже (`front 0.28`, `left_45 0.16` и т.д.).
- Это отличается от новой SDXL-схемы `identity_weights`: в legacy нет единого controlnet policy-слоя, а веса режутся комбинацией orbit preset + type of reference + SFW/NSFW body/face base weights.

### [Пост-обработка и обучение после Phase A]
- `phaseA_face_lora.py` импортирует `export_onetrainer_config` и `build_training_caption`; логи из `logs/*.log` завершаются строкой `OneTrainer config: .../exports/face_lora_config.json`, а `orchestrator_v7.py` прямо инструктирует после Phase A обучить Face LoRA по `exports/face_lora_config.json` и затем вписать `models.face_lora_name` в unified-config.
- Следовательно, Phase A не запускает сам OneTrainer-тренинг, а **экспортирует JSON-конфиг для внешнего обучения**; затем Phase B потребляет имя уже обученной Face LoRA через `models.face_lora_name`.
- Из-за обрыва хвоста `phaseA_face_lora.py` точная строка вызова `export_onetrainer_config(...)` в исходнике недоступна, но факт экспорта подтверждён логами, импортами, UI-текстами и оркестратором.

## 5) phaseB_body_lora.py — полный читаемый flow

### [main]
- **Назначение:** full-body dataset generation для body LoRA после обучения face LoRA.
- **Зависимость от Phase A:** `face_lora_name = args.face_lora or cfg["models"].get("face_lora_name", "")`; если имя отсутствует → `PipelineError`.
- **Порядок стадий:**
  1. загрузка config/runtime/logger;
  2. resolve `face_lora_name` и `ref_face`;
  3. `ComfyUIClient` + `VramGovernor` + `InsightFaceEngine`;
  4. создание директорий `01_candidates/02_selected/03_corrected/04_verified/05_rejected/06_masks/07_tagged`;
  5. чтение SFW/NSFW pose pairs, группировка по категориям;
  6. построение `jobs` равномерным чередованием категорий по `sfw_count` и `nsfw_count`;
  7. генерация `candidates_per_preset` body-кандидатов на job;
  8. `best_candidate(..., reference_path=ref_face, similarity_weight=phaseB.selection_similarity_weight)`;
  9. при `similarity_before < face_correction_similarity_threshold` — face correction через `build_flux_fill_workflow`;
  10. финальная верификация по `verification_similarity_threshold`;
  11. captioning verified images через Florence-2;
  12. экспорт `exports/body_lora_config.json`.
- **Пороги:**
  - correction-trigger: `phaseB.face_correction_similarity_threshold`;
  - verification gate: `phaseB.verification_similarity_threshold`;
  - minimum verified frames: `phaseB.minimum_verified_frames`, иначе весь Phase B падает `PipelineError`.

### [build_body_union_workflow]
- **Назначение:** основной ComfyUI workflow-builder Phase B.
- **База:** DualCLIP → UNet → VAE → positive/negative encoders → EmptyLatent → ControlNet Union over depth → optional Union over pose → optional Union over json → KSampler → VAEDecode → SaveImage.
- **Фактически используемая комбинация ControlNet в `main()`:** depth всегда включён; pose включается, если у pose-pair есть `pose`-image; JSON-ветка теоретически поддерживается функцией, но из `main()` `json_image_name/json_strength` не передаются, т.е. в текущем flow она не активируется.
- **LoRA-цепочка:** поверх model добавляются `detail_lora` и `face_lora`.
- **Что реально включено по блокам:** Phase B не делит body flow на отдельные именованные blocks как Phase A; различие идёт по `split=sfw/nsfw` и `pose category`, а ControlNet composition определяется доступностью pose/depth файлов и конфиг-параметрами strengths/start/end.

## 6) Конфиги и плейсхолдеры

### [Общая структура]
- По `config_analysis.json` найдено `1690` строковых/числовых записей YAML и `363` уникальных конфиг-ключа верхнего/вложенного уровня по 6 unified-config файлам.
- Файлы `*_profiles.yaml` и `*_defaults.yaml` в архиве **не найдены**; из YAML присутствуют только `unified_config_*.yaml` и `emotions*.yaml`. Значит, в этом архиве профили/дефолты не вынесены в отдельные YAML, а живут либо прямо в unified-config, либо в кодовых `.get(..., default)` fallbacks.

### [Плейсхолдеры]
- `character_id` — встречается в `unified_config_Aiza.yaml:660`; `unified_config_Aiza.yaml:732`; `unified_config_Leyla.yaml:651`; `unified_config_Leyla.yaml:721`; `unified_config_Lila.yaml:511`; `unified_config_Lila.yaml:560`
- `workspace_root` — встречается в `unified_config_Lila.yaml:8`; `unified_config_v11_onebutton.yaml:8`

### [Плоские таблицы unified_config_*.yaml]

#### [unified_config_Aiza.yaml]
| key | type | default / YAML value | где используется |
|---|---|---|---|
| `comfyui.base_url` | `str` | "http://127.0.0.1:8188" |  |
| `comfyui.timeout_seconds` | `int` | 2400 |  |
| `comfyui.poll_interval` | `float` | 1.5 |  |
| `paths.workspace_root` | `str` | "/workspace" |  |
| `paths.config_dir` | `str` | "/workspace/WAR333_GODTIER_OMNI/RUNTIME/config" |  |
| `paths.runtime_root` | `str` | "/workspace/godtier_v7_runtime" |  |
| `paths.emotions_file` | `str` | "/workspace/WAR333_GODTIER_OMNI/RUNTIME/config/emotions.yaml" |  |
| `paths.pose_library_root` | `str` | "/workspace/ComfyUI/poses" |  |
| `paths.sfw_pose_pairs_dir` | `str` | "/workspace/ComfyUI/poses" |  |
| `paths.nsfw_pose_pairs_dir` | `str` | "/workspace/ComfyUI/poses" |  |
| `paths.manual_ref_face` | `str` | "/workspace/godtier_v7_runtime/NovaDoll/stage0/selected/ref_face.png" |  |
| `paths.manual_ref_body_sfw` | `str` | "/workspace/godtier_v7_runtime/NovaDoll/stage0/selected/ref_body_sfw.png" |  |
| `paths.manual_ref_body_nsfw` | `str` | "/workspace/godtier_v7_runtime/NovaDoll/stage0/selected/ref_body_nsfw.png" |  |
| `orchestrator.vram_min_free_mb` | `int` | 12000 |  |
| `orchestrator.sleep_between_heavy_models_seconds` | `int` | 12 |  |
| `models.flux_dev_unet` | `str` | "fluxedUpFluxNSFW_90FP16.safetensors" |  |
| `models.flux_dev_unet_sfw` | `str` | "fluxedUpFluxNSFW_90FP16.safetensors" |  |
| `models.flux_dev_unet_nsfw` | `str` | "fluxedUpFluxNSFW_90FP16.safetensors" |  |
| `models.flux_fill_unet` | `str` | "flux1-fill-dev.safetensors" |  |
| `models.flux_fill_weight_dtype` | `str` | "fp8_e4m3fn" |  |
| `models.flux_dev_unet_path_for_onetrainer` | `str` | "/workspace/ComfyUI/models/unet/fluxedUpFluxNSFW_90FP16.safetensors" |  |
| `models.detail_lora` | `str` | "polyhedron_flux_perfect_skin.safetensors" |  |
| `models.detail_lora_strength` | `float` | 0.52 |  |
| `models.detail_lora_strength_face` | `float` | 0.22 |  |
| `models.detail_lora_strength_body` | `float` | 0.28 |  |
| `models.realism_lora` | `str` | "" |  |
| `models.realism_lora_strength` | `float` | 0.0 |  |
| `models.lips_lora` | `str` | "flxBimboLips963.safetensors" |  |
| `models.lips_lora_strength` | `float` | 0.35 |  |
| `models.bust_breast_lora` | `str` | "Big_natural_breasts_for_FLUX.safetensors" |  |
| `models.bust_breast_lora_strength` | `float` | 0.45 |  |
| `models.bust_breast_lora_strength_sfw` | `float` | 0.0 |  |
| `models.bust_breast_lora_strength_nsfw` | `float` | 0.72 |  |
| `models.vagina_detail_lora` | `str` | "Vagina_HQ-000029.safetensors" |  |
| `models.vagina_detail_lora_strength` | `float` | 0.55 |  |
| `models.face_lora_name` | `str` | "" |  |
| `models.face_lora_strength` | `float` | 0.0 |  |
| `models.controlnet_union` | `str` | "FLUX.1-dev-ControlNet-Union-Pro-2.0.safetensors" |  |
| `models.pulid_model` | `str` | "pulid_flux_v0.9.1.safetensors" |  |
| `models.eva_clip` | `str` | "EVA02_CLIP_E_psz14_s4B.pt" |  |
| `models.face_analysis_model` | `str` | "buffalo_l" |  |
| `models.insightface_provider` | `str` | "CPU" |  |
| `models.vae` | `str` | "ae.safetensors" |  |
| `models.clip_l` | `str` | "clip_l.safetensors" |  |
| `models.t5xxl` | `str` | "t5xxl_fp16.safetensors" |  |
| `models.florence_model_id` | `str` | "microsoft/Florence-2-large" |  |
| `models.florence_device` | `str` | "cpu" |  |
| `character.id` | `str` | "NovaDoll" |  |
| `character.trigger_token` | `str` | "NovaDoll" |  |
| `character.face_anchor` | `str` | "young woman, long medium-brown chestnut hair flowing over shoulders, large expressive grey-green eyes, vivid grey-green irises, wide doe-eye shape, heavy dramatic black winged liner, very long dense black lashes, thick dark brown arched brows, soft round face, delicate small upturned nose, bimbo lips, luscious lips, overfilled plump peachy-nude lips, prominent beauty mole above lip corner, lips closed, mouth shut, doll-face aesthetic, soft cinematic lighting\n" |  |
| `character.flux_identity_priority` | `str` | "same woman from reference photo, exact face geometry, large expressive grey-green eyes with dramatic winged liner, bimbo lips, luscious lips, overfilled plump peachy-nude lips, prominent beauty mole above lip, long medium-brown chestnut hair, natural fair skin, visible pores, realistic portrait photograph\n" |  |
| `character.orbit_face_lock` | `str` | "same woman, large expressive grey-green eyes with winged liner, soft round face, full plump peachy-nude lips, long medium-brown chestnut hair, natural fair skin, visible pores, beauty mole\n" |  |
| `character.hair` | `str` | "long medium-brown chestnut hair, silky texture with subtle warm highlights, soft natural waves, framing face and cascading over shoulders, individual hair strands visible, separated locks, flyaway hairs, realistic hair shine, natural hair volume, hair strands catching light\n" |  |
| `character.eyes` | `str` | "large expressive grey-green eyes, vivid grey-green irises, heavy dramatic black winged eyeliner, very long dense voluminous lashes, thick dark brown arched brows, wide-open doll look\n" |  |
| `character.lips` | `str` | "bimbo lips, luscious lips, overfilled lips, extremely plump oversized lips, heavy lower lip, pronounced cupid bow, soft peachy-nude tone, glossy wet sheen, beauty mole prominently above upper lip corner\n" |  |
| `character.face_shape` | `str` | "soft round face, gently rounded cheeks, delicate small upturned nose, smooth jawline, doll-face aesthetic\n" |  |
| `character.skin` | `str` | "natural fair skin, visible skin pores, realistic skin microrelief, peachy-neutral undertone, skin subsurface scattering, realistic skin depth, fine vellus hair on skin, clean skin, smooth even complexion\n" |  |
| `character.hairstyles` | `list` | ["long medium-brown chestnut hair worn loose and flowing, soft waves, center part", "long medium-brown chestnut hair in sleek high ponytail, face fully exposed", "long medium-brown chestnut hair half-up half-down, loose face-framing strands", "long medium-brown chestnut hair in loose low bun, soft tendrils framing face", "long medium-brown chestnut hair in casual side braid over one shoulder", "long medium-brown chestnut hair in messy bun with loose face-framing strands", "long medium-brown chestnut hair straight and sleek, middle part, hair over one shoulder", "long medium-brown chestnut hair in deep side part, soft curls, old Hollywood glam", "long medium-brown chestnut hair pulled back in tight slick bun, clean minimal look"] |  |
| `character.makeup_variants` | `list` | [{"key": "bare_natural", "label": "bare natural", "prompt": "bare face, clean natural skin, faint natural lip color, barely-there groomed brows, fresh dewy complexion, natural fair skin, visible pores, realistic skin texture\n"}, {"key": "no_makeup_makeup", "label": "no-makeup makeup", "prompt": "no-makeup makeup look, light skin-tone concealer, groomed soft brows, clear lip balm, barely-there mascara, natural healthy glow, matte finish, natural fair skin, visible pores, realistic skin texture\n"}, {"key": "soft_everyday", "label": "soft everyday", "prompt": "soft everyday makeup, light foundation, groomed arched brows, soft warm brown eyeshadow, thin black liner, peachy nude lip gloss, natural fair skin, visible pores, realistic skin texture\n"}, {"key": "office_polished", "label": "office polished", "prompt": "polished office makeup, matte medium-coverage foundation, defined dark brows, neutral taupe eyeshadow, thin precise liner, soft mauve lip, subtle sculpted contour, natural fair skin, visible pores, realistic skin texture\n"}, {"key": "glam_evening", "label": "glam evening", "prompt": "full glam makeup, flawless full-coverage foundation, dramatic smoky eye, thick dramatic winged liner, voluminous false lashes, glossy nude lip, sculpted contour, blinding cheekbone highlight, natural fair skin, visible pores, realistic skin texture\n"}, {"key": "old_hollywood", "label": "old Hollywood glam", "prompt": "old Hollywood glam makeup, porcelain matte skin, classic cat-eye liner, voluminous curled lashes, bold classic red lip, sharply arched brows, matte powder finish, natural fair skin, visible pores, realistic skin texture\n"}, {"key": "editorial_bold", "label": "editorial bold", "prompt": "editorial makeup, strong graphic black liner, bold sculptured brow, monochrome burnt terracotta eyeshadow and matching lip, sharp strong contour, natural fair skin, visible pores, realistic skin texture\n"}, {"key": "club_smoky", "label": "club smoky", "prompt": "heavy club smoky eye, thick smudged black kohl all around eyes, overlined glossy lips, heavy dramatic lashes, dewy skin, intense contour, natural fair skin, visible pores, realistic skin texture\n"}, {"key": "vamp_dark", "label": "vamp dark", "prompt": "dark vamp makeup, deep plum-black eyeshadow, heavy smudged black liner, dark berry almost-black lip, pale porcelain matte foundation, sharp dramatic arched brows, natural fair skin, visible pores, realistic skin texture\n"}, {"key": "wet_glam", "label": "wet glossy glam", "prompt": "wet-look makeup, glass-skin dewy finish, sheer ultra-glossy lip, heavy glossy eyelid, intense lower lash line smudge, blinding liquid highlighter on cheekbones and nose tip, natural fair skin, visible pores, realistic skin texture\n"}, {"key": "overdone_party", "label": "overdone party", "prompt": "overdone party makeup, heavy full-coverage foundation, thick dramatic winged liner, extremely glossy overlined lips, rhinestone inner corner accent, maximalist finish, natural fair skin, visible pores, realistic skin texture\n"}, {"key": "y2k_glossy", "label": "Y2K glossy", "prompt": "Y2K makeup, heavy dark lip liner with frosted pink glossy lip, shimmery pink-silver eyeshadow, thin overplucked pencil brows, sparkle under-eye accent, natural fair skin, visible pores, realistic skin texture\n"}, {"key": "soft_grunge", "label": "soft grunge", "prompt": "soft grunge makeup, smudged black lower liner, lived-in smoky eye, matte dusty rose lip, slightly undone aesthetic, natural fair skin, visible pores, realistic skin texture\n"}, {"key": "e_girl", "label": "e-girl", "prompt": "e-girl makeup, graphic black liner detail with small heart stamp at outer corner, bold voluminous lashes, bitten red lip tint, natural fair skin, visible pores, realistic skin texture\n"}] |  |
| `prompts.quality_tail` | `str` | "RAW photo, shot on Sony A7R V 85mm f1.4, hyperrealistic photograph, sharp focus, fine vellus skin hair visible, visible skin pores, realistic skin microrelief, natural skin tone variation, fine facial details, photorealistic sensor noise, natural film grain, skin subsurface scattering, shallow depth of field soft bokeh, realistic eye catch light, limbal ring, iris detail, individual hair strands sharp, separated hair locks, bare clean ears, undecorated skin, even skin tone, clean complexion" |  |
| `prompts.negative_base` | `str` | "blurry, deformed, bad anatomy, extra limbs, watermark, anime, cartoon, tattoos, plastic skin, airbrushed skin, beauty filter, 3d render, cgi, smooth poreless skin, oversmoothed skin, digital painting, illustration, dark skin, tan skin, small eyes, narrow eyes, waxy skin, doll skin, overprocessed skin, fake skin, rubber skin, freckles, heavy blush, rosy cheeks, overfilled cheeks, pink cheeks, painted hair, hair blob, clumped hair, uniform hair mass, flat hair texture, hair without strands, solid hair block" |  |
| `prompts.face_reference` | `str` | "front-facing portrait, neutral expression, soft cinematic lighting, clean dark background, large expressive grey-green eyes, heavy winged black liner, full plump peachy-nude lips, beauty mole above lip, long medium-brown chestnut hair, natural fair skin, visible pores" |  |
| `prompts.hands_reference` | `str` | "studio hand reference, both hands clearly visible, separated fingers, clean nails, realistic knuckles, natural fair skin, visible pores" |  |
| `prompts.body_reference_sfw` | `str` | "black turtleneck midi dress, thick opaque ribbed knit, high neck, dress stretched across large augmented round 34DD bust, prominent bust silhouette under fabric, full body shot crown to knees, standing upright facing camera, beautiful young woman, natural fair skin, visible pores, long medium-brown chestnut hair, RAW photo Canon EOS R5 35mm f/2.0 ISO 400, natural film grain" |  |
| `prompts.body_reference_nsfw` | `str` | "RAW photo Sony A7R IV 50mm f/1.8 ISO 800, full body shot head to toe, completely nude, beautiful young woman, natural fair skin, visible pores, long medium-brown chestnut hair, large silicone-augmented round breasts 34DD, high round projection, firm round shape, full upper pole, completely shaved intimate area, skin pores, natural skin texture with visible pores, unretouched skin" |  |
| `prompts.body_dataset_sfw` | `str` | "candid upper-body fashion photograph, fully clothed in dense double-layer opaque clothing, secure chest coverage with no exposed skin on torso, clean upper-body framing, natural fair skin, visible pores, long medium-brown chestnut hair, sharp focus, film grain, hyperrealistic photograph" |  |
| `prompts.body_dataset_nsfw` | `str` | "candid upper-body nude photograph, large silicone-augmented round breasts 34DD, high round projection, firm round shape, full upper pole, natural fair skin, visible pores, natural skin texture, sharp focus, film grain" |  |
| `prompts.body_flux_shape_priority` | `str` | "large silicone-augmented round breasts 34DD, high round projection, firm perky lifted shape, full upper pole, significant breast volume, extremely narrow waist, hourglass figure" |  |
| `prompts.body_absolute_lock` | `str` | "consistent breast size and shape across all frames, no breast size variation, no sagging, no flat chest" |  |
| `prompts.body_volume_force` | `str` | "large round breast volume forced, prominent chest, full cleavage depth" |  |
| `prompts.body_anchor_sfw` | `str` | "same woman from uploaded reference, exact face and upper-body proportions from reference, fully clothed upper-body portrait, dense double-layer opaque clothing, chest fully covered, no visible nipple outline, no transparent patches, lower body stays covered, modest waist-up fashion framing" |  |
| `prompts.sfw_flux_guardrails` | `str` | "upper-body portrait, fully clothed in dense double-layer opaque fabric, chest skin fully hidden, no visible nipple outline, no transparent patches, lower body remains covered, coherent anatomy, natural skin texture, hyperrealistic photograph" |  |
| `prompts.nsfw_flux_guardrails` | `str` | "realistic human anatomy, coherent torso, big natural breasts, large augmented round breasts 34DD consistent shape, smooth shaved intimate area, natural fair skin, skin pores" |  |
| `anatomy.candidates_count` | `int` | 10 |  |
| `anatomy.skin_base` | `str` | "natural fair skin, visible skin pores, realistic skin microrelief, skin subsurface scattering, fine vellus hair on skin, natural skin tone variation, unretouched skin\n" |  |
| `anatomy.skin_base_chest` | `str` | "natural fair skin, smooth even skin tone, skin subsurface scattering, soft skin sheen, unretouched skin\n" |  |
| `anatomy.skin_base_lower` | `str` | "natural fair skin, visible skin pores, realistic skin microrelief, skin subsurface scattering, fine vellus hair on skin, subtle veins visible on inner thighs, unretouched skin\n" |  |
| `anatomy.areola.breast_shape` | `str` | "Big natural breasts, large round breasts, high round projection, full upper pole, perky lifted breasts, round firm shape, high chest placement, tight smooth skin\n" |  |
| `anatomy.areola.nipple` | `str` | "pfps, tiny pale pink areola, very small areola diameter, small erect nipple, pointed nipple tip\n" |  |
| `anatomy.ass.shape` | `str` | "large round pear-shaped bubble butt, firm perky buttocks, pronounced deep gluteal fold, round full cheeks, subtle cellulite texture on outer lower buttocks, smooth inner cheek skin, natural gluteal crease\n" |  |
| `anatomy.ass.legs` | `str` | "long athletic legs, slim toned thighs, visible thigh gap, smooth fully shaved legs, no leg hair, toned calves\n" |  |
| `anatomy.spread.legs` | `str` | "long athletic legs, wide spread apart, visible thigh gap, smooth shaved inner thighs, toned leg muscles\n" |  |
| `anatomy.spread.anatomy` | `str` | "completely shaved bare pubic area, zero stubble, plump puffy labia majora, protruding full labia minora slightly visible, small hidden clitoris, soft pink intimate color, closed vaginal opening, realistic vulva anatomy, natural intimate skin folds\n" |  |
| `anatomy.spread.wetness` | `str` | "slightly wet glistening labia, natural intimate moisture, soft specular highlight on wet skin surface, realistic natural lubrication sheen\n" |  |
| `anatomy.anus.description` | `str` | "tight slightly relaxed anus, small natural opening visible, natural puckered skin folds around anus, soft pink-rose color, realistic anal texture, smooth skin around anal area, no hair\n" |  |
| `anatomy.negative` | `str` | "3d render, cgi, digital art, octane render, unreal engine, AI artifact, banding, plastic skin, waxy skin, airbrushed, beauty filter, glass skin, doll skin, deformed body, bad anatomy, bad proportions, extra limbs, cartoon, illustration, anime, watermark, low quality, jpeg artifacts, overexposed, blown highlights, tattoos, tattoo, body art, moles, freckles, stretch marks, tan lines, body hair, pubic hair, armpit hair, leg hair\n" |  |
| `anatomy.negative_areola` | `str` | "3d render, cgi, cartoon, anime, watermark, bad anatomy, moles, freckles, pores, skin spots, skin blemishes, blotchy skin\n" |  |
| `anatomy.anatomy_guidance` | `float` | 4.5 |  |
| `anatomy.lora_stack.areola` | `list` | [{"name": "polyhedron_flux_perfect_skin.safetensors", "weight": 0.55}, {"name": "Big_natural_breasts_for_FLUX.safetensors", "weight": 0.7}] |  |
| `anatomy.lora_stack.ass` | `list` | [{"name": "polyhedron_flux_perfect_skin.safetensors", "weight": 0.3}, {"name": "Vagina_HQ-000029.safetensors", "weight": 0.55}] |  |
| `anatomy.lora_stack.spread` | `list` | [{"name": "polyhedron_flux_perfect_skin.safetensors", "weight": 0.3}, {"name": "Vagina_HQ-000029.safetensors", "weight": 0.55}] |  |
| `stage0.face_reference_count` | `int` | 100 |  |
| `stage0.hands_reference_count` | `int` | 4 |  |
| `stage0.body_reference_count` | `int` | 10 |  |
| `stage0.face_width` | `int` | 1024 |  |
| `stage0.face_height` | `int` | 1024 |  |
| `stage0.hands_width` | `int` | 832 |  |
| `stage0.hands_height` | `int` | 1216 |  |
| `stage0.body_width` | `int` | 832 |  |
| `stage0.body_height` | `int` | 1536 |  |
| `stage0.identity_adapter_weight` | `float` | 0.82 |  |
| `stage0.body_pulid_weight` | `float` | 0.52 |  |
| `stage0.body_pulid_start_at` | `float` | 0.0 |  |
| `stage0.body_pulid_end_at` | `float` | 0.85 |  |
| `stage0.generation.steps` | `int` | 35 |  |
| `stage0.generation.guidance` | `float` | 3.5 |  |
| `stage0.generation.sampler` | `str` | "dpmpp_2m" |  |
| `stage0.generation.scheduler` | `str` | "beta" |  |
| `stage0.generation.negative_sfw` | `str` | "nude, nsfw, topless, bare chest, exposed breasts, nipples, transparent clothing, cleavage gap, underwear only, lingerie, exposed skin on chest\n" |  |
| `stage0.generation.negative_nsfw` | `str` | "3d render, cgi, plastic skin, waxy skin, airbrushed, beauty filter, deformed body, bad anatomy, bad proportions, extra limbs, cartoon, illustration, anime, watermark, low quality, saggy breasts, drooping breasts, ptosis, hanging breasts, flat chest, small breasts, natural breasts, tattoos, moles, freckles, stretch marks, tan lines\n" |  |
| `phaseA.emotion_count` | `int` | 24 |  |
| `phaseA.candidates_per_preset` | `int` | 5 |  |
| `phaseA.candidates_per_preset_heavy` | `int` | 4 |  |
| `phaseA.verification_similarity_threshold` | `float` | 0.53 |  |
| `phaseA.verification_similarity_threshold_heavy` | `float` | 0.48 |  |
| `phaseA.verification_similarity_threshold_calm` | `float` | 0.55 |  |
| `phaseA.auto_face_inpaint_emotions` | `bool` | false |  |
| `phaseA.auto_face_inpaint_bust` | `bool` | false |  |
| `phaseA.auto_body_inpaint_sfw` | `bool` | false |  |
| `phaseA.minimum_verified_frames` | `int` | 190 |  |
| `phaseA.pulid_gen_weight` | `float` | 0.52 |  |
| `phaseA.selection_similarity_weight` | `float` | 0.36 |  |
| `phaseA.orbit_selection_similarity_weight` | `float` | 0.34 |  |
| `phaseA.hairstyle_selection_similarity_weight` | `float` | 0.38 |  |
| `phaseA.emotion_reference_strategy` | `str` | "base_ref_only" |  |
| `phaseA.generation.width` | `int` | 832 |  |
| `phaseA.generation.height` | `int` | 1216 |  |
| `phaseA.generation.steps` | `int` | 45 |  |
| `phaseA.generation.guidance` | `float` | 3.8 |  |
| `phaseA.generation.cfg_scale` | `float` | 1.0 |  |
| `phaseA.inpaint.bbox_padding_ratio` | `float` | 0.12 |  |
| `phaseA.inpaint.mask_feather_px` | `int` | 8 |  |
| `phaseA.inpaint.steps` | `int` | 28 |  |
| `phaseA.inpaint.guidance` | `float` | 3.8 |  |
| `phaseA.inpaint.denoise` | `float` | 0.48 |  |
| `phaseA.inpaint.identity_adapter_weight` | `float` | 0.9 |  |
| `phaseA.inpaint.fusion` | `str` | "mean" |  |
| `phaseA.inpaint.train_step` | `int` | 500 |  |
| `phaseA.captioning.append_quality_tail` | `str` | "RAW photo, hyperrealistic, subsurface scattering, visible skin pores, natural skin texture, film grain" |  |
| `phaseA.captioning.include_raw_caption_blocks` | `list` | ["emotion", "hairstyle", "makeup"] |  |
| `phaseA.liquids_mode.enabled` | `bool` | true |  |
| `phaseA.liquids_mode.tears_text` | `str` | "visible tears, wet lower eyelids, tear tracks on cheeks" |  |
| `phaseA.liquids_mode.drool_text` | `str` | "visible saliva string at lower lip, wet drool on lips and chin" |  |
| `phaseA.liquids_mode.sweat_text` | `str` | "light sweat sheen on skin" |  |
| `phaseA.stress_pack.enabled` | `bool` | true |  |
| `phaseA.stress_pack.intense_tokens` | `list` | ["tension in brow and jaw", "wet lower eyelids", "slightly parted lips", "subtle facial strain"] |  |
| `phaseA.orbit_inpaint.denoise` | `float` | 0.5 |  |
| `phaseA.orbit_inpaint.mask_feather_px` | `int` | 5 |  |
| `phaseA.orbit_inpaint.steps` | `int` | 34 |  |
| `phaseA.orbit_inpaint.guidance` | `float` | 3.8 |  |
| `phaseA.orbit_inpaint.identity_adapter_weight` | `float` | 0.94 |  |
| `phaseA.orbit_inpaint.bbox_padding_ratio` | `float` | 0.1 |  |
| `phaseA.orbit_inpaint.fusion` | `str` | "mean" |  |
| `phaseA.orbit_inpaint.train_step` | `int` | 500 |  |
| `phaseA.orbit_inpaint.auto_apply` | `bool` | false |  |
| `phaseA.orbit_inpaint.apply_to` | `list` | ["orbit_front", "orbit_left_45", "orbit_right_45", "orbit_left_profile", "orbit_right_profile"] |  |
| `phaseA.orbit_prompts` | `list` | [{"key": "orbit_front", "pulid_weight": 0.55, "prompt": "portrait photograph, young woman facing directly forward, both eyes fully visible and symmetrical, shoulders level, soft round face, large expressive grey-green eyes, dramatic winged liner, full plump peachy-nude lips, beauty mole, long medium-brown chestnut hair, natural fair skin, visible pores\n"}, {"key": "orbit_left_45", "pulid_weight": 0.32, "prompt": "portrait photograph, young woman head turned left, right cheek and eye prominent, three-quarter view, large expressive grey-green eye with dramatic winged liner, full plump peachy-nude lips, natural fair skin, visible pores, medium-brown chestnut hair\n"}, {"key": "orbit_left_profile", "pulid_weight": 0.24, "prompt": "strict left profile portrait, only right side of face visible, right eye and nostril in view, clean sharp profile silhouette, expressive grey-green eye with dramatic winged liner visible, full plump lips in profile, delicate nose, natural fair skin, visible pores, medium-brown chestnut hair\n"}, {"key": "orbit_left_rear_135", "pulid_weight": 0.0, "prompt": "portrait from behind and slightly right, back of head in frame, medium-brown chestnut hair from behind, left ear barely visible, nape of neck visible, both shoulder blades in frame\n"}, {"key": "orbit_back", "pulid_weight": 0.0, "prompt": "rear view portrait shot from directly behind, back of head centered, no face visible, medium-brown chestnut hair texture, nape of neck clearly visible, both shoulders symmetrical\n"}, {"key": "orbit_right_rear_135", "pulid_weight": 0.0, "prompt": "portrait from behind and slightly left, back of head in frame, medium-brown chestnut hair from behind, right ear barely visible, nape of neck visible, both shoulder blades in frame\n"}, {"key": "orbit_right_profile", "pulid_weight": 0.24, "prompt": "strict right profile portrait, only left side of face visible, left eye and nostril in view, clean sharp profile silhouette, expressive grey-green eye with dramatic winged liner visible, full plump lips in profile, natural fair skin, visible pores, medium-brown chestnut hair\n"}, {"key": "orbit_right_45", "pulid_weight": 0.32, "prompt": "portrait photograph, young woman head turned right, left cheek and eye prominent, three-quarter view, large expressive grey-green eye with dramatic winged liner, full plump peachy-nude lips, natural fair skin, visible pores, medium-brown chestnut hair\n"}] |  |
| `phaseA.body.candidates_per_shot` | `int` | 4 |  |
| `phaseA.body.selection_similarity_weight` | `float` | 0.58 |  |
| `phaseA.body.use_orbit_reference_chaining` | `bool` | true |  |
| `phaseA.body.generation.steps` | `int` | 38 |  |
| `phaseA.body.generation.guidance` | `float` | 3.75 |  |
| `phaseA.body.generation.sampler` | `str` | "dpmpp_2m" |  |
| `phaseA.body.generation.scheduler` | `str` | "beta" |  |
| `phaseA.body.generation.negative_sfw` | `str` | "nude, nsfw, flat chest, wide shot, face cut off, tattoos, see-through fabric, transparent shirt, visible nipple outline, areola, exposed chest skin, bare hips, visible buttocks, sideboob, underboob, wardrobe malfunction, hands under breasts, hands squeezing chest" |  |
| `phaseA.body.generation.negative_nsfw` | `str` | "bad anatomy, wide shot, face cut off, tattoos, saggy breasts, drooping breasts, ptosis, hanging breasts, flat chest, small breasts, deflated breasts, asymmetric breasts, mismatched breast size, deformed nipples, extra nipples, no nipples, blurry, plastic skin, wax skin, overprocessed, CGI, identity drift, wrong person\n" |  |
| `phaseA.body.inpaint.bbox_padding_ratio` | `float` | 0.08 |  |
| `phaseA.body.inpaint.mask_feather_px` | `int` | 6 |  |
| `phaseA.body.inpaint.steps` | `int` | 22 |  |
| `phaseA.body.inpaint.guidance` | `float` | 4.5 |  |
| `phaseA.body.inpaint.denoise` | `float` | 0.5 |  |
| `phaseA.body.inpaint.identity_adapter_weight` | `float` | 0.9 |  |
| `phaseA.body.inpaint.fusion` | `str` | "mean" |  |
| `phaseA.body.inpaint.train_step` | `int` | 500 |  |
| `phaseA.body.bust.framing` | `str` | "upper body shot, waist-up framing, shoulders and chest visible" |  |
| `phaseA.body.bust.sfw_count` | `int` | 14 |  |
| `phaseA.body.bust.nsfw_count` | `int` | 18 |  |
| `phaseA.body.bust.candidates_per_shot` | `int` | 3 |  |
| `phaseA.body.bust.width` | `int` | 832 |  |
| `phaseA.body.bust.height` | `int` | 1216 |  |
| `phaseA.body.bust.pulid_face_weight` | `float` | 0.72 |  |
| `phaseA.body.bust.pulid_body_weight_sfw` | `float` | 0.42 |  |
| `phaseA.body.bust.pulid_body_weight_nsfw` | `float` | 0.52 |  |
| `phaseA.body.bust.sfw_nudity_threshold` | `float` | 0.12 |  |
| `phaseA.body.bust.orbit_angles` | `list` | [{"key": "front", "framing": "waist-up portrait, head and shoulders fully visible, facing directly forward", "back_type": "", "pulid_face": 0.72, "neg_extra": "", "pos_extra": "fuller bust silhouette under clothing, opaque fabric covering chest"}, {"key": "left_45", "framing": "waist-up portrait, three-quarter left view", "back_type": "", "pulid_face": 0.32, "neg_extra": "frontal face, facing directly at camera, symmetrical face", "pos_extra": "fuller bust silhouette under clothing, opaque fabric covering chest"}, {"key": "right_45", "framing": "waist-up portrait, three-quarter right view", "back_type": "", "pulid_face": 0.32, "neg_extra": "frontal face, facing directly at camera, symmetrical face", "pos_extra": "fuller bust silhouette under clothing, opaque fabric covering chest"}, {"key": "left_profile", "framing": "waist-up portrait, strict left profile", "back_type": "", "pulid_face": 0.24, "neg_extra": "both eyes visible, frontal face, three-quarter view", "pos_extra": "fuller bust silhouette under clothing, opaque fabric covering chest"}, {"key": "right_profile", "framing": "waist-up portrait, strict right profile", "back_type": "", "pulid_face": 0.24, "neg_extra": "both eyes visible, frontal face, three-quarter view", "pos_extra": "fuller bust silhouette under clothing, opaque fabric covering chest"}, {"key": "high_angle", "framing": "waist-up portrait shot from above, camera looking down", "back_type": "", "pulid_face": 0.3, "neg_extra": "eye level portrait, flat perspective", "pos_extra": "fuller bust silhouette under clothing, opaque fabric covering chest"}, {"key": "low_angle", "framing": "waist-up portrait shot from below, camera looking upward", "back_type": "", "pulid_face": 0.3, "neg_extra": "eye level portrait, flat perspective", "pos_extra": "fuller bust silhouette under clothing, opaque fabric covering chest"}, {"key": "left_rear_135", "framing": "rear-left three-quarter upper-body portrait", "back_type": "half", "pulid_face": 0.14, "neg_extra": "frontal face, both eyes visible, facing camera, frontal chest visible", "pos_extra": "back anatomy locked, spine line readable, shoulders aligned"}, {"key": "right_rear_135", "framing": "rear-right three-quarter upper-body portrait", "back_type": "half", "pulid_face": 0.14, "neg_extra": "frontal face, both eyes visible, facing camera, frontal chest visible", "pos_extra": "back anatomy locked, spine line readable, shoulders aligned"}, {"key": "back_half", "framing": "rear three-quarter hip-up portrait", "back_type": "half", "pulid_face": 0.1, "neg_extra": "full frontal face, both eyes visible, facing camera, frontal breasts", "pos_extra": "back anatomy locked, spine line readable, shoulders aligned"}, {"key": "back_pure", "framing": "full rear hip-up portrait, no face visible", "back_type": "pure", "pulid_face": 0.0, "neg_extra": "face visible, any eye visible, front view", "pos_extra": "back anatomy locked, spine line readable, shoulders aligned"}] |  |
| `phaseA.body.bust.sfw_ref_clothing_anchor` | `str` | "fitted black mock-neck long-sleeve top, dense double-layer opaque fabric, chest fully covered with no transparency, secure torso coverage, paired with high-waist opaque bottoms covering hips and lower body\n" |  |
| `phaseA.body.bust.lighting_variants` | `list` | ["soft studio lighting, large diffused key light from left", "warm golden hour window light, side-lit, rim light on hair", "dramatic Rembrandt lighting, strong key from upper right, deep shadows", "overcast outdoor light, soft flat even illumination", "cool blue ambient light, soft backlight glow, slight front fill", "warm orange practical light, cozy indoor atmosphere", "soft natural window light, gentle side shadows, warm indoor atmosphere", "soft butterfly lighting, key light directly above, glamour portrait"] |  |
| `phaseA.body.bust.sfw_outfit_variants` | `list` | ["fitted black mock-neck long-sleeve top, dense double-layer opaque ribbed fabric, high neck, chest fully covered, black high-waist leggings covering hips and buttocks completely", "white fitted turtleneck long-sleeve top, thick opaque knit, high neck fully covering throat, chest completely hidden, white high-waist trousers covering hips and lower body completely", "charcoal grey high-neck athletic long-sleeve, double-layer dense performance fabric, chest fully covered, charcoal high-waist leggings covering hips and glutes completely", "ivory mock-neck long-sleeve ribbed top, smooth thick opaque knit, high neck, torso fully covered, ivory high-waist fitted skirt covering hips and buttocks to mid-thigh", "navy mock-neck long-sleeve knit sweater, thick cable-knit opaque fabric, high neck, chest fully covered, navy high-waist wide-leg trousers covering hips and glutes completely", "burgundy turtleneck long-sleeve top, double-layer opaque stretch fabric, high neck, chest fully covered, burgundy fitted midi skirt covering hips and buttocks to knee", "black mock-neck long-sleeve bodycon dress, dense opaque stretch fabric, high neck, torso fully covered, lower body covered to mid-thigh"] |  |
| `phaseA.body.bust.selection_similarity_weight` | `float` | 0.52 |  |
| `phaseA.body.hairstyle_change_every_angles` | `int` | 2 |  |
| `phaseA.onetrainer.output_model_path` | `str` | "/workspace/onetrainer/outputs/{character_id}_face_v11.safetensors" |  |
| `phaseA.onetrainer.lora_model_name` | `str` | "NovaDoll_face_v11" |  |
| `phaseA.onetrainer.rank` | `int` | 32 |  |
| `phaseA.onetrainer.alpha` | `int` | 32 |  |
| `phaseA.onetrainer.batch_size` | `int` | 1 |  |
| `phaseA.onetrainer.gradient_accumulation_steps` | `int` | 4 |  |
| `phaseA.onetrainer.epochs` | `int` | 7 |  |
| `phaseA.emotions_per_hairstyle` | `int` | 1 |  |
| `phaseA.orbit_emotions` | `list` | ["neutral expression", "skeptical expression", "determined expression", "concerned expression", "teary sad expression", "angry restrained expression", "startled expression", "exhausted stressed expression"] |  |
| `hires_pass.enabled` | `bool` | false |  |
| `hires_pass.upscale_model` | `str` | "RealESRGAN_x2plus.pth" |  |
| `hires_pass.scale` | `float` | 2.0 |  |
| `hires_pass.denoise` | `float` | 0.35 |  |
| `hires_pass.steps` | `int` | 20 |  |
| `hires_pass.guidance` | `float` | 3.5 |  |
| `hires_pass.detail_lora_strength` | `float` | 0.12 |  |
| `hires_pass.apply_to` | `list` | ["all"] |  |
| `hires_pass.skip_if_exists` | `bool` | true |  |
| `phaseB.sfw_count` | `int` | 40 |  |
| `phaseB.nsfw_count` | `int` | 18 |  |
| `phaseB.candidates_per_preset` | `int` | 4 |  |
| `phaseB.selection_similarity_weight` | `float` | 0.55 |  |
| `phaseB.face_correction_similarity_threshold` | `float` | 0.68 |  |
| `phaseB.verification_similarity_threshold` | `float` | 0.65 |  |
| `phaseB.minimum_verified_frames` | `int` | 64 |  |
| `phaseB.generation.width` | `int` | 832 |  |
| `phaseB.generation.height` | `int` | 1216 |  |
| `phaseB.generation.steps` | `int` | 34 |  |
| `phaseB.generation.guidance` | `float` | 3.6 |  |
| `phaseB.generation.sampler` | `str` | "dpmpp_2m" |  |
| `phaseB.generation.scheduler` | `str` | "beta" |  |
| `phaseB.generation.negative_sfw` | `str` | "nude, nsfw, flat chest, wide shot, face cut off, tattoos" |  |
| `phaseB.generation.negative_nsfw` | `str` | "bad anatomy, wide shot, face cut off, tattoos" |  |
| `phaseB.controlnet.pose_strength` | `float` | 0.85 |  |
| `phaseB.controlnet.depth_strength` | `float` | 0.82 |  |
| `phaseB.controlnet.json_strength` | `float` | 0.6 |  |
| `phaseB.controlnet.start_percent` | `float` | 0.0 |  |
| `phaseB.controlnet.end_percent` | `float` | 0.75 |  |
| `phaseB.inpaint.bbox_padding_ratio` | `float` | 0.12 |  |
| `phaseB.inpaint.mask_feather_px` | `int` | 12 |  |
| `phaseB.inpaint.steps` | `int` | 20 |  |
| `phaseB.inpaint.guidance` | `float` | 4.3 |  |
| `phaseB.inpaint.denoise` | `float` | 0.36 |  |
| `phaseB.inpaint.identity_adapter_weight` | `float` | 0.84 |  |
| `phaseB.inpaint.train_step` | `int` | 280 |  |
| `phaseB.onetrainer.output_model_path` | `str` | "/workspace/onetrainer/outputs/{character_id}_body_v11.safetensors" |  |
| `phaseB.onetrainer.lora_model_name` | `str` | "NovaDoll_body_v11" |  |
| `phaseB.onetrainer.rank` | `int` | 64 |  |
| `phaseB.onetrainer.alpha` | `int` | 64 |  |
| `phaseB.onetrainer.batch_size` | `int` | 1 |  |
| `phaseB.onetrainer.gradient_accumulation_steps` | `int` | 6 |  |
| `phaseB.onetrainer.epochs` | `int` | 10 |  |
| `nsfw_anatomy_fix.hair_min_ratio` | `float` | 0.005 |  |
| `nsfw_anatomy_fix.color_blend_strength` | `float` | 0.52 |  |
| `nsfw_anatomy_fix.detail_denoise` | `float` | 0.32 |  |
| `nsfw_anatomy_fix.detail_steps` | `int` | 22 |  |
| `nsfw_anatomy_fix.detail_guidance` | `float` | 3.8 |  |
| `nsfw_anatomy_fix.detail_pulid_weight` | `float` | 0.72 |  |
| `nsfw_anatomy_fix.detail_zone` | `str` | "full_nsfw" |  |
| `outfit_swapper.steps` | `int` | 28 |  |
| `outfit_swapper.guidance` | `float` | 4.6 |  |
| `outfit_swapper.control_mode` | `str` | "depth" |  |
| `outfit_swapper.controlnet_strength` | `float` | 0.92 |  |
| `outfit_swapper.control_start` | `float` | 0.0 |  |
| `outfit_swapper.control_end` | `float` | 0.92 |  |
| `outfit_swapper.pulid_weight` | `float` | 0.75 |  |
| `outfit_swapper.pulid_start_at` | `float` | 0.0 |  |
| `outfit_swapper.pulid_end_at` | `float` | 0.85 |  |
| `outfit_swapper.mask_feather_px` | `int` | 18 |  |
| `outfit_swapper.min_mask_ratio` | `float` | 0.01 |  |
| `outfit_swapper.max_mask_ratio` | `float` | 0.45 |  |
| `outfit_swapper.face_bbox_padding_ratio` | `float` | 0.12 |  |
| `outfit_swapper.face_mask_feather_px` | `int` | 20 |  |
| `outfit_swapper.canny_low_threshold` | `int` | 80 |  |
| `outfit_swapper.canny_high_threshold` | `int` | 180 |  |
| `outfit_swapper.pre_scan_skin_threshold` | `float` | 0.08 |  |
| `outfit_swapper.max_retries` | `int` | 2 |  |
| `outfit_swapper.denoise.min` | `float` | 0.45 |  |
| `outfit_swapper.denoise.max` | `float` | 0.55 |  |
| `outfit_swapper.sfw_filter.enabled` | `bool` | true |  |
| `outfit_swapper.sfw_filter.repair_threshold` | `float` | 0.18 |  |
| `outfit_swapper.sfw_filter.final_flag_threshold` | `float` | 0.3 |  |
| `outfit_swapper.sfw_filter.repair_denoise` | `float` | 0.5 |  |
| `outfit_swapper.sfw_filter.torso_top_frac` | `float` | 0.3 |  |
| `outfit_swapper.sfw_filter.repair_outfit_prompt` | `str` | "ultra-tight black second-skin bodycon top, thick opaque fabric stretched across large round bust, every curve outlined, zero slack, no exposed skin on chest\n" |  |
| `outfit_swapper.segmentation.sam_checkpoint` | `str` | "/workspace/ComfyUI/models/sam/sam_vit_b_01ec64.pth" |  |
| `outfit_swapper.segmentation.sam_model_type` | `str` | "vit_b" |  |
| `outfit_swapper.segmentation.yolo_weights` | `str` | "yolov8n-seg.pt" |  |
| `outfit_swapper.extra_negative` | `str` | "nude, topless, bare chest, exposed nipples, areola, underboob, sideboob, transparent clothing, see-through fabric, no top, open shirt, cleavage gap, underwear only, lingerie, exposed skin on chest above waist, different person, wrong face, identity drift, extra fingers, extra limbs, deformed torso, broken anatomy, small eyes, narrow eyes, tan skin, dark skin\n" |  |
| `outfit_swapper.default_patterns` | `list` | ["bust_sfw_*.png", "orbit_*.png", "full_body*.png", "body_*.png"] |  |
| `outfit_swapper.presets.tight_black` | `str` | "ultra-tight black second-skin bodycon crop top, thick opaque fabric stretched across large round 34DD bust, every curve outlined, zero slack" |  |
| `outfit_swapper.presets.tight_white` | `str` | "ultra-tight white ribbed bodycon top, second-skin opaque fabric, large 34DD bust perfectly shaped, maximum curve definition" |  |
| `outfit_swapper.presets.tight_nude` | `str` | "skin-tight nude-tone seamless bodycon top, thick opaque second-skin fabric, large round bust prominently outlined" |  |
| `outfit_swapper.presets.tight_turtleneck_black` | `str` | "skin-tight black turtleneck, dense opaque ribbed knit stretched across large bust, high neck fully covered, second-skin silhouette" |  |
| `outfit_swapper.presets.tight_turtleneck_grey` | `str` | "ultra-tight grey ribbed turtleneck, thick opaque stretch knit, large round 34DD bust clearly defined" |  |
| `outfit_swapper.presets.tight_dress_black` | `str` | "ultra-tight black bodycon mini dress, thick opaque stretch fabric, large bust and waist curves outlined, second-skin fit" |  |
| `outfit_swapper.presets.tight_dress_red` | `str` | "skin-tight red bodycon dress, dense opaque fabric, large 34DD bust prominently shaped, waist cinched" |  |
| `outfit_swapper.presets.tight_crop_burgundy` | `str` | "ultra-tight burgundy crop top, second-skin opaque fabric, large round bust perfectly outlined" |  |
| `outfit_swapper.presets.bikini_white` | `str` | "tiny white string bikini, minimal triangle top with thin string ties, matching tiny white string bikini bottom, natural fair skin, visible pores, beach" |  |
| `outfit_swapper.presets.bikini_black` | `str` | "tiny black string bikini, small triangle bikini top with thin string ties, matching black micro bikini bottom, natural fair skin, visible pores, beach" |  |
| `outfit_swapper.presets.bikini_red` | `str` | "tiny red string bikini, minimal triangle top, matching red micro string bikini bottom, beach, natural fair skin, visible pores" |  |
| `outfit_swapper.presets.thong_bikini_red` | `str` | "red micro thong bikini, tiny triangle top barely covering nipples, matching red thong bikini bottom, natural fair skin, visible pores" |  |
| `outfit_swapper.presets.one_piece_black` | `str` | "black high-cut one-piece swimsuit, deep plunge V-neckline, high leg cut, thin shoulder straps, natural fair skin, visible pores" |  |
| `outfit_swapper.presets.lingerie_lace` | `str` | "matching black lace bra and panties set, delicate lace with sheer panels, underwire bra, matching lace thong, natural fair skin, visible pores" |  |

#### [unified_config_DIOGO_flux1dev_stack.yaml]
| key | type | default / YAML value | где используется |
|---|---|---|---|
| `comfyui.base_url` | `str` | "http://127.0.0.1:8188" |  |
| `comfyui.timeout_seconds` | `int` | 2400 |  |
| `comfyui.poll_interval` | `float` | 1.5 |  |
| `paths.workspace_root` | `str` | "/workspace" |  |
| `paths.config_dir` | `str` | "/workspace/WAR333_GODTIER_OMNI/RUNTIME_DIOGO/config" |  |
| `paths.runtime_root` | `str` | "/workspace/WAR333_GODTIER_OMNI" |  |
| `paths.emotions_file` | `str` | "/workspace/WAR333_GODTIER_OMNI/RUNTIME_DIOGO/config/emotions_DIOGO_flux1dev_stack.yaml" |  |
| `paths.pose_library_root` | `str` | "/workspace/ComfyUI/poses" |  |
| `paths.sfw_pose_pairs_dir` | `str` | "/workspace/ComfyUI/poses" |  |
| `paths.nsfw_pose_pairs_dir` | `str` | "/workspace/ComfyUI/poses" |  |
| `paths.manual_ref_face` | `str` | "/workspace/WAR333_GODTIER_OMNI/ref/REF.png" |  |
| `paths.manual_ref_body_sfw` | `str` | "" |  |
| `paths.manual_ref_body_nsfw` | `str` | "" |  |
| `orchestrator.vram_min_free_mb` | `int` | 10000 |  |
| `orchestrator.sleep_between_heavy_models_seconds` | `int` | 8 |  |
| `models.flux_dev_unet` | `str` | "flux1-dev.safetensors" |  |
| `models.flux_dev_unet_sfw` | `str` | "flux1-dev.safetensors" |  |
| `models.flux_dev_unet_nsfw` | `str` | "flux1-dev.safetensors" |  |
| `models.flux_fill_unet` | `str` | "flux1-fill-dev.safetensors" |  |
| `models.flux_fill_weight_dtype` | `str` | "fp8_e4m3fn" |  |
| `models.flux_dev_unet_path_for_onetrainer` | `str` | "/workspace/ComfyUI/models/unet/flux1-dev.safetensors" |  |
| `models.detail_lora` | `str` | "fluxtrait_flux1dev_v2.safetensors" |  |
| `models.detail_lora_strength` | `float` | 0.75 |  |
| `models.detail_lora_strength_face` | `float` | 0.87 |  |
| `models.detail_lora_strength_body` | `float` | 0.58 |  |
| `models.realism_lora` | `str` | "" |  |
| `models.realism_lora_strength` | `float` | 0.0 |  |
| `models.male_skin_lora` | `str` | "polyhedron_flux_perfect_skin.safetensors" |  |
| `models.male_skin_lora_strength` | `float` | 0.3 |  |
| `models.stubble_lora` | `str` | "skin_pores_detail_flux.safetensors" |  |
| `models.stubble_lora_strength` | `float` | 0.28 |  |
| `models.lips_lora` | `str` | "" |  |
| `models.lips_lora_strength` | `float` | 0.0 |  |
| `models.bust_breast_lora` | `str` | "" |  |
| `models.bust_breast_lora_strength` | `float` | 0.0 |  |
| `models.bust_breast_lora_strength_sfw` | `float` | 0.0 |  |
| `models.bust_breast_lora_strength_nsfw` | `float` | 0.0 |  |
| `models.vagina_detail_lora` | `str` | "" |  |
| `models.vagina_detail_lora_strength` | `float` | 0.0 |  |
| `models.face_lora_name` | `str` | "DIOGO_face_v1.safetensors" |  |
| `models.face_lora_strength` | `float` | 0.52 |  |
| `models.controlnet_union` | `str` | "FLUX.1-dev-ControlNet-Union-Pro-2.0.safetensors" |  |
| `models.pulid_model` | `str` | "pulid_flux_v0.9.1.safetensors" |  |
| `models.eva_clip` | `str` | "EVA02_CLIP_E_psz14_s4B.pt" |  |
| `models.face_analysis_model` | `str` | "buffalo_l" |  |
| `models.insightface_provider` | `str` | "CPU" |  |
| `models.vae` | `str` | "ae.safetensors" |  |
| `models.clip_l` | `str` | "clip_l.safetensors" |  |
| `models.t5xxl` | `str` | "t5xxl_fp16.safetensors" |  |
| `models.florence_model_id` | `str` | "microsoft/Florence-2-large" |  |
| `models.florence_device` | `str` | "cpu" |  |
| `character.id` | `str` | "DIOGO" |  |
| `character.trigger_token` | `str` | "DIOGO" |  |
| `character.face_anchor` | `str` | "adult man, same person as reference, near-black very dark brown wavy hair, medium length hair reaching ears and nape, messy voluminous crown, loose natural wave, thick unruly dark eyebrows, dark brown deep-set heavy-lidded eyes with a sleepy brooding gaze, straight broad nose with rounded tip and medium-wide nostrils, full short boxed beard connected to mustache, dense beard on chin and jaw and softer density on cheeks, oval-to-round full masculine face with soft full cheeks, strong jawline hidden under beard, thick neck, broad shoulders, warm medium olive skin tone, visible skin pores, realistic unretouched skin" |  |
| `character.flux_identity_priority` | `str` | "same man from reference photo, exact facial structure and likeness, dark brown heavy-lidded deep-set eyes, thick dark brows, near-black wavy voluminous messy hair, full short boxed black beard, oval-to-round full masculine face, soft full cheeks, straight broad nose with rounded tip, warm medium olive skin with visible pores, realistic candid portrait photograph, thick neck, broad shoulders, stocky masculine build" |  |
| `character.orbit_face_lock` | `str` | "same man, preserve exact facial geometry, preserve brow thickness, preserve heavy-lidded dark brown eyes, preserve beard density and hairline, preserve nose width and rounded tip, preserve cheek fullness, preserve warm olive skin and visible pores" |  |
| `character.hair` | `str` | "near-black very dark brown hair, wavy and slightly curly, medium length to ears and nape, messy and voluminous on top, natural lift at the crown, unstyled authentic texture, loose strands visible, realistic hair separation, no slick gel finish" |  |
| `character.eyes` | `str` | "dark brown eyes, heavy-lidded upper eyelids, slightly sleepy intense gaze, deep-set masculine eye shape, thick dark eyebrows, realistic iris detail, no bright hazel or green tint" |  |
| `character.lips` | `str` | "natural masculine lips, medium fullness, neutral natural color, upper lip partly framed by mustache, no gloss, no makeup" |  |
| `character.face_shape` | `str` | "oval-to-round full masculine face, soft full cheeks, broad forehead, strong jaw mass under beard, straight broad nose, no narrow angular fashion-model face" |  |
| `character.skin` | `str` | "warm medium olive skin tone, visible open pores on cheeks and nose, realistic skin microrelief, subtle natural T-zone sheen, unretouched real skin, natural tonal variation, fine vellus hair" |  |
| `character.beard` | `str` | "full short boxed black beard, dense on chin and jawline, connected mustache, moderate cheek density with natural upper cheek edge, realistic beard strands, clean but not over-groomed" |  |
| `character.hairstyles` | `list` | ["near-black wavy messy hair with strong crown volume, authentic unstyled look", "near-black wavy hair pushed slightly back, loose strands falling forward naturally", "near-black wavy hair with softer side volume and fuller crown", "near-black slightly damp wavy hair, natural separation and texture", "near-black tousled side-parted wavy hair, casual realistic styling", "near-black wavy hair lifted from forehead, airy crown volume", "near-black messy medium-length waves with visible nape length"] |  |
| `character.grooming_variants` | `list` | [{"key": "full_beard", "label": "full short boxed beard", "prompt": "full short boxed black beard, dense on chin and jaw, connected mustache, natural cheek taper, realistic beard strands, warm olive skin, visible pores"}, {"key": "short_beard", "label": "short trimmed beard", "prompt": "short trimmed black beard with natural edges, even medium coverage on jaw chin and cheeks, masculine clean look, warm olive skin, visible pores"}, {"key": "heavy_beard", "label": "heavy fuller beard", "prompt": "fuller heavier black beard with extra chin density, rugged masculine beard growth, natural cheek taper, warm olive skin, visible pores"}, {"key": "stubble_only", "label": "dense dark stubble", "prompt": "dense dark stubble only, strong beard shadow over jaw chin and cheeks, rugged masculine face, warm olive skin, visible pores"}, {"key": "clean_shaven", "label": "clean shaven", "prompt": "clean shaven masculine face, exact same facial structure, broad nose, heavy-lidded dark eyes, warm olive skin, visible pores"}] |  |
| `prompts.quality_tail` | `str` | "RAW photo, shot on Sony A7R V, hyperrealistic photograph, realistic skin pores, skin microrelief, natural tonal variation, fine facial detail, visible beard strands, authentic hair separation, subtle sensor noise, natural film grain, shallow depth of field, unretouched realistic portrait" |  |
| `prompts.negative_base` | `str` | "blurry, deformed, bad anatomy, extra limbs, watermark, anime, cartoon, tattoos, plastic skin, airbrushed skin, beauty filter, 3d render, cgi, oversmoothed skin, poreless skin, digital painting, illustration, pale skin, grey skin, rubber skin, doll skin, woman, female, feminine features, breasts, makeup, lipstick, thin face, narrow nose, slim build, no beard, beard removed, shaved jaw, green eyes, blue eyes, hazel eyes, amber eyes" |  |
| `prompts.face_reference` | `str` | "front-facing portrait, neutral or brooding expression, soft controlled lighting, dark brown heavy-lidded eyes, thick eyebrows, full short boxed beard, near-black wavy messy medium-length hair, broad straight nose with rounded tip, warm medium olive skin, visible pores, broad-necked stocky masculine build" |  |
| `prompts.hands_reference` | `str` | "studio hand reference, both hands visible, realistic knuckles, natural male hands, warm olive skin tone, visible pores, wide masculine fingers" |  |
| `prompts.body_reference_sfw` | `str` | "fitted black crew-neck t-shirt, clean opaque cotton fabric, broad shoulders, thick neck, stocky masculine physique, full-body or 3/4 body photo, standing upright, warm olive skin, near-black wavy hair, full beard, realistic casual photograph" |  |
| `prompts.body_reference_nsfw` | `str` | "realistic adult male anatomy, large stocky masculine build, broad shoulders, thick chest, natural body hair, warm medium olive skin, near-black wavy hair, full beard" |  |
| `prompts.body_dataset_sfw` | `str` | "candid upper-body fashion photo, fully clothed adult male, broad shoulders and thick chest, realistic modern outfit, warm olive skin, near-black wavy hair, film grain" |  |
| `prompts.body_dataset_nsfw` | `str` | "candid upper-body nude male photograph, broad stocky chest, thick torso, natural chest hair, warm olive skin, full beard, realistic skin texture, sharp focus" |  |
| `prompts.body_flux_shape_priority` | `str` | "large stocky male physique, broad shoulders, thick chest, thick neck, naturally larger frame, masculine proportions, not slim or lean" |  |
| `prompts.body_absolute_lock` | `str` | "consistent large stocky male physique across all frames, consistent broad shoulder width, consistent thick chest and neck, no feminization, no slimming, preserve full beard and face likeness" |  |
| `prompts.body_anchor_sfw` | `str` | "same man from uploaded reference, exact face and upper-body proportions from reference, fully clothed upper-body portrait, clean modern male outfit, broad waist-up framing showing wide shoulders" |  |
| `prompts.sfw_flux_guardrails` | `str` | "upper-body portrait, fully clothed male in modern outfit, coherent anatomy, natural skin texture, hyperrealistic photograph, masculine proportions, large stocky build" |  |
| `prompts.nsfw_flux_guardrails` | `str` | "realistic male anatomy, coherent torso, large stocky masculine build, warm olive skin, visible pores, full beard, authentic proportions" |  |
| `anatomy.candidates_count` | `int` | 8 |  |
| `anatomy.skin_base` | `str` | "warm medium olive skin, visible skin pores, realistic skin microrelief, skin subsurface scattering, fine vellus hair on skin, natural warm olive-brown skin tone variation, unretouched skin, full black beard texture\n" |  |
| `anatomy.skin_base_chest` | `str` | "warm olive skin, natural skin tone, skin subsurface scattering, soft natural skin sheen, unretouched skin, natural chest hair visible\n" |  |
| `anatomy.skin_base_lower` | `str` | "warm olive skin, visible skin pores, realistic skin microrelief, skin subsurface scattering, fine vellus hair on skin, natural masculine leg hair, unretouched skin\n" |  |
| `anatomy.chest.shape` | `str` | "broad thick male chest, wide pectoral muscles, naturally larger stocky male torso, authentic non-athletic build, warm olive skin, natural chest hair\n" |  |
| `anatomy.abs.shape` | `str` | "naturally rounded stomach, not flat abs, authentic stocky male torso, natural soft muscle under layer of natural body fat, olive skin, realistic male torso anatomy, authentic non-fitness-model physique\n" |  |
| `anatomy.nsfw.description` | `str` | "large stocky male nude, tasteful artistic nude, realistic male anatomy, natural proportions, warm olive skin, masculine physique, full black beard\n" |  |
| `anatomy.negative` | `str` | "3d render, cgi, digital art, octane render, unreal engine, AI artifact, plastic skin, waxy skin, airbrushed, beauty filter, doll skin, deformed body, bad anatomy, bad proportions, extra limbs, cartoon, illustration, anime, watermark, low quality, tattoos, feminine features, woman, female, breasts, female anatomy, thin face, slim build, no beard, hazel eyes, amber eyes" |  |
| `anatomy.negative_male` | `str` | "woman, female, feminine, breasts, long hair, makeup, lipstick, nail polish, feminine face structure, female body, female anatomy, slim thin face, angular jaw, no beard, hazel eyes, amber eyes\n" |  |
| `anatomy.anatomy_guidance` | `float` | 4.0 |  |
| `anatomy.lora_stack.chest` | `list` | [{"name": "", "weight": 0.0}] |  |
| `stage0.face_reference_count` | `int` | 60 |  |
| `stage0.hands_reference_count` | `int` | 4 |  |
| `stage0.body_reference_count` | `int` | 8 |  |
| `stage0.face_width` | `int` | 1024 |  |
| `stage0.face_height` | `int` | 1024 |  |
| `stage0.hands_width` | `int` | 832 |  |
| `stage0.hands_height` | `int` | 1216 |  |
| `stage0.body_width` | `int` | 832 |  |
| `stage0.body_height` | `int` | 1536 |  |
| `stage0.identity_adapter_weight` | `float` | 0.85 |  |
| `stage0.body_pulid_weight` | `float` | 0.68 |  |
| `stage0.body_pulid_start_at` | `float` | 0.0 |  |
| `stage0.body_pulid_end_at` | `float` | 0.85 |  |
| `stage0.generation.steps` | `int` | 25 |  |
| `stage0.generation.guidance` | `float` | 3.5 |  |
| `stage0.generation.sampler` | `str` | "dpmpp_2m" |  |
| `stage0.generation.scheduler` | `str` | "beta" |  |
| `stage0.generation.negative_sfw` | `str` | "nude, nsfw, shirtless, bare chest, exposed skin on torso, underwear only, swimwear\n" |  |
| `stage0.generation.negative_nsfw` | `str` | "3d render, cgi, plastic skin, waxy skin, airbrushed, beauty filter, deformed body, bad anatomy, bad proportions, extra limbs, cartoon, illustration, anime, watermark, low quality, tattoos, moles, freckles, stretch marks, female anatomy, woman, feminine features, no beard, thin face, hazel eyes, amber eyes\n" |  |
| `phaseA.emotion_count` | `int` | 24 |  |
| `phaseA.candidates_per_preset` | `int` | 6 |  |
| `phaseA.candidates_per_preset_heavy` | `int` | 6 |  |
| `phaseA.verification_similarity_threshold` | `float` | 0.58 |  |
| `phaseA.verification_similarity_threshold_heavy` | `float` | 0.52 |  |
| `phaseA.verification_similarity_threshold_calm` | `float` | 0.6 |  |
| `phaseA.auto_face_inpaint_emotions` | `bool` | false |  |
| `phaseA.auto_face_inpaint_bust` | `bool` | false |  |
| `phaseA.auto_body_inpaint_sfw` | `bool` | false |  |
| `phaseA.minimum_verified_frames` | `int` | 150 |  |
| `phaseA.pulid_gen_weight` | `float` | 0.85 |  |
| `phaseA.selection_similarity_weight` | `float` | 0.35 |  |
| `phaseA.orbit_selection_similarity_weight` | `float` | 0.33 |  |
| `phaseA.hairstyle_selection_similarity_weight` | `float` | 0.36 |  |
| `phaseA.emotion_reference_strategy` | `str` | "base_ref_only" |  |
| `phaseA.generation.width` | `int` | 832 |  |
| `phaseA.generation.height` | `int` | 1216 |  |
| `phaseA.generation.steps` | `int` | 32 |  |
| `phaseA.generation.guidance` | `float` | 3.8 |  |
| `phaseA.generation.cfg_scale` | `float` | 1.0 |  |
| `phaseA.inpaint.bbox_padding_ratio` | `float` | 0.13 |  |
| `phaseA.inpaint.mask_feather_px` | `int` | 10 |  |
| `phaseA.inpaint.steps` | `int` | 22 |  |
| `phaseA.inpaint.guidance` | `float` | 3.6 |  |
| `phaseA.inpaint.denoise` | `float` | 0.4 |  |
| `phaseA.inpaint.identity_adapter_weight` | `float` | 0.95 |  |
| `phaseA.inpaint.fusion` | `str` | "mean" |  |
| `phaseA.inpaint.train_step` | `int` | 500 |  |
| `phaseA.captioning.append_quality_tail` | `str` | "RAW photo, hyperrealistic, visible pores, realistic skin texture, beard strands, natural film grain" |  |
| `phaseA.captioning.include_raw_caption_blocks` | `list` | ["emotion", "hairstyle", "grooming"] |  |
| `phaseA.stress_pack.enabled` | `bool` | true |  |
| `phaseA.stress_pack.intense_tokens` | `list` | ["tension in brow and jaw", "focused heavy-lidded stare", "slight cheek tension under beard", "subtle masculine facial strain"] |  |
| `phaseA.orbit_inpaint.denoise` | `float` | 0.46 |  |
| `phaseA.orbit_inpaint.mask_feather_px` | `int` | 5 |  |
| `phaseA.orbit_inpaint.steps` | `int` | 22 |  |
| `phaseA.orbit_inpaint.guidance` | `float` | 3.4 |  |
| `phaseA.orbit_inpaint.identity_adapter_weight` | `float` | 0.91 |  |
| `phaseA.orbit_inpaint.bbox_padding_ratio` | `float` | 0.1 |  |
| `phaseA.orbit_inpaint.fusion` | `str` | "mean" |  |
| `phaseA.orbit_inpaint.train_step` | `int` | 500 |  |
| `phaseA.orbit_inpaint.auto_apply` | `bool` | false |  |
| `phaseA.orbit_inpaint.apply_to` | `list` | ["orbit_front", "orbit_left_45", "orbit_right_45", "orbit_left_profile", "orbit_right_profile"] |  |
| `phaseA.orbit_prompts` | `list` | [{"key": "orbit_front", "pulid_weight": 0.88, "prompt": "portrait photograph, adult man facing forward, both dark brown heavy-lidded eyes visible, thick dark brows, full short boxed beard, near-black messy wavy medium-length hair, broad straight nose with rounded tip, warm olive skin, visible pores, stocky masculine neck and shoulders"}, {"key": "orbit_left_45", "pulid_weight": 0.62, "prompt": "portrait photograph, adult man turned left in three-quarter view, right cheek and eye dominant, heavy-lidded dark brown eye, full short boxed beard, near-black wavy messy hair, broad nose profile, warm olive skin, visible pores"}, {"key": "orbit_left_profile", "pulid_weight": 0.44, "prompt": "strict left profile portrait, only right side of face visible, strong beard profile, broad straight nose profile with rounded tip, near-black wavy hair, warm olive skin, visible pores, thick neck"}, {"key": "orbit_left_rear_135", "pulid_weight": 0.0, "prompt": "portrait from behind and slightly right, back of head visible, medium-length near-black wavy hair texture from behind, left ear barely visible, thick neck, broad shoulders, stocky masculine frame"}, {"key": "orbit_back", "pulid_weight": 0.0, "prompt": "rear portrait from directly behind, back of head centered, no face visible, near-black wavy hair texture, thick neck, broad shoulders, stocky masculine frame"}, {"key": "orbit_right_rear_135", "pulid_weight": 0.0, "prompt": "portrait from behind and slightly left, back of head visible, near-black wavy hair from behind, right ear barely visible, thick neck and shoulders"}, {"key": "orbit_right_profile", "pulid_weight": 0.44, "prompt": "strict right profile portrait, only left side of face visible, strong beard profile, broad straight nose profile with rounded tip, near-black wavy hair, warm olive skin, visible pores, thick neck"}, {"key": "orbit_right_45", "pulid_weight": 0.62, "prompt": "portrait photograph, adult man turned right in three-quarter view, left cheek and eye dominant, heavy-lidded dark brown eye, full short boxed beard, near-black wavy messy hair, warm olive skin, visible pores"}] |  |
| `phaseA.body.candidates_per_shot` | `int` | 4 |  |
| `phaseA.body.selection_similarity_weight` | `float` | 0.56 |  |
| `phaseA.body.use_orbit_reference_chaining` | `bool` | true |  |
| `phaseA.body.generation.steps` | `int` | 25 |  |
| `phaseA.body.generation.guidance` | `float` | 3.6 |  |
| `phaseA.body.generation.sampler` | `str` | "dpmpp_2m" |  |
| `phaseA.body.generation.scheduler` | `str` | "beta" |  |
| `phaseA.body.generation.negative_sfw` | `str` | "nude, nsfw, shirtless, bare chest, wide shot, face cut off, tattoos, feminine features, woman, female, thin face, slim build, no beard, hazel eyes, amber eyes" |  |
| `phaseA.body.generation.negative_nsfw` | `str` | "bad anatomy, wide shot, face cut off, tattoos, deformed, feminine features, woman, female, extra limbs, blurry, plastic skin, CGI, identity drift, wrong person, no beard, thin face, hazel eyes\n" |  |
| `phaseA.body.inpaint.bbox_padding_ratio` | `float` | 0.08 |  |
| `phaseA.body.inpaint.mask_feather_px` | `int` | 6 |  |
| `phaseA.body.inpaint.steps` | `int` | 18 |  |
| `phaseA.body.inpaint.guidance` | `float` | 3.8 |  |
| `phaseA.body.inpaint.denoise` | `float` | 0.48 |  |
| `phaseA.body.inpaint.identity_adapter_weight` | `float` | 0.9 |  |
| `phaseA.body.inpaint.fusion` | `str` | "mean" |  |
| `phaseA.body.inpaint.train_step` | `int` | 500 |  |
| `phaseA.body.bust.framing` | `str` | "upper body shot, waist-up framing, broad shoulders and wide chest visible" |  |
| `phaseA.body.bust.sfw_count` | `int` | 14 |  |
| `phaseA.body.bust.nsfw_count` | `int` | 10 |  |
| `phaseA.body.bust.candidates_per_shot` | `int` | 3 |  |
| `phaseA.body.bust.width` | `int` | 832 |  |
| `phaseA.body.bust.height` | `int` | 1216 |  |
| `phaseA.body.bust.pulid_face_weight` | `float` | 0.72 |  |
| `phaseA.body.bust.pulid_body_weight_sfw` | `float` | 0.42 |  |
| `phaseA.body.bust.pulid_body_weight_nsfw` | `float` | 0.52 |  |
| `phaseA.body.bust.sfw_nudity_threshold` | `float` | 0.1 |  |
| `phaseA.body.bust.orbit_angles` | `list` | [{"key": "front", "framing": "waist-up portrait, head and shoulders fully visible, facing directly forward", "back_type": "", "pulid_face": 0.72, "neg_extra": "", "pos_extra": "broad wide shoulders, thick chest under fitted clothing, large stocky masculine build"}, {"key": "left_45", "framing": "waist-up portrait, three-quarter left view", "back_type": "", "pulid_face": 0.4, "neg_extra": "frontal face, facing directly at camera, symmetrical face", "pos_extra": "broad masculine physique, wide frame visible from angle"}, {"key": "right_45", "framing": "waist-up portrait, three-quarter right view", "back_type": "", "pulid_face": 0.4, "neg_extra": "frontal face, facing directly at camera, symmetrical face", "pos_extra": "broad masculine physique, wide frame visible from angle"}, {"key": "left_profile", "framing": "waist-up portrait, strict left profile", "back_type": "", "pulid_face": 0.28, "neg_extra": "both eyes visible, frontal face", "pos_extra": "full black beard profile, broad shoulder profile, stocky build"}, {"key": "right_profile", "framing": "waist-up portrait, strict right profile", "back_type": "", "pulid_face": 0.28, "neg_extra": "both eyes visible, frontal face", "pos_extra": "full black beard profile, broad shoulder profile, stocky build"}, {"key": "high_angle", "framing": "waist-up portrait shot from above, camera looking down", "back_type": "", "pulid_face": 0.34, "neg_extra": "eye level portrait, flat perspective", "pos_extra": "large masculine physique from above, broad shoulders dominant frame"}, {"key": "low_angle", "framing": "waist-up portrait shot from below, camera looking upward", "back_type": "", "pulid_face": 0.34, "neg_extra": "eye level portrait, flat perspective", "pos_extra": "dominant low angle portrait, large powerful masculine frame from below"}, {"key": "left_rear_135", "framing": "rear-left three-quarter upper-body portrait", "back_type": "half", "pulid_face": 0.12, "neg_extra": "frontal face, both eyes visible, facing camera", "pos_extra": "broad back anatomy, wide shoulders, large masculine frame from behind"}, {"key": "right_rear_135", "framing": "rear-right three-quarter upper-body portrait", "back_type": "half", "pulid_face": 0.12, "neg_extra": "frontal face, both eyes visible, facing camera", "pos_extra": "broad back anatomy, wide shoulders, large masculine frame from behind"}, {"key": "back_half", "framing": "rear three-quarter hip-up portrait", "back_type": "half", "pulid_face": 0.08, "neg_extra": "full frontal face, both eyes visible, facing camera", "pos_extra": "broad back anatomy, wide shoulder span, jet black wavy hair from behind"}, {"key": "back_pure", "framing": "full rear hip-up portrait, no face visible", "back_type": "pure", "pulid_face": 0.0, "neg_extra": "face visible, any eye visible, front view", "pos_extra": "broad wide back anatomy, large masculine frame, jet black wavy hair"}] |  |
| `phaseA.body.bust.sfw_ref_clothing_anchor` | `str` | "fitted black crew-neck t-shirt, clean opaque cotton fabric, broad wide shoulders and thick chest silhouette clearly readable under fabric, large stocky masculine proportions, paired with dark slim-fit trousers or dark jeans\n" |  |
| `phaseA.body.bust.lighting_variants` | `list` | ["soft studio lighting, large diffused key light from left", "warm golden hour window light, side-lit, rim light catching jet black wavy hair", "dramatic Rembrandt lighting, strong key from upper right, deep shadows on full black beard", "overcast outdoor light, soft flat even illumination", "cool blue ambient light, soft backlight glow, slight front fill", "warm orange practical light, cozy indoor atmosphere, intimate vibe", "soft natural window light, gentle side shadows, warm indoor atmosphere", "harsh direct sunlight, strong shadows on full beard and round face, outdoor editorial"] |  |
| `phaseA.body.bust.sfw_outfit_variants` | `list` | ["fitted black crew-neck t-shirt, clean opaque cotton, slim fit, dark slim jeans", "white fitted crew-neck tee, casual clean look, dark chino trousers", "dark navy fitted crew-neck tee, minimal casual style, dark slim jeans", "black fitted henley long-sleeve, casual masculine look, dark jeans", "dark charcoal ribbed knit sweater, relaxed fit, dark slim trousers", "fitted dark green long-sleeve crew neck, minimalist style, dark jeans", "black linen button-up shirt, relaxed open collar, casual masculine, dark chinos", "charcoal fitted crewneck sweatshirt, clean streetwear, dark slim joggers", "dark slim-fit blazer over black tee, smart casual masculine, dark trousers", "fitted dark turtleneck charcoal, sophisticated masculine, slim dark trousers"] |  |
| `phaseA.body.bust.selection_similarity_weight` | `float` | 0.5 |  |
| `phaseA.body.hairstyle_change_every_angles` | `int` | 2 |  |
| `phaseA.onetrainer.output_model_path` | `str` | "/workspace/onetrainer/outputs/DIOGO_face_flux1dev_stack_v2.safetensors" |  |
| `phaseA.onetrainer.lora_model_name` | `str` | "DIOGO_face_flux1dev_stack_v2" |  |
| `phaseA.onetrainer.rank` | `int` | 48 |  |
| `phaseA.onetrainer.alpha` | `int` | 48 |  |
| `phaseA.onetrainer.batch_size` | `int` | 1 |  |
| `phaseA.onetrainer.gradient_accumulation_steps` | `int` | 4 |  |
| `phaseA.onetrainer.epochs` | `int` | 9 |  |
| `phaseA.emotions_per_hairstyle` | `int` | 1 |  |
| `phaseA.orbit_emotions` | `list` | ["neutral brooding expression", "calm direct expression", "slight smirk", "focused intense expression", "soft closed-mouth smile", "thoughtful downward look", "serious side profile expression", "amused relaxed expression"] |  |
| `hires_pass.enabled` | `bool` | true |  |
| `hires_pass.upscale_model` | `str` | "RealESRGAN_x2plus.pth" |  |
| `hires_pass.scale` | `float` | 2.0 |  |
| `hires_pass.denoise` | `float` | 0.28 |  |
| `hires_pass.steps` | `int` | 20 |  |
| `hires_pass.guidance` | `float` | 3.5 |  |
| `hires_pass.detail_lora_strength` | `float` | 0.72 |  |
| `hires_pass.apply_to` | `list` | ["all"] |  |
| `hires_pass.skip_if_exists` | `bool` | true |  |
| `phaseB.sfw_count` | `int` | 40 |  |
| `phaseB.nsfw_count` | `int` | 8 |  |
| `phaseB.candidates_per_preset` | `int` | 4 |  |
| `phaseB.selection_similarity_weight` | `float` | 0.54 |  |
| `phaseB.face_correction_similarity_threshold` | `float` | 0.66 |  |
| `phaseB.verification_similarity_threshold` | `float` | 0.64 |  |
| `phaseB.minimum_verified_frames` | `int` | 56 |  |
| `phaseB.generation.width` | `int` | 832 |  |
| `phaseB.generation.height` | `int` | 1216 |  |
| `phaseB.generation.steps` | `int` | 25 |  |
| `phaseB.generation.guidance` | `float` | 3.5 |  |
| `phaseB.generation.sampler` | `str` | "dpmpp_2m" |  |
| `phaseB.generation.scheduler` | `str` | "beta" |  |
| `phaseB.generation.negative_sfw` | `str` | "nude, nsfw, shirtless, wide shot, face cut off, tattoos, feminine, thin face, slim build, no beard, hazel eyes, amber eyes" |  |
| `phaseB.generation.negative_nsfw` | `str` | "bad anatomy, wide shot, face cut off, tattoos, feminine features, no beard, thin face, hazel eyes, amber eyes" |  |
| `phaseB.controlnet.pose_strength` | `float` | 0.85 |  |
| `phaseB.controlnet.depth_strength` | `float` | 0.82 |  |
| `phaseB.controlnet.json_strength` | `float` | 0.6 |  |
| `phaseB.controlnet.start_percent` | `float` | 0.0 |  |
| `phaseB.controlnet.end_percent` | `float` | 0.75 |  |
| `phaseB.inpaint.bbox_padding_ratio` | `float` | 0.12 |  |
| `phaseB.inpaint.mask_feather_px` | `int` | 12 |  |
| `phaseB.inpaint.steps` | `int` | 20 |  |
| `phaseB.inpaint.guidance` | `float` | 3.8 |  |
| `phaseB.inpaint.denoise` | `float` | 0.34 |  |
| `phaseB.inpaint.identity_adapter_weight` | `float` | 0.85 |  |
| `phaseB.inpaint.train_step` | `int` | 280 |  |
| `phaseB.onetrainer.output_model_path` | `str` | "/workspace/onetrainer/outputs/DIOGO_body_flux1dev_stack_v2.safetensors" |  |
| `phaseB.onetrainer.lora_model_name` | `str` | "DIOGO_body_flux1dev_stack_v2" |  |
| `phaseB.onetrainer.rank` | `int` | 64 |  |
| `phaseB.onetrainer.alpha` | `int` | 64 |  |
| `phaseB.onetrainer.batch_size` | `int` | 1 |  |
| `phaseB.onetrainer.gradient_accumulation_steps` | `int` | 6 |  |
| `phaseB.onetrainer.epochs` | `int` | 10 |  |
| `nsfw_anatomy_fix.hair_min_ratio` | `float` | 0.005 |  |
| `nsfw_anatomy_fix.color_blend_strength` | `float` | 0.5 |  |
| `nsfw_anatomy_fix.detail_denoise` | `float` | 0.28 |  |
| `nsfw_anatomy_fix.detail_steps` | `int` | 20 |  |
| `nsfw_anatomy_fix.detail_guidance` | `float` | 3.5 |  |
| `nsfw_anatomy_fix.detail_pulid_weight` | `float` | 0.85 |  |
| `nsfw_anatomy_fix.detail_zone` | `str` | "full_nsfw" |  |
| `outfit_swapper.steps` | `int` | 25 |  |
| `outfit_swapper.guidance` | `float` | 3.5 |  |
| `outfit_swapper.control_mode` | `str` | "depth" |  |
| `outfit_swapper.controlnet_strength` | `float` | 0.92 |  |
| `outfit_swapper.control_start` | `float` | 0.0 |  |
| `outfit_swapper.control_end` | `float` | 0.92 |  |
| `outfit_swapper.pulid_weight` | `float` | 0.85 |  |
| `outfit_swapper.pulid_start_at` | `float` | 0.0 |  |
| `outfit_swapper.pulid_end_at` | `float` | 0.85 |  |
| `outfit_swapper.mask_feather_px` | `int` | 18 |  |
| `outfit_swapper.min_mask_ratio` | `float` | 0.01 |  |
| `outfit_swapper.max_mask_ratio` | `float` | 0.45 |  |
| `outfit_swapper.face_bbox_padding_ratio` | `float` | 0.12 |  |
| `outfit_swapper.face_mask_feather_px` | `int` | 20 |  |
| `outfit_swapper.canny_low_threshold` | `int` | 80 |  |
| `outfit_swapper.canny_high_threshold` | `int` | 180 |  |
| `outfit_swapper.pre_scan_skin_threshold` | `float` | 0.08 |  |
| `outfit_swapper.max_retries` | `int` | 2 |  |
| `outfit_swapper.denoise.min` | `float` | 0.44 |  |
| `outfit_swapper.denoise.max` | `float` | 0.54 |  |
| `outfit_swapper.sfw_filter.enabled` | `bool` | true |  |
| `outfit_swapper.sfw_filter.repair_threshold` | `float` | 0.15 |  |
| `outfit_swapper.sfw_filter.final_flag_threshold` | `float` | 0.28 |  |
| `outfit_swapper.sfw_filter.repair_denoise` | `float` | 0.48 |  |
| `outfit_swapper.sfw_filter.torso_top_frac` | `float` | 0.3 |  |
| `outfit_swapper.sfw_filter.repair_outfit_prompt` | `str` | "fitted black crew-neck t-shirt, clean opaque cotton fabric, large stocky male chest covered, broad masculine proportions\n" |  |
| `outfit_swapper.segmentation.sam_checkpoint` | `str` | "/workspace/ComfyUI/models/sam/sam_vit_b_01ec64.pth" |  |
| `outfit_swapper.segmentation.sam_model_type` | `str` | "vit_b" |  |
| `outfit_swapper.segmentation.yolo_weights` | `str` | "yolov8n-seg.pt" |  |
| `outfit_swapper.extra_negative` | `str` | "nude, topless, bare chest, different person, wrong face, identity drift, extra fingers, extra limbs, deformed torso, broken anatomy, feminine face, woman, female, no beard, thin face, slim build, hazel eyes, amber eyes\n" |  |
| `outfit_swapper.default_patterns` | `list` | ["bust_sfw_*.png", "orbit_*.png", "full_body*.png", "body_*.png"] |  |
| `outfit_swapper.presets.black_tee` | `str` | "fitted black crew-neck t-shirt, clean opaque cotton, large stocky male chest, slim fit" |  |
| `outfit_swapper.presets.white_tee` | `str` | "fitted white crew-neck t-shirt, minimal clean look, broad masculine chest" |  |
| `outfit_swapper.presets.navy_tee` | `str` | "fitted dark navy crew-neck tee, casual clean style, wide shoulders visible" |  |
| `outfit_swapper.presets.black_henley` | `str` | "black fitted henley long-sleeve, casual masculine, clean collar" |  |
| `outfit_swapper.presets.black_linen` | `str` | "black linen button-up, relaxed open collar, clean masculine style" |  |
| `outfit_swapper.presets.dark_longsleeve` | `str` | "fitted dark green long-sleeve crew, minimalist, clean edge" |  |
| `outfit_swapper.presets.charcoal_knit` | `str` | "charcoal ribbed knit sweater, relaxed cozy masculine style" |  |
| `outfit_swapper.presets.dark_polo` | `str` | "fitted dark polo shirt, clean masculine style" |  |
| `outfit_swapper.presets.dark_blazer` | `str` | "slim-fit dark blazer over black tee, smart casual masculine" |  |
| `outfit_swapper.presets.charcoal_turtleneck` | `str` | "fitted charcoal turtleneck, sophisticated masculine style" |  |
| `outfit_swapper.presets.bomber_black` | `str` | "black slim bomber jacket over black tee, streetwear masculine style" |  |
| `outfit_swapper.presets.denim_jacket` | `str` | "dark wash denim jacket over black tee, casual masculine style" |  |
| `ref_regen.steps` | `int` | 25 |  |
| `ref_regen.guidance` | `float` | 3.5 |  |
| `ref_regen.sampler` | `str` | "dpmpp_2m" |  |
| `ref_regen.scheduler` | `str` | "beta" |  |
| `ref_regen.pulid_weight` | `float` | 0.9 |  |
| `ref_regen.pulid_start` | `float` | 0.0 |  |
| `ref_regen.pulid_end` | `float` | 0.9 |  |
| `ref_regen.clip_l_triggers` | `str` | "filmfotos, kodak portra 400, analog film grain, warm olive skin, visible pores, jet black wavy hair, full black beard, dark brown heavy-lidded eyes, round full face" |  |
| `ref_regen.skin_pores` | `str` | "visible open skin pores, realistic skin microrelief, skin subsurface scattering, fine vellus hair on skin, warm medium olive skin tone, full black beard texture, authentic unretouched skin" |  |
| `ref_regen.lighting` | `str` | "soft natural outdoor light, warm golden daylight, rim light catching jet black wavy disheveled hair, urban lifestyle natural light, warm tone" |  |
| `ref_regen.clean` | `str` | "clean even warm olive skin, no blemishes, no tattoos, unretouched authentic photograph, tattoo free, natural masculine appearance with full black beard" |  |
| `ref_regen.quality` | `str` | "RAW photo Sony A7R V 85mm f1.4, hyperrealistic photograph, sharp focus, natural film grain, shallow depth of field, photorealistic sensor noise, filmfotos, kodak portra 400" |  |
| `ref_regen.negative` | `str` | "blurry, deformed, bad anatomy, extra limbs, watermark, anime, cartoon, tattoos, plastic skin, airbrushed skin, beauty filter, 3d render, cgi, smooth poreless skin, oversmoothed skin, digital painting, illustration, pale skin, cool skin tone, waxy skin, doll skin, beauty mole, skin mole, freckles, woman, female, feminine features, breasts, long hair, makeup, lipstick, no beard, thin face, angular face, narrow nose, slim build, hazel eyes, amber eyes, green eyes, beard removed" |  |
| `ref_regen.lora_stack` | `list` | [{"name": "fluxtrait_flux1dev_v2.safetensors", "weight": 0.72}, {"name": "polyhedron_flux_perfect_skin.safetensors", "weight": 0.45}, {"name": "skin_pores_detail_flux.safetensors", "weight": 0.4}, {"name": "DIOGO_face_v1.safetensors", "weight": 0.65}] |  |
| `ref_regen.detail_lora_stack` | `list` | [{"name": "fluxtrait_flux1dev_v2.safetensors", "weight": 0.68}, {"name": "polyhedron_flux_perfect_skin.safetensors", "weight": 0.42}, {"name": "skin_pores_detail_flux.safetensors", "weight": 0.38}, {"name": "DIOGO_face_v1.safetensors", "weight": 0.6}] |  |
| `ref_regen.tight_crop_size` | `int` | 896 |  |
| `ref_regen.tight_denoise` | `float` | 0.38 |  |
| `ref_regen.tight_steps` | `int` | 20 |  |
| `ref_regen.tight_guidance` | `float` | 3.5 |  |
| `ref_regen.detail_denoise` | `float` | 0.18 |  |
| `ref_regen.detail_steps` | `int` | 20 |  |
| `ref_regen.detail_guidance` | `float` | 3.5 |  |
| `ref_regen.detail_clip_l` | `str` | "filmfotos, visible open pores, warm olive skin, full black beard, dark brown heavy-lidded eyes, jet black wavy hair, round full face" |  |
| `ref_regen.upscale_denoise` | `float` | 0.28 |  |
| `ref_regen.upscale_steps` | `int` | 20 |  |
| `ref_regen.upscale_guidance` | `float` | 3.5 |  |
| `ref_regen.upscale_control_strength` | `float` | 0.58 |  |
| `ref_regen.upscale_control_end` | `float` | 0.8 |  |
| `ref_regen.upscale_positive` | `str` | "filmfotos, raw realistic skin, warm medium olive skin, visible skin pores, jet black wavy disheveled hair, dark brown heavy-lidded eyes, large stocky build, full black beard, round full face, masculine portrait, kodak portra 400" |  |
| `ref_regen.upscale_clip_l` | `str` | "filmfotos, visible open pores, warm olive skin, full black beard, dark brown heavy-lidded eyes, round full face" |  |
| `ref_regen.upscale_negative` | `str` | "blurry, plastic skin, airbrushed, smooth skin, waxy skin, doll skin, beauty filter, pale skin, cool skin, beauty mole, woman, female, feminine, thin face, narrow nose, angular face, hazel eyes, amber eyes, no beard" |  |

#### [unified_config_Leyla.yaml]
| key | type | default / YAML value | где используется |
|---|---|---|---|
| `comfyui.base_url` | `str` | "http://127.0.0.1:8188" |  |
| `comfyui.timeout_seconds` | `int` | 2400 |  |
| `comfyui.poll_interval` | `float` | 1.5 |  |
| `paths.workspace_root` | `str` | "/workspace" |  |
| `paths.config_dir` | `str` | "/workspace/WAR333_GODTIER_OMNI/RUNTIME/config" |  |
| `paths.runtime_root` | `str` | "/workspace/godtier_v7_runtime" |  |
| `paths.emotions_file` | `str` | "/workspace/WAR333_GODTIER_OMNI/RUNTIME/config/emotions.yaml" |  |
| `paths.pose_library_root` | `str` | "/workspace/ComfyUI/poses" |  |
| `paths.sfw_pose_pairs_dir` | `str` | "/workspace/ComfyUI/poses" |  |
| `paths.nsfw_pose_pairs_dir` | `str` | "/workspace/ComfyUI/poses" |  |
| `paths.manual_ref_face` | `str` | "/workspace/godtier_v7_runtime/Leyla/stage0/selected/ref_face.png" |  |
| `paths.manual_ref_body_sfw` | `str` | "/workspace/godtier_v7_runtime/Leyla/stage0/selected/ref_body_sfw.png" |  |
| `paths.manual_ref_body_nsfw` | `str` | "/workspace/godtier_v7_runtime/Leyla/stage0/selected/ref_body_nsfw.png" |  |
| `orchestrator.vram_min_free_mb` | `int` | 12000 |  |
| `orchestrator.sleep_between_heavy_models_seconds` | `int` | 12 |  |
| `models.flux_dev_unet` | `str` | "fluxedUpFluxNSFW_90FP16.safetensors" |  |
| `models.flux_dev_unet_sfw` | `str` | "fluxedUpFluxNSFW_90FP16.safetensors" |  |
| `models.flux_dev_unet_nsfw` | `str` | "fluxedUpFluxNSFW_90FP16.safetensors" |  |
| `models.flux_fill_unet` | `str` | "flux1-fill-dev.safetensors" |  |
| `models.flux_fill_weight_dtype` | `str` | "fp8_e4m3fn" |  |
| `models.flux_dev_unet_path_for_onetrainer` | `str` | "/workspace/ComfyUI/models/unet/fluxedUpFluxNSFW_90FP16.safetensors" |  |
| `models.detail_lora` | `str` | "polyhedron_flux_perfect_skin.safetensors" |  |
| `models.detail_lora_strength` | `float` | 0.52 |  |
| `models.detail_lora_strength_face` | `float` | 0.22 |  |
| `models.detail_lora_strength_body` | `float` | 0.28 |  |
| `models.realism_lora` | `str` | "" |  |
| `models.realism_lora_strength` | `float` | 0.0 |  |
| `models.lips_lora` | `str` | "flxBimboLips963.safetensors" |  |
| `models.lips_lora_strength` | `float` | 0.1 |  |
| `models.bust_breast_lora` | `str` | "flux-round-silicone-tits.safetensors" |  |
| `models.bust_breast_lora_strength` | `float` | 0.55 |  |
| `models.bust_breast_lora_strength_sfw` | `float` | 0.35 |  |
| `models.bust_breast_lora_strength_nsfw` | `float` | 0.6 |  |
| `models.vagina_detail_lora` | `str` | "Vagina_HQ-000029.safetensors" |  |
| `models.vagina_detail_lora_strength` | `float` | 0.55 |  |
| `models.face_lora_name` | `str` | "" |  |
| `models.face_lora_strength` | `float` | 0.0 |  |
| `models.controlnet_union` | `str` | "FLUX.1-dev-ControlNet-Union-Pro-2.0.safetensors" |  |
| `models.pulid_model` | `str` | "pulid_flux_v0.9.1.safetensors" |  |
| `models.eva_clip` | `str` | "EVA02_CLIP_E_psz14_s4B.pt" |  |
| `models.face_analysis_model` | `str` | "buffalo_l" |  |
| `models.insightface_provider` | `str` | "CPU" |  |
| `models.vae` | `str` | "ae.safetensors" |  |
| `models.clip_l` | `str` | "clip_l.safetensors" |  |
| `models.t5xxl` | `str` | "t5xxl_fp16.safetensors" |  |
| `models.florence_model_id` | `str` | "microsoft/Florence-2-large" |  |
| `models.florence_device` | `str` | "cpu" |  |
| `character.id` | `str` | "Leyla" |  |
| `character.trigger_token` | `str` | "Leyla" |  |
| `character.face_anchor` | `str` | "young woman, platinum blonde hair slicked back in sleek tight ponytail, light ice-blue eyes, vivid pale blue irises, almond eye shape, natural minimal lashes, clean defined brows, oval face, high pronounced cheekbones, strong defined jaw, straight nose, naturally full soft pink lips, lips closed, mouth shut, golden sun-kissed tan skin, fresh athletic aesthetic, soft natural lighting\n" |  |
| `character.flux_identity_priority` | `str` | "same woman from reference photo, exact face geometry, light ice-blue eyes, naturally full soft pink lips, platinum blonde hair slicked back in tight ponytail, golden tan skin, visible pores, realistic portrait photograph\n" |  |
| `character.orbit_face_lock` | `str` | "same woman, light ice-blue eyes, oval face, high cheekbones, naturally full soft pink lips, platinum blonde hair in tight ponytail, golden tan skin, visible pores\n" |  |
| `character.hair` | `str` | "platinum blonde hair, sleek and slicked back into tight high ponytail, smooth silky texture, bright platinum highlights catching sunlight, individual hair strands visible at hairline, flyaway hairs, realistic hair shine, clean temples, hair pulled taut from face, ponytail tail swinging naturally\n" |  |
| `character.eyes` | `str` | "light ice-blue eyes, pale vivid blue irises, almond-shaped eyes, clean natural lashes, softly defined brows, wide open fresh look, limbal ring visible, realistic iris detail\n" |  |
| `character.lips` | `str` | "naturally full soft lips, medium volume, natural soft pink tone, gentle cupid bow, no gloss overload, healthy natural sheen, clean lip line, no overline\n" |  |
| `character.face_shape` | `str` | "oval face, high pronounced cheekbones, defined strong jaw, straight refined nose, clean angular beauty, athletic Scandinavian aesthetic\n" |  |
| `character.skin` | `str` | "golden sun-kissed tan skin, visible skin pores, realistic skin microrelief, warm golden undertone, skin subsurface scattering, realistic skin depth, fine vellus hair on skin, clean smooth complexion, beach goddess glow, natural tan lines absent, even golden tone\n" |  |
| `character.hairstyles` | `list` | ["platinum blonde hair slicked back in sleek tight high ponytail, all face exposed", "platinum blonde hair in loose casual ponytail, some face-framing pieces free", "platinum blonde hair in wet-look slicked ponytail, gel-finished, ultra-sleek", "platinum blonde hair worn loose and straight, center part, flowing over shoulders", "platinum blonde hair in messy bun, casual athletic look, flyaway strands", "platinum blonde hair in braided ponytail, tight French braid secured back", "platinum blonde hair half-up half-down, top section in mini ponytail, rest loose", "platinum blonde hair in low sleek ponytail, side-swept, polished look", "platinum blonde hair pulled back in tight top knot bun, clean minimal look"] |  |
| `character.makeup_variants` | `list` | [{"key": "bare_natural", "label": "bare natural", "prompt": "bare face, clean natural golden tan skin, faint natural lip color, barely-there groomed brows, fresh dewy complexion, golden sun-kissed skin, visible pores, realistic skin texture, no makeup\n"}, {"key": "no_makeup_makeup", "label": "no-makeup makeup", "prompt": "no-makeup makeup look, light skin-tone tinted moisturizer, groomed soft brows, clear lip balm, barely-there mascara, natural healthy golden glow, matte finish, golden tan skin, visible pores, realistic skin texture\n"}, {"key": "soft_everyday", "label": "soft everyday", "prompt": "soft everyday makeup, light foundation matched to golden tan, groomed arched brows, soft warm brown eyeshadow, thin black liner, peachy natural lip gloss, golden tan skin, visible pores, realistic skin texture\n"}, {"key": "office_polished", "label": "office polished", "prompt": "polished office makeup, matte medium-coverage foundation, defined dark brows, neutral taupe eyeshadow, thin precise liner, soft nude lip, subtle sculpted contour, golden tan skin, visible pores, realistic skin texture\n"}, {"key": "glam_evening", "label": "glam evening", "prompt": "full glam makeup, flawless full-coverage foundation, dramatic smoky eye, thick dramatic winged liner, voluminous lashes, glossy nude lip, sculpted contour, blinding cheekbone highlight, golden tan skin, visible pores, realistic skin texture\n"}, {"key": "old_hollywood", "label": "old Hollywood glam", "prompt": "old Hollywood glam makeup, matte golden tan skin, classic cat-eye liner, voluminous curled lashes, bold classic red lip, sharply arched brows, matte powder finish, golden tan skin, visible pores, realistic skin texture\n"}, {"key": "editorial_bold", "label": "editorial bold", "prompt": "editorial makeup, strong graphic black liner, bold sculptured brow, monochrome bronze-copper eyeshadow and matching lip, sharp strong contour, golden tan skin, visible pores, realistic skin texture\n"}, {"key": "club_smoky", "label": "club smoky", "prompt": "heavy club smoky eye, thick smudged black kohl all around eyes, overlined glossy lips, heavy dramatic lashes, dewy skin, intense contour, golden tan skin, visible pores, realistic skin texture\n"}, {"key": "vamp_dark", "label": "vamp dark", "prompt": "dark vamp makeup, deep plum-black eyeshadow, heavy smudged black liner, dark berry almost-black lip, sculpted jawline contour, sharp dramatic arched brows, golden tan skin, visible pores, realistic skin texture\n"}, {"key": "wet_glam", "label": "wet glossy glam", "prompt": "wet-look makeup, glass-skin dewy finish, sheer ultra-glossy lip, heavy glossy eyelid, intense lower lash line smudge, blinding liquid highlighter on cheekbones and nose tip, golden tan skin, visible pores, realistic skin texture\n"}, {"key": "overdone_party", "label": "overdone party", "prompt": "overdone party makeup, heavy full-coverage foundation, thick dramatic winged liner, extremely glossy overlined lips, rhinestone inner corner accent, maximalist finish, golden tan skin, visible pores, realistic skin texture\n"}, {"key": "y2k_glossy", "label": "Y2K glossy", "prompt": "Y2K makeup, heavy dark lip liner with frosted pink glossy lip, shimmery pink-silver eyeshadow, thin overplucked pencil brows, sparkle under-eye accent, golden tan skin, visible pores, realistic skin texture\n"}, {"key": "soft_grunge", "label": "soft grunge", "prompt": "soft grunge makeup, smudged black lower liner, lived-in smoky eye, matte dusty rose lip, slightly undone aesthetic, golden tan skin, visible pores, realistic skin texture\n"}, {"key": "e_girl", "label": "e-girl", "prompt": "e-girl makeup, graphic black liner detail with small heart stamp at outer corner, bold voluminous lashes, bitten red lip tint, golden tan skin, visible pores, realistic skin texture\n"}] |  |
| `prompts.quality_tail` | `str` | "RAW photo, shot on Sony A7R V 85mm f1.4, hyperrealistic photograph, sharp focus, fine vellus skin hair visible, visible skin pores, realistic skin microrelief, natural skin tone variation, fine facial details, photorealistic sensor noise, natural film grain, skin subsurface scattering, shallow depth of field soft bokeh, realistic eye catch light, limbal ring, iris detail, individual hair strands sharp, separated hair locks, bare clean ears, undecorated skin, even golden tan skin tone, clean complexion" |  |
| `prompts.negative_base` | `str` | "blurry, deformed, bad anatomy, extra limbs, watermark, anime, cartoon, tattoos, plastic skin, airbrushed skin, beauty filter, 3d render, cgi, smooth poreless skin, oversmoothed skin, digital painting, illustration, pale skin, dark skin, small eyes, narrow eyes, waxy skin, doll skin, overprocessed skin, fake skin, rubber skin, freckles, heavy blush, rosy cheeks, overfilled cheeks, pink cheeks, painted hair, hair blob, clumped hair, uniform hair mass, flat hair texture, hair without strands, solid hair block, beauty mole, skin mole" |  |
| `prompts.face_reference` | `str` | "front-facing portrait, neutral expression, soft cinematic lighting, clean dark background, light ice-blue eyes, naturally full soft pink lips, platinum blonde hair slicked back in tight ponytail, golden sun-kissed tan skin, visible pores" |  |
| `prompts.hands_reference` | `str` | "studio hand reference, both hands clearly visible, separated fingers, clean nails, realistic knuckles, golden tan skin, visible pores" |  |
| `prompts.body_reference_sfw` | `str` | "black sports crop top, thick opaque fabric, chest fully covered, prominent natural bust silhouette under fabric, full body shot crown to knees, standing upright facing camera, beautiful young woman, golden tan skin, visible pores, platinum blonde hair in tight ponytail, RAW photo Canon EOS R5 35mm f/2.0 ISO 400, natural film grain" |  |
| `prompts.body_reference_nsfw` | `str` | "RAW photo Sony A7R IV 50mm f/1.8 ISO 800, full body shot head to toe, completely nude, beautiful young woman, golden tan skin, visible pores, platinum blonde hair in tight ponytail, large round silicone augmented breasts, D-cup implants, high round breast placement, full upper pole, perfectly round implant shape, firm tight skin over implants, completely shaved intimate area, skin pores, natural skin texture with visible pores, unretouched skin" |  |
| `prompts.body_dataset_sfw` | `str` | "candid upper-body fashion photograph, fully clothed in dense double-layer opaque clothing, secure chest coverage with no exposed skin on torso, clean upper-body framing, golden tan skin, visible pores, platinum blonde hair in tight ponytail, sharp focus, film grain, hyperrealistic photograph" |  |
| `prompts.body_dataset_nsfw` | `str` | "candid upper-body nude photograph, large round silicone augmented breasts, D-cup implants, high round breast placement, full upper pole, perfectly round implant shape, golden tan skin, visible pores, natural skin texture, sharp focus, film grain" |  |
| `prompts.body_flux_shape_priority` | `str` | "large round silicone augmented breasts, D-cup implants, high round breast placement, full upper pole, perfectly round implant shape, firm tight skin over implants, athletic slim waist, toned hourglass figure, flat toned stomach, visible abs" |  |
| `prompts.body_absolute_lock` | `str` | "consistent large round silicone breast size and shape across all frames, no breast size variation, no sagging, no flat chest, no natural breast shape — always round implant silhouette" |  |
| `prompts.body_volume_force` | `str` | "large round silicone breast volume, prominent augmented chest, round implant cleavage depth, visible implant roundness at upper pole" |  |
| `prompts.body_anchor_sfw` | `str` | "same woman from uploaded reference, exact face and upper-body proportions from reference, fully clothed upper-body portrait, dense double-layer opaque clothing, chest fully covered, no visible nipple outline, no transparent patches, lower body stays covered, athletic waist-up fashion framing" |  |
| `prompts.sfw_flux_guardrails` | `str` | "upper-body portrait, fully clothed in dense double-layer opaque fabric, chest skin fully hidden, no visible nipple outline, no transparent patches, lower body remains covered, coherent anatomy, natural skin texture, hyperrealistic photograph" |  |
| `prompts.nsfw_flux_guardrails` | `str` | "realistic human anatomy, coherent torso, large round silicone augmented D-cup breasts, consistent round implant shape, smooth shaved intimate area, golden tan skin, skin pores" |  |
| `anatomy.candidates_count` | `int` | 10 |  |
| `anatomy.skin_base` | `str` | "golden sun-kissed tan skin, visible skin pores, realistic skin microrelief, skin subsurface scattering, fine vellus hair on skin, natural warm golden skin tone variation, unretouched skin\n" |  |
| `anatomy.skin_base_chest` | `str` | "golden tan skin, smooth even warm skin tone, skin subsurface scattering, soft golden skin sheen, unretouched skin\n" |  |
| `anatomy.skin_base_lower` | `str` | "golden tan skin, visible skin pores, realistic skin microrelief, skin subsurface scattering, fine vellus hair on skin, subtle veins visible on inner thighs, unretouched skin\n" |  |
| `anatomy.areola.breast_shape` | `str` | "large round silicone augmented breasts, D-cup implants, high round breast placement, full upper pole, perfectly round implant shape, firm tight skin over implants, visible implant roundness, prominent cleavage\n" |  |
| `anatomy.areola.nipple` | `str` | "pfps, small light pink areola, small areola diameter, small erect nipple, natural nipple tip, natural tan skin surrounding areola\n" |  |
| `anatomy.ass.shape` | `str` | "round athletic bubble butt, firm perky buttocks, pronounced gluteal fold, round full cheeks, toned smooth outer buttocks, smooth inner cheek skin, natural gluteal crease, athletic glute definition\n" |  |
| `anatomy.ass.legs` | `str` | "long athletic legs, slim toned thighs, visible thigh gap, smooth fully shaved legs, no leg hair, toned calves, golden tan skin on legs\n" |  |
| `anatomy.spread.legs` | `str` | "long athletic legs, wide spread apart, visible thigh gap, smooth shaved inner thighs, toned leg muscles, golden tan skin\n" |  |
| `anatomy.spread.anatomy` | `str` | "completely shaved bare pubic area, zero stubble, plump puffy labia majora, protruding full labia minora slightly visible, small hidden clitoris, soft pink intimate color, closed vaginal opening, realistic vulva anatomy, natural intimate skin folds\n" |  |
| `anatomy.spread.wetness` | `str` | "slightly wet glistening labia, natural intimate moisture, soft specular highlight on wet skin surface, realistic natural lubrication sheen\n" |  |
| `anatomy.anus.description` | `str` | "tight slightly relaxed anus, small natural opening visible, natural puckered skin folds around anus, soft pink-rose color, realistic anal texture, smooth skin around anal area, no hair\n" |  |
| `anatomy.negative` | `str` | "3d render, cgi, digital art, octane render, unreal engine, AI artifact, banding, plastic skin, waxy skin, airbrushed, beauty filter, glass skin, doll skin, deformed body, bad anatomy, bad proportions, extra limbs, cartoon, illustration, anime, watermark, low quality, jpeg artifacts, overexposed, blown highlights, tattoos, tattoo, body art, moles, freckles, stretch marks, tan lines, body hair, pubic hair, armpit hair, leg hair\n" |  |
| `anatomy.negative_areola` | `str` | "3d render, cgi, cartoon, anime, watermark, bad anatomy, moles, freckles, pores, skin spots, skin blemishes, blotchy skin\n" |  |
| `anatomy.anatomy_guidance` | `float` | 4.5 |  |
| `anatomy.lora_stack.areola` | `list` | [{"name": "polyhedron_flux_perfect_skin.safetensors", "weight": 0.55}, {"name": "flux-round-silicone-tits.safetensors", "weight": 0.55}] |  |
| `anatomy.lora_stack.ass` | `list` | [{"name": "polyhedron_flux_perfect_skin.safetensors", "weight": 0.3}, {"name": "Vagina_HQ-000029.safetensors", "weight": 0.55}] |  |
| `anatomy.lora_stack.spread` | `list` | [{"name": "polyhedron_flux_perfect_skin.safetensors", "weight": 0.3}, {"name": "Vagina_HQ-000029.safetensors", "weight": 0.55}] |  |
| `stage0.face_reference_count` | `int` | 100 |  |
| `stage0.hands_reference_count` | `int` | 4 |  |
| `stage0.body_reference_count` | `int` | 10 |  |
| `stage0.face_width` | `int` | 1024 |  |
| `stage0.face_height` | `int` | 1024 |  |
| `stage0.hands_width` | `int` | 832 |  |
| `stage0.hands_height` | `int` | 1216 |  |
| `stage0.body_width` | `int` | 832 |  |
| `stage0.body_height` | `int` | 1536 |  |
| `stage0.identity_adapter_weight` | `float` | 0.82 |  |
| `stage0.body_pulid_weight` | `float` | 0.52 |  |
| `stage0.body_pulid_start_at` | `float` | 0.0 |  |
| `stage0.body_pulid_end_at` | `float` | 0.85 |  |
| `stage0.generation.steps` | `int` | 35 |  |
| `stage0.generation.guidance` | `float` | 3.5 |  |
| `stage0.generation.sampler` | `str` | "dpmpp_2m" |  |
| `stage0.generation.scheduler` | `str` | "beta" |  |
| `stage0.generation.negative_sfw` | `str` | "nude, nsfw, topless, bare chest, exposed breasts, nipples, transparent clothing, cleavage gap, underwear only, lingerie, exposed skin on chest\n" |  |
| `stage0.generation.negative_nsfw` | `str` | "3d render, cgi, plastic skin, waxy skin, airbrushed, beauty filter, deformed body, bad anatomy, bad proportions, extra limbs, cartoon, illustration, anime, watermark, low quality, saggy breasts, drooping breasts, ptosis, hanging breasts, flat chest, small breasts, natural small breasts, tattoos, moles, freckles, stretch marks, tan lines\n" |  |
| `phaseA.emotion_count` | `int` | 24 |  |
| `phaseA.candidates_per_preset` | `int` | 5 |  |
| `phaseA.candidates_per_preset_heavy` | `int` | 4 |  |
| `phaseA.verification_similarity_threshold` | `float` | 0.53 |  |
| `phaseA.verification_similarity_threshold_heavy` | `float` | 0.48 |  |
| `phaseA.verification_similarity_threshold_calm` | `float` | 0.55 |  |
| `phaseA.auto_face_inpaint_emotions` | `bool` | false |  |
| `phaseA.auto_face_inpaint_bust` | `bool` | false |  |
| `phaseA.auto_body_inpaint_sfw` | `bool` | false |  |
| `phaseA.minimum_verified_frames` | `int` | 190 |  |
| `phaseA.pulid_gen_weight` | `float` | 0.52 |  |
| `phaseA.selection_similarity_weight` | `float` | 0.36 |  |
| `phaseA.orbit_selection_similarity_weight` | `float` | 0.34 |  |
| `phaseA.hairstyle_selection_similarity_weight` | `float` | 0.38 |  |
| `phaseA.emotion_reference_strategy` | `str` | "base_ref_only" |  |
| `phaseA.generation.width` | `int` | 832 |  |
| `phaseA.generation.height` | `int` | 1216 |  |
| `phaseA.generation.steps` | `int` | 45 |  |
| `phaseA.generation.guidance` | `float` | 3.8 |  |
| `phaseA.generation.cfg_scale` | `float` | 1.0 |  |
| `phaseA.inpaint.bbox_padding_ratio` | `float` | 0.12 |  |
| `phaseA.inpaint.mask_feather_px` | `int` | 8 |  |
| `phaseA.inpaint.steps` | `int` | 28 |  |
| `phaseA.inpaint.guidance` | `float` | 3.8 |  |
| `phaseA.inpaint.denoise` | `float` | 0.48 |  |
| `phaseA.inpaint.identity_adapter_weight` | `float` | 0.9 |  |
| `phaseA.inpaint.fusion` | `str` | "mean" |  |
| `phaseA.inpaint.train_step` | `int` | 500 |  |
| `phaseA.captioning.append_quality_tail` | `str` | "RAW photo, hyperrealistic, subsurface scattering, visible skin pores, natural skin texture, film grain" |  |
| `phaseA.captioning.include_raw_caption_blocks` | `list` | ["emotion", "hairstyle", "makeup"] |  |
| `phaseA.liquids_mode.enabled` | `bool` | true |  |
| `phaseA.liquids_mode.tears_text` | `str` | "visible tears, wet lower eyelids, tear tracks on cheeks" |  |
| `phaseA.liquids_mode.drool_text` | `str` | "visible saliva string at lower lip, wet drool on lips and chin" |  |
| `phaseA.liquids_mode.sweat_text` | `str` | "light sweat sheen on skin" |  |
| `phaseA.stress_pack.enabled` | `bool` | true |  |
| `phaseA.stress_pack.intense_tokens` | `list` | ["tension in brow and jaw", "wet lower eyelids", "slightly parted lips", "subtle facial strain"] |  |
| `phaseA.orbit_inpaint.denoise` | `float` | 0.5 |  |
| `phaseA.orbit_inpaint.mask_feather_px` | `int` | 5 |  |
| `phaseA.orbit_inpaint.steps` | `int` | 34 |  |
| `phaseA.orbit_inpaint.guidance` | `float` | 3.8 |  |
| `phaseA.orbit_inpaint.identity_adapter_weight` | `float` | 0.94 |  |
| `phaseA.orbit_inpaint.bbox_padding_ratio` | `float` | 0.1 |  |
| `phaseA.orbit_inpaint.fusion` | `str` | "mean" |  |
| `phaseA.orbit_inpaint.train_step` | `int` | 500 |  |
| `phaseA.orbit_inpaint.auto_apply` | `bool` | false |  |
| `phaseA.orbit_inpaint.apply_to` | `list` | ["orbit_front", "orbit_left_45", "orbit_right_45", "orbit_left_profile", "orbit_right_profile"] |  |
| `phaseA.orbit_prompts` | `list` | [{"key": "orbit_front", "pulid_weight": 0.55, "prompt": "portrait photograph, young woman facing directly forward, both eyes fully visible and symmetrical, shoulders level, oval face, high cheekbones, light ice-blue eyes, naturally full soft pink lips, platinum blonde hair in tight sleek ponytail, golden tan skin, visible pores\n"}, {"key": "orbit_left_45", "pulid_weight": 0.32, "prompt": "portrait photograph, young woman head turned left, right cheek and eye prominent, three-quarter view, light ice-blue eye, naturally full soft pink lips, golden tan skin, visible pores, platinum blonde hair in tight ponytail\n"}, {"key": "orbit_left_profile", "pulid_weight": 0.24, "prompt": "strict left profile portrait, only right side of face visible, right eye and nostril in view, clean sharp profile silhouette, light ice-blue eye visible, naturally full lips in profile, straight refined nose, golden tan skin, visible pores, platinum blonde ponytail\n"}, {"key": "orbit_left_rear_135", "pulid_weight": 0.0, "prompt": "portrait from behind and slightly right, back of head in frame, platinum blonde ponytail from behind, left ear barely visible, nape of neck visible, both shoulder blades in frame\n"}, {"key": "orbit_back", "pulid_weight": 0.0, "prompt": "rear view portrait shot from directly behind, back of head centered, no face visible, platinum blonde ponytail texture, nape of neck clearly visible, both shoulders symmetrical\n"}, {"key": "orbit_right_rear_135", "pulid_weight": 0.0, "prompt": "portrait from behind and slightly left, back of head in frame, platinum blonde ponytail from behind, right ear barely visible, nape of neck visible, both shoulder blades in frame\n"}, {"key": "orbit_right_profile", "pulid_weight": 0.24, "prompt": "strict right profile portrait, only left side of face visible, left eye and nostril in view, clean sharp profile silhouette, light ice-blue eye visible, naturally full lips in profile, golden tan skin, visible pores, platinum blonde ponytail\n"}, {"key": "orbit_right_45", "pulid_weight": 0.32, "prompt": "portrait photograph, young woman head turned right, left cheek and eye prominent, three-quarter view, light ice-blue eye, naturally full soft pink lips, golden tan skin, visible pores, platinum blonde hair in tight ponytail\n"}] |  |
| `phaseA.body.candidates_per_shot` | `int` | 4 |  |
| `phaseA.body.selection_similarity_weight` | `float` | 0.58 |  |
| `phaseA.body.use_orbit_reference_chaining` | `bool` | true |  |
| `phaseA.body.generation.steps` | `int` | 38 |  |
| `phaseA.body.generation.guidance` | `float` | 3.75 |  |
| `phaseA.body.generation.sampler` | `str` | "dpmpp_2m" |  |
| `phaseA.body.generation.scheduler` | `str` | "beta" |  |
| `phaseA.body.generation.negative_sfw` | `str` | "nude, nsfw, flat chest, wide shot, face cut off, tattoos, see-through fabric, transparent shirt, visible nipple outline, areola, exposed chest skin, bare hips, visible buttocks, sideboob, underboob, wardrobe malfunction, hands under breasts, hands squeezing chest" |  |
| `phaseA.body.generation.negative_nsfw` | `str` | "bad anatomy, wide shot, face cut off, tattoos, saggy breasts, drooping breasts, ptosis, hanging breasts, flat chest, small breasts, natural small breasts, deflated breasts, asymmetric breasts, mismatched breast size, deformed nipples, extra nipples, no nipples, blurry, plastic skin, wax skin, overprocessed, CGI, identity drift, wrong person\n" |  |
| `phaseA.body.inpaint.bbox_padding_ratio` | `float` | 0.08 |  |
| `phaseA.body.inpaint.mask_feather_px` | `int` | 6 |  |
| `phaseA.body.inpaint.steps` | `int` | 22 |  |
| `phaseA.body.inpaint.guidance` | `float` | 4.5 |  |
| `phaseA.body.inpaint.denoise` | `float` | 0.5 |  |
| `phaseA.body.inpaint.identity_adapter_weight` | `float` | 0.9 |  |
| `phaseA.body.inpaint.fusion` | `str` | "mean" |  |
| `phaseA.body.inpaint.train_step` | `int` | 500 |  |
| `phaseA.body.bust.framing` | `str` | "upper body shot, waist-up framing, shoulders and chest visible" |  |
| `phaseA.body.bust.sfw_count` | `int` | 14 |  |
| `phaseA.body.bust.nsfw_count` | `int` | 18 |  |
| `phaseA.body.bust.candidates_per_shot` | `int` | 3 |  |
| `phaseA.body.bust.width` | `int` | 832 |  |
| `phaseA.body.bust.height` | `int` | 1216 |  |
| `phaseA.body.bust.pulid_face_weight` | `float` | 0.72 |  |
| `phaseA.body.bust.pulid_body_weight_sfw` | `float` | 0.42 |  |
| `phaseA.body.bust.pulid_body_weight_nsfw` | `float` | 0.52 |  |
| `phaseA.body.bust.sfw_nudity_threshold` | `float` | 0.12 |  |
| `phaseA.body.bust.orbit_angles` | `list` | [{"key": "front", "framing": "waist-up portrait, head and shoulders fully visible, facing directly forward", "back_type": "", "pulid_face": 0.72, "neg_extra": "", "pos_extra": "large round silicone bust silhouette under clothing, opaque fabric covering chest"}, {"key": "left_45", "framing": "waist-up portrait, three-quarter left view", "back_type": "", "pulid_face": 0.32, "neg_extra": "frontal face, facing directly at camera, symmetrical face", "pos_extra": "large round silicone bust silhouette under clothing, opaque fabric covering chest"}, {"key": "right_45", "framing": "waist-up portrait, three-quarter right view", "back_type": "", "pulid_face": 0.32, "neg_extra": "frontal face, facing directly at camera, symmetrical face", "pos_extra": "large round silicone bust silhouette under clothing, opaque fabric covering chest"}, {"key": "left_profile", "framing": "waist-up portrait, strict left profile", "back_type": "", "pulid_face": 0.24, "neg_extra": "both eyes visible, frontal face, three-quarter view", "pos_extra": "large round silicone bust silhouette under clothing, opaque fabric covering chest"}, {"key": "right_profile", "framing": "waist-up portrait, strict right profile", "back_type": "", "pulid_face": 0.24, "neg_extra": "both eyes visible, frontal face, three-quarter view", "pos_extra": "large round silicone bust silhouette under clothing, opaque fabric covering chest"}, {"key": "high_angle", "framing": "waist-up portrait shot from above, camera looking down", "back_type": "", "pulid_face": 0.3, "neg_extra": "eye level portrait, flat perspective", "pos_extra": "large round silicone bust silhouette under clothing, opaque fabric covering chest"}, {"key": "low_angle", "framing": "waist-up portrait shot from below, camera looking upward", "back_type": "", "pulid_face": 0.3, "neg_extra": "eye level portrait, flat perspective", "pos_extra": "large round silicone bust silhouette under clothing, opaque fabric covering chest"}, {"key": "left_rear_135", "framing": "rear-left three-quarter upper-body portrait", "back_type": "half", "pulid_face": 0.14, "neg_extra": "frontal face, both eyes visible, facing camera, frontal chest visible", "pos_extra": "back anatomy locked, spine line readable, shoulders aligned"}, {"key": "right_rear_135", "framing": "rear-right three-quarter upper-body portrait", "back_type": "half", "pulid_face": 0.14, "neg_extra": "frontal face, both eyes visible, facing camera, frontal chest visible", "pos_extra": "back anatomy locked, spine line readable, shoulders aligned"}, {"key": "back_half", "framing": "rear three-quarter hip-up portrait", "back_type": "half", "pulid_face": 0.1, "neg_extra": "full frontal face, both eyes visible, facing camera, frontal breasts", "pos_extra": "back anatomy locked, spine line readable, shoulders aligned"}, {"key": "back_pure", "framing": "full rear hip-up portrait, no face visible", "back_type": "pure", "pulid_face": 0.0, "neg_extra": "face visible, any eye visible, front view", "pos_extra": "back anatomy locked, spine line readable, shoulders aligned"}] |  |
| `phaseA.body.bust.sfw_ref_clothing_anchor` | `str` | "fitted black sports crop top, dense double-layer opaque fabric, chest fully covered with no transparency, large round silicone bust silhouette clearly visible under fabric, secure torso coverage, paired with high-waist opaque bottoms covering hips and lower body\n" |  |
| `phaseA.body.bust.lighting_variants` | `list` | ["soft studio lighting, large diffused key light from left", "warm golden hour window light, side-lit, rim light on hair", "dramatic Rembrandt lighting, strong key from upper right, deep shadows", "overcast outdoor light, soft flat even illumination", "cool blue ambient light, soft backlight glow, slight front fill", "warm orange practical light, cozy indoor atmosphere", "soft natural window light, gentle side shadows, warm indoor atmosphere", "soft butterfly lighting, key light directly above, glamour portrait"] |  |
| `phaseA.body.bust.sfw_outfit_variants` | `list` | ["fitted black sports crop top, dense double-layer opaque fabric, chest fully covered, black high-waist leggings covering hips and buttocks completely", "white fitted athletic long-sleeve top, thick opaque fabric, chest completely hidden, white high-waist trousers covering hips and lower body completely", "charcoal grey high-neck athletic long-sleeve, double-layer dense performance fabric, chest fully covered, charcoal high-waist leggings covering hips and glutes completely", "ivory ribbed long-sleeve top, smooth thick opaque knit, torso fully covered, ivory high-waist fitted skirt covering hips and buttocks to mid-thigh", "navy long-sleeve athletic top, thick opaque fabric, chest fully covered, navy high-waist wide-leg trousers covering hips and glutes completely", "burgundy high-neck long-sleeve top, double-layer opaque stretch fabric, chest fully covered, burgundy fitted midi skirt covering hips and buttocks to knee", "black long-sleeve bodycon dress, dense opaque stretch fabric, torso fully covered, lower body covered to mid-thigh"] |  |
| `phaseA.body.bust.selection_similarity_weight` | `float` | 0.52 |  |
| `phaseA.body.hairstyle_change_every_angles` | `int` | 2 |  |
| `phaseA.onetrainer.output_model_path` | `str` | "/workspace/onetrainer/outputs/{character_id}_face_v11.safetensors" |  |
| `phaseA.onetrainer.lora_model_name` | `str` | "Leyla_face_v11" |  |
| `phaseA.onetrainer.rank` | `int` | 32 |  |
| `phaseA.onetrainer.alpha` | `int` | 32 |  |
| `phaseA.onetrainer.batch_size` | `int` | 1 |  |
| `phaseA.onetrainer.gradient_accumulation_steps` | `int` | 4 |  |
| `phaseA.onetrainer.epochs` | `int` | 7 |  |
| `phaseA.emotions_per_hairstyle` | `int` | 1 |  |
| `phaseA.orbit_emotions` | `list` | ["neutral expression", "skeptical expression", "determined expression", "concerned expression", "teary sad expression", "angry restrained expression", "startled expression", "exhausted stressed expression"] |  |
| `hires_pass.enabled` | `bool` | false |  |
| `hires_pass.upscale_model` | `str` | "RealESRGAN_x2plus.pth" |  |
| `hires_pass.scale` | `float` | 2.0 |  |
| `hires_pass.denoise` | `float` | 0.35 |  |
| `hires_pass.steps` | `int` | 20 |  |
| `hires_pass.guidance` | `float` | 3.5 |  |
| `hires_pass.detail_lora_strength` | `float` | 0.12 |  |
| `hires_pass.apply_to` | `list` | ["all"] |  |
| `hires_pass.skip_if_exists` | `bool` | true |  |
| `phaseB.sfw_count` | `int` | 40 |  |
| `phaseB.nsfw_count` | `int` | 18 |  |
| `phaseB.candidates_per_preset` | `int` | 4 |  |
| `phaseB.selection_similarity_weight` | `float` | 0.55 |  |
| `phaseB.face_correction_similarity_threshold` | `float` | 0.68 |  |
| `phaseB.verification_similarity_threshold` | `float` | 0.65 |  |
| `phaseB.minimum_verified_frames` | `int` | 64 |  |
| `phaseB.generation.width` | `int` | 832 |  |
| `phaseB.generation.height` | `int` | 1216 |  |
| `phaseB.generation.steps` | `int` | 34 |  |
| `phaseB.generation.guidance` | `float` | 3.6 |  |
| `phaseB.generation.sampler` | `str` | "dpmpp_2m" |  |
| `phaseB.generation.scheduler` | `str` | "beta" |  |
| `phaseB.generation.negative_sfw` | `str` | "nude, nsfw, flat chest, wide shot, face cut off, tattoos" |  |
| `phaseB.generation.negative_nsfw` | `str` | "bad anatomy, wide shot, face cut off, tattoos" |  |
| `phaseB.controlnet.pose_strength` | `float` | 0.85 |  |
| `phaseB.controlnet.depth_strength` | `float` | 0.82 |  |
| `phaseB.controlnet.json_strength` | `float` | 0.6 |  |
| `phaseB.controlnet.start_percent` | `float` | 0.0 |  |
| `phaseB.controlnet.end_percent` | `float` | 0.75 |  |
| `phaseB.inpaint.bbox_padding_ratio` | `float` | 0.12 |  |
| `phaseB.inpaint.mask_feather_px` | `int` | 12 |  |
| `phaseB.inpaint.steps` | `int` | 20 |  |
| `phaseB.inpaint.guidance` | `float` | 4.3 |  |
| `phaseB.inpaint.denoise` | `float` | 0.36 |  |
| `phaseB.inpaint.identity_adapter_weight` | `float` | 0.84 |  |
| `phaseB.inpaint.train_step` | `int` | 280 |  |
| `phaseB.onetrainer.output_model_path` | `str` | "/workspace/onetrainer/outputs/{character_id}_body_v11.safetensors" |  |
| `phaseB.onetrainer.lora_model_name` | `str` | "Leyla_body_v11" |  |
| `phaseB.onetrainer.rank` | `int` | 64 |  |
| `phaseB.onetrainer.alpha` | `int` | 64 |  |
| `phaseB.onetrainer.batch_size` | `int` | 1 |  |
| `phaseB.onetrainer.gradient_accumulation_steps` | `int` | 6 |  |
| `phaseB.onetrainer.epochs` | `int` | 10 |  |
| `nsfw_anatomy_fix.hair_min_ratio` | `float` | 0.005 |  |
| `nsfw_anatomy_fix.color_blend_strength` | `float` | 0.52 |  |
| `nsfw_anatomy_fix.detail_denoise` | `float` | 0.32 |  |
| `nsfw_anatomy_fix.detail_steps` | `int` | 22 |  |
| `nsfw_anatomy_fix.detail_guidance` | `float` | 3.8 |  |
| `nsfw_anatomy_fix.detail_pulid_weight` | `float` | 0.72 |  |
| `nsfw_anatomy_fix.detail_zone` | `str` | "full_nsfw" |  |
| `outfit_swapper.steps` | `int` | 28 |  |
| `outfit_swapper.guidance` | `float` | 4.6 |  |
| `outfit_swapper.control_mode` | `str` | "depth" |  |
| `outfit_swapper.controlnet_strength` | `float` | 0.92 |  |
| `outfit_swapper.control_start` | `float` | 0.0 |  |
| `outfit_swapper.control_end` | `float` | 0.92 |  |
| `outfit_swapper.pulid_weight` | `float` | 0.75 |  |
| `outfit_swapper.pulid_start_at` | `float` | 0.0 |  |
| `outfit_swapper.pulid_end_at` | `float` | 0.85 |  |
| `outfit_swapper.mask_feather_px` | `int` | 18 |  |
| `outfit_swapper.min_mask_ratio` | `float` | 0.01 |  |
| `outfit_swapper.max_mask_ratio` | `float` | 0.45 |  |
| `outfit_swapper.face_bbox_padding_ratio` | `float` | 0.12 |  |
| `outfit_swapper.face_mask_feather_px` | `int` | 20 |  |
| `outfit_swapper.canny_low_threshold` | `int` | 80 |  |
| `outfit_swapper.canny_high_threshold` | `int` | 180 |  |
| `outfit_swapper.pre_scan_skin_threshold` | `float` | 0.08 |  |
| `outfit_swapper.max_retries` | `int` | 2 |  |
| `outfit_swapper.denoise.min` | `float` | 0.45 |  |
| `outfit_swapper.denoise.max` | `float` | 0.55 |  |
| `outfit_swapper.sfw_filter.enabled` | `bool` | true |  |
| `outfit_swapper.sfw_filter.repair_threshold` | `float` | 0.18 |  |
| `outfit_swapper.sfw_filter.final_flag_threshold` | `float` | 0.3 |  |
| `outfit_swapper.sfw_filter.repair_denoise` | `float` | 0.5 |  |
| `outfit_swapper.sfw_filter.torso_top_frac` | `float` | 0.3 |  |
| `outfit_swapper.sfw_filter.repair_outfit_prompt` | `str` | "ultra-tight black second-skin bodycon crop top, thick opaque fabric stretched across large round silicone D-cup bust, every curve outlined, zero slack, no exposed skin on chest\n" |  |
| `outfit_swapper.segmentation.sam_checkpoint` | `str` | "/workspace/ComfyUI/models/sam/sam_vit_b_01ec64.pth" |  |
| `outfit_swapper.segmentation.sam_model_type` | `str` | "vit_b" |  |
| `outfit_swapper.segmentation.yolo_weights` | `str` | "yolov8n-seg.pt" |  |
| `outfit_swapper.extra_negative` | `str` | "nude, topless, bare chest, exposed nipples, areola, underboob, sideboob, transparent clothing, see-through fabric, no top, open shirt, cleavage gap, underwear only, lingerie, exposed skin on chest above waist, different person, wrong face, identity drift, extra fingers, extra limbs, deformed torso, broken anatomy, small eyes, narrow eyes, pale skin, fair skin, dark skin\n" |  |
| `outfit_swapper.default_patterns` | `list` | ["bust_sfw_*.png", "orbit_*.png", "full_body*.png", "body_*.png"] |  |
| `outfit_swapper.presets.tight_black` | `str` | "ultra-tight black second-skin bodycon crop top, thick opaque fabric stretched across large round silicone D-cup bust, every curve outlined, zero slack" |  |
| `outfit_swapper.presets.tight_white` | `str` | "ultra-tight white ribbed bodycon top, second-skin opaque fabric, large round silicone D-cup bust perfectly shaped, maximum curve definition" |  |
| `outfit_swapper.presets.tight_nude` | `str` | "skin-tight nude-tone seamless bodycon top, thick opaque second-skin fabric, large round silicone bust prominently outlined" |  |
| `outfit_swapper.presets.tight_turtleneck_black` | `str` | "skin-tight black turtleneck, dense opaque ribbed knit stretched across large round silicone D-cup bust, high neck fully covered, second-skin silhouette" |  |
| `outfit_swapper.presets.tight_turtleneck_grey` | `str` | "ultra-tight grey ribbed turtleneck, thick opaque stretch knit, large round silicone D-cup bust clearly defined" |  |
| `outfit_swapper.presets.tight_dress_black` | `str` | "ultra-tight black bodycon mini dress, thick opaque stretch fabric, large round silicone bust and waist curves outlined, second-skin fit" |  |
| `outfit_swapper.presets.tight_dress_red` | `str` | "skin-tight red bodycon dress, dense opaque fabric, large round silicone D-cup bust prominently shaped, waist cinched" |  |
| `outfit_swapper.presets.tight_crop_burgundy` | `str` | "ultra-tight burgundy crop top, second-skin opaque fabric, large round silicone bust perfectly outlined" |  |
| `outfit_swapper.presets.bikini_white` | `str` | "tiny white string bikini, minimal triangle top with thin string ties, matching tiny white string bikini bottom, golden tan skin, visible pores, beach" |  |
| `outfit_swapper.presets.bikini_black` | `str` | "tiny black string bikini, small triangle bikini top with thin string ties, matching black micro bikini bottom, golden tan skin, visible pores, beach" |  |
| `outfit_swapper.presets.bikini_red` | `str` | "tiny red string bikini, minimal triangle top, matching red micro string bikini bottom, beach, golden tan skin, visible pores" |  |
| `outfit_swapper.presets.thong_bikini_red` | `str` | "red micro thong bikini, tiny triangle top barely covering nipples, matching red thong bikini bottom, golden tan skin, visible pores" |  |
| `outfit_swapper.presets.one_piece_black` | `str` | "black high-cut one-piece swimsuit, deep plunge V-neckline, high leg cut, thin shoulder straps, golden tan skin, visible pores" |  |
| `outfit_swapper.presets.lingerie_lace` | `str` | "matching black lace bra and panties set, delicate lace with sheer panels, underwire bra, matching lace thong, golden tan skin, visible pores" |  |
| `outfit_swapper.presets.sports_black_set` | `str` | "black sports crop top and matching black mini skirt, athletic fit, golden tan skin, visible pores, beach setting" |  |
| `outfit_swapper.presets.sports_crop_white` | `str` | "white sports crop top, athletic fit, natural bust silhouette, golden tan skin, visible pores" |  |
| `ref_regen.steps` | `int` | 28 |  |
| `ref_regen.guidance` | `float` | 3.5 |  |
| `ref_regen.sampler` | `str` | "euler" |  |
| `ref_regen.scheduler` | `str` | "simple" |  |
| `ref_regen.pulid_weight` | `float` | 0.6 |  |
| `ref_regen.pulid_start` | `float` | 0.0 |  |
| `ref_regen.pulid_end` | `float` | 0.58 |  |
| `ref_regen.clip_l_triggers` | `str` | "filmfotos, golden tan skin, platinum blonde hair" |  |
| `ref_regen.skin_pores` | `str` | "visible open skin pores, realistic skin microrelief, skin subsurface scattering, fine vellus hair on skin, golden sun-kissed tan skin" |  |
| `ref_regen.lighting` | `str` | "soft natural outdoor light, warm golden hour glow, rim light catching platinum blonde hair, beach natural light" |  |
| `ref_regen.clean` | `str` | "clean even golden tan skin, no blemishes, no tattoos, no beauty mole, unretouched authentic photograph, tattoo free" |  |
| `ref_regen.quality` | `str` | "RAW photo Sony A7R V 85mm f1.4, hyperrealistic photograph, sharp focus, natural film grain, shallow depth of field, photorealistic sensor noise" |  |
| `ref_regen.negative` | `str` | "blurry, deformed, bad anatomy, extra limbs, watermark, anime, cartoon, tattoos, plastic skin, airbrushed skin, beauty filter, 3d render, cgi, smooth poreless skin, oversmoothed skin, digital painting, illustration, pale skin, fair skin, dark skin, waxy skin, doll skin, beauty mole, skin mole, freckles, brown hair, chestnut hair, dark hair, grey eyes, green eyes" |  |
| `ref_regen.lora_stack` | `list` | [{"name": "polyhedron_flux_perfect_skin.safetensors", "weight": 0.22}] |  |
| `ref_regen.detail_lora_stack` | `list` | [{"name": "polyhedron_flux_perfect_skin.safetensors", "weight": 0.12}] |  |
| `ref_regen.tight_crop_size` | `int` | 896 |  |
| `ref_regen.tight_denoise` | `float` | 0.42 |  |
| `ref_regen.tight_steps` | `int` | 34 |  |
| `ref_regen.tight_guidance` | `float` | 2.75 |  |
| `ref_regen.detail_denoise` | `float` | 0.2 |  |
| `ref_regen.detail_steps` | `int` | 34 |  |
| `ref_regen.detail_guidance` | `float` | 2.75 |  |
| `ref_regen.detail_clip_l` | `str` | "filmfotos, visible open pores, golden tan skin" |  |
| `ref_regen.upscale_denoise` | `float` | 0.38 |  |
| `ref_regen.upscale_steps` | `int` | 28 |  |
| `ref_regen.upscale_guidance` | `float` | 3.0 |  |
| `ref_regen.upscale_control_strength` | `float` | 0.6 |  |
| `ref_regen.upscale_control_end` | `float` | 0.82 |  |
| `ref_regen.upscale_positive` | `str` | "filmfotos, raw realistic skin, golden sun-kissed tan skin, visible skin pores, platinum blonde hair, light ice-blue eyes, athletic figure" |  |
| `ref_regen.upscale_clip_l` | `str` | "filmfotos, visible open pores, golden tan skin" |  |
| `ref_regen.upscale_negative` | `str` | "blurry, plastic skin, airbrushed, smooth skin, waxy skin, doll skin, beauty filter, pale skin, dark skin, beauty mole" |  |

#### [unified_config_Lila.yaml]
| key | type | default / YAML value | где используется |
|---|---|---|---|
| `comfyui.base_url` | `str` | "http://127.0.0.1:8188" |  |
| `comfyui.timeout_seconds` | `int` | 2400 |  |
| `comfyui.poll_interval` | `float` | 1.5 |  |
| `paths.workspace_root` | `str` | "/workspace" |  |
| `paths.config_dir` | `str` | "/workspace/war333/config" |  |
| `paths.runtime_root` | `str` | "{workspace_root}/godtier_v7_runtime" |  |
| `paths.emotions_file` | `str` | "/workspace/war333/config/emotions_v7_BEST.yaml" |  |
| `paths.pose_library_root` | `str` | "/workspace/ComfyUI/poses" |  |
| `paths.sfw_pose_pairs_dir` | `str` | "/workspace/ComfyUI/poses" |  |
| `paths.nsfw_pose_pairs_dir` | `str` | "/workspace/ComfyUI/poses" |  |
| `paths.manual_ref_face` | `str` | "" |  |
| `paths.manual_ref_body_sfw` | `str` | "/workspace/godtier_v7_runtime/lilav_voss/stage0/selected/ref_body_sfw.png" |  |
| `paths.manual_ref_body_nsfw` | `str` | "/workspace/godtier_v7_runtime/lilav_voss/stage0/selected/ref_body_nsfw.png" |  |
| `orchestrator.vram_min_free_mb` | `int` | 12000 |  |
| `orchestrator.sleep_between_heavy_models_seconds` | `int` | 12 |  |
| `models.flux_dev_unet` | `str` | "fluxedUpFluxNSFW_81BF16.safetensors" |  |
| `models.flux_dev_unet_sfw` | `str` | "fluxedUpFluxNSFW_81BF16.safetensors" |  |
| `models.flux_dev_unet_nsfw` | `str` | "fluxedUpFluxNSFW_81BF16.safetensors" |  |
| `models.flux_fill_unet` | `str` | "flux1-fill-dev.safetensors" |  |
| `models.flux_fill_weight_dtype` | `str` | "fp8_e4m3fn" |  |
| `models.flux_dev_unet_path_for_onetrainer` | `str` | "/workspace/ComfyUI/models/unet/Persephone_2.0_FP16.safetensors" |  |
| `models.detail_lora` | `str` | "aidmaHyperrealism-FLUX-v0.3.safetensors" |  |
| `models.detail_lora_strength` | `float` | 0.25 |  |
| `models.bust_breast_lora` | `str` | "Big_natural_breasts_for_FLUX.safetensors" |  |
| `models.bust_breast_lora_strength` | `float` | 0.45 |  |
| `models.bust_breast_lora_strength_sfw` | `float` | 0.45 |  |
| `models.bust_breast_lora_strength_nsfw` | `float` | 0.85 |  |
| `models.face_lora_name` | `str` | "aidmaHyperrealism-FLUX-v0.3.safetensors" |  |
| `models.face_lora_strength` | `float` | 0.0 |  |
| `models.controlnet_union` | `str` | "FLUX.1-dev-ControlNet-Union-Pro-2.0.safetensors" |  |
| `models.pulid_model` | `str` | "pulid_flux_v0.9.1.safetensors" |  |
| `models.eva_clip` | `str` | "EVA02_CLIP_E_psz14_s4B.pt" |  |
| `models.face_analysis_model` | `str` | "buffalo_l" |  |
| `models.insightface_provider` | `str` | "CPU" |  |
| `models.vae` | `str` | "ae.safetensors" |  |
| `models.clip_l` | `str` | "clip_l.safetensors" |  |
| `models.t5xxl` | `str` | "t5xxl_fp16.safetensors" |  |
| `models.florence_model_id` | `str` | "microsoft/Florence-2-large" |  |
| `models.florence_device` | `str` | "cpu" |  |
| `character.id` | `str` | "LilaVoss" |  |
| `character.trigger_token` | `str` | "LilaVoss" |  |
| `character.face_anchor` | `str` | "young woman with very long jet-black raven hair, thick voluminous flowing heavily over both shoulders and framing the face and chest, large almond-shaped warm brown eyes with dark limbal ring, thick dark strongly arched eyebrows, extremely high sharp prominent cheekbones, strong defined angular jawline, very slim narrow face, straight refined nose with narrow bridge, full soft plump lips with natural terracotta-coral tone, very deep dark bronze tan skin, dark Mediterranean olive complexion, deeply sun-kissed golden-brown skin tone, realistic skin texture with visible open pores and natural micro texture, moody cinematic lighting with warm side rim light, seductive confident neutral expression with direct gaze and slightly parted lips\n" |  |
| `character.flux_identity_priority` | `str` | "same woman from the exact reference photo, exact face geometry locked, exact slim elongated face shape locked, exact large almond warm brown eyes with dark limbal ring locked, exact extremely high sharp cheekbones locked, exact strong angular jawline locked, exact full plump lips with natural terracotta tone locked, very long jet-black raven hair flowing heavily over shoulders and chest, very deep dark bronze tan Mediterranean olive skin, realistic skin texture with visible pores, realistic portrait photograph\n" |  |
| `character.orbit_face_lock` | `str` | "same woman from the reference photo, exact large warm brown almond eyes locked, exact slim face silhouette and extremely high cheekbones locked, exact full plump lips locked, very long jet-black hair flowing naturally over shoulders, very dark bronze Mediterranean tan skin, realistic skin texture, seductive confident expression\n" |  |
| `character.hair` | `str` | "very long jet-black raven hair, thick voluminous, cold blue-black specular highlights, individual strands visible, heavily framing face and cascading over shoulders and upper chest\n" |  |
| `character.eyes` | `str` | "large almond-shaped warm brown eyes with dark limbal ring, thick dark strongly arched eyebrows, natural separated lashes, confident seductive direct gaze\n" |  |
| `character.lips` | `str` | "enormously full oversized lips, extremely heavy thick lower lip with massive volume, very pronounced deep cupid bow upper lip, exaggerated natural plumpness, large lip body much fuller than average, natural terracotta-coral tone, wet glossy sheen\n" |  |
| `character.face_shape` | `str` | "very slim narrow elongated face, extremely high sharp prominent cheekbones, strong defined angular jawline, very slim narrow lower face\n" |  |
| `character.skin` | `str` | "very deep dark bronze tan skin, dark Mediterranean olive complexion, deeply sun-kissed golden-brown tone, realistic texture with visible open pores and natural imperfections\n" |  |
| `character.hairstyles` | `list` | ["long straight dark chestnut-brown hair worn loose and flowing, center part, strands falling over shoulders", "long dark chestnut-brown hair pulled back in a sleek high ponytail, face fully exposed, clean and polished", "long dark chestnut-brown hair half-up half-down, rest flowing straight down the back", "long dark chestnut-brown hair in a loose low bun, tendrils framing face softly", "long dark chestnut-brown hair in a classic side braid over one shoulder", "long dark chestnut-brown hair in a messy bun with loose face-framing strands"] |  |
| `prompts.quality_tail` | `str` | "filmfotos, flux_realism, sharp skin texture, realistic pores, crisp detail, highly detailed, photorealistic, natural film grain\n" |  |
| `prompts.negative_base` | `str` | "blurry, deformed, bad anatomy, extra limbs, watermark, anime, cartoon, tattoos, body piercings, banding, color banding, plastic skin, airbrushed skin, smooth perfect skin, beauty filter, 3d render, cgi\n" |  |
| `prompts.face_reference` | `str` | "front-facing portrait reference, neutral relaxed expression, moody cinematic lighting with warm side rim light, clean dark background, identity-safe reference shot, very slim narrow elongated face, extremely high sharp prominent cheekbones, strong angular jawline, large almond warm brown eyes, full plump lips natural terracotta tone, very deep dark bronze tan Mediterranean olive skin, jet-black raven hair flowing over shoulders\n" |  |
| `prompts.hands_reference` | `str` | "studio hand reference, both hands clearly visible, separated fingers, clean nails, realistic knuckles, anatomy-first composition, very dark bronze tan skin tone\n" |  |
| `prompts.body_reference_sfw` | `str` | "wearing black turtleneck midi dress, thick heavy opaque ribbed jersey knit, high neck completely covering throat and chest, long sleeves, dress hem at knee, no cleavage no décolletage no skin on torso, turtleneck collar touching chin, zero transparency, dress stretched across large bust silhouette under fabric, full body shot from crown of head to both knees in frame, both knees visible, standing upright facing camera, enormously full lips extremely heavy lower lip massive cupid bow thick lip volume natural terracotta tone wet glossy sheen, beautiful young woman very deep dark bronze tan Mediterranean olive skin, jet-black long raven hair, large bust volume shaped under turtleneck, RAW photo Canon EOS R5 35mm f/2.0 ISO 400 natural daylight, slight chromatic aberration candid feel no beauty filter natural film grain\n" |  |
| `prompts.body_reference_nsfw` | `str` | "RAW photo, Sony A7R IV, 50mm f/1.8, ISO 800, warm ambient indoor light, full body shot head to toe, completely nude, beautiful young woman, very dark bronze tan Mediterranean olive skin, jet-black long hair, large augmented round breasts size 34DD, prominent silicone implant shape, high round projection, firm round shape, natural nipple position, completely shaved pubic area, smooth bare intimate area, soft pink labia, full plump natural labia, intimate anatomy clearly visible, natural skin texture with pores on chest abdomen and thighs, subtle bikini tan lines, a few scattered small moles on skin, realistic depth of field, no beauty filter, raw unretouched photograph\n" |  |
| `prompts.body_dataset_sfw` | `str` | "candid upper-body fashion photograph, clothed upper-body portrait, ultra-tight body-con clothing perfectly outlining bust and waist curves, very dark bronze tan skin, jet-black hair, realistic photography, natural skin texture, large round augmented bust clearly defined under fabric, sharp focus, film grain, hyperrealistic photograph\n" |  |
| `prompts.body_dataset_nsfw` | `str` | "candid upper-body nude photograph, realistic photography, large augmented round breasts size 34DD consistent projection, firm high round silicone shape, consistent chest proportions, very dark bronze tan Mediterranean skin, natural skin texture, sharp focus, film grain, completely shaved smooth intimate area\n" |  |
| `prompts.sfw_flux_guardrails` | `str` | "upper-body portrait, face in frame, fully clothed in ultra-tight fabric, second-skin fit clothing, maximum curve definition under opaque fabric, bust and hip curves clearly outlined but fully covered, no skin visible above waist, coherent anatomy, natural skin texture, hyperrealistic photograph\n" |  |
| `prompts.nsfw_flux_guardrails` | `str` | "realistic human anatomy, coherent shoulders ribcage and torso, upper-body crop only, maintain natural skin texture and proportions, large augmented round breasts 34DD consistent shape and projection, natural round silicone implant shape, smooth shaved intimate area, clean bronze tan skin without tattoos\n" |  |
| `stage0.face_reference_count` | `int` | 100 |  |
| `stage0.hands_reference_count` | `int` | 4 |  |
| `stage0.body_reference_count` | `int` | 10 |  |
| `stage0.face_width` | `int` | 1024 |  |
| `stage0.face_height` | `int` | 1024 |  |
| `stage0.hands_width` | `int` | 832 |  |
| `stage0.hands_height` | `int` | 1216 |  |
| `stage0.body_width` | `int` | 832 |  |
| `stage0.body_height` | `int` | 1536 |  |
| `stage0.identity_adapter_weight` | `float` | 0.82 |  |
| `stage0.body_pulid_weight` | `float` | 0.52 |  |
| `stage0.body_pulid_start_at` | `float` | 0.0 |  |
| `stage0.body_pulid_end_at` | `float` | 0.85 |  |
| `stage0.generation.steps` | `int` | 35 |  |
| `stage0.generation.guidance` | `float` | 3.5 |  |
| `stage0.generation.sampler` | `str` | "dpmpp_2m" |  |
| `stage0.generation.scheduler` | `str` | "beta" |  |
| `stage0.generation.negative_sfw` | `str` | "nude, nsfw, topless, bare chest, exposed breasts, nipples visible, areola, transparent clothing, see-through fabric, wet transparent top, no top, open shirt, cleavage gap, underwear only, lingerie, bikini top, exposed skin on chest" |  |
| `phaseA.emotion_count` | `int` | 31 |  |
| `phaseA.candidates_per_preset` | `int` | 5 |  |
| `phaseA.candidates_per_preset_heavy` | `int` | 4 |  |
| `phaseA.verification_similarity_threshold` | `float` | 0.53 |  |
| `phaseA.minimum_verified_frames` | `int` | 190 |  |
| `phaseA.pulid_gen_weight` | `float` | 0.52 |  |
| `phaseA.selection_similarity_weight` | `float` | 0.48 |  |
| `phaseA.orbit_selection_similarity_weight` | `float` | 0.34 |  |
| `phaseA.hairstyle_selection_similarity_weight` | `float` | 0.46 |  |
| `phaseA.emotion_reference_strategy` | `str` | "base_ref_only" |  |
| `phaseA.generation.width` | `int` | 832 |  |
| `phaseA.generation.height` | `int` | 1216 |  |
| `phaseA.generation.steps` | `int` | 30 |  |
| `phaseA.generation.guidance` | `float` | 3.2 |  |
| `phaseA.inpaint.bbox_padding_ratio` | `float` | 0.12 |  |
| `phaseA.inpaint.mask_feather_px` | `int` | 8 |  |
| `phaseA.inpaint.steps` | `int` | 28 |  |
| `phaseA.inpaint.guidance` | `float` | 30.0 |  |
| `phaseA.inpaint.denoise` | `float` | 0.5 |  |
| `phaseA.inpaint.identity_adapter_weight` | `float` | 0.9 |  |
| `phaseA.inpaint.fusion` | `str` | "mean" |  |
| `phaseA.inpaint.train_step` | `int` | 500 |  |
| `phaseA.captioning.append_quality_tail` | `str` | "flux_realism, sharp skin texture, realistic pores, crisp detail, highly detailed, photorealistic, film grain" |  |
| `phaseA.captioning.include_raw_caption_blocks` | `list` | ["emotion", "hairstyle"] |  |
| `phaseA.liquids_mode.enabled` | `bool` | true |  |
| `phaseA.liquids_mode.tears_text` | `str` | "visible tears, wet lower eyelids, tear tracks on cheeks" |  |
| `phaseA.liquids_mode.drool_text` | `str` | "visible saliva string at tongue or lower lip, wet drool on lips and chin" |  |
| `phaseA.liquids_mode.sweat_text` | `str` | "light sweat sheen on skin" |  |
| `phaseA.stress_pack.enabled` | `bool` | true |  |
| `phaseA.stress_pack.intense_tokens` | `list` | ["tension in brow and jaw", "wet lower eyelids", "slightly parted lips", "subtle facial strain"] |  |
| `phaseA.orbit_inpaint.denoise` | `float` | 0.52 |  |
| `phaseA.orbit_inpaint.mask_feather_px` | `int` | 5 |  |
| `phaseA.orbit_inpaint.steps` | `int` | 34 |  |
| `phaseA.orbit_inpaint.guidance` | `float` | 30.0 |  |
| `phaseA.orbit_inpaint.identity_adapter_weight` | `float` | 0.94 |  |
| `phaseA.orbit_inpaint.bbox_padding_ratio` | `float` | 0.1 |  |
| `phaseA.orbit_inpaint.fusion` | `str` | "mean" |  |
| `phaseA.orbit_inpaint.train_step` | `int` | 500 |  |
| `phaseA.orbit_inpaint.auto_apply` | `bool` | false |  |
| `phaseA.orbit_inpaint.apply_to` | `list` | ["orbit_front", "orbit_left_45", "orbit_right_45", "orbit_left_profile", "orbit_right_profile", "orbit_high_angle", "orbit_low_angle"] |  |
| `phaseA.orbit_prompts` | `list` | [{"key": "orbit_front", "pulid_weight": 0.55, "prompt": "portrait photograph of a young woman facing directly forward, both eyes fully visible and symmetrical, nose centered in frame, both ears equally visible, chin pointing straight at camera, natural relaxed posture, shoulders level and square, neck upright, studio portrait photography, very slim narrow elongated face, extremely high sharp prominent cheekbones, strong angular jawline, large almond warm brown eyes with dark limbal ring, full plump lips terracotta tone, very deep dark bronze tan Mediterranean olive skin, jet-black raven hair\n"}, {"key": "orbit_left_45", "pulid_weight": 0.32, "prompt": "portrait photograph of a young woman with her head turned to the left, right cheek and right eye prominently visible, left side of face partially turned away, classic three-quarter view, candid portrait photography, very slim narrow elongated face, extremely high cheekbones, large almond warm brown eye visible, full plump lips, very deep dark bronze tan skin, jet-black hair\n"}, {"key": "orbit_left_profile", "pulid_weight": 0.24, "prompt": "strict left profile portrait photograph of a young woman, only the right side of her face visible, right eye and nostril in view, clean sharp profile silhouette, editorial profile shot, hair falling naturally, very slim narrow face in profile, extremely high sharp cheekbone visible, full plump lips in profile, strong angular jawline profile, very deep dark bronze tan skin, jet-black raven hair\n"}, {"key": "orbit_left_rear_135", "pulid_weight": 0.0, "prompt": "portrait photograph of a young woman seen from behind and slightly to the right, back of head occupying most of frame, jet-black raven hair visible from behind, left ear barely peeking at edge, nape of neck visible, both shoulder blades in frame, hair texture detailed from rear perspective\n"}, {"key": "orbit_back", "pulid_weight": 0.0, "prompt": "rear view portrait photograph of a young woman shot from directly behind, back of head centered in frame, no face visible whatsoever, detailed jet-black raven hair texture and structure from behind, nape of neck clearly visible, both shoulders symmetrical in lower frame, clean documentary back-of-head shot\n"}, {"key": "orbit_right_rear_135", "pulid_weight": 0.0, "prompt": "portrait photograph of a young woman seen from behind and slightly to the left, back of head occupying most of frame, jet-black raven hair visible from behind, right ear barely peeking at edge, nape of neck visible, both shoulder blades in frame, hair texture detailed from rear perspective\n"}, {"key": "orbit_right_profile", "pulid_weight": 0.24, "prompt": "strict right profile portrait photograph of a young woman, only the left side of her face visible, left eye and nostril in view, clean sharp profile silhouette, editorial profile shot, hair falling naturally, very slim narrow face in profile, extremely high sharp cheekbone visible, full plump lips in profile, strong angular jawline profile, very deep dark bronze tan skin, jet-black raven hair\n"}, {"key": "orbit_right_45", "pulid_weight": 0.32, "prompt": "portrait photograph of a young woman with her head turned to the right, left cheek and left eye prominently visible, right side of face partially turned away, classic three-quarter view, candid portrait photography, very slim narrow elongated face, extremely high cheekbones, large almond warm brown eye visible, full plump lips, very deep dark bronze tan skin, jet-black hair\n"}, {"key": "orbit_high_angle", "pulid_weight": 0.38, "prompt": "overhead angle portrait photograph of a young woman shot from above, top of her head and forehead dominate the upper frame, eyes appear lower in frame, nose foreshortened, chin receding, jet-black raven hair visible across top of skull, shoulders narrow in lower frame, bird's eye perspective portrait\n"}, {"key": "orbit_low_angle", "pulid_weight": 0.38, "prompt": "low angle portrait photograph of a young woman shot from below chin level, underside of chin and jaw dominate, nostrils visible from below, chin prominent, forehead receding far back, neck elongated and prominent, chest and collarbones visible at bottom of frame, worm's eye view portrait, very deep dark bronze tan skin\n"}] |  |
| `phaseA.body.candidates_per_shot` | `int` | 4 |  |
| `phaseA.body.selection_similarity_weight` | `float` | 0.58 |  |
| `phaseA.body.use_orbit_reference_chaining` | `bool` | true |  |
| `phaseA.body.generation.steps` | `int` | 32 |  |
| `phaseA.body.generation.guidance` | `float` | 2.8 |  |
| `phaseA.body.generation.sampler` | `str` | "dpmpp_2m" |  |
| `phaseA.body.generation.scheduler` | `str` | "beta" |  |
| `phaseA.body.generation.negative_sfw` | `str` | "nude, nsfw, flat chest, wide shot, face cut off, tattoos, piercings" |  |
| `phaseA.body.generation.negative_nsfw` | `str` | "bad anatomy, wide shot, face cut off, tattoos, piercings" |  |
| `phaseA.body.inpaint.bbox_padding_ratio` | `float` | 0.08 |  |
| `phaseA.body.inpaint.mask_feather_px` | `int` | 6 |  |
| `phaseA.body.inpaint.steps` | `int` | 22 |  |
| `phaseA.body.inpaint.guidance` | `float` | 4.5 |  |
| `phaseA.body.inpaint.denoise` | `float` | 0.52 |  |
| `phaseA.body.inpaint.identity_adapter_weight` | `float` | 0.8 |  |
| `phaseA.body.inpaint.fusion` | `str` | "mean" |  |
| `phaseA.body.inpaint.train_step` | `int` | 500 |  |
| `phaseA.body.bust.framing` | `str` | "upper body shot, waist-up framing, bust portrait, shoulders and chest visible" |  |
| `phaseA.body.bust.sfw_count` | `int` | 13 |  |
| `phaseA.body.bust.nsfw_count` | `int` | 22 |  |
| `phaseA.body.bust.candidates_per_shot` | `int` | 6 |  |
| `phaseA.body.bust.width` | `int` | 832 |  |
| `phaseA.body.bust.height` | `int` | 1216 |  |
| `phaseA.body.bust.pulid_face_weight` | `float` | 0.4 |  |
| `phaseA.body.bust.pulid_body_weight_sfw` | `float` | 0.85 |  |
| `phaseA.body.bust.pulid_body_weight_nsfw` | `float` | 0.65 |  |
| `phaseA.body.bust.sfw_nudity_threshold` | `float` | 0.42 |  |
| `phaseA.body.bust.orbit_angles` | `list` | [{"key": "front", "framing": "waist-up portrait, head and shoulders fully visible, upper body to waist, facing directly forward, torso facing camera", "back_type": "", "pulid_face": 0.58, "neg_extra": "", "pos_extra": "fuller bust silhouette under clothing, opaque fabric covering chest"}, {"key": "left_45", "framing": "waist-up portrait, three-quarter left view, head and torso turned left together, right cheek prominent, body rotation visible to waist", "back_type": "", "pulid_face": 0.32, "neg_extra": "frontal face, facing directly at camera, symmetrical face", "pos_extra": "fuller bust silhouette under clothing, opaque fabric covering chest"}, {"key": "right_45", "framing": "waist-up portrait, three-quarter right view, head and torso turned right together, left cheek prominent, body rotation visible to waist", "back_type": "", "pulid_face": 0.32, "neg_extra": "frontal face, facing directly at camera, symmetrical face", "pos_extra": "fuller bust silhouette under clothing, opaque fabric covering chest"}, {"key": "left_profile", "framing": "waist-up portrait, strict left profile, only right side of face visible, torso in side profile, shoulder-to-waist silhouette visible", "back_type": "", "pulid_face": 0.24, "neg_extra": "both eyes visible, frontal face, three-quarter view", "pos_extra": "fuller bust silhouette under clothing, opaque fabric covering chest"}, {"key": "right_profile", "framing": "waist-up portrait, strict right profile, only left side of face visible, torso in side profile, shoulder-to-waist silhouette visible", "back_type": "", "pulid_face": 0.24, "neg_extra": "both eyes visible, frontal face, three-quarter view", "pos_extra": "fuller bust silhouette under clothing, opaque fabric covering chest"}, {"key": "high_angle", "framing": "waist-up portrait shot from above, camera looking down, top of head and forehead more prominent, shoulders and upper torso visible", "back_type": "", "pulid_face": 0.3, "neg_extra": "eye level portrait, flat perspective, normal angle", "pos_extra": "fuller bust silhouette under clothing, opaque fabric covering chest"}, {"key": "low_angle", "framing": "waist-up portrait shot from below, camera looking upward, chin and jawline more prominent, shoulders and upper torso visible", "back_type": "", "pulid_face": 0.3, "neg_extra": "eye level portrait, flat perspective, normal angle", "pos_extra": "fuller bust silhouette under clothing, opaque fabric covering chest"}, {"key": "left_rear_135", "framing": "rear-left three-quarter upper-body portrait, subject standing upright, left shoulder blade and full upper back dominant, waist visible, torso rotated away from camera 135 degrees left, only tiny right cheek or jawline visible at most, no frontal chest visible", "back_type": "half", "pulid_face": 0.14, "neg_extra": "frontal face, both eyes visible, facing camera, frontal chest visible, seated pose, kneeling pose, crouching pose", "pos_extra": "back anatomy locked, spine line readable, shoulders aligned, no front collapse"}, {"key": "right_rear_135", "framing": "rear-right three-quarter upper-body portrait, subject standing upright, right shoulder blade and full upper back dominant, waist visible, torso rotated away from camera 135 degrees right, only tiny left cheek or jawline visible at most, no frontal chest visible", "back_type": "half", "pulid_face": 0.14, "neg_extra": "frontal face, both eyes visible, facing camera, frontal chest visible, seated pose, kneeling pose, crouching pose", "pos_extra": "back anatomy locked, spine line readable, shoulders aligned, no front collapse"}, {"key": "back_half", "framing": "rear three-quarter hip-up portrait, subject standing upright, camera behind subject, upper back waist hips and buttocks visible, torso rotated away from camera, only one cheek or jawline silhouette visible at most, no frontal chest visible, framing from shoulders to upper thighs", "back_type": "half", "pulid_face": 0.1, "neg_extra": "full frontal face, both eyes visible, facing camera, frontal breasts, seated pose, kneeling pose, crouching pose, duplicated hands", "pos_extra": "back anatomy locked, spine line readable, shoulders aligned, no front collapse"}, {"key": "back_pure", "framing": "full rear hip-up portrait, subject standing upright, back of head neck shoulders upper back waist and hips visible, spine line readable, buttocks visible, absolutely no face visible, framing from shoulders to upper thighs", "back_type": "pure", "pulid_face": 0.0, "neg_extra": "face visible, any eye visible, front view, seated pose, kneeling pose, crouching pose", "pos_extra": "back anatomy locked, spine line readable, shoulders aligned, no front collapse"}] |  |
| `phaseA.body.bust.sfw_ref_clothing_anchor` | `str` | "wearing ultra-tight black second-skin bodycon top, fabric stretched taut across large augmented round 34DD bust, every curve perfectly outlined under thick opaque fabric, no cleavage gap, no transparency, maximum body-con fit, consistent upper-body look matching body reference\n" |  |
| `phaseA.body.bust.lighting_variants` | `list` | ["soft studio lighting, large diffused key light from left", "warm golden hour window light, side-lit, rim light on hair", "dramatic Rembrandt lighting, strong key from upper right, deep shadows", "overcast outdoor light, soft flat even illumination", "cool blue ambient light, soft backlight glow, slight front fill", "warm orange practical light, cozy indoor atmosphere, slight lens flare", "harsh direct flash, bleached highlights, documentary style", "soft butterfly lighting, key light directly above, glamour portrait"] |  |
| `phaseA.body.bust.sfw_outfit_variants` | `list` | ["wearing ultra-tight black second-skin bodycon crop top, fabric stretched taut across large round 34DD bust, every curve perfectly outlined, zero slack, opaque thick fabric, no transparency", "wearing white ultra-tight ribbed bodycon top, second-skin fit, large augmented bust perfectly shaped under taut opaque fabric, maximum curve definition", "wearing tight deep-V black bodycon dress, thick opaque fabric, large round bust prominently shaped under fabric, body-con silhouette head to hips", "wearing skin-tight charcoal turtleneck, dense opaque ribbed knit stretched across large round bust, every curve defined, zero transparency", "wearing ultra-tight burgundy bodycon top, second-skin stretch fabric, large augmented bust and waist curves perfectly outlined under taut opaque material", "wearing tight nude-tone bodycon top, thick seamless opaque fabric, large round 34DD bust shape clearly defined, body-con fit with zero slack", "wearing skin-tight black mock-neck long sleeve top, second-skin fabric stretched taut across large augmented bust, strong curve silhouette", "wearing ultra-tight forest green bodycon crop, thick opaque stretch fabric, large round bust perfectly outlined, waist cinched, maximum body-con", "wearing tight white fitted tank top, double-layer thick opaque cotton stretched across large augmented 34DD bust, strong defined curves", "wearing skin-tight navy blue bodycon dress, opaque heavy stretch knit, large round augmented bust prominently defined under taut fabric", "wearing ultra-tight camel ribbed bodycon top, second-skin fit, thick opaque fabric stretched across large round bust, every curve maximum definition", "wearing tight black long sleeve crop top, second-skin fabric, large augmented bust clearly shaped under thick opaque material, body-con silhouette"] |  |
| `phaseA.body.bust.selection_similarity_weight` | `float` | 0.52 |  |
| `phaseA.body.hairstyle_change_every_angles` | `int` | 2 |  |
| `phaseA.onetrainer.output_model_path` | `str` | "/workspace/onetrainer/outputs/{character_id}_face_v11.safetensors" |  |
| `phaseA.onetrainer.lora_model_name` | `str` | "LilaVoss_face_v11" |  |
| `phaseA.onetrainer.rank` | `int` | 32 |  |
| `phaseA.onetrainer.alpha` | `int` | 32 |  |
| `phaseA.onetrainer.batch_size` | `int` | 1 |  |
| `phaseA.onetrainer.gradient_accumulation_steps` | `int` | 4 |  |
| `phaseA.onetrainer.epochs` | `int` | 12 |  |
| `phaseA.emotions_per_hairstyle` | `int` | 1 |  |
| `phaseA.orbit_emotions` | `list` | ["neutral expression", "skeptical expression", "determined expression", "concerned expression", "teary sad expression", "angry restrained expression", "startled expression", "exhausted stressed expression"] |  |
| `phaseB.sfw_count` | `int` | 40 |  |
| `phaseB.nsfw_count` | `int` | 40 |  |
| `phaseB.candidates_per_preset` | `int` | 4 |  |
| `phaseB.selection_similarity_weight` | `float` | 0.55 |  |
| `phaseB.face_correction_similarity_threshold` | `float` | 0.68 |  |
| `phaseB.verification_similarity_threshold` | `float` | 0.65 |  |
| `phaseB.minimum_verified_frames` | `int` | 64 |  |
| `phaseB.generation.width` | `int` | 832 |  |
| `phaseB.generation.height` | `int` | 1216 |  |
| `phaseB.generation.steps` | `int` | 34 |  |
| `phaseB.generation.guidance` | `float` | 3.6 |  |
| `phaseB.generation.sampler` | `str` | "dpmpp_2m" |  |
| `phaseB.generation.scheduler` | `str` | "beta" |  |
| `phaseB.generation.negative_sfw` | `str` | "nude, nsfw, flat chest, wide shot, face cut off, tattoos, piercings" |  |
| `phaseB.generation.negative_nsfw` | `str` | "bad anatomy, wide shot, face cut off, tattoos, piercings" |  |
| `phaseB.controlnet.pose_strength` | `float` | 0.85 |  |
| `phaseB.controlnet.depth_strength` | `float` | 0.82 |  |
| `phaseB.controlnet.json_strength` | `float` | 0.6 |  |
| `phaseB.controlnet.start_percent` | `float` | 0.0 |  |
| `phaseB.controlnet.end_percent` | `float` | 0.75 |  |
| `phaseB.inpaint.bbox_padding_ratio` | `float` | 0.12 |  |
| `phaseB.inpaint.mask_feather_px` | `int` | 12 |  |
| `phaseB.inpaint.steps` | `int` | 20 |  |
| `phaseB.inpaint.guidance` | `float` | 4.3 |  |
| `phaseB.inpaint.denoise` | `float` | 0.36 |  |
| `phaseB.inpaint.identity_adapter_weight` | `float` | 0.84 |  |
| `phaseB.inpaint.train_step` | `int` | 280 |  |
| `phaseB.onetrainer.output_model_path` | `str` | "/workspace/onetrainer/outputs/{character_id}_body_v11.safetensors" |  |
| `phaseB.onetrainer.lora_model_name` | `str` | "LilaVoss_body_v11" |  |
| `phaseB.onetrainer.rank` | `int` | 64 |  |
| `phaseB.onetrainer.alpha` | `int` | 64 |  |
| `phaseB.onetrainer.batch_size` | `int` | 1 |  |
| `phaseB.onetrainer.gradient_accumulation_steps` | `int` | 6 |  |
| `phaseB.onetrainer.epochs` | `int` | 10 |  |
| `outfit_swapper.steps` | `int` | 28 |  |
| `outfit_swapper.guidance` | `float` | 4.6 |  |
| `outfit_swapper.control_mode` | `str` | "canny" |  |
| `outfit_swapper.controlnet_strength` | `float` | 0.92 |  |
| `outfit_swapper.control_start` | `float` | 0.0 |  |
| `outfit_swapper.control_end` | `float` | 0.92 |  |
| `outfit_swapper.pulid_weight` | `float` | 0.82 |  |
| `outfit_swapper.pulid_start_at` | `float` | 0.0 |  |
| `outfit_swapper.pulid_end_at` | `float` | 1.0 |  |
| `outfit_swapper.mask_feather_px` | `int` | 18 |  |
| `outfit_swapper.min_mask_ratio` | `float` | 0.01 |  |
| `outfit_swapper.max_mask_ratio` | `float` | 0.45 |  |
| `outfit_swapper.face_bbox_padding_ratio` | `float` | 0.12 |  |
| `outfit_swapper.face_mask_feather_px` | `int` | 20 |  |
| `outfit_swapper.canny_low_threshold` | `int` | 80 |  |
| `outfit_swapper.canny_high_threshold` | `int` | 180 |  |
| `outfit_swapper.pre_scan_skin_threshold` | `float` | 0.14 |  |
| `outfit_swapper.max_retries` | `int` | 2 |  |
| `outfit_swapper.denoise.min` | `float` | 0.52 |  |
| `outfit_swapper.denoise.max` | `float` | 0.65 |  |
| `outfit_swapper.sfw_filter.enabled` | `bool` | true |  |
| `outfit_swapper.sfw_filter.repair_threshold` | `float` | 0.18 |  |
| `outfit_swapper.sfw_filter.final_flag_threshold` | `float` | 0.3 |  |
| `outfit_swapper.sfw_filter.repair_denoise` | `float` | 0.5 |  |
| `outfit_swapper.sfw_filter.torso_top_frac` | `float` | 0.3 |  |
| `outfit_swapper.segmentation.sam_checkpoint` | `str` | "/workspace/ComfyUI/models/sams/sam_vit_b_01ec64.pth" |  |
| `outfit_swapper.segmentation.sam_model_type` | `str` | "vit_b" |  |
| `outfit_swapper.segmentation.yolo_weights` | `str` | "yolov8n-seg.pt" |  |
| `outfit_swapper.extra_negative` | `str` | "nude, topless, bare chest, exposed nipples, areola, underboob, sideboob, transparent clothing, see-through fabric, wet transparent top, no top, open shirt, cleavage gap, underwear only, lingerie, bikini top, exposed skin on chest above waist, different person, wrong face, face change, identity drift, extra fingers, extra limbs, deformed torso, broken anatomy, altered bust size, altered waist, melted fabric" |  |
| `outfit_swapper.default_patterns` | `list` | ["bust_sfw_*.png", "orbit_*.png", "full_body*.png", "body_*.png"] |  |
| `outfit_swapper.presets.tight_black` | `str` | "wearing ultra-tight black second-skin bodycon crop top, thick opaque fabric stretched taut across large augmented round 34DD bust, every curve perfectly outlined, zero slack, no transparency, strong body-con silhouette" |  |
| `outfit_swapper.presets.tight_white` | `str` | "wearing ultra-tight white ribbed bodycon top, second-skin opaque fabric, large augmented 34DD bust perfectly shaped under taut material, maximum curve definition, no transparency" |  |
| `outfit_swapper.presets.tight_nude` | `str` | "wearing skin-tight nude-tone seamless bodycon top, thick opaque second-skin fabric, large round augmented bust prominently outlined, strong waist and bust definition, zero slack" |  |
| `outfit_swapper.presets.tight_turtleneck_black` | `str` | "wearing skin-tight black turtleneck, dense opaque ribbed knit stretched taut across large augmented bust, every curve defined, high neck fully covered, second-skin silhouette" |  |
| `outfit_swapper.presets.tight_turtleneck_grey` | `str` | "wearing ultra-tight grey ribbed turtleneck, thick opaque stretch knit, large round 34DD bust clearly defined under fabric, body-con silhouette, zero transparency" |  |
| `outfit_swapper.presets.tight_dress_black` | `str` | "wearing ultra-tight black bodycon mini dress, thick opaque stretch fabric, large augmented round bust and waist curves perfectly outlined, second-skin fit from bust to hips" |  |
| `outfit_swapper.presets.tight_dress_red` | `str` | "wearing skin-tight red bodycon dress, dense opaque fabric, large augmented 34DD bust prominently shaped, waist cinched, every curve maximum definition, body-con silhouette" |  |
| `outfit_swapper.presets.tight_crop_burgundy` | `str` | "wearing ultra-tight burgundy crop top, second-skin opaque fabric, large round augmented bust perfectly outlined, strong curve silhouette, no transparency, zero slack" |  |
| `outfit_swapper.presets.bikini_white` | `str` | "wearing tiny white string bikini, minimal triangular top with thin string ties, very small triangle cups, matching tiny white string bikini bottom, tanned bronze skin, beach setting, photorealistic swimwear" |  |
| `outfit_swapper.presets.bikini_black` | `str` | "wearing tiny black string bikini, very small triangle bikini top with thin string ties, matching black micro bikini bottom, photorealistic beach photography, very dark tan skin" |  |
| `outfit_swapper.presets.bikini_red` | `str` | "wearing tiny red string bikini, minimal triangle top with thin string ties, very small cups, matching red micro string bikini bottom, beach, photorealistic swimwear photography, bronze tan skin" |  |
| `outfit_swapper.presets.thong_bikini_red` | `str` | "wearing red micro thong bikini, tiny triangle top barely covering nipples with thin string, matching red thong bikini bottom, beach or pool setting, very dark bronze tan skin, photorealistic" |  |
| `outfit_swapper.presets.one_piece_black` | `str` | "wearing black high-cut one-piece swimsuit, deep plunge V-neckline, high leg cut, thin shoulder straps, photorealistic poolside photography, dark bronze tan skin" |  |
| `outfit_swapper.presets.lingerie_lace` | `str` | "wearing matching black lace bra and panties set, delicate lace with sheer panels, underwire bra with lace trim, matching lace thong, bedroom setting, photorealistic lingerie editorial, dark bronze tan skin" |  |

#### [unified_config_MARCO.yaml]
| key | type | default / YAML value | где используется |
|---|---|---|---|
| `comfyui.base_url` | `str` | "http://127.0.0.1:8188" |  |
| `comfyui.timeout_seconds` | `int` | 2400 |  |
| `comfyui.poll_interval` | `float` | 1.5 |  |
| `paths.workspace_root` | `str` | "/workspace" |  |
| `paths.config_dir` | `str` | "/workspace/WAR333_GODTIER_OMNI/RUNTIME/config" |  |
| `paths.runtime_root` | `str` | "/workspace/godtier_v7_runtime" |  |
| `paths.emotions_file` | `str` | "/workspace/WAR333_GODTIER_OMNI/RUNTIME/config/emotions_MARCO.yaml" |  |
| `paths.pose_library_root` | `str` | "/workspace/ComfyUI/poses" |  |
| `paths.sfw_pose_pairs_dir` | `str` | "/workspace/ComfyUI/poses" |  |
| `paths.nsfw_pose_pairs_dir` | `str` | "/workspace/ComfyUI/poses" |  |
| `paths.manual_ref_face` | `str` | "/workspace/godtier_v7_runtime/MARCO/stage0/selected/ref_face.png" |  |
| `paths.manual_ref_body_sfw` | `str` | "/workspace/godtier_v7_runtime/MARCO/stage0/selected/ref_body_sfw.png" |  |
| `paths.manual_ref_body_nsfw` | `str` | "/workspace/godtier_v7_runtime/MARCO/stage0/selected/ref_body_nsfw.png" |  |
| `orchestrator.vram_min_free_mb` | `int` | 10000 |  |
| `orchestrator.sleep_between_heavy_models_seconds` | `int` | 8 |  |
| `models.flux_dev_unet` | `str` | "flux-2-klein-9b.safetensors" |  |
| `models.flux_dev_unet_sfw` | `str` | "flux-2-klein-9b.safetensors" |  |
| `models.flux_dev_unet_nsfw` | `str` | "flux-2-klein-9b.safetensors" |  |
| `models.flux_fill_unet` | `str` | "flux1-fill-dev.safetensors" |  |
| `models.flux_fill_weight_dtype` | `str` | "fp8_e4m3fn" |  |
| `models.flux_dev_unet_path_for_onetrainer` | `str` | "/workspace/ComfyUI/models/checkpoints/flux2-klein-9b/flux-2-klein-9b.safetensors" |  |
| `models.detail_lora` | `str` | "" |  |
| `models.detail_lora_strength` | `float` | 0.0 |  |
| `models.detail_lora_strength_face` | `float` | 0.0 |  |
| `models.detail_lora_strength_body` | `float` | 0.0 |  |
| `models.realism_lora` | `str` | "" |  |
| `models.realism_lora_strength` | `float` | 0.0 |  |
| `models.male_skin_lora` | `str` | "" |  |
| `models.male_skin_lora_strength` | `float` | 0.0 |  |
| `models.stubble_lora` | `str` | "" |  |
| `models.stubble_lora_strength` | `float` | 0.0 |  |
| `models.lips_lora` | `str` | "" |  |
| `models.lips_lora_strength` | `float` | 0.0 |  |
| `models.bust_breast_lora` | `str` | "" |  |
| `models.bust_breast_lora_strength` | `float` | 0.0 |  |
| `models.bust_breast_lora_strength_sfw` | `float` | 0.0 |  |
| `models.bust_breast_lora_strength_nsfw` | `float` | 0.0 |  |
| `models.vagina_detail_lora` | `str` | "" |  |
| `models.vagina_detail_lora_strength` | `float` | 0.0 |  |
| `models.face_lora_name` | `str` | "" |  |
| `models.face_lora_strength` | `float` | 0.0 |  |
| `models.controlnet_union` | `str` | "FLUX.1-dev-ControlNet-Union-Pro-2.0.safetensors" |  |
| `models.pulid_model` | `str` | "pulid_flux_v0.9.1.safetensors" |  |
| `models.eva_clip` | `str` | "EVA02_CLIP_E_psz14_s4B.pt" |  |
| `models.face_analysis_model` | `str` | "buffalo_l" |  |
| `models.insightface_provider` | `str` | "CPU" |  |
| `models.vae` | `str` | "ae.safetensors" |  |
| `models.clip_l` | `str` | "clip_l.safetensors" |  |
| `models.t5xxl` | `str` | "t5xxl_fp16.safetensors" |  |
| `models.florence_model_id` | `str` | "microsoft/Florence-2-large" |  |
| `models.florence_device` | `str` | "cpu" |  |
| `character.id` | `str` | "MARCO" |  |
| `character.trigger_token` | `str` | "MARCO" |  |
| `character.face_anchor` | `str` | "young man, short dark brown hair styled casually with texture, dark amber-hazel eyes, strong defined jaw with light-medium stubble, straight nose with slight bridge definition, full natural lips pressed together, high cheekbones, angular masculine face shape, olive Mediterranean skin tone, clean athletic aesthetic, natural confident expression\n" |  |
| `character.flux_identity_priority` | `str` | "same man from reference photo, exact face geometry, dark amber-hazel eyes, strong defined jaw, light-medium stubble, short dark brown textured hair, olive Mediterranean skin, visible pores, realistic portrait photograph\n" |  |
| `character.orbit_face_lock` | `str` | "same man, dark amber-hazel eyes, strong jaw with light stubble, angular masculine face, short dark brown textured hair, olive Mediterranean skin, visible pores\n" |  |
| `character.hair` | `str` | "short dark brown hair, casually styled with natural texture and slight wave, individual hair strands visible, natural hair shine, clean temples, slight disheveled authentic look, realistic hair microdetail\n" |  |
| `character.eyes` | `str` | "dark amber-hazel eyes, strong brow ridge, thick naturally groomed dark brows, sharp focused gaze, limbal ring visible, realistic iris detail, masculine eye shape\n" |  |
| `character.lips` | `str` | "full natural masculine lips, medium volume, natural nude-pink tone, no gloss, natural healthy appearance, clean lip line\n" |  |
| `character.face_shape` | `str` | "angular masculine face, strong defined jaw, high cheekbones, straight refined nose with slight bridge definition, clean strong bone structure, Mediterranean masculine aesthetic\n" |  |
| `character.skin` | `str` | "olive Mediterranean skin tone, visible skin pores, realistic skin microrelief, warm olive undertone, skin subsurface scattering, realistic skin depth, fine vellus hair on skin, clean smooth complexion, light facial stubble coverage, natural tan, even olive tone\n" |  |
| `character.stubble` | `str` | "light-medium dark facial stubble, 2-3 day growth, even coverage on jaw and upper lip, realistic hair follicle detail, masculine groomed look, dark brown stubble matching hair color\n" |  |
| `character.hairstyles` | `list` | ["short dark brown hair styled with light texture, natural side part, clean look", "short dark brown hair with slight messy texture, casual authentic style", "short dark brown hair slightly damp and slicked, clean polished look", "short dark brown hair with natural wave and volume, effortless style", "short dark brown hair in very clean tight fade, sharp temple lines", "short dark brown hair slightly tousled, post-workout authentic look", "short dark brown hair neatly groomed with matte product, Instagram style"] |  |
| `character.grooming_variants` | `list` | [{"key": "clean_stubble", "label": "clean light stubble", "prompt": "light 2-day dark stubble, clean natural groomed look, no beard, light shadow on jaw and upper lip, masculine fresh appearance, olive skin, visible pores\n"}, {"key": "medium_stubble", "label": "medium stubble", "prompt": "medium 4-day dark stubble, even coverage on jaw, chin and upper lip, slightly scruffy masculine look, well-maintained, olive skin, visible pores\n"}, {"key": "short_beard", "label": "short trimmed beard", "prompt": "short trimmed dark beard, neat clean edges, full coverage on jaw and chin, tapered to upper cheek, professional masculine appearance, olive skin, visible pores\n"}, {"key": "clean_shaven", "label": "clean shaven", "prompt": "clean shaven smooth face, no stubble, fresh groomed masculine look, olive skin clearly visible, smooth jaw, visible pores, clean fresh appearance\n"}, {"key": "heavy_stubble", "label": "heavy 5 o clock shadow", "prompt": "heavy dark 5 o clock shadow, nearly full beard density, rugged masculine look, dark stubble clearly defined on jaw and cheeks, intense masculine appearance, olive skin, visible pores\n"}] |  |
| `prompts.quality_tail` | `str` | "RAW photo, shot on Sony A7R V 85mm f1.4, hyperrealistic photograph, sharp focus, fine vellus skin hair visible, visible skin pores, realistic skin microrelief, natural skin tone variation, fine facial details, photorealistic sensor noise, natural film grain, shallow depth of field soft bokeh, realistic eye catch light, limbal ring, iris detail, individual hair strands sharp, separated hair locks, olive skin tone, clean complexion" |  |
| `prompts.negative_base` | `str` | "blurry, deformed, bad anatomy, extra limbs, watermark, anime, cartoon, tattoos, plastic skin, airbrushed skin, beauty filter, 3d render, cgi, smooth poreless skin, oversmoothed skin, digital painting, illustration, pale skin, dark skin, waxy skin, doll skin, overprocessed skin, fake skin, rubber skin, freckles, woman, female, feminine features, breasts, long hair, makeup, effeminate face, female anatomy" |  |
| `prompts.face_reference` | `str` | "front-facing portrait, neutral expression, soft cinematic lighting, clean dark background, dark amber-hazel eyes, strong defined jaw with light stubble, short dark brown textured hair, olive Mediterranean skin tone, visible pores" |  |
| `prompts.hands_reference` | `str` | "studio hand reference, both hands clearly visible, separated fingers, clean trimmed nails, realistic knuckles, olive skin tone, visible pores, male hands" |  |
| `prompts.body_reference_sfw` | `str` | "fitted white crew-neck t-shirt, clean simple fabric, athletic male physique, full body shot crown to knees, standing upright facing camera, athletic young man, olive skin, visible pores, short dark brown hair, RAW photo Canon EOS R5 35mm f/2.0 ISO 400, natural film grain" |  |
| `prompts.body_reference_nsfw` | `str` | "RAW photo Sony A7R IV 50mm f/1.8 ISO 800, full body shot head to toe, completely nude male, athletic young man, olive Mediterranean skin, visible pores, short dark brown hair, athletic muscular physique, flat toned stomach, visible abdominal definition, toned chest, skin pores, natural skin texture with visible pores, unretouched skin, male anatomy" |  |
| `prompts.body_dataset_sfw` | `str` | "candid upper-body fashion photograph, fully clothed male in clean modern outfit, athletic chest and shoulder coverage, clean upper-body framing, olive skin, visible pores, short dark brown textured hair, sharp focus, film grain, hyperrealistic photograph" |  |
| `prompts.body_dataset_nsfw` | `str` | "candid upper-body nude male photograph, athletic toned chest, defined pectoral muscles, flat stomach with visible abs, olive skin, visible pores, natural skin texture, sharp focus, film grain" |  |
| `prompts.body_flux_shape_priority` | `str` | "athletic male physique, broad shoulders, toned chest, defined pectoral muscles, flat toned stomach, visible abdominal definition, athletic V-taper torso, masculine proportions" |  |
| `prompts.body_absolute_lock` | `str` | "consistent athletic male physique across all frames, consistent shoulder width, consistent chest definition, no feminization, no anatomy drift" |  |
| `prompts.body_anchor_sfw` | `str` | "same man from uploaded reference, exact face and upper-body proportions from reference, fully clothed upper-body portrait, clean modern male outfit, athletic waist-up fashion framing" |  |
| `prompts.sfw_flux_guardrails` | `str` | "upper-body portrait, fully clothed male in modern outfit, coherent anatomy, natural skin texture, hyperrealistic photograph, masculine proportions" |  |
| `prompts.nsfw_flux_guardrails` | `str` | "realistic male anatomy, coherent torso, athletic muscular build, olive skin, skin pores, masculine features" |  |
| `anatomy.candidates_count` | `int` | 8 |  |
| `anatomy.skin_base` | `str` | "olive Mediterranean skin, visible skin pores, realistic skin microrelief, skin subsurface scattering, fine vellus hair on skin, natural warm olive skin tone variation, unretouched skin, light dark stubble\n" |  |
| `anatomy.skin_base_chest` | `str` | "olive skin, smooth even warm skin tone, skin subsurface scattering, soft natural skin sheen, unretouched skin, slight chest hair if natural\n" |  |
| `anatomy.skin_base_lower` | `str` | "olive skin, visible skin pores, realistic skin microrelief, skin subsurface scattering, fine vellus hair on skin, natural masculine leg hair, unretouched skin\n" |  |
| `anatomy.chest.shape` | `str` | "athletic toned male chest, defined pectoral muscles, natural masculine chest, firm skin, visible muscle definition, olive skin\n" |  |
| `anatomy.abs.shape` | `str` | "flat toned stomach, visible abdominal definition, athletic male core, natural muscle contours, olive skin, realistic male torso anatomy\n" |  |
| `anatomy.nsfw.description` | `str` | "athletic male nude, tasteful artistic nude, realistic male anatomy, natural proportions, olive skin, masculine physique\n" |  |
| `anatomy.negative` | `str` | "3d render, cgi, digital art, octane render, unreal engine, AI artifact, banding, plastic skin, waxy skin, airbrushed, beauty filter, glass skin, doll skin, deformed body, bad anatomy, bad proportions, extra limbs, cartoon, illustration, anime, watermark, low quality, jpeg artifacts, overexposed, blown highlights, tattoos, tattoo, body art, moles, freckles, feminine features, woman, female, breasts, female anatomy\n" |  |
| `anatomy.negative_male` | `str` | "woman, female, feminine, breasts, long hair, makeup, lipstick, nail polish, feminine face structure, female body, female anatomy\n" |  |
| `anatomy.anatomy_guidance` | `float` | 4.2 |  |
| `anatomy.lora_stack.chest` | `list` | [{"name": "", "weight": 0.0}] |  |
| `stage0.face_reference_count` | `int` | 80 |  |
| `stage0.hands_reference_count` | `int` | 4 |  |
| `stage0.body_reference_count` | `int` | 8 |  |
| `stage0.face_width` | `int` | 1024 |  |
| `stage0.face_height` | `int` | 1024 |  |
| `stage0.hands_width` | `int` | 832 |  |
| `stage0.hands_height` | `int` | 1216 |  |
| `stage0.body_width` | `int` | 832 |  |
| `stage0.body_height` | `int` | 1536 |  |
| `stage0.identity_adapter_weight` | `float` | 0.8 |  |
| `stage0.body_pulid_weight` | `float` | 0.5 |  |
| `stage0.body_pulid_start_at` | `float` | 0.0 |  |
| `stage0.body_pulid_end_at` | `float` | 0.85 |  |
| `stage0.generation.steps` | `int` | 25 |  |
| `stage0.generation.guidance` | `float` | 3.5 |  |
| `stage0.generation.sampler` | `str` | "dpmpp_2m" |  |
| `stage0.generation.scheduler` | `str` | "beta" |  |
| `stage0.generation.negative_sfw` | `str` | "nude, nsfw, shirtless, bare chest, exposed skin on torso, underwear only, swimwear\n" |  |
| `stage0.generation.negative_nsfw` | `str` | "3d render, cgi, plastic skin, waxy skin, airbrushed, beauty filter, deformed body, bad anatomy, bad proportions, extra limbs, cartoon, illustration, anime, watermark, low quality, tattoos, moles, freckles, stretch marks, female anatomy, woman, feminine features\n" |  |
| `phaseA.emotion_count` | `int` | 20 |  |
| `phaseA.candidates_per_preset` | `int` | 4 |  |
| `phaseA.candidates_per_preset_heavy` | `int` | 3 |  |
| `phaseA.verification_similarity_threshold` | `float` | 0.52 |  |
| `phaseA.verification_similarity_threshold_heavy` | `float` | 0.46 |  |
| `phaseA.verification_similarity_threshold_calm` | `float` | 0.54 |  |
| `phaseA.auto_face_inpaint_emotions` | `bool` | false |  |
| `phaseA.auto_face_inpaint_bust` | `bool` | false |  |
| `phaseA.auto_body_inpaint_sfw` | `bool` | false |  |
| `phaseA.minimum_verified_frames` | `int` | 160 |  |
| `phaseA.pulid_gen_weight` | `float` | 0.5 |  |
| `phaseA.selection_similarity_weight` | `float` | 0.35 |  |
| `phaseA.orbit_selection_similarity_weight` | `float` | 0.33 |  |
| `phaseA.hairstyle_selection_similarity_weight` | `float` | 0.36 |  |
| `phaseA.emotion_reference_strategy` | `str` | "base_ref_only" |  |
| `phaseA.generation.width` | `int` | 832 |  |
| `phaseA.generation.height` | `int` | 1216 |  |
| `phaseA.generation.steps` | `int` | 25 |  |
| `phaseA.generation.guidance` | `float` | 3.8 |  |
| `phaseA.generation.cfg_scale` | `float` | 1.0 |  |
| `phaseA.inpaint.bbox_padding_ratio` | `float` | 0.12 |  |
| `phaseA.inpaint.mask_feather_px` | `int` | 8 |  |
| `phaseA.inpaint.steps` | `int` | 22 |  |
| `phaseA.inpaint.guidance` | `float` | 3.8 |  |
| `phaseA.inpaint.denoise` | `float` | 0.46 |  |
| `phaseA.inpaint.identity_adapter_weight` | `float` | 0.9 |  |
| `phaseA.inpaint.fusion` | `str` | "mean" |  |
| `phaseA.inpaint.train_step` | `int` | 500 |  |
| `phaseA.captioning.append_quality_tail` | `str` | "RAW photo, hyperrealistic, subsurface scattering, visible skin pores, natural skin texture, film grain" |  |
| `phaseA.captioning.include_raw_caption_blocks` | `list` | ["emotion", "hairstyle", "grooming"] |  |
| `phaseA.liquids_mode.enabled` | `bool` | false |  |
| `phaseA.liquids_mode.tears_text` | `str` | "visible tears, wet lower eyelids, tear tracks on cheeks" |  |
| `phaseA.liquids_mode.drool_text` | `str` | "" |  |
| `phaseA.liquids_mode.sweat_text` | `str` | "light sweat sheen on skin" |  |
| `phaseA.stress_pack.enabled` | `bool` | true |  |
| `phaseA.stress_pack.intense_tokens` | `list` | ["tension in brow and jaw", "focused intense stare", "slightly clenched jaw", "subtle facial strain"] |  |
| `phaseA.orbit_inpaint.denoise` | `float` | 0.5 |  |
| `phaseA.orbit_inpaint.mask_feather_px` | `int` | 5 |  |
| `phaseA.orbit_inpaint.steps` | `int` | 28 |  |
| `phaseA.orbit_inpaint.guidance` | `float` | 3.8 |  |
| `phaseA.orbit_inpaint.identity_adapter_weight` | `float` | 0.93 |  |
| `phaseA.orbit_inpaint.bbox_padding_ratio` | `float` | 0.1 |  |
| `phaseA.orbit_inpaint.fusion` | `str` | "mean" |  |
| `phaseA.orbit_inpaint.train_step` | `int` | 500 |  |
| `phaseA.orbit_inpaint.auto_apply` | `bool` | false |  |
| `phaseA.orbit_inpaint.apply_to` | `list` | ["orbit_front", "orbit_left_45", "orbit_right_45", "orbit_left_profile", "orbit_right_profile"] |  |
| `phaseA.orbit_prompts` | `list` | [{"key": "orbit_front", "pulid_weight": 0.54, "prompt": "portrait photograph, young man facing directly forward, both eyes fully visible and symmetrical, shoulders level, angular masculine face, strong jaw with light stubble, dark amber-hazel eyes, short dark brown textured hair, olive Mediterranean skin, visible pores\n"}, {"key": "orbit_left_45", "pulid_weight": 0.3, "prompt": "portrait photograph, young man head turned left, right cheek and eye prominent, three-quarter view, dark amber-hazel eye, strong jaw with stubble, olive skin, visible pores, short dark brown textured hair\n"}, {"key": "orbit_left_profile", "pulid_weight": 0.22, "prompt": "strict left profile portrait, only right side of face visible, strong jaw profile, light stubble on jaw, dark eye and nostril in view, clean sharp masculine profile silhouette, straight nose, olive skin, visible pores\n"}, {"key": "orbit_left_rear_135", "pulid_weight": 0.0, "prompt": "portrait from behind and slightly right, back of head in frame, short dark brown hair from behind, left ear barely visible, nape of neck, both shoulder blades in frame, masculine athletic build\n"}, {"key": "orbit_back", "pulid_weight": 0.0, "prompt": "rear view portrait shot from directly behind, back of head centered, no face visible, short dark brown hair texture, nape of neck clearly visible, both shoulders symmetrical, masculine frame\n"}, {"key": "orbit_right_rear_135", "pulid_weight": 0.0, "prompt": "portrait from behind and slightly left, back of head in frame, short dark brown hair from behind, right ear barely visible, nape of neck, both shoulder blades in frame\n"}, {"key": "orbit_right_profile", "pulid_weight": 0.22, "prompt": "strict right profile portrait, only left side of face visible, strong jaw profile with light stubble, dark eye and nostril in view, clean sharp masculine profile, straight nose, olive skin, visible pores, short dark hair\n"}, {"key": "orbit_right_45", "pulid_weight": 0.3, "prompt": "portrait photograph, young man head turned right, left cheek and eye prominent, three-quarter view, dark amber-hazel eye, strong jaw with stubble, olive skin, visible pores, short dark brown textured hair\n"}] |  |
| `phaseA.body.candidates_per_shot` | `int` | 4 |  |
| `phaseA.body.selection_similarity_weight` | `float` | 0.56 |  |
| `phaseA.body.use_orbit_reference_chaining` | `bool` | true |  |
| `phaseA.body.generation.steps` | `int` | 25 |  |
| `phaseA.body.generation.guidance` | `float` | 3.75 |  |
| `phaseA.body.generation.sampler` | `str` | "dpmpp_2m" |  |
| `phaseA.body.generation.scheduler` | `str` | "beta" |  |
| `phaseA.body.generation.negative_sfw` | `str` | "nude, nsfw, shirtless, bare chest, wide shot, face cut off, tattoos, feminine features, woman, female" |  |
| `phaseA.body.generation.negative_nsfw` | `str` | "bad anatomy, wide shot, face cut off, tattoos, deformed, feminine features, woman, female, extra limbs, blurry, plastic skin, CGI, identity drift, wrong person\n" |  |
| `phaseA.body.inpaint.bbox_padding_ratio` | `float` | 0.08 |  |
| `phaseA.body.inpaint.mask_feather_px` | `int` | 6 |  |
| `phaseA.body.inpaint.steps` | `int` | 18 |  |
| `phaseA.body.inpaint.guidance` | `float` | 4.2 |  |
| `phaseA.body.inpaint.denoise` | `float` | 0.48 |  |
| `phaseA.body.inpaint.identity_adapter_weight` | `float` | 0.9 |  |
| `phaseA.body.inpaint.fusion` | `str` | "mean" |  |
| `phaseA.body.inpaint.train_step` | `int` | 500 |  |
| `phaseA.body.bust.framing` | `str` | "upper body shot, waist-up framing, shoulders and chest visible" |  |
| `phaseA.body.bust.sfw_count` | `int` | 14 |  |
| `phaseA.body.bust.nsfw_count` | `int` | 10 |  |
| `phaseA.body.bust.candidates_per_shot` | `int` | 3 |  |
| `phaseA.body.bust.width` | `int` | 832 |  |
| `phaseA.body.bust.height` | `int` | 1216 |  |
| `phaseA.body.bust.pulid_face_weight` | `float` | 0.7 |  |
| `phaseA.body.bust.pulid_body_weight_sfw` | `float` | 0.4 |  |
| `phaseA.body.bust.pulid_body_weight_nsfw` | `float` | 0.5 |  |
| `phaseA.body.bust.sfw_nudity_threshold` | `float` | 0.1 |  |
| `phaseA.body.bust.orbit_angles` | `list` | [{"key": "front", "framing": "waist-up portrait, head and shoulders fully visible, facing directly forward", "back_type": "", "pulid_face": 0.7, "neg_extra": "", "pos_extra": "athletic toned male chest under fitted clothing, masculine proportions"}, {"key": "left_45", "framing": "waist-up portrait, three-quarter left view", "back_type": "", "pulid_face": 0.3, "neg_extra": "frontal face, facing directly at camera, symmetrical face", "pos_extra": "athletic male physique, broad shoulders"}, {"key": "right_45", "framing": "waist-up portrait, three-quarter right view", "back_type": "", "pulid_face": 0.3, "neg_extra": "frontal face, facing directly at camera, symmetrical face", "pos_extra": "athletic male physique, broad shoulders"}, {"key": "left_profile", "framing": "waist-up portrait, strict left profile", "back_type": "", "pulid_face": 0.22, "neg_extra": "both eyes visible, frontal face", "pos_extra": "strong masculine jaw profile, athletic build visible"}, {"key": "right_profile", "framing": "waist-up portrait, strict right profile", "back_type": "", "pulid_face": 0.22, "neg_extra": "both eyes visible, frontal face", "pos_extra": "strong masculine jaw profile, athletic build visible"}, {"key": "high_angle", "framing": "waist-up portrait shot from above, camera looking down", "back_type": "", "pulid_face": 0.28, "neg_extra": "eye level portrait, flat perspective", "pos_extra": "athletic male physique from above, dominant masculine presence"}, {"key": "low_angle", "framing": "waist-up portrait shot from below, camera looking upward", "back_type": "", "pulid_face": 0.28, "neg_extra": "eye level portrait, flat perspective", "pos_extra": "dominant low angle male portrait, powerful masculine framing"}, {"key": "left_rear_135", "framing": "rear-left three-quarter upper-body portrait", "back_type": "half", "pulid_face": 0.12, "neg_extra": "frontal face, both eyes visible, facing camera", "pos_extra": "back anatomy locked, spine line readable, broad shoulders aligned"}, {"key": "right_rear_135", "framing": "rear-right three-quarter upper-body portrait", "back_type": "half", "pulid_face": 0.12, "neg_extra": "frontal face, both eyes visible, facing camera", "pos_extra": "back anatomy locked, spine line readable, broad shoulders aligned"}, {"key": "back_half", "framing": "rear three-quarter hip-up portrait", "back_type": "half", "pulid_face": 0.08, "neg_extra": "full frontal face, both eyes visible, facing camera", "pos_extra": "back anatomy locked, spine line readable, athletic back definition"}, {"key": "back_pure", "framing": "full rear hip-up portrait, no face visible", "back_type": "pure", "pulid_face": 0.0, "neg_extra": "face visible, any eye visible, front view", "pos_extra": "back anatomy locked, athletic V-taper, broad shoulders"}] |  |
| `phaseA.body.bust.sfw_ref_clothing_anchor` | `str` | "fitted white crew-neck t-shirt, clean opaque cotton fabric, athletic chest silhouette clearly readable under fabric, masculine proportions, paired with dark slim-fit trousers or jeans\n" |  |
| `phaseA.body.bust.lighting_variants` | `list` | ["soft studio lighting, large diffused key light from left", "warm golden hour window light, side-lit, rim light catching dark hair", "dramatic Rembrandt lighting, strong key from upper right, deep shadows on jaw", "overcast outdoor light, soft flat even illumination", "cool blue ambient light, soft backlight glow, slight front fill", "warm orange practical light, cozy indoor atmosphere, coffee shop vibe", "soft natural window light, gentle side shadows, warm indoor atmosphere", "harsh direct sunlight, strong shadows on face, outdoor editorial look"] |  |
| `phaseA.body.bust.sfw_outfit_variants` | `list` | ["fitted white crew-neck t-shirt, clean opaque cotton, slim fit, dark slim jeans", "light grey fitted crew-neck tee, clean minimal look, dark chino trousers", "black fitted polo shirt, clean preppy style, dark slim jeans", "navy blue fitted henley long-sleeve, casual masculine look, dark jeans", "cream ribbed knit sweater, relaxed fit, dark slim trousers", "fitted black long-sleeve crew neck, minimalist style, dark jeans", "white linen button-up shirt, relaxed open collar, casual masculine, cream chinos", "charcoal fitted crewneck sweatshirt, clean streetwear, dark slim joggers", "slim-fit camel blazer over white tee, smart casual masculine look, dark trousers", "fitted turtleneck dark charcoal, sophisticated masculine, slim dark trousers"] |  |
| `phaseA.body.bust.selection_similarity_weight` | `float` | 0.5 |  |
| `phaseA.body.hairstyle_change_every_angles` | `int` | 2 |  |
| `phaseA.onetrainer.output_model_path` | `str` | "/workspace/onetrainer/outputs/{character_id}_face_v11.safetensors" |  |
| `phaseA.onetrainer.lora_model_name` | `str` | "MARCO_face_v11" |  |
| `phaseA.onetrainer.rank` | `int` | 32 |  |
| `phaseA.onetrainer.alpha` | `int` | 32 |  |
| `phaseA.onetrainer.batch_size` | `int` | 1 |  |
| `phaseA.onetrainer.gradient_accumulation_steps` | `int` | 4 |  |
| `phaseA.onetrainer.epochs` | `int` | 7 |  |
| `phaseA.emotions_per_hairstyle` | `int` | 1 |  |
| `phaseA.orbit_emotions` | `list` | ["neutral expression", "confident expression", "smirking expression", "intense focused expression", "relaxed natural expression", "slight smile expression", "concerned expression", "amused expression"] |  |
| `hires_pass.enabled` | `bool` | false |  |
| `hires_pass.upscale_model` | `str` | "RealESRGAN_x2plus.pth" |  |
| `hires_pass.scale` | `float` | 2.0 |  |
| `hires_pass.denoise` | `float` | 0.33 |  |
| `hires_pass.steps` | `int` | 18 |  |
| `hires_pass.guidance` | `float` | 3.5 |  |
| `hires_pass.detail_lora_strength` | `float` | 0.0 |  |
| `hires_pass.apply_to` | `list` | ["all"] |  |
| `hires_pass.skip_if_exists` | `bool` | true |  |
| `phaseB.sfw_count` | `int` | 40 |  |
| `phaseB.nsfw_count` | `int` | 8 |  |
| `phaseB.candidates_per_preset` | `int` | 4 |  |
| `phaseB.selection_similarity_weight` | `float` | 0.54 |  |
| `phaseB.face_correction_similarity_threshold` | `float` | 0.66 |  |
| `phaseB.verification_similarity_threshold` | `float` | 0.64 |  |
| `phaseB.minimum_verified_frames` | `int` | 56 |  |
| `phaseB.generation.width` | `int` | 832 |  |
| `phaseB.generation.height` | `int` | 1216 |  |
| `phaseB.generation.steps` | `int` | 25 |  |
| `phaseB.generation.guidance` | `float` | 3.6 |  |
| `phaseB.generation.sampler` | `str` | "dpmpp_2m" |  |
| `phaseB.generation.scheduler` | `str` | "beta" |  |
| `phaseB.generation.negative_sfw` | `str` | "nude, nsfw, shirtless, wide shot, face cut off, tattoos, feminine" |  |
| `phaseB.generation.negative_nsfw` | `str` | "bad anatomy, wide shot, face cut off, tattoos, feminine features" |  |
| `phaseB.controlnet.pose_strength` | `float` | 0.85 |  |
| `phaseB.controlnet.depth_strength` | `float` | 0.82 |  |
| `phaseB.controlnet.json_strength` | `float` | 0.6 |  |
| `phaseB.controlnet.start_percent` | `float` | 0.0 |  |
| `phaseB.controlnet.end_percent` | `float` | 0.75 |  |
| `phaseB.inpaint.bbox_padding_ratio` | `float` | 0.12 |  |
| `phaseB.inpaint.mask_feather_px` | `int` | 12 |  |
| `phaseB.inpaint.steps` | `int` | 18 |  |
| `phaseB.inpaint.guidance` | `float` | 4.2 |  |
| `phaseB.inpaint.denoise` | `float` | 0.34 |  |
| `phaseB.inpaint.identity_adapter_weight` | `float` | 0.82 |  |
| `phaseB.inpaint.train_step` | `int` | 280 |  |
| `phaseB.onetrainer.output_model_path` | `str` | "/workspace/onetrainer/outputs/{character_id}_body_v11.safetensors" |  |
| `phaseB.onetrainer.lora_model_name` | `str` | "MARCO_body_v11" |  |
| `phaseB.onetrainer.rank` | `int` | 64 |  |
| `phaseB.onetrainer.alpha` | `int` | 64 |  |
| `phaseB.onetrainer.batch_size` | `int` | 1 |  |
| `phaseB.onetrainer.gradient_accumulation_steps` | `int` | 6 |  |
| `phaseB.onetrainer.epochs` | `int` | 10 |  |
| `nsfw_anatomy_fix.hair_min_ratio` | `float` | 0.005 |  |
| `nsfw_anatomy_fix.color_blend_strength` | `float` | 0.5 |  |
| `nsfw_anatomy_fix.detail_denoise` | `float` | 0.3 |  |
| `nsfw_anatomy_fix.detail_steps` | `int` | 18 |  |
| `nsfw_anatomy_fix.detail_guidance` | `float` | 3.8 |  |
| `nsfw_anatomy_fix.detail_pulid_weight` | `float` | 0.7 |  |
| `nsfw_anatomy_fix.detail_zone` | `str` | "full_nsfw" |  |
| `outfit_swapper.steps` | `int` | 24 |  |
| `outfit_swapper.guidance` | `float` | 4.5 |  |
| `outfit_swapper.control_mode` | `str` | "depth" |  |
| `outfit_swapper.controlnet_strength` | `float` | 0.92 |  |
| `outfit_swapper.control_start` | `float` | 0.0 |  |
| `outfit_swapper.control_end` | `float` | 0.92 |  |
| `outfit_swapper.pulid_weight` | `float` | 0.72 |  |
| `outfit_swapper.pulid_start_at` | `float` | 0.0 |  |
| `outfit_swapper.pulid_end_at` | `float` | 0.85 |  |
| `outfit_swapper.mask_feather_px` | `int` | 18 |  |
| `outfit_swapper.min_mask_ratio` | `float` | 0.01 |  |
| `outfit_swapper.max_mask_ratio` | `float` | 0.45 |  |
| `outfit_swapper.face_bbox_padding_ratio` | `float` | 0.12 |  |
| `outfit_swapper.face_mask_feather_px` | `int` | 20 |  |
| `outfit_swapper.canny_low_threshold` | `int` | 80 |  |
| `outfit_swapper.canny_high_threshold` | `int` | 180 |  |
| `outfit_swapper.pre_scan_skin_threshold` | `float` | 0.08 |  |
| `outfit_swapper.max_retries` | `int` | 2 |  |
| `outfit_swapper.denoise.min` | `float` | 0.44 |  |
| `outfit_swapper.denoise.max` | `float` | 0.54 |  |
| `outfit_swapper.sfw_filter.enabled` | `bool` | true |  |
| `outfit_swapper.sfw_filter.repair_threshold` | `float` | 0.15 |  |
| `outfit_swapper.sfw_filter.final_flag_threshold` | `float` | 0.28 |  |
| `outfit_swapper.sfw_filter.repair_denoise` | `float` | 0.48 |  |
| `outfit_swapper.sfw_filter.torso_top_frac` | `float` | 0.3 |  |
| `outfit_swapper.sfw_filter.repair_outfit_prompt` | `str` | "fitted white crew-neck t-shirt, clean opaque cotton fabric, athletic male chest covered, masculine proportions\n" |  |
| `outfit_swapper.segmentation.sam_checkpoint` | `str` | "/workspace/ComfyUI/models/sam/sam_vit_b_01ec64.pth" |  |
| `outfit_swapper.segmentation.sam_model_type` | `str` | "vit_b" |  |
| `outfit_swapper.segmentation.yolo_weights` | `str` | "yolov8n-seg.pt" |  |
| `outfit_swapper.extra_negative` | `str` | "nude, topless, bare chest, different person, wrong face, identity drift, extra fingers, extra limbs, deformed torso, broken anatomy, feminine face, woman, female\n" |  |
| `outfit_swapper.default_patterns` | `list` | ["bust_sfw_*.png", "orbit_*.png", "full_body*.png", "body_*.png"] |  |
| `outfit_swapper.presets.white_tee` | `str` | "fitted white crew-neck t-shirt, clean opaque cotton, athletic male chest, slim fit" |  |
| `outfit_swapper.presets.black_tee` | `str` | "fitted black crew-neck t-shirt, minimal clean look, athletic male chest, slim fit" |  |
| `outfit_swapper.presets.grey_tee` | `str` | "fitted light grey crew-neck tee, clean casual style, athletic build" |  |
| `outfit_swapper.presets.navy_henley` | `str` | "navy fitted henley long-sleeve, casual masculine, clean collar" |  |
| `outfit_swapper.presets.white_linen` | `str` | "white linen button-up, relaxed open collar, clean masculine style" |  |
| `outfit_swapper.presets.black_longsleeve` | `str` | "fitted black long-sleeve crew, minimalist, clean edge" |  |
| `outfit_swapper.presets.cream_knit` | `str` | "cream ribbed knit sweater, relaxed cozy masculine style" |  |
| `outfit_swapper.presets.dark_polo` | `str` | "fitted dark navy polo shirt, preppy clean masculine style" |  |
| `outfit_swapper.presets.camel_blazer` | `str` | "slim-fit camel blazer over white tee, smart casual masculine" |  |
| `outfit_swapper.presets.charcoal_turtleneck` | `str` | "fitted charcoal turtleneck, sophisticated masculine style" |  |
| `outfit_swapper.presets.bomber_black` | `str` | "black slim bomber jacket over white tee, streetwear masculine style" |  |
| `outfit_swapper.presets.denim_jacket` | `str` | "light wash denim jacket over white tee, casual masculine style" |  |
| `ref_regen.steps` | `int` | 22 |  |
| `ref_regen.guidance` | `float` | 3.4 |  |
| `ref_regen.sampler` | `str` | "dpmpp_2m" |  |
| `ref_regen.scheduler` | `str` | "beta" |  |
| `ref_regen.pulid_weight` | `float` | 0.58 |  |
| `ref_regen.pulid_start` | `float` | 0.0 |  |
| `ref_regen.pulid_end` | `float` | 0.56 |  |
| `ref_regen.clip_l_triggers` | `str` | "filmfotos, olive Mediterranean skin, dark brown hair" |  |
| `ref_regen.skin_pores` | `str` | "visible open skin pores, realistic skin microrelief, skin subsurface scattering, fine vellus hair on skin, olive Mediterranean skin tone, light facial stubble texture" |  |
| `ref_regen.lighting` | `str` | "soft natural outdoor light, warm golden hour glow, rim light catching dark brown hair, urban lifestyle natural light" |  |
| `ref_regen.clean` | `str` | "clean even olive skin, no blemishes, no tattoos, unretouched authentic photograph, tattoo free, natural masculine appearance" |  |
| `ref_regen.quality` | `str` | "RAW photo Sony A7R V 85mm f1.4, hyperrealistic photograph, sharp focus, natural film grain, shallow depth of field, photorealistic sensor noise" |  |
| `ref_regen.negative` | `str` | "blurry, deformed, bad anatomy, extra limbs, watermark, anime, cartoon, tattoos, plastic skin, airbrushed skin, beauty filter, 3d render, cgi, smooth poreless skin, oversmoothed skin, digital painting, illustration, pale skin, waxy skin, doll skin, beauty mole, skin mole, freckles, woman, female, feminine features, breasts, long hair, makeup, lipstick" |  |
| `ref_regen.lora_stack` | `list` | [{"name": "", "weight": 0.0}] |  |
| `ref_regen.detail_lora_stack` | `list` | [{"name": "", "weight": 0.0}] |  |
| `ref_regen.tight_crop_size` | `int` | 896 |  |
| `ref_regen.tight_denoise` | `float` | 0.4 |  |
| `ref_regen.tight_steps` | `int` | 28 |  |
| `ref_regen.tight_guidance` | `float` | 2.7 |  |
| `ref_regen.detail_denoise` | `float` | 0.18 |  |
| `ref_regen.detail_steps` | `int` | 28 |  |
| `ref_regen.detail_guidance` | `float` | 2.7 |  |
| `ref_regen.detail_clip_l` | `str` | "filmfotos, visible open pores, olive skin, dark stubble" |  |
| `ref_regen.upscale_denoise` | `float` | 0.36 |  |
| `ref_regen.upscale_steps` | `int` | 22 |  |
| `ref_regen.upscale_guidance` | `float` | 2.8 |  |
| `ref_regen.upscale_control_strength` | `float` | 0.58 |  |
| `ref_regen.upscale_control_end` | `float` | 0.8 |  |
| `ref_regen.upscale_positive` | `str` | "filmfotos, raw realistic skin, olive Mediterranean skin, visible skin pores, dark brown hair, dark amber-hazel eyes, athletic build, light facial stubble, masculine portrait" |  |
| `ref_regen.upscale_clip_l` | `str` | "filmfotos, visible open pores, olive skin" |  |
| `ref_regen.upscale_negative` | `str` | "blurry, plastic skin, airbrushed, smooth skin, waxy skin, doll skin, beauty filter, pale skin, beauty mole, woman, female, feminine" |  |

#### [unified_config_v11_onebutton.yaml]
| key | type | default / YAML value | где используется |
|---|---|---|---|
| `comfyui.base_url` | `str` | "http://127.0.0.1:8188" |  |
| `comfyui.timeout_seconds` | `int` | 2400 |  |
| `comfyui.poll_interval` | `float` | 1.5 |  |
| `paths.workspace_root` | `str` | "/workspace" |  |
| `paths.config_dir` | `str` | "/workspace/war333/config" |  |
| `paths.runtime_root` | `str` | "{workspace_root}/godtier_v7_runtime" |  |
| `paths.emotions_file` | `str` | "/workspace/war333/config/emotions_v7_BEST.yaml" |  |
| `paths.pose_library_root` | `str` | "/workspace/ComfyUI/poses" |  |
| `paths.sfw_pose_pairs_dir` | `str` | "/workspace/ComfyUI/poses" |  |
| `paths.nsfw_pose_pairs_dir` | `str` | "/workspace/ComfyUI/poses" |  |
| `paths.manual_ref_face` | `str` | "" |  |
| `paths.manual_ref_body_sfw` | `str` | "/workspace/godtier_v7_runtime/persephone_v7/stage0/selected/ref_body_sfw.png" |  |
| `paths.manual_ref_body_nsfw` | `str` | "/workspace/godtier_v7_runtime/persephone_v7/stage0/selected/ref_body_nsfw.png" |  |
| `orchestrator.vram_min_free_mb` | `int` | 12000 |  |
| `orchestrator.sleep_between_heavy_models_seconds` | `int` | 12 |  |
| `models.flux_dev_unet` | `str` | "Persephone_2.0_FP16.safetensors" |  |
| `models.flux_dev_unet_sfw` | `str` | "Persephone_2.0_FP16.safetensors" |  |
| `models.flux_dev_unet_nsfw` | `str` | "Persephone_2.0_FP16.safetensors" |  |
| `models.flux_fill_unet` | `str` | "flux1-fill-dev.safetensors" |  |
| `models.flux_dev_unet_path_for_onetrainer` | `str` | "/workspace/ComfyUI/models/unet/Persephone_2.0_FP16.safetensors" |  |
| `models.detail_lora` | `str` | "aidmaHyperrealism-FLUX-v0.3.safetensors" |  |
| `models.detail_lora_strength` | `float` | 0.28 |  |
| `models.bust_breast_lora` | `str` | "Big_natural_breasts_for_FLUX.safetensors" |  |
| `models.bust_breast_lora_strength` | `float` | 0.45 |  |
| `models.bust_breast_lora_strength_sfw` | `float` | 0.45 |  |
| `models.bust_breast_lora_strength_nsfw` | `float` | 0.85 |  |
| `models.face_lora_name` | `str` | "aidmaHyperrealism-FLUX-v0.3.safetensors" |  |
| `models.face_lora_strength` | `float` | 0.0 |  |
| `models.controlnet_union` | `str` | "FLUX.1-dev-ControlNet-Union-Pro-2.0.safetensors" |  |
| `models.pulid_model` | `str` | "pulid_flux_v0.9.1.safetensors" |  |
| `models.eva_clip` | `str` | "EVA02_CLIP_E_psz14_s4B.pt" |  |
| `models.face_analysis_model` | `str` | "buffalo_l" |  |
| `models.insightface_provider` | `str` | "CPU" |  |
| `models.vae` | `str` | "ae.safetensors" |  |
| `models.clip_l` | `str` | "clip_l.safetensors" |  |
| `models.t5xxl` | `str` | "t5xxl_fp16.safetensors" |  |
| `models.florence_model_id` | `str` | "microsoft/Florence-2-large" |  |
| `models.florence_device` | `str` | "cpu" |  |
| `character.id` | `str` | "persephone_v7" |  |
| `character.trigger_token` | `str` | "Eliska" |  |
| `character.face_anchor` | `str` | "same woman from reference, piercing crystal blue eyes, vivid blue irises, exact face geometry, straight nose, full lips, high cheekbones, fair skin with light freckles, natural skin texture" |  |
| `character.flux_identity_priority` | `str` | "same woman from reference, piercing crystal blue eyes locked, exact face geometry, exact jawline, exact nose bridge, exact lip shape, realistic portrait photograph" |  |
| `character.orbit_face_lock` | `str` | "piercing crystal blue eyes locked, same woman from reference, exact crystal blue eye color, exact face silhouette, exact jawline, exact cheekbone structure, realistic portrait photograph" |  |
| `character.body_anchor_sfw` | `str` | "waist-up portrait of the same woman, face and upper body fully in frame, head shoulders and waist visible, fuller bust silhouette under opaque clothing, consistent upper-body proportions, natural shoulder width, slim torso, natural skin texture, hyperrealistic" |  |
| `character.body_anchor_nsfw` | `str` | "large full natural breasts, heavy natural bust, significant breast volume, large round breasts with natural weight and droop, big natural breasts matching body reference exactly, same large bust size and projection as body reference, identical heavy natural bust volume to uploaded body reference, nude upper-body portrait of the same woman, realistic anatomy, medium-width shoulders, defined waist, slim torso, natural skin texture" |  |
| `character.body_flux_shape_priority` | `str` | "large full natural bust locked to body reference, big heavy breasts matching reference, consistent upper-body proportions, realistic shoulder width, realistic waist ratio" |  |
| `character.body_absolute_lock` | `str` | "same fuller bust size locked to reference, realistic shoulders, realistic slim torso, chest proportions must match reference in every frame" |  |
| `character.body_hard_scale` | `str` | "same fuller bust projection matching reference, exact chest volume from reference, medium-width shoulders, realistic waist-to-chest contrast, upper-body crop only" |  |
| `character.body_volume_force` | `str` | "consistent body volume across all shots, same upper-body shape, same skin tone, same torso and chest proportions in every frame" |  |
| `character.hair` | `str` | "dark brown straight hair, medium length" |  |
| `character.eyes` | `str` | "piercing blue eyes" |  |
| `character.skin` | `str` | "fair neutral skin tone" |  |
| `character.hairstyles` | `list` | ["long dark brown hair pulled back in a tight high ponytail, face fully exposed, sleek", "long dark brown hair in a low loose ponytail over one shoulder, strands escaping around face", "long dark brown hair in a classic French braid running down the back, neat, forehead clear", "long dark brown hair in two braids over the shoulders, symmetrical twin braids, playful", "long dark brown hair in a messy bun on top of head, loose strands framing face, casual updo", "long dark brown hair half-up half-down, top section pinned back, rest flowing loose"] |  |
| `prompts.quality_tail` | `str` | "flux_realism, sharp skin texture, realistic pores, crisp detail, highly detailed, photorealistic, film grain" |  |
| `prompts.negative_base` | `str` | "blurry, deformed, bad anatomy, extra limbs, watermark, anime, cartoon" |  |
| `prompts.face_reference` | `str` | "front-facing portrait reference, neutral expression, even soft studio light, clean background, identity-safe reference shot" |  |
| `prompts.hands_reference` | `str` | "studio hand reference, both hands clearly visible, separated fingers, clean nails, realistic knuckles, anatomy-first composition" |  |
| `prompts.body_reference_sfw` | `str` | "full body shot head to toe, SFW studio reference, standing neutral pose, studio lighting, clean background" |  |
| `prompts.body_reference_nsfw` | `str` | "full body shot head to toe, NSFW anatomy reference, completely nude, standing neutral pose, studio lighting, clean background" |  |
| `prompts.body_dataset_sfw` | `str` | "candid upper-body fashion photograph, clothed upper-body portrait, wearing top, realistic photography, natural skin texture, soft studio lighting, sharp focus, film grain, hyperrealistic photograph" |  |
| `prompts.body_dataset_nsfw` | `str` | "candid upper-body nude photograph, realistic photography, same fuller bust size and projection as reference, consistent chest proportions, natural skin texture, sharp focus, film grain" |  |
| `prompts.sfw_flux_guardrails` | `str` | "upper-body portrait, face in frame, realistic clothing, coherent anatomy, natural skin texture, hyperrealistic photograph" |  |
| `prompts.nsfw_flux_guardrails` | `str` | "realistic human anatomy, coherent shoulders ribcage and torso, upper-body crop only, maintain natural skin texture and proportions, same fuller bust size as reference, natural round bust shape, consistent chest proportions" |  |
| `stage0.face_reference_count` | `int` | 3 |  |
| `stage0.hands_reference_count` | `int` | 3 |  |
| `stage0.body_reference_count` | `int` | 3 |  |
| `stage0.face_width` | `int` | 1024 |  |
| `stage0.face_height` | `int` | 1024 |  |
| `stage0.hands_width` | `int` | 1024 |  |
| `stage0.hands_height` | `int` | 1024 |  |
| `stage0.body_width` | `int` | 832 |  |
| `stage0.body_height` | `int` | 1216 |  |
| `stage0.identity_adapter_weight` | `float` | 0.82 |  |
| `stage0.generation.steps` | `int` | 35 |  |
| `stage0.generation.guidance` | `float` | 3.5 |  |
| `stage0.generation.sampler` | `str` | "dpmpp_2m" |  |
| `stage0.generation.scheduler` | `str` | "beta" |  |
| `phaseA.emotion_count` | `int` | 31 |  |
| `phaseA.candidates_per_preset` | `int` | 5 |  |
| `phaseA.candidates_per_preset_heavy` | `int` | 4 |  |
| `phaseA.verification_similarity_threshold` | `float` | 0.53 |  |
| `phaseA.minimum_verified_frames` | `int` | 190 |  |
| `phaseA.pulid_gen_weight` | `float` | 0.52 |  |
| `phaseA.selection_similarity_weight` | `float` | 0.48 |  |
| `phaseA.orbit_selection_similarity_weight` | `float` | 0.34 |  |
| `phaseA.hairstyle_selection_similarity_weight` | `float` | 0.46 |  |
| `phaseA.emotion_reference_strategy` | `str` | "base_ref_only" |  |
| `phaseA.generation.width` | `int` | 832 |  |
| `phaseA.generation.height` | `int` | 1216 |  |
| `phaseA.generation.steps` | `int` | 30 |  |
| `phaseA.generation.guidance` | `float` | 3.2 |  |
| `phaseA.inpaint.bbox_padding_ratio` | `float` | 0.12 |  |
| `phaseA.inpaint.mask_feather_px` | `int` | 8 |  |
| `phaseA.inpaint.steps` | `int` | 28 |  |
| `phaseA.inpaint.guidance` | `float` | 30.0 |  |
| `phaseA.inpaint.denoise` | `float` | 0.5 |  |
| `phaseA.inpaint.identity_adapter_weight` | `float` | 0.9 |  |
| `phaseA.inpaint.fusion` | `str` | "mean" |  |
| `phaseA.inpaint.train_step` | `int` | 500 |  |
| `phaseA.captioning.append_quality_tail` | `str` | "flux_realism, sharp skin texture, realistic pores, crisp detail, highly detailed, photorealistic, film grain" |  |
| `phaseA.captioning.include_raw_caption_blocks` | `list` | ["emotion", "hairstyle"] |  |
| `phaseA.liquids_mode.enabled` | `bool` | true |  |
| `phaseA.liquids_mode.tears_text` | `str` | "visible tears, wet lower eyelids, tear tracks on cheeks" |  |
| `phaseA.liquids_mode.drool_text` | `str` | "visible saliva string at tongue or lower lip, wet drool on lips and chin" |  |
| `phaseA.liquids_mode.sweat_text` | `str` | "light sweat sheen on skin" |  |
| `phaseA.stress_pack.enabled` | `bool` | true |  |
| `phaseA.stress_pack.intense_tokens` | `list` | ["tension in brow and jaw", "wet lower eyelids", "slightly parted lips", "subtle facial strain"] |  |
| `phaseA.orbit_inpaint.denoise` | `float` | 0.52 |  |
| `phaseA.orbit_inpaint.mask_feather_px` | `int` | 5 |  |
| `phaseA.orbit_inpaint.steps` | `int` | 34 |  |
| `phaseA.orbit_inpaint.guidance` | `float` | 30.0 |  |
| `phaseA.orbit_inpaint.identity_adapter_weight` | `float` | 0.94 |  |
| `phaseA.orbit_inpaint.bbox_padding_ratio` | `float` | 0.1 |  |
| `phaseA.orbit_inpaint.fusion` | `str` | "mean" |  |
| `phaseA.orbit_inpaint.train_step` | `int` | 500 |  |
| `phaseA.orbit_inpaint.auto_apply` | `bool` | false |  |
| `phaseA.orbit_inpaint.apply_to` | `list` | ["orbit_front", "orbit_left_45", "orbit_right_45", "orbit_left_profile", "orbit_right_profile", "orbit_high_angle", "orbit_low_angle"] |  |
| `phaseA.orbit_prompts` | `list` | [{"key": "orbit_front", "pulid_weight": 0.97, "prompt": "portrait photograph of a young woman facing directly forward, both eyes fully visible and symmetrical, nose centered in frame, both ears equally visible on each side, chin pointing straight at camera, natural relaxed posture, shoulders level and square, neck upright, studio portrait photography\n"}, {"key": "orbit_left_45", "pulid_weight": 0.93, "prompt": "portrait photograph of a young woman with her head turned to the left, right cheek and right eye prominently visible and facing camera, left side of face partially turned away, left ear mostly hidden, nose pointing left of center frame, right jawline clearly defined, right shoulder pulled back, left shoulder forward, classic three-quarter view, candid portrait photography\n"}, {"key": "orbit_left_profile", "pulid_weight": 0.84, "prompt": "strict left profile portrait photograph of a young woman, camera positioned directly to her right side, only the right side of her face visible, right eye and right nostril in view, left eye completely hidden behind her face, both lips visible in profile silhouette, right ear forward, left ear at back of head, clean sharp profile silhouette against background, editorial profile shot, hair falling naturally\n"}, {"key": "orbit_left_rear_135", "pulid_weight": 0.0, "prompt": "portrait photograph of a young woman seen from behind and slightly to the right, back of head occupying most of frame, dark hair visible from behind, left ear barely peeking at edge, right side of face completely hidden, nape of neck visible, both shoulder blades in frame, slight right cheekbone glimpsed at far edge, hair texture detailed from rear perspective\n"}, {"key": "orbit_back", "pulid_weight": 0.0, "prompt": "rear view portrait photograph of a young woman shot from directly behind, back of head centered in frame, no face visible whatsoever, detailed hair texture and structure from behind, nape of neck clearly visible below hairline, both shoulders symmetrical in lower frame, hair parting and scalp details visible, clean documentary back-of-head shot\n"}, {"key": "orbit_right_rear_135", "pulid_weight": 0.0, "prompt": "portrait photograph of a young woman seen from behind and slightly to the left, back of head occupying most of frame, dark hair visible from behind, right ear barely peeking at edge, left side of face completely hidden, nape of neck visible, both shoulder blades in frame, slight left cheekbone glimpsed at far edge, hair texture detailed from rear perspective\n"}, {"key": "orbit_right_profile", "pulid_weight": 0.84, "prompt": "strict right profile portrait photograph of a young woman, camera positioned directly to her left side, only the left side of her face visible, left eye and left nostril in view, right eye completely hidden behind her face, both lips visible in profile silhouette, left ear forward, right ear at back of head, clean sharp profile silhouette against background, editorial profile shot, hair falling naturally\n"}, {"key": "orbit_right_45", "pulid_weight": 0.93, "prompt": "portrait photograph of a young woman with her head turned to the right, left cheek and left eye prominently visible and facing camera, right side of face partially turned away, right ear mostly hidden, nose pointing right of center frame, left jawline clearly defined, left shoulder pulled back, right shoulder forward, classic three-quarter view, candid portrait photography\n"}, {"key": "orbit_high_angle", "pulid_weight": 0.38, "prompt": "overhead angle portrait photograph of a young woman shot from above, top of her head and forehead dominate the upper frame, forehead appears larger and more prominent than usual due to perspective, eyes appear lower in frame than normal, nose foreshortened pointing downward, chin very small and receding into neck from this angle, hair visible across top of skull, shoulders narrow in lower frame, bird's eye perspective portrait, dramatic downward angle photography\n"}, {"key": "orbit_low_angle", "pulid_weight": 0.38, "prompt": "low angle portrait photograph of a young woman shot from below chin level, underside of chin and jaw dominate the lower portion of face, nostrils visible from below, chin prominent and jutting forward, forehead receding far back in upper frame, appears small from this angle, neck elongated and prominent, chest and collarbones visible at bottom of frame, wide shoulders frame the composition from below, worm's eye view portrait, dramatic upward angle photography\n"}] |  |
| `phaseA.body.candidates_per_shot` | `int` | 4 |  |
| `phaseA.body.selection_similarity_weight` | `float` | 0.58 |  |
| `phaseA.body.use_orbit_reference_chaining` | `bool` | true |  |
| `phaseA.body.generation.steps` | `int` | 32 |  |
| `phaseA.body.generation.guidance` | `float` | 2.8 |  |
| `phaseA.body.generation.sampler` | `str` | "dpmpp_2m" |  |
| `phaseA.body.generation.scheduler` | `str` | "beta" |  |
| `phaseA.body.generation.negative_sfw` | `str` | "nude, nsfw, flat chest, wide shot, face cut off" |  |
| `phaseA.body.generation.negative_nsfw` | `str` | "bad anatomy, wide shot, face cut off" |  |
| `phaseA.body.inpaint.bbox_padding_ratio` | `float` | 0.08 |  |
| `phaseA.body.inpaint.mask_feather_px` | `int` | 6 |  |
| `phaseA.body.inpaint.steps` | `int` | 22 |  |
| `phaseA.body.inpaint.guidance` | `float` | 4.5 |  |
| `phaseA.body.inpaint.denoise` | `float` | 0.52 |  |
| `phaseA.body.inpaint.identity_adapter_weight` | `float` | 0.8 |  |
| `phaseA.body.inpaint.fusion` | `str` | "mean" |  |
| `phaseA.body.inpaint.train_step` | `int` | 500 |  |
| `phaseA.body.bust.framing` | `str` | "upper body shot, waist-up framing, bust portrait, shoulders and chest visible" |  |
| `phaseA.body.bust.sfw_count` | `int` | 13 |  |
| `phaseA.body.bust.nsfw_count` | `int` | 22 |  |
| `phaseA.body.bust.candidates_per_shot` | `int` | 6 |  |
| `phaseA.body.bust.width` | `int` | 832 |  |
| `phaseA.body.bust.height` | `int` | 1216 |  |
| `phaseA.body.bust.pulid_face_weight` | `float` | 0.4 |  |
| `phaseA.body.bust.pulid_body_weight_sfw` | `float` | 0.85 |  |
| `phaseA.body.bust.pulid_body_weight_nsfw` | `float` | 0.65 |  |
| `phaseA.body.bust.sfw_nudity_threshold` | `float` | 0.42 |  |
| `phaseA.body.bust.orbit_angles` | `list` | [{"key": "front", "framing": "waist-up portrait, head and shoulders fully visible, upper body to waist, facing directly forward, torso facing camera", "back_type": "", "pulid_face": 0.58, "neg_extra": "", "pos_extra": "fuller bust silhouette under clothing, opaque fabric covering chest"}, {"key": "left_45", "framing": "waist-up portrait, three-quarter left view, head and torso turned left together, right cheek prominent, body rotation visible to waist", "back_type": "", "pulid_face": 0.32, "neg_extra": "frontal face, facing directly at camera, symmetrical face", "pos_extra": "fuller bust silhouette under clothing, opaque fabric covering chest"}, {"key": "right_45", "framing": "waist-up portrait, three-quarter right view, head and torso turned right together, left cheek prominent, body rotation visible to waist", "back_type": "", "pulid_face": 0.32, "neg_extra": "frontal face, facing directly at camera, symmetrical face", "pos_extra": "fuller bust silhouette under clothing, opaque fabric covering chest"}, {"key": "left_profile", "framing": "waist-up portrait, strict left profile, only right side of face visible, torso in side profile, shoulder-to-waist silhouette visible", "back_type": "", "pulid_face": 0.24, "neg_extra": "both eyes visible, frontal face, three-quarter view", "pos_extra": "fuller bust silhouette under clothing, opaque fabric covering chest"}, {"key": "right_profile", "framing": "waist-up portrait, strict right profile, only left side of face visible, torso in side profile, shoulder-to-waist silhouette visible", "back_type": "", "pulid_face": 0.24, "neg_extra": "both eyes visible, frontal face, three-quarter view", "pos_extra": "fuller bust silhouette under clothing, opaque fabric covering chest"}, {"key": "high_angle", "framing": "waist-up portrait shot from above, camera looking down, top of head and forehead more prominent, shoulders and upper torso visible", "back_type": "", "pulid_face": 0.3, "neg_extra": "eye level portrait, flat perspective, normal angle", "pos_extra": "fuller bust silhouette under clothing, opaque fabric covering chest"}, {"key": "low_angle", "framing": "waist-up portrait shot from below, camera looking upward, chin and jawline more prominent, shoulders and upper torso visible", "back_type": "", "pulid_face": 0.3, "neg_extra": "eye level portrait, flat perspective, normal angle", "pos_extra": "fuller bust silhouette under clothing, opaque fabric covering chest"}, {"key": "left_rear_135", "framing": "rear-left three-quarter upper-body portrait, subject standing upright, left shoulder blade and full upper back dominant, waist visible, torso rotated away from camera 135 degrees left, only tiny right cheek or jawline visible at most, no frontal chest visible", "back_type": "half", "pulid_face": 0.14, "neg_extra": "frontal face, both eyes visible, facing camera, frontal chest visible, seated pose, kneeling pose, crouching pose", "pos_extra": "back anatomy locked, spine line readable, shoulders aligned, no front collapse"}, {"key": "right_rear_135", "framing": "rear-right three-quarter upper-body portrait, subject standing upright, right shoulder blade and full upper back dominant, waist visible, torso rotated away from camera 135 degrees right, only tiny left cheek or jawline visible at most, no frontal chest visible", "back_type": "half", "pulid_face": 0.14, "neg_extra": "frontal face, both eyes visible, facing camera, frontal chest visible, seated pose, kneeling pose, crouching pose", "pos_extra": "back anatomy locked, spine line readable, shoulders aligned, no front collapse"}, {"key": "back_half", "framing": "rear three-quarter hip-up portrait, subject standing upright, camera behind subject, upper back waist hips and buttocks visible, torso rotated away from camera, only one cheek or jawline silhouette visible at most, no frontal chest visible, framing from shoulders to upper thighs", "back_type": "half", "pulid_face": 0.1, "neg_extra": "full frontal face, both eyes visible, facing camera, frontal breasts, seated pose, kneeling pose, crouching pose, duplicated hands", "pos_extra": "back anatomy locked, spine line readable, shoulders aligned, no front collapse"}, {"key": "back_pure", "framing": "full rear hip-up portrait, subject standing upright, back of head neck shoulders upper back waist and hips visible, spine line readable, buttocks visible, absolutely no face visible, framing from shoulders to upper thighs", "back_type": "pure", "pulid_face": 0.0, "neg_extra": "face visible, any eye visible, front view, seated pose, kneeling pose, crouching pose", "pos_extra": "back anatomy locked, spine line readable, shoulders aligned, no front collapse"}] |  |
| `phaseA.body.bust.sfw_ref_clothing_anchor` | `str` | "wearing black fitted sports bra, wide opaque straps, full coverage fabric panel across chest, fuller bust shape under thick opaque fabric, no cleavage gap, no transparency, consistent upper-body look matching body reference" |  |
| `phaseA.body.bust.lighting_variants` | `list` | ["soft studio lighting, large diffused key light from left", "warm golden hour window light, side-lit, rim light on hair", "dramatic Rembrandt lighting, strong key from upper right, deep shadows", "overcast outdoor light, soft flat even illumination", "cool blue ambient light, soft backlight glow, slight front fill", "warm orange practical light, cozy indoor atmosphere, slight lens flare", "harsh direct flash, bleached highlights, documentary style", "soft butterfly lighting, key light directly above, glamour portrait"] |  |
| `phaseA.body.bust.sfw_outfit_variants` | `list` | ["wearing black high-support sports bra, thick opaque fabric, wide straps, full chest coverage, zero transparency, fuller bust shape under fabric", "wearing white compression sports bra, double-layer opaque fabric, wide straps, chest fully covered, fuller bust silhouette", "wearing charcoal racerback athletic top, thick matte opaque fabric, full bust coverage, secure fit, no transparency", "wearing ivory mock-neck fitted top, smooth thick opaque fabric, chest fully covered, clean clothed silhouette", "wearing navy square-neck knit top, dense opaque fabric, broad shoulder straps, fully covered bust, structured fit", "wearing burgundy scoop-neck tank top, double-layer opaque cotton, wide straps, secure chest coverage", "wearing dark forest green halter top, thick opaque front panel, full bust coverage, no side exposure", "wearing beige ribbed sleeveless turtleneck, dense opaque knit, fully covered chest, modest silhouette", "wearing black longline bralette top, structured opaque fabric, wide underbust band, fully covered bust", "wearing soft grey fitted crop top, heavyweight opaque stretch fabric, no transparency, full bust coverage", "wearing deep blue zip-front athletic top, fully zipped, thick opaque performance fabric, chest fully secured", "wearing white button-up shirt, all buttons closed, layered opaque fabric, bust fully controlled under fabric"] |  |
| `phaseA.body.bust.selection_similarity_weight` | `float` | 0.52 |  |
| `phaseA.body.hairstyle_change_every_angles` | `int` | 2 |  |
| `phaseA.onetrainer.output_model_path` | `str` | "/workspace/onetrainer/outputs/{character_id}_face_v11.safetensors" |  |
| `phaseA.onetrainer.lora_model_name` | `str` | "Eliska_face_v11" |  |
| `phaseA.onetrainer.rank` | `int` | 32 |  |
| `phaseA.onetrainer.alpha` | `int` | 32 |  |
| `phaseA.onetrainer.batch_size` | `int` | 1 |  |
| `phaseA.onetrainer.gradient_accumulation_steps` | `int` | 4 |  |
| `phaseA.onetrainer.epochs` | `int` | 12 |  |
| `phaseA.emotions_per_hairstyle` | `int` | 1 |  |
| `phaseA.orbit_emotions` | `list` | ["neutral expression", "skeptical expression", "determined expression", "concerned expression", "teary sad expression", "angry restrained expression", "startled expression", "exhausted stressed expression"] |  |
| `phaseB.sfw_count` | `int` | 40 |  |
| `phaseB.nsfw_count` | `int` | 40 |  |
| `phaseB.candidates_per_preset` | `int` | 4 |  |
| `phaseB.selection_similarity_weight` | `float` | 0.55 |  |
| `phaseB.face_correction_similarity_threshold` | `float` | 0.68 |  |
| `phaseB.verification_similarity_threshold` | `float` | 0.65 |  |
| `phaseB.minimum_verified_frames` | `int` | 64 |  |
| `phaseB.generation.width` | `int` | 832 |  |
| `phaseB.generation.height` | `int` | 1216 |  |
| `phaseB.generation.steps` | `int` | 34 |  |
| `phaseB.generation.guidance` | `float` | 3.6 |  |
| `phaseB.generation.sampler` | `str` | "dpmpp_2m" |  |
| `phaseB.generation.scheduler` | `str` | "beta" |  |
| `phaseB.generation.negative_sfw` | `str` | "nude, nsfw, flat chest, wide shot, face cut off" |  |
| `phaseB.generation.negative_nsfw` | `str` | "bad anatomy, wide shot, face cut off" |  |
| `phaseB.controlnet.pose_strength` | `float` | 0.85 |  |
| `phaseB.controlnet.depth_strength` | `float` | 0.82 |  |
| `phaseB.controlnet.json_strength` | `float` | 0.6 |  |
| `phaseB.controlnet.start_percent` | `float` | 0.0 |  |
| `phaseB.controlnet.end_percent` | `float` | 0.75 |  |
| `phaseB.inpaint.bbox_padding_ratio` | `float` | 0.12 |  |
| `phaseB.inpaint.mask_feather_px` | `int` | 12 |  |
| `phaseB.inpaint.steps` | `int` | 20 |  |
| `phaseB.inpaint.guidance` | `float` | 4.3 |  |
| `phaseB.inpaint.denoise` | `float` | 0.36 |  |
| `phaseB.inpaint.identity_adapter_weight` | `float` | 0.84 |  |
| `phaseB.inpaint.train_step` | `int` | 280 |  |
| `phaseB.onetrainer.output_model_path` | `str` | "/workspace/onetrainer/outputs/{character_id}_body_v11.safetensors" |  |
| `phaseB.onetrainer.lora_model_name` | `str` | "Eliska_body_v11" |  |
| `phaseB.onetrainer.rank` | `int` | 64 |  |
| `phaseB.onetrainer.alpha` | `int` | 64 |  |
| `phaseB.onetrainer.batch_size` | `int` | 1 |  |
| `phaseB.onetrainer.gradient_accumulation_steps` | `int` | 6 |  |
| `phaseB.onetrainer.epochs` | `int` | 10 |  |

## 7) Markdown / operational constraints

- Найденные markdown-файлы: `INSIGHTFACE_FIX_GUIDE.md`, `SETUP_FIRST.md`.
- `MASTER-POD-CHECKLIST.md` в архиве отсутствует.

### [INSIGHTFACE_FIX_GUIDE.md]
- **Содержимое по факту:** текст про падение Phase A на некоторых изображениях из-за InsightFace; файл документирует проблему/фиксацию, а не отдельные runtime-лимиты с множеством чисел.
- **Числовые фрагменты, найденные в тексте:**
  - `1` — не обнаружил лицо ```  ### Что происходит:  1. **Генерация кандидатов** — успешно создаются 3-4 варианта эмоции 2. **Выбор лучшего** —
  - `3` — **Генерация кандидатов** — успешно создаются 3-4 варианта эмоции 2. **Выбор лучшего** — успешно выбирается best candidate 3. **Face Inpa
  - `4` — Генерация кандидатов** — успешно создаются 3-4 варианта эмоции 2. **Выбор лучшего** — успешно выбирается best candidate 3. **Face Inpain
  - `2` — ов** — успешно создаются 3-4 варианта эмоции 2. **Выбор лучшего** — успешно выбирается best candidate 3. **Face Inpaint** — **ТУТ ПАДАЕТ
  - `3` — учшего** — успешно выбирается best candidate 3. **Face Inpaint** — **ТУТ ПАДАЕТ**:    - Система пытается создать маску лица: `scorer.cre
  - `0.12` — лицо?  Даже с fallback стратегиями (padding 0.12, 0.20, 0.30) InsightFace может не найти лицо если: - Экстремальная эмоция (eyes_rolled, o
  - `0.20` — Даже с fallback стратегиями (padding 0.12, 0.20, 0.30) InsightFace может не найти лицо если: - Экстремальная эмоция (eyes_rolled, overwhe
  - `0.30` — с fallback стратегиями (padding 0.12, 0.20, 0.30) InsightFace может не найти лицо если: - Экстремальная эмоция (eyes_rolled, overwhelmed,
  - `1` — яркий/тёмный свет  ## ✅ РЕШЕНИЕ  ### Вариант 1: Исправить обработку ошибок (РЕКОМЕНДУЮ)  Изменить функцию `_face_inpaint()` чтобы она **
  - `0.12` — ng_ratio=float(inp.get("bbox_padding_ratio", 0.12)),                 feather_px=int(inp.get("mask_feather_px", 24)),             )
  - `24` — feather_px=int(inp.get("mask_feather_px", 24)),             )             logger.info("✅ Mask created: %s", mask_path.name)         ex
  - `717` — ```python # В блоке Face Emotions (строка ~717): refined = _face_inpaint(...)  # ── ДОБАВИТЬ ПРОВЕРКУ ── if refined is None:     logger.
### [SETUP_FIRST.md]
- **Операционные числа/пути, присутствующие в тексте:**
  - копировать best photo в `stage0/selected/ref_face.png`;
  - запуск stages: `ref`, `stage0`, `phaseA`, `phaseB`;
  - ComfyUI URL/порт косвенно через runtime setup: `127.0.0.1:8188`;
  - checkpoint path: `/workspace/ComfyUI/models/checkpoints/flux2-klein-9b/flux-2-klein-9b.safetensors`;
  - рекомендуемые параметры для Klein 9B vs Flux.1 Dev: `steps 35–45 vs 22–28`, `guidance 3.5–4.0 vs 3.4–3.8`, `sampler euler vs dpmpp_2m`, `schedule simple vs beta`.
- **Числовые фрагменты, найденные в тексте:**
  - `1` — # MARCO — Setup Before Running  ## 1. Copy ref_face.png  ```bash # Best real photo of you (jaw + eyes + stubble angle) cp "you
  - `2` — e/MARCO/stage0/selected/ref_face.png ```  ## 2. Deploy to RunPod  ```bash cp -r RUNTIME/* /workspace/WAR333_GODTIER_OMNI/RUNTIME/ ```  #
  - `3` — rkspace/WAR333_GODTIER_OMNI/RUNTIME/ ```  ## 3. Setup check  ```bash bash /workspace/WAR333_GODTIER_OMNI/RUNTIME/RUN_MARCO.sh setup ```
  - `4` — TIER_OMNI/RUNTIME/RUN_MARCO.sh setup ```  ## 4. Run pipeline step by step  ```bash # Generate ref faces (PuLID locked to your face) bash
  - `5` — ody dataset bash RUN_MARCO.sh phaseB ```  ## 5. Klein 9B checkpoint location ``` /workspace/ComfyUI/models/checkpoints/flux2-klein-9b/fl
  - `9` — et bash RUN_MARCO.sh phaseB ```  ## 5. Klein 9B checkpoint location ``` /workspace/ComfyUI/models/checkpoints/flux2-klein-9b/flux-2-klei
  - `9` — space/ComfyUI/models/checkpoints/flux2-klein-9b/flux-2-klein-9b.safetensors ```  ## Key params (Klein 9B vs Flux.1 Dev) | Param    | Flu
  - `2` — mfyUI/models/checkpoints/flux2-klein-9b/flux-2-klein-9b.safetensors ```  ## Key params (Klein 9B vs Flux.1 Dev) | Param    | Flux.1 Dev
  - `9` — dels/checkpoints/flux2-klein-9b/flux-2-klein-9b.safetensors ```  ## Key params (Klein 9B vs Flux.1 Dev) | Param    | Flux.1 Dev | Klein
  - `9` — ein-9b.safetensors ```  ## Key params (Klein 9B vs Flux.1 Dev) | Param    | Flux.1 Dev | Klein 9B | |----------|-----------|----------|
  - `9` — Flux.1 Dev) | Param    | Flux.1 Dev | Klein 9B | |----------|-----------|----------| | Steps    | 35-45     | 22-28    | | Guidance | 3
  - `35` — -------|-----------|----------| | Steps    | 35-45     | 22-28    | | Guidance | 3.5-4.0   | 3.4-3.8  | | Sampler  | euler     | dpmpp_2m

## 8) Краткий итог для сверки с новым SDXL-скриптом

- В legacy core нет CLIP-score и нет runtime auto-reject в `best_candidate()`; top-1 выбирается всегда, а жёсткие пороги живут в вызывающих слоях.
- `VramGovernor` — только `nvidia-smi` wait-gate + `ComfyUI free_memory`; dynamic reduction generation params по фактическому free VRAM нет.
- `InsightFaceEngine` — lazy `FaceAnalysis`, модель из конфига (`buffalo_l` fallback), similarity = dot product нормализованных embedding-ов, provider CPU/CUDA задаётся отдельно.
- `build_flux_workflow()` сам не различает face/hands/body; Phase B использует другой builder (`build_body_union_workflow`) для ControlNet depth/pose composition.
- `ref_regen.py` — не дубль Stage0, а отдельный pre-Stage0 digitization path: ESRGAN → PuLID txt2img variants → QC → two-pass face detail → optional upscale.
- Phase A legacy режет PuLID/identity не через единый declarative слой, а набором preset-specific numeric caps; это самое заметное отличие от новой SDXL-схемы c `identity_weights`.
- Phase A экспортирует `face_lora_config.json`, но не запускает OneTrainer сам; Phase B требует уже обученную Face LoRA по имени.