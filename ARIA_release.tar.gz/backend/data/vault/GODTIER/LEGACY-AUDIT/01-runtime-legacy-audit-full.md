---
status: archived
tags: [legacy-audit]
---
# Аудит legacy-скриптов генерации (Flux/PuLID → SDXL/InstantID)

Источник: `RUNTIME.rar`

Область: только фактическое описание текущего поведения кода. Приоритет отдан блокам, связанным с генерацией per-GPU параметров, скорингом/отбором, retry/resume, ComfyUI workflow graph, PuLID/ControlNet/Flux Fill.

---

## Карта файлов и основных связей

### [межскриптовые_связи]
Назначение: карта основных вызовов между скриптами.
Триггер: используется как верхний уровень запуска всего пайплайна.
Вход → выход: CLI args/config YAML → запуск Stage0/PhaseA/PhaseB, генерация датасета/манифестов/конфигов.
Побочные эффекты: subprocess-запуски, HTTP к ComfyUI, запись PNG/TXT/JSON/YAML логов.
Магические числа/константы:
- `8188` — стандартный порт ComfyUI в нескольких местах.
- `10000` MB — частый дефолт минимального свободного VRAM.
- `1800` / `2400` сек — таймауты ожидания ComfyUI.
Особые случаи / edge cases, которые код явно обрабатывает:
- отсутствие `ref_face.png`;
- отсутствие `face_lora_name` для Phase B;
- частично битые/несуществующие YAML;
- пустой ответ ComfyUI или `execution_error` в `/history/{prompt_id}`;
- fallback на уже существующие output-файлы при `--force`/без него.

Связи / вызовы:
- `orchestrator_v7.py` → `stage0_references.py`, `phaseA_face_lora.py`, `phaseB_body_lora.py`.
- `stage0_references.py` → `godtier_v7_core.build_flux_workflow`, `best_candidate`, `ComfyUIClient`, `VramGovernor`.
- `phaseA_face_lora.py` → встроенный guard/retry/restart ComfyUI, `godtier_v7_core` utilities, `pulid_forward_patch2.py`.
- `phaseB_body_lora.py` → `godtier_v7_core.build_body_union_workflow`, `build_flux_fill_workflow`, `best_candidate`.
- `ref_regen.py` → отдельный legacy-генератор вариаций + QC + upscale.
- `comfyui_cuda_patch.py`, `flux_model_patch.py`, `pulid_forward_patch2.py` — патчат рантайм/исходники ComfyUI/PuLID.

---

# orchestrator_v7.py

### [parse_args]
Назначение: разбирает верхнеуровневые команды оркестратора.
Триггер: вызывается из `main()` при старте файла.
Вход → выход: CLI → `argparse.Namespace` с `command`, `config`, `ref_face`, `face_lora`, `force`, `clean`, `auto_select`.
Побочные эффекты: нет.
Магические числа/константы:
- команды: `stage0`, `phaseA`, `phaseB`, `full`, `resume-phaseB`.
Особые случаи / edge cases, которые код явно обрабатывает:
- `command` по умолчанию = `full`.

### [run_stage]
Назначение: запускает дочерний этап как отдельный Python-процесс.
Триггер: вызывается из `main()` для каждого этапа.
Вход → выход: `script_name: str`, `args: List[str]`, `logger` → `None` или `PipelineError`.
Побочные эффекты: `subprocess.run`, логирование, запуск отдельного процесса.
Магические числа/константы: нет.
Особые случаи / edge cases, которые код явно обрабатывает:
- если `returncode != 0`, поднимает `PipelineError` с именем этапа.

### [main]
Назначение: управляет последовательностью Stage0 → PhaseA → PhaseB и resume-сценарием.
Триггер: точка входа файла.
Вход → выход: CLI/config → код завершения `0/1`.
Побочные эффекты:
- чтение YAML;
- создание `RuntimePaths`;
- инициализация `ComfyUIClient` и `VramGovernor`;
- запуск subprocess-этапов;
- печать инструкций по resume.
Магические числа/константы:
- `timeout_seconds` дефолт `1800`;
- `poll_interval` дефолт `1.5`;
- `vram_min_free_mb` дефолт `10000`;
- `sleep_between_heavy_models_seconds` дефолт `10`.
Особые случаи / edge cases, которые код явно обрабатывает:
- `--auto-select` добавляется только в Stage0;
- при `full`, если `face_lora_name` пустой после Phase A, оркестратор останавливается и печатает команду `resume-phaseB`;
- для `phaseB` и `resume-phaseB` перед запуском вызывается `governor.flush("phaseB")`.

Связи / вызовы:
- `load_yaml` → `RuntimePaths.from_config` → `setup_logger`.
- `ComfyUIClient.wait_ready()` перед любым этапом.
- `VramGovernor.flush()` перед `phaseB` и между `stage0/phaseA/phaseB` в `full`.
- `run_stage("stage0_references.py", ...)`, `run_stage("phaseA_face_lora.py", ...)`, `run_stage("phaseB_body_lora.py", ...)`.

---

# phasea_comfy_guard.py

### [_log]
Назначение: унифицированный логгер с fallback на `print`.
Триггер: вызывается всеми guard-функциями.
Вход → выход: `logger`, `level`, `msg`, `*args` → `None`.
Побочные эффекты: stdout/logging.
Магические числа/константы: нет.
Особые случаи / edge cases, которые код явно обрабатывает:
- если `logger is None`, форматирует строку через `%` и печатает напрямую.

### [_post_json]
Назначение: посылает POST JSON в ComfyUI endpoint.
Триггер: вызывается из `hard_flush`.
Вход → выход: `base_url: str`, `path: str`, `payload: Optional[dict]`, `timeout: int=20` → `bool`.
Побочные эффекты: HTTP POST.
Магические числа/константы:
- `timeout=20`.
Особые случаи / edge cases, которые код явно обрабатывает:
- любые исключения глотаются, возвращается `False`.

### [hard_flush]
Назначение: агрессивно чистит очередь/VRAM ComfyUI и локальный CUDA-кэш.
Триггер: вызывается перед повтором и после рестарта ComfyUI.
Вход → выход: `base_url`, `logger=None`, `wait_s: float=12.0` → `None`.
Побочные эффекты:
- POST в `/interrupt`, `/queue`, `/free`;
- `torch.cuda.synchronize()` / `empty_cache()`;
- `gc.collect()`.
Магические числа/константы:
- двойной `/free`;
- `wait_s * 0.5` дважды.
Особые случаи / edge cases, которые код явно обрабатывает:
- работает даже если `torch`/CUDA недоступны.

### [reseed_workflow]
Назначение: меняет seed у всех `KSampler`/`KSamplerAdvanced` узлов workflow.
Триггер: вызывается при retry в `safe_run_and_save`.
Вход → выход: `workflow: Dict[str, Any]` → изменённый in-place workflow.
Побочные эффекты: меняет содержимое dict in-place.
Магические числа/константы:
- стартовый seed берётся из `random.randint(0, 2**32 - 1)`.
Особые случаи / edge cases, которые код явно обрабатывает:
- seed инкрементируется для каждого найденного sampler-узла.

### [_find_comfy_process]
Назначение: ищет процесс ComfyUI по `cmdline`.
Триггер: вызывается из `restart_comfy`.
Вход → выход: `() -> tuple[Optional[int], Optional[list[str]]]`.
Побочные эффекты: читает `psutil.process_iter` и `/proc/*/cmdline`.
Магические числа/константы: нет.
Особые случаи / edge cases, которые код явно обрабатывает:
- сначала пробует `psutil`, потом fallback через `/proc`.

### [restart_comfy]
Назначение: убивает текущий ComfyUI и поднимает заново.
Триггер: вызывается после неудачного `run_and_save` в `safe_run_and_save`.
Вход → выход: `comfy_client`, `logger=None`, `sleep_s: float=4.0` → `None`.
Побочные эффекты:
- `os.kill(SIGTERM/SIGKILL)`;
- `subprocess.Popen` в `/workspace/ComfyUI`;
- пересоздание `requests.Session`;
- ожидание `comfy_client.wait_ready(max_wait=300)`.
Магические числа/константы:
- fallback cmd: `python3 main.py --listen 0.0.0.0 --port 8188 --normalvram --disable-auto-launch`.
- `max_wait=300`.
Особые случаи / edge cases, которые код явно обрабатывает:
- если исходная командная строка ComfyUI не найдена, использует fallback-команду.

### [safe_run_and_save]
Назначение: retry-обёртка вокруг `comfy_client.run_and_save` с reseed/flush/restart.
Триггер: вызывается внешним кодом вместо прямого `run_and_save`.
Вход → выход: `comfy_client`, `workflow`, `dst: Path`, `logger=None`, `max_attempts: int=5` → `Path`.
Побочные эффекты:
- удаляет старый `dst`;
- HTTP к ComfyUI через `run_and_save`;
- reseed workflow;
- hard flush;
- restart ComfyUI.
Магические числа/константы:
- `max_attempts=5`;
- файл считается валидным если `st_size > 1024`;
- `wait_s=min(8.0 + attempt*3.0, 18.0)`;
- `sleep_s=min(4.0 + attempt*2.0, 10.0)`.
Особые случаи / edge cases, которые код явно обрабатывает:
- если файл уже успел появиться и больше `1024` байт, считает попытку успешной даже после исключения;
- на последней неудаче бросает `RuntimeError`.

Связи / вызовы:
- `safe_run_and_save` → `reseed_workflow` → `hard_flush` → `restart_comfy`.
- `restart_comfy` → `_find_comfy_process`, `hard_flush`, `wait_ready`.

---

# comfyui_cuda_patch.py

### [apply]
Назначение: monkey-patch `comfy.model_patcher.ModelPatcher` в памяти для retry на `CUDA invalid argument`.
Триггер: вызывается автоматически при импорте файла.
Вход → выход: `() -> None`.
Побочные эффекты:
- monkey-patch методов `ModelPatcher.load`, `unpatch_model`, `partially_unload`;
- печать статуса в stdout.
Магические числа/константы:
- `_CUDA_FIX_APPLIED` — idempotency-флаг;
- retry `.to(device)` до `3` раз;
- `_cuda_flush(4 + attempt*2)`.
Особые случаи / edge cases, которые код явно обрабатывает:
- повторный импорт безопасен;
- если ошибка не содержит `invalid argument`, она пробрасывается без retry.

### [_cuda_flush]
Назначение: синхронизирует CUDA, чистит cache, делает GC и sleep.
Триггер: внутренний helper в `apply`.
Вход → выход: `sleep_sec: float=4.0` → `None`.
Побочные эффекты: CUDA sync/cache clear, `gc.collect`, `sleep`.
Магические числа/константы: `4.0` сек дефолт.
Особые случаи / edge cases, которые код явно обрабатывает:
- `synchronize()` завернут в `try/except`.

### [_load_patched/_unpatch_patched/_partial_patched]
Назначение: оборачивают штатные методы `ModelPatcher` retry-логикой.
Триггер: вызываются самим ComfyUI после monkey-patch.
Вход → выход: те же аргументы, что у оригинальных методов → результат оригинального метода.
Побочные эффекты: stdout, задержки, очистка CUDA.
Магические числа/константы:
- `load`: 3 попытки;
- `unpatch_model`/`partially_unload`: 1 повтор после flush.
Особые случаи / edge cases, которые код явно обрабатывает:
- патч применяет только `partially_unload`, если атрибут существует у класса.

Связи / вызовы:
- импортируется в `phaseA_face_lora.py` как побочный runtime-patch.

---

# pulid_forward_patch2.py

### [_backup]
Назначение: делает одноразовый backup `pulidflux.py.orig`.
Триггер: вызывается из `patch()` перед изменением файла.
Вход → выход: `path: Path` → `Path` backup-файла.
Побочные эффекты: копирование файла.
Магические числа/константы: `.py.orig`.
Особые случаи / edge cases, которые код явно обрабатывает:
- backup не перезаписывается, если уже существует.

### [_is_already_patched]
Назначение: проверяет наличие маркера патча в тексте.
Триггер: вызывается из `patch()`.
Вход → выход: `src: str` → `bool`.
Побочные эффекты: нет.
Магические числа/константы:
- `PATCH_MARKER = "timestep_zero_index=None"`.
Особые случаи / edge cases, которые код явно обрабатывает: нет.

### [_strategy_full_replace]
Назначение: пытается заменить всю функцию `forward_orig` целиком на заранее зашитое тело.
Триггер: первая стратегия в `patch()`.
Вход → выход: `src: str` → `str | None`.
Побочные эффекты: нет.
Магические числа/константы:
- ищет start markers `def forward_orig(...`;
- ищет end markers до `return img`.
Особые случаи / edge cases, которые код явно обрабатывает:
- если старт или конец не найдены, возвращает `None`.

### [_strategy_sig_kwargs]
Назначение: fallback-патч сигнатуры `forward_orig`, добавляющий `timestep_zero_index=None`, `transformer_options={}`, `**kwargs`.
Триггер: вызывается, если full replace не сработал.
Вход → выход: `src: str` → `str | None`.
Побочные эффекты: нет.
Магические числа/константы:
- regex по сигнатуре `def forward_orig(... ) -> Tensor:`.
Особые случаи / edge cases, которые код явно обрабатывает:
- не добавляет параметры повторно, если они уже присутствуют.

### [patch]
Назначение: патчит `/workspace/ComfyUI/custom_nodes/ComfyUI-PuLID-Flux/pulidflux.py`.
Триггер: прямой запуск скрипта или автозапуск из `phaseA_face_lora.py`.
Вход → выход: `path: Path` → `bool`.
Побочные эффекты:
- чтение/запись системного файла;
- создание backup;
- печать статуса.
Магические числа/константы:
- `PULID_PATH = /workspace/ComfyUI/custom_nodes/ComfyUI-PuLID-Flux/pulidflux.py`.
Особые случаи / edge cases, которые код явно обрабатывает:
- если файл уже содержит маркер, ничего не делает;
- если обе стратегии не сработали, печатает инструкцию запустить `--dump`.

### [dump_sig]
Назначение: печатает текущую сигнатуру `forward_orig` для ручной диагностики.
Триггер: `--dump`.
Вход → выход: `path: Path` → `None`.
Побочные эффекты: stdout.
Магические числа/константы: regex по `forward_orig(...)->Tensor:`.
Особые случаи / edge cases, которые код явно обрабатывает:
- если функция не найдена, пишет `forward_orig not found in file`.

### [PATCHED_FORWARD]
Назначение: полное встроенное replacement-тело `forward_orig` с поддержкой `timestep_zero_index`, `transformer_options`, `**kwargs`.
Триггер: вставляется `_strategy_full_replace`.
Вход → выход: tensor inputs → Tensor img.
Побочные эффекты: меняет поведение custom node PuLID.
Магические числа/константы:
- проверка `img.ndim != 3 or txt.ndim != 3`;
- интервалы `self.pulid_double_interval` / `self.pulid_single_interval`;
- фильтрация по `sigma_start >= timesteps >= sigma_end`.
Особые случаи / edge cases, которые код явно обрабатывает:
- если `y is None`, создаёт нулевой conditioning-вектор;
- ControlNet input/output подмешивается по блокам.

Связи / вызовы:
- `phaseA_face_lora.py` запускает этот скрипт в самом начале через `subprocess.run`.

---

# flux_model_patch.py

### [find_target]
Назначение: находит `comfy/ldm/flux/model.py` внутри `/workspace/ComfyUI`.
Триггер: вызывается в `__main__`.
Вход → выход: `() -> Path`.
Побочные эффекты: файловый поиск `rglob`.
Магические числа/константы:
- `COMFY_ROOT = /workspace/ComfyUI`.
Особые случаи / edge cases, которые код явно обрабатывает:
- если стандартный путь не найден, ищет fallback через `rglob`.

### [patch]
Назначение: патчит сигнатуру `forward_orig` в `flux/model.py`.
Триггер: прямой запуск скрипта.
Вход → выход: `path: Path` → `bool`.
Побочные эффекты: backup `.py.orig`, запись файла, stdout.
Магические числа/константы:
- маркер `timestep_zero_index=None`.
- 2 стратегии: `SIG_INJECT`, `LINE_INJECT`.
Особые случаи / edge cases, которые код явно обрабатывает:
- повторный запуск идемпотентен;
- если ни одна стратегия не сработала, печатает ручную инструкцию через `grep`.

### [verify]
Назначение: проверяет, что маркер патча реально записан.
Триггер: вызывается после `patch()`.
Вход → выход: `path: Path` → `bool`.
Побочные эффекты: чтение файла.
Магические числа/константы: тот же `MARKER`.
Особые случаи / edge cases, которые код явно обрабатывает: нет.

---

# godtier_v7_core.py

### [PipelineError]
Назначение: тип контролируемых ошибок пайплайна.
Триггер: используется почти во всех скриптах.
Вход → выход: human-readable message → exception.
Побочные эффекты: прерывание контролируемого сценария.
Магические числа/константы: нет.
Особые случаи / edge cases, которые код явно обрабатывает: нет.

### [setup_logger]
Назначение: создаёт logger с выводом в stdout и файл.
Триггер: вызывается почти каждым верхнеуровневым скриптом.
Вход → выход: `name: str`, `log_dir: Path` → `logging.Logger`.
Побочные эффекты: создаёт каталог логов, файл `<name>.log`.
Магические числа/константы:
- формат времени `%Y-%m-%d %H:%M:%S`.
Особые случаи / edge cases, которые код явно обрабатывает:
- если у логгера уже есть handlers, возвращает его без повторной конфигурации.

### [load_yaml/save_yaml/save_json/read_json/ensure_dir/resolve_path]
Назначение: базовые файловые утилиты рантайма.
Триггер: вызываются всеми сценариями.
Вход → выход:
- `load_yaml(path) -> Dict[str, Any]`
- `save_yaml(path, data) -> None`
- `save_json(path, data) -> None`
- `read_json(path, default=None) -> Any`
- `ensure_dir(path: Path) -> Path`
- `resolve_path(base_dir, raw_value, cfg=None) -> Path`
Побочные эффекты: чтение/запись файлов, создание директорий.
Магические числа/константы:
- placeholder keys в `resolve_path`: `character_id`, `character_token`, `workspace_root`.
Особые случаи / edge cases, которые код явно обрабатывает:
- `load_yaml` валидирует, что YAML верхнего уровня — dict, иначе `PipelineError`.
- `read_json` возвращает `default`, если файла нет.

### [RuntimePaths.from_config]
Назначение: строит структуру runtime-каталогов персонажа.
Триггер: вызывается из `stage0/phaseA/phaseB/orchestrator`.
Вход → выход: `cfg`, `config_path` → `RuntimePaths(root, logs, stage0, phaseA, phaseB, exports, temp)`.
Побочные эффекты: создаёт каталоги.
Магические числа/константы:
- подкаталоги: `logs`, `stage0`, `phaseA`, `phaseB`, `exports`, `tmp`.
Особые случаи / edge cases, которые код явно обрабатывает:
- `character.id` fallback = `character`.

### [ComfyUIClient]
Назначение: HTTP-клиент ComfyUI.
Триггер: создаётся в верхнеуровневых этапах.
Вход → выход: `base_url`, `logger`, timeouts → объект клиента.
Побочные эффекты: держит `requests.Session`.
Магические числа/константы:
- `wait_ready(max_wait=180)`;
- `upload_image(... timeout=120)`;
- `/prompt timeout=60`;
- `/history timeout=30`.
Особые случаи / edge cases, которые код явно обрабатывает:
- `wait_ready` ждёт `/system_stats`;
- `submit_workflow` при отсутствии `prompt_id` раскрывает `node_errors` по узлам;
- `wait_for_outputs` отслеживает `execution_error` в последних status messages;
- `first_image_meta` падает, если ComfyUI не вернул ни одной картинки.

### [ComfyUIClient.wait_ready]
Назначение: блокирующее ожидание готовности ComfyUI.
Триггер: сразу после создания клиента.
Вход → выход: `max_wait: int=180` → `None`.
Побочные эффекты: HTTP GET `/system_stats`, логирование.
Магические числа/константы:
- polling каждые `2` сек.
Особые случаи / edge cases, которые код явно обрабатывает:
- сохраняет текст последней ошибки и включает его в `PipelineError`.

### [ComfyUIClient.upload_image]
Назначение: загружает изображение в ComfyUI `/upload/image`.
Триггер: перед каждым workflow, где нужен `LoadImage` из input-хранилища ComfyUI.
Вход → выход: `image_path: Path`, `overwrite=True`, `image_type="input"`, `subfolder=""` → `uploaded_name: str`.
Побочные эффекты: multipart HTTP POST.
Магические числа/константы:
- mime type принудительно `image/png`.
Особые случаи / edge cases, которые код явно обрабатывает:
- если файла нет — `PipelineError`;
- `payload.get("name") or payload.get("filename") or image_path.name`.

### [ComfyUIClient.submit_workflow]
Назначение: отправляет workflow в `/prompt`.
Триггер: вызывается `run_and_save`.
Вход → выход: `workflow: Dict[str, Any]` → `prompt_id: str`.
Побочные эффекты: HTTP POST.
Магические числа/константы: нет.
Особые случаи / edge cases, которые код явно обрабатывает:
- при отказе ComfyUI собирает подробное сообщение по `node_errors`.

### [ComfyUIClient.wait_for_outputs]
Назначение: ждёт завершения workflow по `/history/{prompt_id}`.
Триггер: после `/prompt`.
Вход → выход: `prompt_id: str` → `outputs: Dict[str, Any]`.
Побочные эффекты: повторные HTTP GET, sleep.
Магические числа/константы:
- дедлайн = `timeout_seconds` клиента.
Особые случаи / edge cases, которые код явно обрабатывает:
- если запись по `prompt_id` ещё не появилась, продолжает polling;
- если видит `execution_error`, сразу бросает `PipelineError`.

### [ComfyUIClient.download_image/run_and_save/free_memory]
Назначение: скачивание первого output-изображения, полный цикл генерации, принудительная очистка памяти.
Триггер: стандартный путь выполнения workflow.
Вход → выход:
- `download_image(image_meta, dst) -> Path`
- `run_and_save(workflow, dst) -> Path`
- `free_memory() -> None`
Побочные эффекты: HTTP GET `/view`, запись файла, POST `/free`.
Магические числа/константы:
- `free_memory` отправляет `{unload_models: true, free_memory: true}`.
Особые случаи / edge cases, которые код явно обрабатывает:
- `download_image` подставляет `filename/subfolder/type` из `image_meta`.

### [VramGovernor.flush]
Назначение: синхронизирует переход между тяжёлыми этапами и не даёт идти дальше при низком VRAM.
Триггер: вызывается перед сменой stage/модели.
Вход → выход: `next_stage: str` → `None`.
Побочные эффекты:
- ComfyUI `/free`;
- `torch.cuda.empty_cache/ipc_collect/reset_peak_memory_stats`;
- `gc.collect`;
- `nvidia-smi` polling;
- sleep.
Магические числа/константы:
- дефолт `min_free_mb=10000`, `sleep_seconds=10`;
- wait loop до `120` сек с шагом `10` сек.
Особые случаи / edge cases, которые код явно обрабатывает:
- если `nvidia-smi` не даёт значение, просто логирует warning и не блокирует выполнение;
- если VRAM не восстановился после `120` сек, пишет error, но всё равно продолжает.

### [InsightFaceEngine.detect]
Назначение: детектит лицо с fallback-стратегиями resize/padding.
Триггер: вызывается scoring/mask/similarity-блоками.
Вход → выход: `image_bgr: np.ndarray` → `List[Any]` faces.
Побочные эффекты: lazy load InsightFace модели.
Магические числа/константы:
- `det_size=(640,640)`, `det_thresh=0.15`;
- resize при `max_dim > 1280`;
- pad ratios `0.12`, `0.20`, `0.30`;
- min pad `48` или `32` на resized.
Особые случаи / edge cases, которые код явно обрабатывает:
- после padded/resized детекта ремапит bbox/kps назад в исходные координаты.

### [InsightFaceEngine.score_quality]
Назначение: считает quality-score лица для отбора кадров.
Триггер: `best_candidate`, QC, Phase A/Phase B scoring.
Вход → выход: `image_path: Path` → dict с `score`, `det_score`, `sharpness`, `symmetry`, `size_ratio`, `center_score`, `eye_level_score`, `yaw_balance`, `pitch_ratio`, `face_count`.
Побочные эффекты: чтение файла и инференс InsightFace.
Магические числа/константы:
- `sharpness = LaplacianVar / 900.0`, capped to `1.0`;
- `eye_level_score = 1 - eye_roll / 0.28`;
- размер лица нормируется на `0.20` площади кадра;
- веса итогового score: `det 0.26`, `sharp 0.25`, `sym 0.16`, `size 0.10`, `center 0.12`, `eye_level 0.11`;
- penalty по числу лиц = `1/max(1,len(faces))`.
Особые случаи / edge cases, которые код явно обрабатывает:
- если лица нет, возвращает нули по всем метрикам.

### [InsightFaceEngine.create_face_mask]
Назначение: строит разные типы face-mask для inpaint.
Триггер: face inpaint в Phase A/Phase B.
Вход → выход: `image_path`, `out_path`, `padding_ratio=0.12`, `feather_px=25`, `mode="face"` → dict с `mask_path`, `bbox`, `center`, `axes`, `padding_ratio`, `feather_px`, `mode`.
Побочные эффекты: запись PNG-маски.
Магические числа/константы:
- общий вертикальный сдвиг центра `+ face_h * 0.06`;
- оси эллипса `face_w * 0.58`, `face_h * 0.72` + padding;
- специальные режимы: `eyes_mouth_precise`, `expression_combo`, `mouth_focus`, `face_except_eyes`;
- kernel close ~ `max(face_w, face_h) * 0.08`;
- bbox bottom расширяется на `face_h * 0.18`.
Особые случаи / edge cases, которые код явно обрабатывает:
- специальные masks для eye-roll / mouth / tears;
- вырезание eye-holes в режиме `face_except_eyes`;
- bbox-ограничение маски после рисования эллипсов.

### [FlorenceCaptioner]
Назначение: генерирует детальные caption'ы для датасета.
Триггер: tag/caption шаги в Phase A/Phase B.
Вход → выход: `caption(image_path, task="<DETAILED_CAPTION>") -> str`.
Побочные эффекты: загрузка HF модели/процессора, GPU/CPU память.
Магические числа/константы:
- `max_new_tokens=192`, `num_beams=3`, `do_sample=False`.
Особые случаи / edge cases, которые код явно обрабатывает:
- все float tensors кастятся в `model_dtype`, чтобы избежать dtype mismatch;
- `unload()` освобождает модель и чистит CUDA cache.

### [best_candidate]
Назначение: общий selector лучшего кандидата по quality+similarity.
Триггер: Stage0, PhaseB и др.
Вход → выход: `candidate_paths`, `scorer`, `logger`, `reference_path=None`, `similarity_weight=0.45` → `(best_path: Path, table: List[Dict[str, Any]])`.
Побочные эффекты: логирует полную таблицу кандидатов в JSON.
Магические числа/константы:
- `total = quality.score*(1-similarity_weight) + similarity*similarity_weight`.
Особые случаи / edge cases, которые код явно обрабатывает:
- если similarity не удалось посчитать, оставляет только quality;
- если список пустой, бросает `PipelineError`.

### [collect_pose_pairs]
Назначение: собирает triplet'ы поз depth/pose/json.
Триггер: PhaseB и pose-ориентированные этапы.
Вход → выход: `folder: Path` → list dicts `{key, depth, pose, json_img, json_file}`.
Побочные эффекты: читает директорию и sidecar `.json`.
Магические числа/константы:
- suffix conventions: `_depth`, `_pose`, `_json`.
Особые случаи / edge cases, которые код явно обрабатывает:
- depth-only fallback (`person_001.png`);
- если нет ни одного валидного изображения — `PipelineError`.

### [render_openpose_json]
Назначение: рендерит OpenPose JSON в skeleton PNG.
Триггер: используется как утилита для pose library.
Вход → выход: `json_path`, `out_png`, `width=832`, `height=1216` → `Optional[Path]`.
Побочные эффекты: запись PNG.
Магические числа/константы:
- COCO connections зашиты в списке;
- radius circle = `6`, line width = `3`.
Особые случаи / edge cases, которые код явно обрабатывает:
- поддерживает 2 формата: ComfyUI JSON и простой список точек.

### [build_flux_workflow]
Назначение: базовый txt2img workflow для Stage0 с optional LoRA stack и PuLID.
Триггер: Stage0 `generate_candidates` / anatomy генерация.
Вход → выход: cfg + prompts + размеры + seed + steps + guidance + набор LoRA/ref аргументов → `Dict[str, Any]` workflow.
Побочные эффекты: нет сам по себе; формирует graph для `/prompt`.
Магические числа/константы:
- базовые узлы: `DualCLIPLoader`, `UNETLoader`, `VAELoader`, `CLIPTextEncodeFlux`, `EmptyLatentImage`, `KSampler`, `VAEDecode`, `SaveImage`;
- sampler/scheduler берутся из `cfg.stage0.generation`, fallback `dpmpp_2m` / `beta`;
- `cfg` у `KSampler` жёстко `1.0`.
Особые случаи / edge cases, которые код явно обрабатывает:
- LoRA узлы вставляются последовательно и переназначают `model_input`;
- при наличии `reference_image_name` добавляется PuLID-ветка;
- при отсутствии reference ветка PuLID не строится.

### [build_flux_fill_workflow]
Назначение: Flux Fill / inpaint workflow с mask и PuLID.
Триггер: face/body correction, inpaint-и в разных фазах.
Вход → выход: `base_image_name`, `mask_image_name`, `ref_image_name`, prompt/negative/seed/steps/guidance/denoise/output_prefix`, optional face LoRA, `pulid_weight` → workflow dict.
Побочные эффекты: нет сам по себе.
Магические числа/константы:
- использует `InpaintModelConditioning`;
- `CLIPTextEncodeFlux` negative `guidance=1.0`;
- default sampler/scheduler для PhaseB берутся из `phaseB.generation` иначе Stage0.
Особые случаи / edge cases, которые код явно обрабатывает:
- если `face_lora_name` задан, node `11` переиспользуется под `LoraLoaderModelOnly`, а `ApplyPulidFlux` переезжает на node `15`.

### [build_body_union_workflow]
Назначение: PhaseB body-generation workflow с ControlNet Union (depth + optional pose + optional json skeleton).
Триггер: `phaseB_body_lora.main()`.
Вход → выход: cfg + positive/negative + размеры + seed/steps/guidance + output + depth_image + face/detail LoRA + control strengths + optional pose/json inputs → workflow dict.
Побочные эффекты: нет сам по себе.
Магические числа/константы:
- базовый ControlNet узел `controlnet_union`;
- sampler/scheduler берутся из `phaseB.generation` иначе из Stage0;
- `cfg` в KSampler = `1.0`.
Особые случаи / edge cases, которые код явно обрабатывает:
- `pose_image_name` и `json_image_name` добавляются только если соответствующие strength > 0;
- positive/negative conditioning цепочкой переподключаются через `ControlNetApplyAdvanced`.

---

# stage0_references.py

### [_build_stage0_lora_stacks]
Назначение: собирает face/body LoRA stack для Stage0 из конфига.
Триггер: вызывается из `generate_candidates`.
Вход → выход: `cfg: Dict` → `(face_stack, body_sfw_stack, body_nsfw_stack)`.
Побочные эффекты: нет.
Магические числа/константы:
- `detail_lora_strength_face` cap `0.18`;
- `detail_lora_strength_body` cap `0.15`;
- NSFW bust LoRA cap `0.60`;
- комментарий: суммарный стек `<= 1.0` для face, `<= 0.90` для body.
Особые случаи / edge cases, которые код явно обрабатывает:
- при отсутствии значений читает fallback из `models.*`.

### [build_face_negative/build_face_prompt/build_hand_prompt/build_hand_negative]
Назначение: собирают stage0 prompts для face/hands.
Триггер: вызываются из `main()` при генерации соответствующих reference blocks.
Вход → выход: `cfg -> str`.
Побочные эффекты: нет.
Магические числа/константы:
- `build_face_negative` явно добавляет блок против `dark skin`, `small eyes`, `thin lips`, `multiple faces`, `open mouth`, `sunglasses/hat/hood`.
Особые случаи / edge cases, которые код явно обрабатывает:
- body/anatomy-токены намеренно не добавляются в face negative.

### [build_body_prompt]
Назначение: собирает SFW/NSFW body-reference prompt для Stage0.
Триггер: вызывается при body_sfw/body_nsfw блоках.
Вход → выход: `cfg`, `nsfw: bool` → `str`.
Побочные эффекты: нет.
Магические числа/константы:
- если YAML не даёт `body_reference_sfw/nsfw`, используются встроенные `_BODY_SFW_POSITIVE` / `_BODY_NSFW_POSITIVE`.
Особые случаи / edge cases, которые код явно обрабатывает:
- `character.skin` и `flux_identity_priority` подмешиваются отдельно;
- `character.lips` сознательно не дублируется.

### [build_body_negative]
Назначение: сливает YAML negative и встроенный hard negative для body.
Триггер: Stage0 body generation.
Вход → выход: `cfg`, `nsfw: bool` → `str`.
Побочные эффекты: нет.
Магические числа/константы:
- merge порядок: `negative_base + yaml_split_neg + builtin`.
Особые случаи / edge cases, которые код явно обрабатывает:
- исправляет старое поведение, где builtin negative мог полностью теряться.

### [generate_candidates]
Назначение: генерирует кандидатов face/hands/body для Stage0 с GPU-safe retry.
Триггер: вызывается из `main()` для face/hands/body блоков.
Вход → выход: `comfy`, `cfg`, `out_dir`, `prompt`, `negative`, `count`, `width`, `height`, `tag`, `reference_image_name=""`, `is_body=False`, `is_nsfw=False`, `force=False` → `List[Path]`.
Побочные эффекты:
- создаёт output-каталог;
- строит workflow;
- отправляет в ComfyUI;
- перезаписывает/создаёт PNG;
- делает `/queue clear` и `/free`.
Магические числа/константы:
- body+ref → `pulid_weight` из `cfg.stage0.body_pulid_weight`, defaults `0.52`, `start_at=0.0`, `end_at=0.85`;
- без reference PuLID полностью выключается (`0.0/0.0/1.0`);
- steps/guidance floors: NSFW body `>=38 / >=3.75`, SFW body `>=36 / >=3.65`;
- файл считается валидным при `>1024` байт;
- retry до `4` попыток.
Особые случаи / edge cases, которые код явно обрабатывает:
- если `dst` уже существует и `not force`, файл просто переиспользуется;
- retry меняет seed только у sampler-узлов workflow;
- PuLID намеренно отключается для face/hands без ref image.

### [_hard_flush / _run_with_cuda_retry]
Назначение: локальные helpers Stage0 для очистки VRAM и повторного запуска генерации.
Триггер: внутри `generate_candidates`.
Вход → выход:
- `_hard_flush(wait_s=8.0) -> None`
- `_run_with_cuda_retry(wf, dst, max_attempts=4) -> None`
Побочные эффекты: POST `/queue`/`/free`, CUDA cache clear, reseed sampler node.
Магические числа/константы:
- `_hard_flush` делает двойной `/free`;
- retry wait `min(8.0 + attempt*4.0, 20.0)`.
Особые случаи / edge cases, которые код явно обрабатывает:
- flush вызывается перед каждым shot.

### [_build_anatomy_lora_stack]
Назначение: собирает anatomy-specific LoRA stack из `cfg.anatomy.lora_stack`.
Триггер: вызывается `generate_anatomy_candidates`.
Вход → выход: `cfg -> Dict[block -> tuple[(name, weight), ...]]`.
Побочные эффекты: нет.
Магические числа/константы:
- fallback на `models.detail_lora` / `detail_lora_strength`.
Особые случаи / edge cases, которые код явно обрабатывает:
- отдельно хранит stacks для `areola`, `ass`, `spread`.

### [generate_anatomy_candidates]
Назначение: генерирует anatomy reference candidates для `areola`, `ass`, `spread`.
Триггер: вызывается из `run_anatomy_blocks`.
Вход → выход: `comfy`, `cfg`, `out_dir`, `prompts`, `block_tag`, `ref_face_name`, `count=10`, `force=False` → `List[Path]`.
Побочные эффекты:
- запись PNG;
- ComfyUI generation;
- flush/retry.
Магические числа/константы:
- PuLID всегда отключён (`0.0/0.0/1.0`), т.к. лица нет в кадре;
- размеры fallback: `areola 1024x1024`, `ass 832x1216`, `spread 1216x832`;
- retry до `3` попыток.
Особые случаи / edge cases, которые код явно обрабатывает:
- для `areola` обнуляет `vagina_detail_lora`;
- второй элемент стека роутится по-разному: `areola -> bust_breast_lora`, `ass/spread -> extra_lora`;
- `extras_str` для `areola` ставится ПЕРЕД camera prompt, чтобы T5 дал максимальный вес триггерам соска/ареолы.

### [run_anatomy_blocks]
Назначение: роутит запуск anatomy блоков и пишет отдельный `anatomy_manifest.json`.
Триггер: `main()`, если в `--block` есть `areola|ass|spread|anatomy_all`.
Вход → выход: `args`, `comfy`, `cfg`, `runtime`, `logger`, `ref_face_final` → `Dict` manifest.
Побочные эффекты:
- upload `ref_face`;
- создание каталогов `05_areola_candidates`, `06_ass_candidates`, `07_spread_candidates`;
- запись `stage0/anatomy_manifest.json`.
Магические числа/константы:
- `areola` count = `9`, остальные `10`.
Особые случаи / edge cases, которые код явно обрабатывает:
- если `ref_face.png` отсутствует, бросает `PipelineError` с требованием сначала запустить face block.

### [main]
Назначение: верхний Stage0 runner для face/hands/body/anatomy reference generation и отбора.
Триггер: точка входа файла.
Вход → выход: CLI/config → exit code.
Побочные эффекты:
- автоподмена `--config` по `--char`;
- инициализация `ComfyUIClient`, `VramGovernor`, `InsightFaceEngine`;
- генерация кандидатов;
- manual/auto selection;
- копирование в `stage0/selected`;
- запись manifest.
Магические числа/константы:
- `auto_select = args.auto_select or cfg.stage0.auto_select`.
Особые случаи / edge cases, которые код явно обрабатывает:
- если `--char` задан и `config/unified_config_{char}.yaml` нет, кидает `FileNotFoundError` без fallback на чужой конфиг;
- body блоки требуют уже существующий `selected/ref_face.png`.

Связи / вызовы:
- `main` → `generate_candidates` → `godtier_v7_core.build_flux_workflow`.
- auto-select → `best_candidate`; manual → `choose_interactively`.
- anatomy → `generate_anatomy_candidates` → тот же builder `build_flux_workflow`.

<!-- APPEND HERE -->