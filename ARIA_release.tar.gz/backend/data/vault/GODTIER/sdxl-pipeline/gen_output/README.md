---
status: placeholder
tags: [artifact, generated-output, placeholder]
---
# gen_output

Папка для итоговых генераций пайплайна brunette. В архиве примеры не приложены.
