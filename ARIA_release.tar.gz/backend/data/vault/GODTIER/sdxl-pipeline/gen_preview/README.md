---
status: placeholder
tags: [artifact, preview, placeholder]
---
# gen_preview

Папка для превью/контрольных рендеров пайплайна brunette. В архиве примеры не приложены.
