#!/usr/bin/env python3
"""
gen_phaseA_sdxl.py — SDXL Phase A: Face LoRA Dataset
v2.0 — Prompts from prompts_brunette.yaml

Генерирует полный датасет:
  1. Emotions — 17 эмоций × 3 seeds
  2. Bust — 6 вариантов × 2 seeds
  3. Orbitals — 12 углов × 2 seeds  
  4. Hairstyles — 10 вариантов × 2 seeds
  5. Styles — 5 outfits × 2 seeds

Usage:
  python gen_phaseA_sdxl.py
  python gen_phaseA_sdxl.py --checkpoint bigLust_v16
  python gen_phaseA_sdxl.py --bigLust           # bigLust_v16
  python gen_phaseA_sdxl.py --emotions-only
  python gen_phaseA_sdxl.py --orbitals-only
  python gen_phaseA_sdxl.py --base-seed 424242
"""
import os, sys, json, yaml, time, argparse, re, urllib.request, copy
from datetime import datetime
from pathlib import Path

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG = os.path.join(SCRIPT_DIR, "unified_config_brunette.yaml")
PROMPTS = os.path.join(SCRIPT_DIR, "prompts_brunette.yaml")


def load_cfg(path):
    with open(path) as f:
        return yaml.safe_load(f)


def build_workflow(cfg, pos_text, neg_text, base_pos, ip_weight, seed, tag,
                   ip_scaling="linear", ip_embeds="K+V", ip_start=0.0, ip_end=0.8,
                   use_hands=False, use_controlnet=False):
    """Build ComfyUI API workflow for one gen.
    
    use_hands: per-prompt hands flag (from prompts YAML)
    use_controlnet: enable weak OpenPose ControlNet for body shots
    """
    ckpt = cfg["checkpoint"]["name"]
    ref = os.path.basename(cfg["checkpoint"]["reference"])
    vae = cfg["checkpoint"]["vae"]
    res = cfg["generation"]["resolution"]
    hires = cfg["generation"]["hires"]
    w, h = res
    hw, hh = hires["target"]
    
    pos = pos_text + ", " + base_pos
    # Smart trim: обрезать по последней запятой, не резать посреди слова
    max_chars = 512
    if len(pos) > max_chars:
        truncated = pos[:max_chars]
        last_comma = truncated.rfind(",")
        if last_comma > max_chars * 0.7:  # если запятая в последних 30%
            pos = truncated[:last_comma]
        else:
            # ищем предпоследнюю запятую
            second_last = truncated[:last_comma].rfind(",") if last_comma > 0 else -1
            if second_last > 0:
                pos = truncated[:second_last]
            else:
                pos = truncated
    
    lora_stack = cfg.get("lora_stack", [])
    hands_cfg = cfg.get("hands", {})
    controlnet_cfg = cfg.get("controlnet", {}).get("pose", {})
    
    # Build nodes
    nodes = {
        "1": {"class_type": "CheckpointLoaderSimple", "inputs": {"ckpt_name": ckpt}},
        "2": {"class_type": "CLIPSetLastLayer", "inputs": {"clip": ["1", 1], "stop_at_clip_layer": -2}},
        "3": {"class_type": "IPAdapterUnifiedLoader", "inputs": {"model": ["1", 0], "preset": "PLUS FACE"}},
        "4": {"class_type": "LoadImage", "inputs": {"image": ref}},
        "5": {"class_type": "IPAdapterAdvanced",
              "inputs": {"model": ["3", 0], "ipadapter": ["3", 1], "image": ["4", 0],
                         "weight": ip_weight, "weight_type": ip_scaling,
                         "combine_embeds": "concat", "start_at": ip_start, "end_at": ip_end,
                         "embeds_scaling": ip_embeds}},
        "6": {"class_type": "CLIPTextEncode", "inputs": {"clip": ["2", 0], "text": pos}},
        "7": {"class_type": "CLIPTextEncode", "inputs": {"clip": ["2", 0], "text": neg_text}},
        "8": {"class_type": "VAELoader", "inputs": {"vae_name": vae}},
        "9": {"class_type": "EmptyLatentImage", "inputs": {"width": w, "height": h, "batch_size": 1}},
        "10": {"class_type": "KSampler",
               "inputs": {"model": ["5", 0], "positive": ["6", 0], "negative": ["7", 0],
                          "latent_image": ["9", 0], "seed": seed,
                          "steps": cfg["generation"]["steps"],
                          "cfg": cfg["generation"]["cfg"],
                          "sampler_name": cfg["generation"]["sampler"],
                          "scheduler": cfg["generation"]["scheduler"],
                          "denoise": 1.0}},
        "11": {"class_type": "LatentUpscale",
               "inputs": {"samples": ["10", 0], "upscale_method": hires["method"],
                          "width": hw, "height": hh, "crop": "disabled"}},
        "12": {"class_type": "KSampler",
               "inputs": {"model": ["5", 0], "positive": ["6", 0], "negative": ["7", 0],
                          "latent_image": ["11", 0], "seed": seed,
                          "steps": hires["steps"], "cfg": cfg["generation"]["cfg"],
                          "sampler_name": cfg["generation"]["sampler"],
                          "scheduler": cfg["generation"]["scheduler"],
                          "denoise": hires["denoise"]}},
        "13": {"class_type": "VAEDecode", "inputs": {"samples": ["12", 0], "vae": ["8", 0]}},
        "14": {"class_type": "SaveImage", "inputs": {"filename_prefix": tag, "images": ["13", 0]}},
    }
    
    # Add face LoRA chain after checkpoint (node 1 → LoRA1 → LoRA2 → ...)
    model_in = ["1", 0]
    clip_in = ["1", 1]
    for idx, lora in enumerate(lora_stack):
        nid = str(50 + idx)
        nodes[nid] = {"class_type": "LoraLoader",
                      "inputs": {"model": model_in, "clip": clip_in,
                                 "lora_name": lora["name"], "strength_model": lora["weight"],
                                 "strength_clip": lora.get("weight_clip", lora["weight"])}}
        model_in = [nid, 0]
        clip_in = [nid, 1]
    
    # ── Hands LoRA (per-prompt, based on hands flag from YAML) ──
    if use_hands and hands_cfg.get("enabled", True):
        hlora = hands_cfg.get("lora", {})
        if hlora.get("enabled", True) and hlora.get("name"):
            h_nid = str(80)  # dedicated hands LoRA slot
            nodes[h_nid] = {"class_type": "LoraLoader",
                           "inputs": {"model": model_in, "clip": clip_in,
                                      "lora_name": hlora["name"],
                                      "strength_model": hlora.get("weight", 0.6),
                                      "strength_clip": hlora.get("weight_clip", hlora.get("weight", 0.6))}}
            model_in = [h_nid, 0]
            clip_in = [h_nid, 1]
    
    # Rewire: model → last LoRA (face LoRA or hands LoRA if present), clip → last LoRA
    nodes["5"]["inputs"]["model"] = model_in
    nodes["2"]["inputs"]["clip"] = clip_in
    nodes["3"]["inputs"]["model"] = model_in
    
    # ══════════════════════════════════════════════════════════════
    # DETAILER CHAIN — Face (base) → Hands (optional)
    # ══════════════════════════════════════════════════════════════
    # FaceDetailer — всегда, для общего рефайнмента лица
    # HandsDetailer — доп проход, только когда hands=true в YAML
    # SaveImage всегда берёт output последнего детейлера в цепочке
    
    det_cfg = cfg.get("detailer", {})
    last_img_out = ["13", 0]  # старт: VAE Decode output
    
    # ── 1. Face Detailer (base, always) ──
    face_det = det_cfg.get("face", {})
    if face_det.get("enabled", True) and face_det.get("model"):
        nodes["70"] = {"class_type": "UltralyticsDetectorProvider",
                      "inputs": {"model_name": face_det["model"]}}
        nodes["71"] = {"class_type": "FaceDetailer",
                      "inputs": {
                          "image": last_img_out,
                          "model": model_in,
                          "clip": clip_in,
                          "vae": ["8", 0],
                          "positive": ["6", 0],
                          "negative": ["7", 0],
                          "detailer_hook": None,
                          "guide_size": face_det.get("guide_size", 384),
                          "max_size": face_det.get("max_size", 768),
                          "feather": face_det.get("feather", 20),
                          "noise_mask": face_det.get("noise_mask", "enabled"),
                          "denoise": face_det.get("denoise", 0.30),
                          "feather_mask": "disabled",
                          "inpaint_model": face_det.get("inpaint_model", True),
                          "noise_mask_feather": face_det.get("noise_mask_feather", 10),
                          "force_inpaint": True,
                          "cycle": face_det.get("cycle", 1),
                          "bbox_detector": ["70", 0],
                          "sam_model_opt": None,
                          "segm_detector_opt": None,
                          "wildcard": "",
                          "dilate": face_det.get("dilate", 10),
                          "inpaint_mask": True,
                      }}
        last_img_out = ["71", 0]  # chain to next detailer
    
    # ── 2. Hands Detailer (additional pass, only when hands=true) ──
    if use_hands:
        hands_det = det_cfg.get("hands", {})
        if hands_det.get("enabled", True) and hands_det.get("model"):
            nd = 72  # starts after face detailer nodes (70,71)
            nodes[str(nd)] = {"class_type": "UltralyticsDetectorProvider",
                             "inputs": {"model_name": hands_det["model"]}}
            nd += 1
            nodes[str(nd)] = {"class_type": "FaceDetailer",
                             "inputs": {
                                 "image": last_img_out,
                                 "model": model_in,
                                 "clip": clip_in,
                                 "vae": ["8", 0],
                                 "positive": ["6", 0],
                                 "negative": ["7", 0],
                                 "detailer_hook": None,
                                 "guide_size": hands_det.get("guide_size", 256),
                                 "max_size": hands_det.get("max_size", 512),
                                 "feather": hands_det.get("feather", 20),
                                 "noise_mask": hands_det.get("noise_mask", "enabled"),
                                 "denoise": hands_det.get("denoise", 0.35),
                                 "feather_mask": "disabled",
                                 "inpaint_model": hands_det.get("inpaint_model", True),
                                 "noise_mask_feather": hands_det.get("noise_mask_feather", 10),
                                 "force_inpaint": True,
                                 "cycle": hands_det.get("cycle", 1),
                                 "bbox_detector": [str(nd - 1), 0],
                                 "sam_model_opt": None,
                                 "segm_detector_opt": None,
                                 "wildcard": "",
                                 "dilate": hands_det.get("dilate", 10),
                                 "inpaint_mask": True,
                             }}
            last_img_out = [str(nd), 0]  # chain: face → hands → save
    
    # Rewire SaveImage to take last detailer output
    nodes["14"]["inputs"]["images"] = last_img_out
    
    # ── Weak OpenPose ControlNet for body shots ──
    # Только для bust и styles (где тело видно)
    if use_controlnet and controlnet_cfg.get("enabled", True):
        cn_model = controlnet_cfg["model"]
        cn_strength = controlnet_cfg.get("strength", 0.25)
        cn_start = controlnet_cfg.get("start_at", 0.0)
        cn_end = controlnet_cfg.get("end_at", 0.6)
        
        # Load ControlNet + pose estimation
        nodes["90"] = {"class_type": "ControlNetLoader",
                      "inputs": {"control_net_name": cn_model}}
        nodes["91"] = {"class_type": "DWPreprocessor",
                      "inputs": {"image": ["4", 0], "resolution": 512, "bbox_detector": "yolox_l.torchscript.pt"}}
        nodes["92"] = {"class_type": "ControlNetApplyAdvanced",
                      "inputs": {
                          "positive": ["6", 0],
                          "negative": ["7", 0],
                          "control_net": ["90", 0],
                          "image": ["91", 0],
                          "strength": cn_strength,
                          "start_percent": cn_start,
                          "end_percent": cn_end,
                      }}
        
        # Rewire KSampler to use ControlNet-adjusted model
        # model comes from IPAdapter (node 5), positive/negative from ControlNet (node 92)
        nodes["10"]["inputs"]["model"] = ["5", 0]
        nodes["12"]["inputs"]["model"] = ["5", 0]
        nodes["10"]["inputs"]["positive"] = ["92", 0]
        nodes["10"]["inputs"]["negative"] = ["92", 1]
        nodes["12"]["inputs"]["positive"] = ["92", 0]
        nodes["12"]["inputs"]["negative"] = ["92", 1]
    
    return nodes


def submit_job(api_url, workflow, tag, seed, ip_w, timeout=15):
    """Submit one job to ComfyUI API."""
    payload = json.dumps({"prompt": workflow}).encode()
    req = urllib.request.Request(f"{api_url}/prompt", data=payload,
                                  headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            resp_data = json.loads(resp.read())
        pid = resp_data.get("prompt_id", "?")
        if resp_data.get("node_errors", {}):
            errs = list(resp_data["node_errors"].keys())
            print(f"  ❌ SKIP {tag}: node errors {errs}")
            return None
        return pid
    except Exception as e:
        print(f"  ❌ FAIL {tag}: {e}")
        return None


def wait_queue(api_url, check_interval=3, max_cycles=600):
    """Wait for ComfyUI queue to drain."""
    import urllib.request
    for cycle in range(max_cycles):
        time.sleep(check_interval)
        try:
            with urllib.request.urlopen(f"{api_url}/queue", timeout=5) as resp:
                q = json.loads(resp.read())
            running = len(q.get("queue_running", []))
            pending = len(q.get("queue_pending", []))
            if running == 0 and pending == 0:
                print(f"  ✅ Queue empty after ~{cycle*check_interval}s")
                return True
            if cycle % 30 == 0:
                print(f"  ⏳ waiting... (running={running}, pending={pending}, {cycle*check_interval}s)")
        except Exception as e:
            print(f"  ⏳ Queue check error (cycle {cycle}): {e} — retrying...")
            pass
    print("  ⚠️ Queue wait timeout")
    return False


def gen_batch(cfg, prompts_data, api_url, seeds, modes, ip_override=None,
              no_hands=False, max_difficulty=99, skip_existing=False,
              output_dir=None):
    """Main batch generator.
    
    no_hands: global override to disable hands LoRA/detailer
    max_difficulty: max difficulty level (1=easy, 3=hard, 99=all)
    skip_existing: skip prompts already present in output_dir
    output_dir: directory to check for existing images (for skip_existing)
    """
    neg = prompts_data["negative"]
    base_pos = prompts_data["base_positive"]
    ip_cfg = prompts_data.get("ip_adapter", {})
    ip_scaling = ip_cfg.get("scaling", "linear")
    ip_embeds = ip_cfg.get("embeds_scaling", "K+V")
    ip_start = ip_cfg.get("start_at", 0.0)
    ip_end = ip_cfg.get("end_at", 0.8)
    
    # Build existing filename set for skip_existing
    existing = set()
    if skip_existing and output_dir and os.path.isdir(output_dir):
        for fname in os.listdir(output_dir):
            if fname.endswith(".png"):
                existing.add(Path(fname).stem)
    
    def should_skip(item, si):
        """Check if item should be skipped (difficulty or existing)."""
        diff = item.get("difficulty", 1)
        if diff > max_difficulty:
            return True
        if skip_existing:
            tag = f"{item['key']}_s{si}"
            if tag in existing or any(ex.startswith(tag) for ex in existing):
                return True
        return False
    
    total_submitted = 0
    jobs = []  # [(tag, pid, seed, ip_w)]
    skipped_difficulty = 0
    skipped_existing = 0
    
    # ── Block 1: Emotions (17 × seeds) ──
    if "emotions" in modes:
        emotions = prompts_data.get("emotions", [])
        # Filter by difficulty
        filtered_em = [e for e in emotions if e.get("difficulty", 1) <= max_difficulty]
        skipped_d = len(emotions) - len(filtered_em)
        skipped_difficulty += skipped_d
        
        print(f"\n{'='*60}")
        print(f"📸 Emotions: {len(filtered_em)}/{len(emotions)} x {len(seeds)} seeds = {len(filtered_em)*len(seeds)}")
        if skipped_d: print(f"   (skipped {skipped_d} by difficulty > {max_difficulty})")
        print(f"{'='*60}")
        for em in filtered_em:
            key = em["key"]
            prompt = em["prompt"]
            ip_w = ip_override if ip_override is not None else em.get("ip_weight",
                     prompts_data["ip_adapter"]["weight_base"])
            show_hands = em.get("hands", False) and not no_hands
            
            for si, seed in enumerate(seeds):
                if skip_existing and should_skip(em, si):
                    skipped_existing += 1
                    continue
                tag = f"{key}_s{si}"
                wf = build_workflow(cfg, prompt, neg, base_pos, ip_w, seed, tag,
                                    ip_scaling, ip_embeds, ip_start, ip_end,
                                    use_hands=show_hands, use_controlnet=False)
                pid = submit_job(api_url, wf, tag, seed, ip_w)
                if pid:
                    jobs.append((tag, pid, seed, ip_w))
                    total_submitted += 1
    
    # ── Block 2: Bust (14 × seeds) ──
    if "bust" in modes:
        bust = prompts_data.get("bust", {})
        bust_all = bust.get("sfw", []) + bust.get("nsfw", [])
        filtered_bust = [b for b in bust_all if b.get("difficulty", 1) <= max_difficulty]
        skipped_d = len(bust_all) - len(filtered_bust)
        skipped_difficulty += skipped_d
        
        print(f"\n{'='*60}")
        print(f"👗 Bust: {len(filtered_bust)}/{len(bust_all)} x {len(seeds)} seeds = {len(filtered_bust)*len(seeds)}")
        if skipped_d: print(f"   (skipped {skipped_d} by difficulty > {max_difficulty})")
        print(f"{'='*60}")
        for b in filtered_bust:
            prompt = b["prompt"]
            show_hands = b.get("hands", False) and not no_hands
            ip_w = ip_override if ip_override is not None else b.get("ip_weight", prompts_data["ip_adapter"]["weight_base"])
            for si, seed in enumerate(seeds):
                if skip_existing and should_skip(b, si):
                    skipped_existing += 1
                    continue
                tag = f"{b['key']}_s{si}"
                wf = build_workflow(cfg, prompt, neg, base_pos, ip_w, seed, tag,
                                    ip_scaling, ip_embeds, ip_start, ip_end,
                                    use_hands=show_hands, use_controlnet=True)
                pid = submit_job(api_url, wf, tag, seed, ip_w)
                if pid:
                    jobs.append((tag, pid, seed, ip_w))
                    total_submitted += 1
    
    # ── Block 3: Orbitals (15 × seeds) ──
    if "orbitals" in modes:
        orbitals = prompts_data.get("orbitals", [])
        filtered_orb = [o for o in orbitals if o.get("difficulty", 1) <= max_difficulty]
        skipped_d = len(orbitals) - len(filtered_orb)
        skipped_difficulty += skipped_d
        
        print(f"\n{'='*60}")
        print(f"🔄 Orbitals: {len(filtered_orb)}/{len(orbitals)} x {len(seeds)} seeds = {len(filtered_orb)*len(seeds)}")
        if skipped_d: print(f"   (skipped {skipped_d} by difficulty > {max_difficulty})")
        print(f"{'='*60}")
        for orb in filtered_orb:
            prompt = orb["prompt"]
            show_hands = orb.get("hands", False) and not no_hands
            ip_w = ip_override if ip_override is not None else orb.get("ip_weight", prompts_data["ip_adapter"]["weight_base"])
            for si, seed in enumerate(seeds):
                if skip_existing and should_skip(orb, si):
                    skipped_existing += 1
                    continue
                tag = f"{orb['key']}_s{si}"
                wf = build_workflow(cfg, prompt, neg, base_pos, ip_w, seed, tag,
                                    ip_scaling, ip_embeds, ip_start, ip_end,
                                    use_hands=show_hands, use_controlnet=False)
                pid = submit_job(api_url, wf, tag, seed, ip_w)
                if pid:
                    jobs.append((tag, pid, seed, ip_w))
                    total_submitted += 1
    
    # ── Block 4: Hairstyles (10 × seeds) ──
    if "hairstyles" in modes:
        hairstyles = prompts_data.get("hairstyles", [])
        filtered_hs = [h for h in hairstyles if h.get("difficulty", 1) <= max_difficulty]
        skipped_d = len(hairstyles) - len(filtered_hs)
        skipped_difficulty += skipped_d
        
        print(f"\n{'='*60}")
        print(f"💇 Hairstyles: {len(filtered_hs)}/{len(hairstyles)} x {len(seeds)} seeds = {len(filtered_hs)*len(seeds)}")
        if skipped_d: print(f"   (skipped {skipped_d} by difficulty > {max_difficulty})")
        print(f"{'='*60}")
        for hs in filtered_hs:
            prompt = hs["prompt"]
            show_hands = hs.get("hands", False) and not no_hands
            ip_w = ip_override if ip_override is not None else hs.get("ip_weight", prompts_data["ip_adapter"]["weight_base"])
            full_prompt = f"Young woman, {prompt}, front view, neutral expression, looking at camera, portrait"
            for si, seed in enumerate(seeds):
                if skip_existing and should_skip(hs, si):
                    skipped_existing += 1
                    continue
                tag = f"{hs['key']}_s{si}"
                wf = build_workflow(cfg, full_prompt, neg, base_pos, ip_w, seed, tag,
                                    ip_scaling, ip_embeds, ip_start, ip_end,
                                    use_hands=show_hands, use_controlnet=False)
                pid = submit_job(api_url, wf, tag, seed, ip_w)
                if pid:
                    jobs.append((tag, pid, seed, ip_w))
                    total_submitted += 1
    
    # ── Block 5: Styles (14 × seeds) ──
    if "styles" in modes:
        styles = prompts_data.get("styles", [])
        filtered_st = [s for s in styles if s.get("difficulty", 1) <= max_difficulty]
        skipped_d = len(styles) - len(filtered_st)
        skipped_difficulty += skipped_d
        
        print(f"\n{'='*60}")
        print(f"👔 Styles: {len(filtered_st)}/{len(styles)} x {len(seeds)} seeds = {len(filtered_st)*len(seeds)}")
        if skipped_d: print(f"   (skipped {skipped_d} by difficulty > {max_difficulty})")
        print(f"{'='*60}")
        for st in filtered_st:
            prompt = st["prompt"]
            show_hands = st.get("hands", False) and not no_hands
            ip_w = ip_override if ip_override is not None else st.get("ip_weight", prompts_data["ip_adapter"]["weight_base"])
            for si, seed in enumerate(seeds):
                if skip_existing and should_skip(st, si):
                    skipped_existing += 1
                    continue
                tag = f"{st['key']}_s{si}"
                wf = build_workflow(cfg, prompt, neg, base_pos, ip_w, seed, tag,
                                    ip_scaling, ip_embeds, ip_start, ip_end,
                                    use_hands=show_hands, use_controlnet=True)
                pid = submit_job(api_url, wf, tag, seed, ip_w)
                if pid:
                    jobs.append((tag, pid, seed, ip_w))
                    total_submitted += 1
    
    if skipped_existing:
        print(f"\n⏭️ Skipped {skipped_existing} existing images")
    if skipped_difficulty:
        print(f"🎯 Skipped {skipped_difficulty} prompts by difficulty > {max_difficulty}")
    
    return jobs, total_submitted


def main():
    parser = argparse.ArgumentParser(description="SDXL Phase A Dataset Generator v3.1 PRO")
    parser.add_argument("--api", default="http://127.0.0.1:8188", help="ComfyUI API URL")
    parser.add_argument("--checkpoint", default=None, help="Override checkpoint name")
    parser.add_argument("--bigLust", action="store_true", help="Use bigLust_v16")
    parser.add_argument("--phase", type=int, choices=[1,2,3], default=1,
                        help="Phase 1=Face only (emotions+orbitals+hairstyles), 2=Bust only, 3=Full Body")
    parser.add_argument("--base-seed", type=int, default=None, help="Base seed for reproducible runs. Omit for fully random seeds")
    parser.add_argument("--seeds", type=int, default=3, help="Seeds per prompt")
    parser.add_argument("--ip-weight", type=float, default=None, help="Override IP-Adapter weight")
    parser.add_argument("--emotions-only", action="store_true", help="Only emotions (overrides --phase)")
    parser.add_argument("--orbitals-only", action="store_true", help="Only orbitals (overrides --phase)")
    parser.add_argument("--bust-only", action="store_true", help="Only bust (overrides --phase)")
    parser.add_argument("--hairstyles-only", action="store_true", help="Only hairstyles (overrides --phase)")
    parser.add_argument("--styles-only", action="store_true", help="Only styles (overrides --phase)")
    parser.add_argument("--skip-emotions", action="store_true", help="Skip emotions")
    parser.add_argument("--skip-bust", action="store_true", help="Skip bust")
    parser.add_argument("--skip-orbitals", action="store_true", help="Skip orbitals")
    parser.add_argument("--skip-hairstyles", action="store_true", help="Skip hairstyles")
    parser.add_argument("--skip-styles", action="store_true", help="Skip styles")
    parser.add_argument("--dry-run", action="store_true", help="Show prompts without sending to API")
    parser.add_argument("--out", default=None, help="Output directory override")
    parser.add_argument("--report", action="store_true", help="Save report .txt")
    parser.add_argument("--validate", action="store_true", help="Run quality validation after generation")
    parser.add_argument("--regenerate", default=None, help="Comma-separated tags to regenerate")
    parser.add_argument("--min-score", type=float, default=0.85, help="Quality threshold (default: 0.85)")
    parser.add_argument("--no-hands", action="store_true", help="Disable hands LoRA + detailer globally")
    parser.add_argument("--max-difficulty", type=int, default=99,
                        help="Max difficulty level (1=easy, 2=medium, 3=hard). default: all")
    parser.add_argument("--skip-existing", action="store_true",
                        help="Skip prompts already present in output dir (avoid duplicates)")
    parser.add_argument("--post-process", action="store_true",
                        help="Run DatasetPostProcessor after generation (crop + verify + bucket)")
    parser.add_argument("--auto-clean", action="store_true",
                        help="Delete failed images after validation / post-process")
    args = parser.parse_args()
    
    # Load configs
    cfg = load_cfg(CONFIG)
    prompts_data = load_cfg(PROMPTS)
    
    # Checkpoint override
    if args.bigLust:
        cfg["checkpoint"]["name"] = "Lustify_apexV8.safetensors"
    elif args.checkpoint:
        cfg["checkpoint"]["name"] = args.checkpoint
    
    # Phase labels for output path
    phase_labels = {1: "phase1_face_1024", 2: "phase2_bust_highres", 3: "phase3_full"}
    # Resolve output dir
    if args.out:
        out = args.out
    else:
        # Phase-based default path
        label = phase_labels.get(args.phase, f"phase{args.phase}")
        ts = datetime.now().strftime('%Y%m%d_%H%M')
        out = os.path.join(SCRIPT_DIR, "..", "gen_output", f"brunette_{label}_{ts}")
    os.makedirs(out, exist_ok=True)
    print(f"\n📁 Output: {out}")
    
    # === PHASE CONTROL ===
    if args.phase == 1 or args.emotions_only or args.orbitals_only or args.hairstyles_only:
        modes = {"emotions", "orbitals", "hairstyles"}
        print("🔵 PHASE 1 — Face focused (1024×1024 tight crop)")
    elif args.phase == 2 or args.bust_only:
        modes = {"bust"}
        print("🟠 PHASE 2 — Bust focused (high res portrait)")
    elif args.phase == 3 or args.styles_only:
        modes = {"styles"}
        print("🟢 PHASE 3 — Full body")
    else:
        modes = {"emotions", "bust", "orbitals", "hairstyles", "styles"}
        print("⚪ ALL MODES — Full dataset")
    
    # Apply skip flags (overrides phase)
    if args.skip_emotions: modes.discard("emotions")
    if args.skip_bust: modes.discard("bust")
    if args.skip_orbitals: modes.discard("orbitals")
    if args.skip_hairstyles: modes.discard("hairstyles")
    if args.skip_styles: modes.discard("styles")
    
    # Dry run — показать что будет сгенерировано
    if args.dry_run:
        print(f"\n{'='*60}")
        print(f"🔍 DRY RUN — {cfg['character']['name']}")
        print(f"{'='*60}")
        print(f"  Checkpoint: {cfg['checkpoint']['name']}")
        if "emotions" in modes:
            e = prompts_data.get("emotions", [])
            print(f"  Emotions:   {len(e)} × {args.seeds} = {len(e)*args.seeds}")
            for em in e:
                diff = em.get("difficulty", "?")
                hands = "🤚" if em.get("hands") else "  "
                print(f"    {hands} [{diff}] {em['key']}: ip={em.get('ip_weight','dflt')} — {em['prompt'][:55]}...")
        if "orbitals" in modes:
            o = prompts_data.get("orbitals", [])
            print(f"  Orbitals:   {len(o)} × {min(args.seeds,2)} = {len(o)*min(args.seeds,2)}")
            for orb in o:
                hands = "🤚" if orb.get("hands") else "  "
                print(f"    {hands} {orb['key']}")
        if "hairstyles" in modes:
            h = prompts_data.get("hairstyles", [])
            print(f"  Hairstyles: {len(h)} × {min(args.seeds,2)} = {len(h)*min(args.seeds,2)}")
        if "bust" in modes:
            b_all = prompts_data.get("bust", {}).get("sfw", []) + prompts_data.get("bust", {}).get("nsfw", [])
            print(f"  Bust:       {len(b_all)} × {min(args.seeds,2)} = {len(b_all)*min(args.seeds,2)}")
            for b in b_all:
                hands = "🤚" if b.get("hands") else "  "
                cn = "+CN" if b.get("hands") else "   "
                print(f"    {hands} {b['key']} {cn}")
        if "styles" in modes:
            s = prompts_data.get("styles", [])
            print(f"  Styles:     {len(s)} × {min(args.seeds,2)} = {len(s)*min(args.seeds,2)}")
            for st in s:
                hands = "🤚" if st.get("hands") else "  "
                cn = "+CN" if st.get("hands") else "   "
                print(f"    {hands} {st['key']} {cn}")
        hands_count = sum(1 for e in prompts_data.get("emotions",[]) if e.get("hands"))
        hands_count += sum(1 for o in prompts_data.get("orbitals",[]) if o.get("hands"))
        hands_count += sum(1 for h in prompts_data.get("hairstyles",[]) if h.get("hands"))
        for s in ['sfw','nsfw']:
            hands_count += sum(1 for b in prompts_data.get("bust",{}).get(s,[]) if b.get("hands"))
        hands_count += sum(1 for s in prompts_data.get("styles",[]) if s.get("hands"))
        print(f"{'='*60}")
        total_prompts = sum(len(prompts_data.get(k,[])) for k in modes if k in ["emotions","orbitals","hairstyles","styles"])
        if "bust" in modes:
            total_prompts += len(prompts_data.get("bust",{}).get("sfw",[])) + len(prompts_data.get("bust",{}).get("nsfw",[]))
        print(f"  Unique prompts: {total_prompts} (mode: {modes})")
        print(f"  Hands LoRA+Detailer: {hands_count} prompts")
        print(f"  Estimated images: ~{total_prompts * min(args.seeds,2)}")
        print(f"  Use --base-seed {args.base_seed} to reproduce")
        
        # VRAM Budget Estimate
        has_cn = any(True for b in prompts_data.get("bust",{}).get("sfw",[]) if b.get("hands"))
        has_cn = has_cn or any(True for b in prompts_data.get("bust",{}).get("nsfw",[]) if b.get("hands"))
        has_cn = has_cn or any(True for s in prompts_data.get("styles",[]) if s.get("hands"))
        has_hands = hands_count > 0
        det = cfg.get("detailer", {})
        budget = det.get("budget", {}).get("total_vram_gb", 24)
        warn_pct = det.get("budget", {}).get("warn_at", 0.85)
        vram_base = 6.9
        vram_ip = 0.5
        vram_cn = 0.6 if has_cn else 0.0
        vram_ksampler = 3.0
        vram_vae = 1.0
        vram_face_det = 1.5
        vram_hands_det = 1.0 if has_hands else 0.0
        vram_total = vram_base + vram_ip + vram_cn + vram_ksampler + vram_vae + vram_face_det + vram_hands_det
        print()
        print("  💾 VRAM Budget Estimate:")
        print(f"     Base SDXL:      {vram_base:.1f} GB")
        print(f"     IP-Adapter:     +{vram_ip:.1f} GB")
        if has_cn:
            print(f"     ControlNet:     +{vram_cn:.1f} GB")
        print(f"     KSampler:       +{vram_ksampler:.1f} GB")
        print(f"     VAE:            +{vram_vae:.1f} GB")
        print(f"     FaceDetailer:   +{vram_face_det:.1f} GB")
        if has_hands:
            print(f"     HandsDetailer:  +{vram_hands_det:.1f} GB")
        print("     " + "─" * 21)
        pct = vram_total / budget * 100
        warn = "⚠️" if pct > warn_pct * 100 else "✅"
        print(f"     {warn} TOTAL: {vram_total:.1f} / {budget} GB ({pct:.0f}%)")
        if pct > warn_pct * 100:
            print(f"     ⚠️ Above {warn_pct*100:.0f}%! Reduce guide_size or disable detailers")
        print()
        return
    
    # Seeds — рандом по умолчанию
    import random
    if args.base_seed is not None:
        random.seed(args.base_seed)
        seeds = [random.randint(0, 2**32 - 1) for _ in range(args.seeds)]
        print(f"🌱 Reproducible seeds (base={args.base_seed}): {seeds}")
    else:
        seeds = [random.randint(0, 2**32 - 1) for _ in range(args.seeds)]
        print(f"🌱 Random seeds: {seeds}")
    print(f"🎯 Modes: {modes}")
    if args.ip_weight: print(f"⚖️ IP weight: {args.ip_weight}")
    if args.no_hands: print(f"🖐️ Hands LoRA: DISABLED")
    if args.max_difficulty < 99: print(f"🎯 Max difficulty: {args.max_difficulty}")
    if args.min_score != 0.85: print(f"🎯 Min quality score: {args.min_score}")
    if args.skip_existing: print(f"⏭️ Skip-existing: ON")
    if args.post_process: print(f"🔧 Post-process: ON")
    
    # ── Regenerate mode ──
    if args.regenerate:
        tags_to_regenerate = [t.strip() for t in args.regenerate.split(",")]
        print(f"\n🔄 Regenerating {len(tags_to_regenerate)} tags: {tags_to_regenerate}")
        # Reuse output dir with _regenerated suffix
        regen_out = out + "_regen"
        os.makedirs(regen_out, exist_ok=True)
        print(f"📁 Output: {regen_out}")
        
        # Collect all prompts that match the given tags
        all_prompts = []
        for section_key in ["emotions", "orbitals", "hairstyles", "styles"]:
            for item in prompts_data.get(section_key, []):
                all_prompts.append({**item, "_section": section_key})
        for section_name in ["sfw", "nsfw"]:
            for item in prompts_data.get("bust", {}).get(section_name, []):
                all_prompts.append({**item, "_section": "bust"})
        
        regen_jobs = []
        # Seeds for regenerate = same seeds as original gen
        for item in all_prompts:
            key = item["key"]
            if key not in tags_to_regenerate:
                continue
            prompt = item["prompt"]
            ip_w = item.get("ip_weight", 0.50)
            show_hands = item.get("hands", False) and not args.no_hands
            use_cn = item.get("_section") in ("bust", "styles")
            for si, seed in enumerate(seeds):
                tag = f"{key}_s{si}"
                wf = build_workflow(cfg, prompt, prompts_data["negative"],
                                    prompts_data["base_positive"], ip_w, seed, tag,
                                    use_hands=show_hands, use_controlnet=use_cn)
                pid = submit_job(args.api, wf, tag, seed, ip_w)
                if pid:
                    regen_jobs.append((tag, pid, seed, ip_w))
        
        print(f"  Submitted: {len(regen_jobs)} regeneration jobs")
        wait_queue(args.api)
        print(f"  ✅ Regenerated {len(regen_jobs)} images in {regen_out}")
        return
    
    # ── Normal generation ──
    jobs, total = gen_batch(cfg, prompts_data, args.api, seeds, modes,
                           args.ip_weight, no_hands=args.no_hands,
                           max_difficulty=args.max_difficulty,
                           skip_existing=args.skip_existing,
                           output_dir=out)
    
    print(f"\n{'='*60}")
    print(f"📤 Submitted: {total} jobs")
    
    if total == 0:
        print("⚠️ Nothing submitted. Check API URL and workflow.")
        return
    
    # Wait for queue — проверяем что очередь реально опустела
    if not wait_queue(args.api):
        print("⚠️ Queue did not drain in time — images may be incomplete.")
        print("  Continuing anyway (validate/post-process will check).")
    import time
    time.sleep(5)  # fsync buffer: ComfyUI может не дописать файлы на диск
    
    # Save report
    if args.report:
        char_name = cfg["character"]["name"]
        report_path = os.path.join(out, f"_report_{char_name}.txt")
        with open(report_path, "w") as f:
            f.write(f"Phase A Report — {char_name}\n")
            f.write(f"Date: {datetime.now().isoformat()}\n")
            f.write(f"Checkpoint: {cfg['checkpoint']['name']}\n")
            f.write(f"Seeds: {seeds}\n")
            f.write(f"Total submitted: {total}\n\n")
            f.write("Jobs:\n")
            for tag, pid, seed, ip_w in jobs:
                f.write(f"  {tag} | seed={seed} | ip={ip_w:.2f} | pid={pid}\n")
            f.write("\nOutput directory: " + out + "\n")
        print(f"📝 Report saved: {report_path}")
    
    # ── Validate after generation ──
    if args.validate or args.post_process:
        print(f"\n{'='*60}")
        extra = " + post-process" if args.post_process else ""
        print(f"🔍 Running quality validation{extra} (threshold: {args.min_score})...")
        print(f"{'='*60}")
        try:
            from dataset_validator import DatasetValidator
            
            # Fix ref_path: check multiple locations
            ref_candidates = [
                os.path.join(SCRIPT_DIR, "..", "ref_face_1024.png"),
                os.path.join(SCRIPT_DIR, "..", "..", "ref_face_1024.png"),
                os.path.join(os.path.dirname(out), "ref_face_1024.png"),
                os.path.expanduser("~/Desktop/WORK/ref_face_1024.png"),
                "ref_face_1024.png",
            ]
            ref_path = None
            for candidate in ref_candidates:
                if os.path.exists(candidate):
                    ref_path = os.path.abspath(candidate)
                    break
            if ref_path:
                print(f"  📸 Reference: {ref_path}")
            else:
                print(f"  ⚠️ No reference image found — will use QS default (face_sim=0.5)")
            
            validator = DatasetValidator(out, ref_path=ref_path or "",
                                         threshold=args.min_score)
            results = validator.scan()
            report_text = validator.report(results)
            print(report_text)
            
            # Save validation report
            val_report_path = os.path.join(out, "_validation_report.txt")
            with open(val_report_path, "w", encoding="utf-8") as f:
                f.write(report_text)
            print(f"📝 Validation report saved: {val_report_path}")
            
            # Save CSV
            csv_path = os.path.join(out, "_validation_scores.csv")
            validator.save_csv(results, csv_path)
            
            # ── Post-process (crop + bucket + verified/) ──
            if args.post_process:
                print(f"\n{'='*60}")
                print(f"🔧 Running DatasetPostProcessor...")
                print(f"{'='*60}")
                try:
                    from post_process import DatasetPostProcessor
                    pp = DatasetPostProcessor(
                        output_dir=out,
                        ref_path=ref_path or "",
                        threshold=args.min_score,
                        device="cuda",
                        prompts_yaml=PROMPTS,
                        phase=args.phase,
                    )
                    pp_report = pp.process(crop=True)
                    print(pp_report)
                except ImportError as e:
                    print(f"  ⚠️ Post-process import error: {e}")
                except Exception as e:
                    print(f"  ⚠️ Post-process error: {e}")
                    import traceback
                    traceback.print_exc()
            
        except ImportError as e:
            print(f"  ⚠️ Validation import error: {e}")
            print(f"  Install: pip install insightface opencv-python pillow")
        except Exception as e:
            print(f"  ⚠️ Validation error: {e}")
            import traceback
            traceback.print_exc()
    
    # ── Auto-clean failed images ──
    if args.auto_clean and (args.validate or args.post_process):
        failed_dir = os.path.join(out, "failed")
        if os.path.isdir(failed_dir):
            failed_files = [f for f in os.listdir(failed_dir) if f.lower().endswith((".png", ".jpg", ".jpeg"))]
            if failed_files:
                print(f"\n{'='*60}")
                print(f"🧹 Auto-clean: deleting {len(failed_files)} failed images...")
                for fname in failed_files:
                    fpath = os.path.join(failed_dir, fname)
                    try:
                        os.remove(fpath)
                        print(f"  ✗ {fname}")
                    except Exception as e:
                        print(f"  ⚠️ Can't delete {fname}: {e}")
                print(f"✅ Cleaned {len(failed_files)} failed images")
            else:
                print(f"\n🧹 Auto-clean: no failed images found")
        else:
            print(f"\n🧹 Auto-clean: no failed/ directory")
    
    # Summary
    print(f"\n{'='*60}")
    print(f"✅ Done! {total} images expected in {out}")
    print(f"   Single prompt coverage:")
    if "emotions" in modes:
        e = len(prompts_data.get("emotions", []))
        print(f"     Emotions:    {e} x {args.seeds} = {e * args.seeds}")
    if "bust" in modes:
        b = len(prompts_data.get("bust", {}).get("sfw", [])) + len(prompts_data.get("bust", {}).get("nsfw", []))
        print(f"     Bust:        {b} x {args.seeds} = {b * args.seeds}")
    if "orbitals" in modes:
        o = len(prompts_data.get("orbitals", []))
        print(f"     Orbitals:    {o} x {args.seeds} = {o * args.seeds}")
    if "hairstyles" in modes:
        h = len(prompts_data.get("hairstyles", []))
        print(f"     Hairstyles:  {h} x {args.seeds} = {h * args.seeds}")
    if "styles" in modes:
        s = len(prompts_data.get("styles", []))
        print(f"     Styles:      {s} x {args.seeds} = {s * args.seeds}")
    
    total_expected = total
    print(f"     Total:       {total_expected} images")


if __name__ == "__main__":
    main()
