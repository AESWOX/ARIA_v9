"""
post_process.py — Post-processing for Phase A face dataset.

Что делает:
1. Сканирует папку с результатами генерации
2. Оценивает каждое изображение через QualityScorer
3. Копирует passed (score >= threshold) в verified/ с кропом 1024x1024
4. Создаёт .txt капшены
5. Сортирует по группам (emotions/orbitals/hairstyles/bust/styles)
6. Выдаёт отчёт + команду для регенерации failed

Использование:
    python post_process.py /path/to/output --ref ref_face_1024.png
    python post_process.py /path/to/output --threshold 0.85 --no-crop
    python post_process.py /path/to/output --skip-verified  # уже есть verified/
"""

import os
import re
import sys
import csv
import shutil
import yaml
from pathlib import Path
from collections import defaultdict
from quality_scorer import QualityScorer


class DatasetPostProcessor:
    """Production post-processor for Phase A dataset."""

    GROUP_MAP = {
        # Map prompt key patterns to bucketed subdirectories
        "emotions": ["neutral_", "smile_", "kiss_", "mouth_", "soft_",
                     "crying_", "eyes_rolled_", "blush_", "surprised_", "wink_"],
        "orbitals": ["orb_"],
        "hairstyles": ["hair_", "hairstyle_", "braided_", "ponytail_", "bob_",
                       "wavy_", "messy_", "long_"],
        "bust_sfw": ["bust_sfw"],
        "bust_nsfw": ["bust_nsfw"],
        "styles": ["style_"],
    }

    def __init__(self, output_dir, ref_path="ref_face_1024.png",
                 threshold=0.85, weights=None, device="cuda", prompts_yaml=None,
                 phase=1, crop_mode=None):
        self.output_dir = Path(output_dir).resolve()
        self.ref_path = Path(ref_path).resolve() if ref_path else None
        self.threshold = threshold
        self.weights = weights
        self.device = device
        self.phase = phase  # 1=face, 2=bust
        # crop_mode: auto from phase unless overridden
        self.crop_mode = crop_mode or ("face" if phase == 1 else "bust" if phase == 2 else "none")
        self.scorer = None  # lazy init
        
        self.verified_dir = self.output_dir / "verified"
        self.failed_dir = self.output_dir / "failed"
        
        # Load YAML prompts for better captions
        self.prompt_map = {}
        if prompts_yaml:
            self._load_prompts(prompts_yaml)
    
    def _load_prompts(self, yaml_path):
        """Load prompts from YAML and build key→prompt map."""
        try:
            with open(yaml_path, "r", encoding="utf-8") as f:
                data = yaml.safe_load(f)
            sections = ["emotions", "emotions_intense", "orbitals", "hairstyles", "bust", "styles", "lighting", "age"]
            for section in sections:
                items = data.get(section, [])
                if isinstance(items, list):
                    for item in items:
                        if isinstance(item, dict):
                            key = item.get("key", "")
                            prompt = item.get("prompt", "")
                            if key and prompt:
                                self.prompt_map[key] = prompt
            print(f"  📖 Loaded {len(self.prompt_map)} prompts from YAML")
        except Exception as e:
            print(f"  ⚠️ Failed to load prompts YAML: {e}")
    
    def _get_scorer(self):
        if self.scorer is None:
            self.scorer = QualityScorer(
                ref_image_path=str(self.ref_path) if self.ref_path else "",
                device=self.device,
                weights=self.weights,
            )
        return self.scorer
    
    def _parse_tag(self, filename):
        """Extract prompt key and seed from filename.
        
        Format: key_s{seed}_{pid}_.png or key_{seed}_{pid}.png
        """
        stem = Path(filename).stem
        # Try: key_s{seed}_{pid}
        m = re.match(r'(.+?)_s(\d+)(?:_\d+)?$', stem)
        if m:
            return m.group(1), int(m.group(2))
        # Try: key_{seed}_{pid}
        m = re.match(r'(.+?)_(\d+)(?:_\d+)?$', stem)
        if m:
            return m.group(1), int(m.group(2))
        return stem, 0
    
    def _detect_group(self, key):
        """Determine which bucket a prompt key belongs to."""
        for group, patterns in self.GROUP_MAP.items():
            for pat in patterns:
                if key.startswith(pat):
                    return group
        # Fallback: check bust_nsfw separately
        if "nsfw" in key.lower() or "nude" in key.lower():
            return "bust_nsfw"
        if "sfw" in key.lower():
            return "bust_sfw"
        return "other"
    
    def _crop_image(self, img, target_size=1024, margin=0.2):
        """Crop image depending on crop_mode.
        
        crop_mode='face': face-centered 1024x1024 square crop (face LoRA)
        crop_mode='bust': center crop square (keeps body visible)
        crop_mode='none': no crop, just resize if needed
        """
        h, w = img.shape[:2]
        
        if self.crop_mode == "none":
            return img
        
        if self.crop_mode == "bust":
            # Bust — portrait aspect ratio with max resolution
            # Phase 2 trains at 1024x1536 (portrait), preserves upper body area
            target_w, target_h = 1024, 1536  # or 1152x1728 if VRAM allows
            h, w = img.shape[:2]
            
            # Center crop with portrait aspect ratio
            target_ratio = target_w / target_h
            crop_h = int(h * 0.85)  # keep ~85% of height (upper body area)
            crop_w = min(w, int(crop_h * target_ratio))
            
            y = (h - crop_h) // 2
            x = (w - crop_w) // 2
            
            cropped = img[y:y+crop_h, x:x+crop_w]
            cropped = cv2.resize(cropped, (target_w, target_h), interpolation=cv2.INTER_AREA)
            return cropped
        
        # ── Face mode (default) ──
        if self._get_scorer().face_app is None:
            # Fallback: center crop square
            size = min(h, w)
            y = (h - size) // 2
            x = (w - size) // 2
            return img[y:y+size, x:x+size]
        
        faces = self._get_scorer().face_app.get(img)
        if not faces:
            # Fallback: center crop square
            size = min(h, w)
            y = (h - size) // 2
            x = (w - size) // 2
            return img[y:y+size, x:x+size]
        
        face = faces[0]
        bbox = face.bbox  # [x1, y1, x2, y2]
        cx = (bbox[0] + bbox[2]) / 2
        cy = (bbox[1] + bbox[3]) / 2
        face_w = bbox[2] - bbox[0]
        face_h = bbox[3] - bbox[1]
        
        # Square size with margin
        crop_size = max(face_w, face_h) * (1.0 + margin)
        
        x1 = max(0, int(cx - crop_size / 2))
        y1 = max(0, int(cy - crop_size / 2))
        x2 = min(w, int(cx + crop_size / 2))
        y2 = min(h, int(cy + crop_size / 2))
        
        cropped = img[y1:y2, x1:x2]
        
        # Resize to target_size
        ch, cw = cropped.shape[:2]
        if ch != target_size or cw != target_size:
            scale = target_size / max(ch, cw)
            if scale < 1.0:
                new_w = int(cw * scale)
                new_h = int(ch * scale)
                cropped = cv2.resize(cropped, (new_w, new_h), interpolation=cv2.INTER_AREA)
            ch, cw = cropped.shape[:2]
            pad_y = (target_size - ch) // 2
            pad_x = (target_size - cw) // 2
            cropped = cv2.copyMakeBorder(
                cropped,
                max(0, pad_y), max(0, target_size - ch - pad_y),
                max(0, pad_x), max(0, target_size - cw - pad_x),
                cv2.BORDER_REFLECT
            )
            cropped = cv2.resize(cropped, (target_size, target_size))
        
        return cropped
    
    def scan(self, img_dir=None):
        """Scan directory for images and score each one.
        
        Returns:
            results: list of dicts with keys: path, tag, score, details, group, passed
        """
        import cv2
        
        img_dir = Path(img_dir or self.output_dir)
        scorer = self._get_scorer()
        
        # Find all PNGs (exclude subdirectories)
        images = sorted(img_dir.glob("*.png"))
        if not images:
            images = sorted(img_dir.glob("*.jpg"))
        if not images:
            # Try the output dir directly
            images = sorted(img_dir.glob("*.[pP][nN][gG]"))
        
        if not images:
            print(f"  ⚠️ No images found in {img_dir}")
            return []
        
        print(f"  Found {len(images)} images")
        
        results = []
        for i, img_path in enumerate(images):
            tag, seed = self._parse_tag(img_path.name)
            group = self._detect_group(tag)
            
            # Read and score
            img = cv2.imread(str(img_path))
            if img is None:
                continue
            
            total, details = scorer.score_image(img, prompt_key=tag)
            passed = total >= self.threshold
            
            results.append({
                "path": img_path,
                "tag": tag,
                "seed": seed,
                "group": group,
                "score": round(total, 4),
                "details": details,
                "passed": passed,
            })
            
            if (i + 1) % 20 == 0:
                print(f"    ... {i+1}/{len(images)} scored")
        
        return results
    
    def process(self, img_dir=None, crop=True, dry_run=False):
        """Full post-processing pipeline.
        
        1. Score all images
        2. Copy passed to verified/{group}/ with 1024x1024 crop (unless dry-run)
        3. Create .txt captions from actual YAML prompts
        4. Generate summary report
        
        Returns:
            report_text: str
        """
        import cv2
        
        results = self.scan(img_dir)
        if not results:
            return "No results to process."
        
        passed = [r for r in results if r["passed"]]
        failed = [r for r in results if not r["passed"]]
        
        print(f"\n  📊 Results: {len(passed)} passed / {len(failed)} failed")
        
        if dry_run:
            print("  🏁 DRY RUN — no files copied")
            report = self._generate_report(passed, failed)
            print("\n" + report)
            return report
        
        # Create directories
        for group in set(r["group"] for r in results):
            (self.verified_dir / group).mkdir(parents=True, exist_ok=True)
        self.failed_dir.mkdir(parents=True, exist_ok=True)
        
        # Process passed images
        for r in passed:
            group_dir = self.verified_dir / r["group"]
            
            # Load image if needed for crop
            if crop:
                img = cv2.imread(str(r["path"]))
                if img is not None:
                    cropped = self._crop_image(img)
                    out_path = group_dir / r["path"].name
                    cv2.imwrite(str(out_path), cropped,
                                [cv2.IMWRITE_PNG_COMPRESSION, 6])
                else:
                    # Fallback: copy as-is
                    shutil.copy2(r["path"], group_dir / r["path"].name)
            else:
                shutil.copy2(r["path"], group_dir / r["path"].name)
            
            # Create .txt caption from actual YAML prompt
            caption_path = group_dir / (r["path"].stem + ".txt")
            tag_key = r["tag"]
            # Remove seed suffix (e.g. "neutral_direct_s0" -> "neutral_direct")
            base_key = re.sub(r'_s\d+$', '', tag_key)
            actual_prompt = self.prompt_map.get(base_key, "")
            if actual_prompt:
                caption = actual_prompt
            else:
                # Fallback: use the tag key itself (better than replace)
                caption = base_key.replace("_", " ")
            with open(caption_path, "w", encoding="utf-8") as f:
                f.write(caption)
        
        # Copy failed to failed/ for review
        for r in failed:
            shutil.copy2(r["path"], self.failed_dir / r["path"].name)
        
        report = self._generate_report(passed, failed)
        
        # Save report
        report_path = self.output_dir / "_post_process_report.txt"
        with open(report_path, "w", encoding="utf-8") as f:
            f.write(report)
        print(f"  📝 Report: {report_path}")
        
        # Save CSV
        csv_path = self.output_dir / "_post_process_scores.csv"
        self._save_csv(results, csv_path)
        print(f"  📊 CSV: {csv_path}")
        
        # Summary
        trainer_dir = self.output_dir / "trainer_ready"
        if passed:
            # Symlink or copy structure
            print(f"\n  ✅ Training-ready dataset: {self.verified_dir}")
            print(f"     Total: {len(passed)} images in {len(set(r['group'] for r in passed))} buckets")
            print(f"     Command: python OneTrainer.py --dataset {self.verified_dir}")
        
        return report
    
    def _generate_report(self, passed, failed):
        """Generate human-readable report."""
        lines = []
        lines.append("=" * 60)
        lines.append("📋 Phase A Post-Processing Report")
        lines.append("=" * 60)
        lines.append(f"Date: {__import__('datetime').datetime.now().isoformat()}")
        lines.append(f"Threshold: {self.threshold}")
        lines.append(f"Total: {len(passed) + len(failed)}")
        lines.append(f"Passed: {len(passed)} ({len(passed)/max(len(passed)+len(failed),1)*100:.1f}%)")
        lines.append(f"Failed: {len(failed)} ({len(failed)/max(len(passed)+len(failed),1)*100:.1f}%)")
        lines.append("")
        
        # Per-group stats
        groups = defaultdict(lambda: {"passed": 0, "failed": 0})
        for r in passed:
            groups[r["group"]]["passed"] += 1
        for r in failed:
            groups[r["group"]]["failed"] += 1
        
        lines.append("📁 Per-Group Statistics:")
        lines.append(f"  {'Group':<15} {'Passed':<8} {'Failed':<8} {'Rate':<8}")
        lines.append("  " + "-" * 40)
        for g in sorted(groups.keys()):
            p = groups[g]["passed"]
            f = groups[g]["failed"]
            rate = p / max(p + f, 1) * 100
            lines.append(f"  {g:<15} {p:<8} {f:<8} {rate:<7.1f}%")
        lines.append("")
        
        # Failed details
        if failed:
            lines.append("❌ FAILED Images:")
            for r in sorted(failed, key=lambda x: x["score"], reverse=True):
                d = r["details"]
                reasons = []
                for metric, weight in [("face_consistency", 0.45),
                                        ("anatomy", 0.20),
                                        ("image_quality", 0.15),
                                        ("artifacts", 0.10),
                                        ("prompt_match", 0.10)]:
                    val = d.get(metric, 0)
                    if val < self.threshold * 0.8:
                        reasons.append(f"{metric}={val:.2f}")
                lines.append(f"  {r['tag']}_s{r['seed']}: score={r['score']:.2f} "
                           f"({' | '.join(reasons[:3])})")
            lines.append("")
        
        # Regenerate command
        if failed:
            failed_tags = sorted(set(f"{r['tag']}_s{r['seed']}" for r in failed), key=lambda x: x)
            chunk_size = 10
            for i in range(0, len(failed_tags), chunk_size):
                chunk = failed_tags[i:i+chunk_size]
                cmd = f"python gen_phaseA_sdxl.py --regenerate \"{','.join(chunk)}\""
                lines.append(f"  🔄 Regen batch {i//chunk_size + 1}:")
                lines.append(f"     {cmd}")
        
        # Average scores
        lines.append("")
        lines.append("📊 Average Scores:")
        if passed:
            avg_scores = defaultdict(list)
            for r in passed:
                for k, v in r["details"].items():
                    avg_scores[k].append(v)
            for metric in ["face_consistency", "anatomy", "image_quality", "artifacts", "prompt_match"]:
                vals = avg_scores.get(metric, [0])
                avg = sum(vals) / len(vals)
                lines.append(f"  {metric:<20}: {avg:.3f}")
        
        lines.append("")
        lines.append("=" * 60)
        return "\n".join(lines)
    
    def _save_csv(self, results, csv_path):
        """Save detailed scores to CSV."""
        fields = ["tag", "seed", "group", "score", "passed",
                  "face_consistency", "anatomy", "image_quality",
                  "artifacts", "prompt_match"]
        with open(csv_path, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=fields)
            writer.writeheader()
            for r in results:
                writer.writerow({
                    "tag": r["tag"],
                    "seed": r["seed"],
                    "group": r["group"],
                    "score": r["score"],
                    "passed": r["passed"],
                    **r["details"],
                })


def main():
    import argparse
    parser = argparse.ArgumentParser(description="Phase A Dataset Post-Processor v3.1 PRO")
    parser.add_argument("input_dir", help="Directory with generated images")
    parser.add_argument("--phase", type=int, choices=[1,2,3], default=1,
                        help="Phase 1=face (face crop), 2=bust (center crop), 3=full (no crop)")
    parser.add_argument("--crop-mode", choices=["face", "bust", "none"], default=None,
                        help="Override crop mode (default: auto from --phase)")
    parser.add_argument("--ref", default="ref_face_1024.png", help="Reference face image")
    parser.add_argument("--prompts-yaml", default=None, help="Path to prompts_brunette.yaml for real captions")
    parser.add_argument("--threshold", type=float, default=0.85, help="Quality threshold")
    parser.add_argument("--no-crop", action="store_true", help="Skip cropping entirely")
    parser.add_argument("--dry-run", action="store_true", help="Score without copying files")
    parser.add_argument("--skip-verified", action="store_true",
                        help="Skip scoring, rebuild from existing verified/")
    parser.add_argument("--device", default="cuda", help="Device (cuda/cpu)")
    args = parser.parse_args()
    
    input_dir = Path(args.input_dir)
    if not input_dir.exists():
        print(f"❌ Input directory not found: {input_dir}")
        sys.exit(1)
    
    # Resolve ref path
    ref_path = args.ref
    if not os.path.exists(ref_path):
        # Try relative to input dir
        alt = input_dir.parent / args.ref
        if alt.exists():
            ref_path = str(alt)
        else:
            ref_path = None
            print("  ⚠️ Reference image not found — face_sim disabled")
    
    pp = DatasetPostProcessor(
        output_dir=input_dir,
        ref_path=ref_path,
        threshold=args.threshold,
        device=args.device,
        prompts_yaml=args.prompts_yaml,
        phase=args.phase,
        crop_mode=args.crop_mode,
    )
    
    if args.skip_verified:
        # Just rebuild report from existing verified/
        verified_dir = input_dir / "verified"
        if verified_dir.exists():
            results = []
            for group_dir in sorted(verified_dir.iterdir()):
                if group_dir.is_dir():
                    for img_path in sorted(group_dir.glob("*.png")):
                        tag, seed = pp._parse_tag(img_path.name)
                        results.append({
                            "path": img_path,
                            "tag": tag,
                            "seed": seed,
                            "group": group_dir.name,
                            "score": 1.0,  # assumed passed
                            "passed": True,
                        })
            passed = results
            failed = []
            report = pp._generate_report(passed, failed)
            print(report)
        else:
            print("❌ No verified/ directory found")
    else:
        report = pp.process(crop=not args.no_crop, dry_run=args.dry_run)
        print(report)


if __name__ == "__main__":
    main()
