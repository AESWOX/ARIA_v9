#!/usr/bin/env python3
"""
gen_batch7.py — Итерация после вижн анализа 2026-07-08
Что изменилось:
- LoRA RealSkin_xxXL_v1 (weight 0.6) — пластик кожи фикс
- LoRA DetailedEyes_V3 (weight 0.5) — детали глаз
- IP weight 0.8→0.7, weight_type="linear", embeds_scaling="K+V"
- Denoise 0.45→0.35 — меньше артефактов
- Neg prompt: smooth skin, plastic skin, soap skin
- Pos prompt: detailed skin texture, pores
- CFG: 5.5→6.0
"""
import requests, json, random, time, sys, os

API = "http://127.0.0.1:8188"
NEG = "bad anatomy, ugly, deformed, blurry, low resolution, duplicate, morbid, mutilated, extra fingers, mutation, poorly drawn face, bad teeth, long neck, watermark, signature, text, logo, nude, naked, (smooth skin:1.5), plastic skin, soap skin, airbrushed, doll skin, perfect skin, flat lighting"

PROMPTS = {
    "front_smile": "young woman, front facing, direct eye contact with camera, genuine warm smile, bright eyes, high fashion, perfect face symmetry, detailed skin texture, pores, natural skin imperfections, highly detailed face",
    "tq_left_serious": "young woman, three-quarter left profile, portrait, serious thoughtful expression, looking into distance, elegant neck, detailed skin texture, pores, natural skin, highly detailed face",
    "prof_right_neutral": "young woman, right side profile, soft portrait, neutral expression looking right, long neck, elegant hair draped, detailed skin texture, pores, highly detailed face",
    "high_surprised": "young woman, chin up, looking slightly upward with open happy expression, playful, bright eyes, lifted brows, detailed skin texture, pores",
    "tq_right_happy": "young woman, three-quarter right pose, genuine happy smile, looking slightly off camera, soft relaxed expression, detailed skin texture, pores",
}

def build_workflow(seed, pos_prompt):
    return {
        "1": {"class_type": "CheckpointLoaderSimple", "inputs": {"ckpt_name": "lustify_apexV8.safetensors"}},
        "17": {"class_type": "LoraLoaderNode", "inputs": {"model": ["1", 0], "clip": ["1", 1],
                "lora_name": "RealSkin_xxXL_v1.safetensors", "strength_model": 0.6, "strength_clip": 0.6}},
        "18": {"class_type": "LoraLoaderNode", "inputs": {"model": ["17", 0], "clip": ["17", 1],
                "lora_name": "DetailedEyes_V3.safetensors", "strength_model": 0.5, "strength_clip": 0.5}},
        "2": {"class_type": "CLIPSetLastLayer", "inputs": {"clip": ["18", 1], "stop_at_clip_layer": -2}},
        "3": {"class_type": "IPAdapterUnifiedLoader", "inputs": {"model": ["18", 0], "preset": "PLUS FACE",
                "ipadapter": "ip-adapter-plus-face_sdxl_vit-h.safetensors", "cache_mode": "disabled"}},
        "4": {"class_type": "IPAdapterAdvanced", "inputs": {"ipadapter": ["3", 0], "model": ["3", 1],
                "image": ["14", 0], "weight": 0.7, "weight_type": "linear", "noise": 0.0,
                "embeds_scaling": "K+V", "start_at": 0.0, "end_at": 0.8}},
        "6": {"class_type": "CLIPTextEncode", "inputs": {"text": pos_prompt, "clip": ["2", 0]}},
        "7": {"class_type": "CLIPTextEncode", "inputs": {"text": NEG, "clip": ["2", 0]}},
        "8": {"class_type": "EmptyLatentImage", "inputs": {"width": 832, "height": 1216, "batch_size": 1}},
        "9": {"class_type": "KSampler", "inputs": {"seed": seed, "steps": 30, "cfg": 6.0,
                "sampler_name": "dpmpp_2m_sde", "scheduler": "karras", "denoise": 1.0,
                "model": ["4", 0], "positive": ["6", 0], "negative": ["7", 0], "latent_image": ["8", 0]}},
        "10": {"class_type": "LatentUpscaleBy", "inputs": {"upscale_method": "bicubic", "scale_factor": 1.5,
                 "latent": ["9", 0]}},
        "11": {"class_type": "KSampler", "inputs": {"seed": seed+1, "steps": 22, "cfg": 6.0,
                "sampler_name": "dpmpp_2m_sde", "scheduler": "karras", "denoise": 0.35,
                "model": ["4", 0], "positive": ["6", 0], "negative": ["7", 0], "latent_image": ["10", 0]}},
        "12": {"class_type": "VAEDecode", "inputs": {"samples": ["11", 0], "vae": ["13", 0]}},
        "13": {"class_type": "VAELoader", "inputs": {"vae_name": "sdxl_vae.safetensors"}},
        "14": {"class_type": "LoadImage", "inputs": {"image": "ref_face_1024.png"}},
        "15": {"class_type": "SaveImage", "inputs": {"images": ["12", 0], "filename_prefix": ""}},
    }

def submit(seed, name):
    wf = build_workflow(seed, PROMPTS[name])
    resp = requests.post(f"{API}/prompt", json={"prompt": wf}, timeout=30)
    data = resp.json()
    pid = data.get("prompt_id", "?")
    print(f"  OK {name} seed={seed} pid={pid}")
    return pid

if __name__ == "__main__":
    session_names = sorted(PROMPTS.keys())
    print(f"Submitting {len(session_names)} prompts (gen_batch7: LoRA+IP0.7+K+V)...")
    for name in session_names:
        seed = random.randint(1, 999999999)
        submit(seed, name)
    print(f"\nSubmitted {len(session_names)}/{len(session_names)}. Waiting for queue...")
    for i in range(20):
        time.sleep(30)
        try:
            q = requests.get(f"{API}/queue", timeout=5).json()
            r = len(q.get("queue_running", []))
            p = len(q.get("queue_pending", []))
            imgs = len(os.listdir("/workspace/runpod-slim/ComfyUI/output/")) if os.path.exists("/workspace/runpod-slim/ComfyUI/output/") else "?"
            print(f"  {i*30+30}s: r={r} p={p} images={imgs}")
            if r == 0 and p == 0:
                print("  Queue empty - done!")
                break
        except Exception as e:
            print(f"  {i*30+30}s: check failed: {e}")
