---
status: working
tags: [godtier, sdxl-pipeline, brunette]
---
# 🚀 RunPod Pod — Финальный чеклист разворота

> **Единственный источник правды.** Дата: 2026-07-08
> Последний тест: под `g186atwe2cn7pc` (194.14.47.19:23246), RTX 3090
> Полный разворот: **~5 минут**

---

## 📋 Содержание

1. [Деплой пода](#1-деплой-пода)
2. [Перенос с B2](#2-перенос-с-b2)
3. [Установка зависимостей](#3-установка-зависимостей)
4. [Верификация файлов](#4-верификация-файлов)
5. [Файловая структура пода](#5-файловая-структура-пода)
6. [Запуск ComfyUI](#6-запуск-comfyui)
7. [Генерация — скрипты и пайплайн](#7-генерация)
8. [Оценка качества](#8-оценка-качества)
9. [Финансовый аудит](#9-финансовый-аудит)
10. [Отвал старого пода](#10-отвал-старого-пода)
11. [Все Pitfalls](#11-pitfalls)

---

## 1. Деплой пода

### Скрипты (единственный способ)

**Путь:** `~/Desktop/WORK/SCRIPTS/runpod/`
**Рабочий ключ:** `APY/RUNPOD/RUNPOD_2.txt`

```bash
# Авто (A5000 → 3090):
python ~/Desktop/WORK/SCRIPTS/runpod/deploy_pod.py

# Принудительно:
python ~/Desktop/WORK/SCRIPTS/runpod/deploy_pod.py a5000        # $0.16/h
python ~/Desktop/WORK/SCRIPTS/runpod/deploy_pod.py 3090         # $0.22/h
python ~/Desktop/WORK/SCRIPTS/runpod/deploy_pod.py 4090 lora    # $0.34/h, ТОЛЬКО lora

# Терминейт:
python ~/Desktop/WORK/SCRIPTS/runpod/terminate_pod.py <POD_ID>
```

### Параметры деплоя

| Параметр | Значение |
|----------|----------|
| Template | `2lv7ev3wfp` (ComfyUI — CUDA 13) |
| Image | `runpod/comfyui:cuda13.0` |
| Cloud | `COMMUNITY` |
| Disk | **200 GB** (50 не хватает для моделей 63GB + LoRA) |
| GPU | 1 |
| Ports | `8188/http,8888/http,22/tcp` |

### ⏳ Ждать готовность

A5000 — до 5 минут, 3090 — до 3 минут. Проверить:
```bash
ssh -p <PORT> -i ~/.ssh/runpod_key -o StrictHostKeyChecking=no root@<IP>
```
После SSH проверить ComfyUI:
```bash
curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:8188/
# Ожидание: 200
```

### Прокси-адрес

`https://{podHostId}-8188.proxy.runpod.net`

`podHostId` — из `pod.machine.podHostId`, НЕ pod.id.

**После деплоя записать:** ID пода, IP, SSH-порт, proxy URL.

---

## 2. Перенос с B2

### Настройка rclone на поде

```bash
cat > /root/.rclone_b2.conf << 'EOF'
[ALEX]
type = b2
account = <B2_ACCOUNT_ID>
key = <B2_APP_KEY>
EOF
```

### Структура B2

```
ALEX.STORAGE/deploy/
├── comfyui-models/   → 40 GB   (checkpoints, ipadapter, loras, controlnet, clip_vision, vae, sams, onnx, upscale)
├── comfyui-runtime/  → 56 GB   (весь runpod-slim ComfyUI, custom_nodes, input, output...)
└── scripts/          → 19 файлов (pod_setup.sh, pod_tasks.sh, requirements.txt, gen_batch*.py...)

Итого: ~56 GB объектов (3479 файлов)
```

### Процесс синка (ПАРАЛЛЕЛЬНО)

**Модели (~4 мин, 8 потоков):**
```bash
rclone sync ALEX:ALEX.STORAGE/deploy/comfyui-models/ \
  /workspace/runpod-slim/ComfyUI/models/ --transfers=8
```

**Runtime (~30 сек, 4 потока):**
```bash
rclone sync ALEX:ALEX.STORAGE/deploy/comfyui-runtime/ \
  /workspace/runpod-slim/ComfyUI/ --transfers=4
```

**Скрипты (~10 сек):**
```bash
rclone sync ALEX:ALEX.STORAGE/deploy/scripts/ \
  /workspace/scripts/ --transfers=4
```

> **Важно:** Модели и runtime синкаются параллельно (разные targets).

### Верификация синка

```bash
# Количество файлов моделей (~79,000 после разархивации)
find /workspace/runpod-slim/ComfyUI/models/ -type f | wc -l

# Общий размер моделей
du -sh /workspace/runpod-slim/ComfyUI/models/
# Ожидание: 57 GB

# Ключевые файлы
ls -lh /workspace/runpod-slim/ComfyUI/models/checkpoints/Lustify_apexV8.safetensors
# ~6.5 GB
ls -lh /workspace/runpod-slim/ComfyUI/models/sams/sam_vit_b_01ec64.pth
# 358 MB — СКАЧАТЬ отдельно если не в B2!

# Проверка custom_nodes
ls /workspace/runpod-slim/ComfyUI/custom_nodes/ | grep -E "Impact|IPAdapter|Detail|Face"
# Ожидание: Impact-Pack, IPAdapter_plus, Detail-Daemon
```

---

## 3. Установка зависимостей

### Через requirements (если на B2):
```bash
pip install -r /workspace/scripts/requirements.txt
```

### Список всех необходимых пакетов:
```
ultralytics              # YOLO детекторы
insightface              # FaceAnalysis для сравнения лиц
opencv-python-headless   # CV операции
opencv-python            # CV2
facexlib                 # Face restorers
piexif                   # EXIF
segment-anything         # SAM (FDP)
scikit-image             # Image processing
onnx                     # ONNX runtime
```

### SAM модель (ЕСЛИ НЕ НА B2):
```bash
mkdir -p /workspace/runpod-slim/ComfyUI/models/sams
curl -L --connect-timeout 10 --max-time 120 \
  "https://dl.fbaipublicfiles.com/segment_anything/sam_vit_b_01ec64.pth" \
  -o /workspace/runpod-slim/ComfyUI/models/sams/sam_vit_b_01ec64.pth
```

### YOLO→ONNX конвертация (для FaceDetailer):
```bash
mkdir -p /workspace/runpod-slim/ComfyUI/models/onnx
python3 -c "
from ultralytics import YOLO
YOLO('/workspace/runpod-slim/ComfyUI/models/ultralytics/bbox/face_yolov8m.pt').export(
    format='onnx', imgsz=[640,640]
)"
cp /workspace/runpod-slim/ComfyUI/models/ultralytics/bbox/face_yolov8m.onnx \
   /workspace/runpod-slim/ComfyUI/models/onnx/face_yolov8m.onnx
```

---

## 4. Верификация файлов

### После полного синка:

```bash
# Модели
du -sh /workspace/runpod-slim/ComfyUI/models/*/ | sort -rh
```

| Директория | Размер | Что внутри |
|------------|--------|------------|
| ipadapter/ | 21 GB | IPAdapter модели + CLIP Vision |
|| checkpoints/ | 13 GB | Lustify_apexV8 (6.5GB), bigLust_v16 |
| controlnet/ | 7.1 GB | ControlNet'ы |
| loras/ | 6.9 GB | LoRA |
| clip_vision/ | 3.7 GB | ViT-H-14, ViT-G |
| pulid/ | 1.7 GB | PuLID |
| instantid/ | 1.6 GB | InstantID |
| insightface/ | 1.4 GB | Face models |
| clip/ | 470 MB | CLIP encoders |
| sams/ | 358 MB | SAM ViT-B |
| vae/ | 320 MB | SDXL VAE |
| ultralytics/ | 149 MB | face_yolov8m |
| onnx/ | 99 MB | face_yolov8m.onnx |
| upscale_models/ | 64 MB | Upscalers |

### Эталонные скрипты на поде:
```
/workspace/gen_batch6.py     — текущий рабочий скрипт
/workspace/quality_eval.py   — скрипт оценки качества
```

---

## 5. Файловая структура пода

### Модели (57 GB)
```
/workspace/runpod-slim/ComfyUI/models/
├── checkpoints/
│   ├── Lustify_apexV8.safetensors   ✓ (6.5 GB)
│   └── Lustify_apexV8.safetensors     (основная production модель)
├── ipadapter/                    ✓ (21 GB)
├── loras/                        ✓ (6.9 GB)
├── controlnet/                   ✓ (7.1 GB)
├── clip_vision/                  ✓ (3.7 GB)
├── vae/                          ✓ (sdxl_vae.safetensors)
├── sams/
│   └── sam_vit_b_01ec64.pth      ✓ (358 MB)
├── onnx/
│   └── face_yolov8m.onnx         ✓ (99 MB)
├── ultralytics/bbox/
│   └── face_yolov8m.pt           ✓ (оригинал .pt)
├── insightface/                  ✓ (1.4 GB)
├── pulid/                        ✓ (1.7 GB)
├── instantid/                    ✓ (1.6 GB)
├── upscale_models/               ✓ (64 MB)
├── clip/                         ✓ (470 MB)
└── configs/                      ✓
```

### Custom Nodes
```
/workspace/runpod-slim/ComfyUI/custom_nodes/
├── ComfyUI-Impact-Pack/         ✓ — FaceDetailer
├── ComfyUI-IPAdapter_plus/      ✓ — IPAdapter
├── ComfyUI-Detail-Daemon/       ✓ — DetailDaemon
├── Civicomfy/                   ✓
├── ComfyUI-KJNodes/             ✓
├── ComfyUI-Face-Style-Preset/   ✓
├── ComfyUI-Manager/             ✓
├── ComfyUI-RunpodDirect/        ✓
├── ComfyUI_InstantID/           ✓
├── PuLID_ComfyUI/               ✓
└── ComfyUI/                     ✓ (базовые ноды)
```

### Референс
```
/workspace/runpod-slim/ComfyUI/input/
└── ref_face_1024.png            ✓
```

---

## 6. Запуск ComfyUI

```bash
cd /workspace/runpod-slim/ComfyUI
nohup python3 main.py --listen 0.0.0.0 --port 8188 > /tmp/comfyui.log 2>&1 &
echo "PID=$!"

# Ждать готовности (модели грузятся ~15 сек)
sleep 15
curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:8188/
# Ожидание: 200

# Проверка нод
curl -s http://127.0.0.1:8188/object_info | python3 -c "
import sys,json
d=json.load(sys.stdin)
print('FaceDetailer:', 'FaceDetailer' in d)
print('IPAdapter:', 'IPAdapter' in d)
print('ONNXDetector:', 'ONNXDetectorProvider' in d)
print('DD:', 'DetailDaemonSamplerNode' in d)
"
# Все должно быть True
```

### ⚠️ Перезапуск (OOM recovery)
Если ComfyUI упал (502/соединение сброшено):
```bash
# ТРИ отдельных SSH вызова (pkill + nohup в одном — сессия падает!)
ssh -p <PORT> -i ~/.ssh/runpod_key root@<IP> 'pkill -f "python3 main"'
sleep 2
ssh -p <PORT> -i ~/.ssh/runpod_key root@<IP> 'cd /workspace/runpod-slim/ComfyUI && nohup python3 main.py --listen 0.0.0.0 --port 8188 > /tmp/comfyui.log 2>&1 & echo "PID=$!"'
sleep 15
ssh -p <PORT> -i ~/.ssh/runpod_key root@<IP> 'curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:8188/'
```

---

## 7. Генерация — скрипты и пайплайн

### Текущий рабочий скрипт: `gen_batch6.py`

**Архитектура (gen_batch5-style, без FD/SAM):**
```
CheckpointLoader → IPAdapter(PLUS FACE, w=0.8) → KSampler(30 steps) → 
LatentUpscale → KSampler(20 steps, denoise 0.45) → VAEDecode → SaveImage
```

**Что генерирует:** 5 углов × 3 сида = 15 изображений

| Промт | Поза | Выражение |
|-------|------|-----------|
| front_smile | Front | Warm smile |
| tq_left_serious | 3/4 left | Serious |
| prof_right_neutral | Profile right | Neutral |
| high_surprised | Chin up, looking up | Surprised |
| tq_right_happy | 3/4 right | Happy smile |

**Параметры:**
- Модель: `Lustify_apexV8.safetensors`
- Референс: `ref_face_1024.png`
- IPAdapter preset: `PLUS FACE (portraits)`
- IP weight: `0.8`, weight_type: `standard`, embeds_scaling: `V only`
- CFG: `5.5`, sampler: `dpmpp_2m_sde`, scheduler: `karras`
- Base: 30 steps, denoise 1.0
- Hires: 22 steps, denoise 0.45
- Разрешение: 832×1216 → 1248×1824
- Сиды: **каждый — random.randint(1, 999999999)**

**На поде:** `/workspace/gen_batch6.py`

**Запуск:**
```bash
cd /workspace && python3 -u gen_batch6.py
```

### Хронометраж
- 1 изображение: ~30-35 сек (на 3090)
- 15 изображений: ~8-10 минут
- Очередь: 1 running + 14 pending

### ⚠️ FaceDetailer — OOM
FaceDetailer с SAM моделями НЕ РАБОТАЕТ на RTX 3090 (24 GB). Даже с `force_inpaint=False`.
- Без FD: стабильно, 0 OOM
- С FD: OOM на второй генерации
- Возможное решение: `--lowvram` флаг ComfyUI (не тестировалось)

### DetailDaemon — не протестирован
DD через SamplerCustom требует правильной связки:
```
KSamplerSelect → DetailDaemonSamplerNode → BasicScheduler → SamplerCustom
```
Требует параметры: `add_noise`, `noise_seed`, `cfg` в SamplerCustom.
UV установка cfg_scale_override в DD.

---

## 8. Оценка качества

**Скрипт:** `/workspace/quality_eval.py`

```bash
cd /workspace && python3 -u quality_eval.py
```

**Метрики:**
- Face similarity: insightface (buffalo_l) — compare face embeddings
- Sharpness: Laplacian variance
- Exposure: mean pixel value
- Итоговый score: 0-100 (sim × 50 + sharp / 200 × 25 + exposure balance × 25)

**Требования:**
- cv2 (opencv-python) ✅ на поде
- insightface ✅ на поде
- Референс: `/workspace/runpod-slim/ComfyUI/input/ref_face_1024.png`

---

## 9. Финансовый аудит

| GPU | Цена/ч | 15 изображений | 1 полный run |
|-----|--------|----------------|--------------|
| A5000 | $0.16 | ~$0.048 | ~$0.06 |
| RTX 3090 | $0.22 | ~$0.044 | ~$0.08 |
| RTX 4090 | $0.34 | ~$0.068 | ~$0.12 |

> Если >$0.15 за full run — что-то не так (завис/падение/двойная оплата).

---

## 10. Отвал старого пода

```bash
python ~/Desktop/WORK/SCRIPTS/runpod/terminate_pod.py <OLD_POD_ID>
```

**Только DELETE (HTTP 204). Никогда `stop_pod()`!**

После DELETE проверить:
```bash
python -c "import runpod; runpod.api_key=open('APY/RUNPOD/RUNPOD_2.txt').read().strip(); print(runpod.get_pods())"
# Под должен отсутствовать в списке
```

---

## 11. Pitfalls

### 🚨 КРИТИЧЕСКИЕ
| Pitfall | Решение |
|---------|---------|
| **FaceDetailer OOM** | Убрать FD из пайплайна. SDXL + IPAdapter + SAM > 24GB. Пока без FD. |
| **SSH pkill + nohup в одной сессии** | Если `pkill` убивает SSH, nohup не запускается. Делать в 3 вызова. |
| **wildcard="face" не существует** | Impact Pack wildcards/face.txt нет. wildcard просто как строка промпта. |
| **SAM model 0 байт** | Скачивать с `dl.fbaipublicfiles.com`, не с HuggingFace (редиректы). |

### ⚠️ ВАЖНЫЕ
| Pitfall | Решение |
|---------|---------|
| `python3` на ПК ≠ Python 3.11 | На ПК `python` = 3.11.15, `python3` = 3.2.2 (без f-strings!) |
| queue/endpoint пустой | ComfyUI упал — 502. Перезапускать. |
| GPU memory 0 MiB | ComfyUI упал. Проверить `dmesg \| grep -i oom`. |
| `container_disk_in_gb` vs `container_disk_size_gb` | SDK: `container_disk_in_gb` (проверять имя параметра). |
| proxy URL содержит podHostId, не pod_id | `pod.machine.podHostId` — новый ID для proxy. |
| `--normal-vram` не существует | Этот флаг не в этой версии ComfyUI. |
| template_id + image_name оба обязательны | Не пропускать ни один. |
| A5000 грузится 5 мин | Не проверять через 30 секунд. |

### 🔧 НАСТРОЙКИ
| Параметр | Текущее | Альтернатива |
|----------|---------|-------------|
| IP weight | 0.8 | 0.75-1.0 (но 0.8 — стабильно) |
| Weight type | standard | linear, ease in/out |
| Embeds scaling | V only | I+J, K+V |
| CFG | 5.5 | 4.5-7.0 |
| Sampler | dpmpp_2m_sde_karras | dpmpp_3m_sde, euler |
| Base steps | 30 | 25-35 |
| Hires denoise | 0.45 | 0.35-0.55 |
| DD detail_amount | 30% (не тест) | 15-50% |

### 📋 ДЕПЛОЙ
| Pitfall | Решение |
|---------|---------|
| Диск 50 GB | **200 GB минимум** — 63 GB моделей + генерации. 50 не хватает. |
| rclone не настроен | Создать `/root/.rclone_b2.conf` с B2 аккаунтом/ключом. |
| Синк не закончен | Проверить `ps aux \| grep rclone`. Ждать завершения. |
| SAM model нет | Скачать через curl с `dl.fbaipublicfiles.com`. |
| YOLO .onnx нет | Конвертировать .pt через `YOLO.export(format='onnx')`. |

---

### История изменений

| Дата | Что |
|------|-----|
| 2026-07-08 | Первая версия. Основана на тестах под `g186atwe2cn7pc`. |
