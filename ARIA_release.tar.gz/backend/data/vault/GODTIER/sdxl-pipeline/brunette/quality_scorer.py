"""
quality_scorer.py — Quality evaluation for Phase A face dataset (v3.1 PRO).

Метрики:
- face_consistency (45%): InsightFace cosine similarity с референсом
- anatomy (20%): OpenPose-based скелет + симметрия лица
- image_quality (15%): Laplacian sharpness + noise
- artifacts (10%): Sobel banding + flat regions
- prompt_match (10%): CLIP score (fallback heuristic)

Требования (опционально): pip install open-clip-torch
"""

import os
import cv2
import numpy as np
from pathlib import Path


class QualityScorer:
    """Production-level quality scorer for face LoRA dataset images."""

    def __init__(self, ref_image_path="ref_face_1024.png", device="cuda",
                 weights=None):
        self.device = device if device == "cuda" and self._cuda_available() else "cpu"
        self.ref_embedding = None
        self.face_app = None
        self.clip_model = None
        self.clip_preprocess = None
        self.ref_image_path = ref_image_path
        
        # Default weights
        self.weights = weights or {
            "face_consistency": 0.45,
            "anatomy": 0.20,
            "image_quality": 0.15,
            "artifacts": 0.10,
            "prompt_match": 0.10,
        }
        
        self._setup_insightface()
        self._setup_clip()
    
    def _cuda_available(self):
        try:
            import torch
            return torch.cuda.is_available()
        except ImportError:
            return False
    
    def _setup_insightface(self):
        """Lazy init of InsightFace + reference embedding."""
        try:
            import insightface
            from insightface.app import FaceAnalysis
            
            self.face_app = FaceAnalysis(name="buffalo_l",
                                         root=os.path.expanduser("~/.insightface"))
            ctx = 0 if self.device == "cuda" else -1
            self.face_app.prepare(ctx_id=ctx, det_size=(320, 320))
            
            if os.path.exists(self.ref_image_path):
                ref_img = cv2.imread(self.ref_image_path)
                if ref_img is not None:
                    faces = self.face_app.get(ref_img)
                    if faces:
                        emb = faces[0].embedding
                        self.ref_embedding = emb / (np.linalg.norm(emb) + 1e-10)
        except ImportError:
            print("  ⚠️ InsightFace not installed — face_sim=0.5")
    
    def _setup_clip(self):
        """Optional CLIP for prompt_match. Graceful fallback if not available."""
        try:
            import clip
            import torch
            model_name = "ViT-B/32"
            self.clip_model, self.clip_preprocess = clip.load(
                model_name, device=self.device)
            print(f"  ✓ CLIP loaded ({model_name})")
        except Exception:
            self.clip_model = None
    
    # ── Core scoring methods ──

    def face_similarity(self, img):
        """Cosine similarity with reference face. Returns [0, 1]."""
        if self.ref_embedding is None or self.face_app is None:
            return 0.5
        try:
            faces = self.face_app.get(img)
            if not faces:
                return 0.0  # no face = fail
            best_sim = 0.0
            for face in faces:
                emb = face.embedding / (np.linalg.norm(face.embedding) + 1e-10)
                sim = float(np.dot(self.ref_embedding, emb))
                best_sim = max(best_sim, sim)
            # Normalize [-1, 1] → [0, 1]
            return max(0.0, min(1.0, (best_sim + 1.0) / 2.0))
        except Exception:
            return 0.0
    
    def anatomy_score(self, img):
        """Advanced anatomy: face landmarks symmetry + proportion + keypoints."""
        if self.face_app is None:
            return 0.5
        try:
            faces = self.face_app.get(img)
            if not faces:
                return 0.0
            
            face = faces[0]
            h, w = img.shape[:2]
            img_area = h * w
            
            # 1. Face proportion score (15-35% of frame = ideal)
            bbox = face.bbox
            face_area = (bbox[2] - bbox[0]) * (bbox[3] - bbox[1])
            ratio = face_area / max(img_area, 1)
            prop_score = 1.0 - abs(ratio - 0.25) * 3.0
            prop_score = max(0.0, min(1.0, prop_score))
            
            # 2. Landmark symmetry (5 landmarks from InsightFace)
            landmarks = face.landmark  # 5 points: left_eye, right_eye, nose, mouth_left, mouth_right
            sym_score = 0.5
            if landmarks is not None and len(landmarks) >= 5:
                le, re, nose, ml, mr = landmarks[:5]
                # Eyes horizontal?
                eye_dy = abs(le[1] - re[1])
                eye_dx = abs(le[0] - re[0])
                eye_horiz = 1.0 - min(1.0, eye_dy / max(eye_dx, 1))
                
                # Nose centered between eyes?
                nose_x = nose[0]
                eyes_center_x = (le[0] + re[0]) / 2
                nose_offset = abs(nose_x - eyes_center_x) / max(eye_dx, 1)
                nose_centered = 1.0 - min(1.0, nose_offset * 2)
                
                # Mouth symmetry
                mouth_dy = abs(ml[1] - mr[1])
                mouth_sym = 1.0 - min(1.0, mouth_dy / max(abs(ml[0] - mr[0]), 1))
                
                sym_score = eye_horiz * 0.35 + nose_centered * 0.35 + mouth_sym * 0.30
            
            # 3. Detection confidence bonus
            det_score = min(1.0, face.det_score * 1.2)
            
            return prop_score * 0.35 + sym_score * 0.35 + det_score * 0.30
            
        except Exception:
            return 0.5
    
    def face_symmetry_score(self, img):
        """Explicit face symmetry from landmarks."""
        if self.face_app is None:
            return 0.5
        try:
            faces = self.face_app.get(img)
            if not faces:
                return 0.0
            face = faces[0]
            landmarks = face.landmark
            if landmarks is None or len(landmarks) < 5:
                return 0.5
            
            le, re, nose, ml, mr = landmarks[:5]
            # Check mirror symmetry: left side vs right side
            # Face center is midpoint between eyes
            cx = (le[0] + re[0]) / 2
            
            # Left side points relative to center
            left_dist = abs(cx - le[0])
            right_dist = abs(re[0] - cx)
            
            # Nose should be near center
            nose_sym = 1.0 - min(1.0, abs(nose[0] - cx) / max(left_dist, right_dist, 1))
            
            # Mouth corners symmetric around center?
            mouth_cx = (ml[0] + mr[0]) / 2
            mouth_sym = 1.0 - min(1.0, abs(mouth_cx - cx) / max(left_dist, right_dist, 1))
            
            # Eyes vertical alignment
            eye_y_sym = 1.0 - min(1.0, abs(le[1] - re[1]) / 20.0)
            
            return nose_sym * 0.40 + mouth_sym * 0.35 + eye_y_sym * 0.25
        except Exception:
            return 0.5
    
    def sharpness_score(self, img):
        """Laplacian variance sharpness (BRISQUE-free)."""
        try:
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            lap_var = cv2.Laplacian(gray, cv2.CV_64F).var()
            # Normalize: 0-500 range → 0-1
            return max(0.0, min(1.0, lap_var / 300.0))
        except Exception:
            return 0.5
    
    def artifact_score(self, img):
        """Detect artifacts: banding, flat regions, over-smoothing."""
        try:
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            h, w = gray.shape
            
            # Edge gradient (Sobel)
            sobel_x = cv2.Sobel(gray, cv2.CV_64F, 1, 0, ksize=3)
            sobel_y = cv2.Sobel(gray, cv2.CV_64F, 0, 1, ksize=3)
            grad_mag = np.sqrt(sobel_x**2 + sobel_y**2)
            
            # 1. Flat region penalty (banding / smooth plastic)
            flat_mask = grad_mag < 5.0
            flat_ratio = np.mean(flat_mask)
            # <40% flat = good, >70% flat = terrible
            flat_score = 1.0 - max(0.0, min(1.0, (flat_ratio - 0.40) / 0.30))
            
            # 2. Noise score (high freq detail)
            noise_map = cv2.GaussianBlur(grad_mag, (3, 3), 0)
            noise_ratio = np.mean(noise_map > 50)
            noise_score = min(1.0, noise_ratio * 3.0)
            
            # 3. Edge banding: repeated horizontal/vertical lines
            h_edges = np.mean(grad_mag > 30, axis=1)
            v_edges = np.mean(grad_mag > 30, axis=0)
            h_band = np.std(h_edges) / (np.mean(h_edges) + 1e-10)
            v_band = np.std(v_edges) / (np.mean(v_edges) + 1e-10)
            banding = min(1.0, max(h_band, v_band) * 2.0)
            
            return flat_score * 0.50 + noise_score * 0.25 + (1.0 - banding * 0.25)
        except Exception:
            return 0.5
    
    def prompt_match(self, img, prompt_text="", prompt_key=""):
        """CLIP-based prompt match with heuristic fallback."""
        # Try CLIP first
        if self.clip_model is not None:
            try:
                return self._clip_prompt_match(img, prompt_text or prompt_key)
            except Exception:
                pass
        # Fallback: heuristic
        return self._heuristic_prompt_match(img, prompt_text, prompt_key)
    
    def _clip_prompt_match(self, img, text):
        """CLIP-based image-text similarity."""
        import torch
        from PIL import Image
        try:
            pil_img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            pil_img = Image.fromarray(pil_img)
            
            image_input = self.clip_preprocess(pil_img).unsqueeze(0).to(self.device)
            text_tokens = clip.tokenize([text]).to(self.device)
            
            with torch.no_grad():
                image_features = self.clip_model.encode_image(image_input)
                text_features = self.clip_model.encode_text(text_tokens)
            
            image_features /= image_features.norm(dim=-1, keepdim=True)
            text_features /= text_features.norm(dim=-1, keepdim=True)
            
            similarity = (image_features @ text_features.T).item()
            # Normalize typical CLIP range [0.15, 0.35] → [0.0, 1.0]
            return max(0.0, min(1.0, (similarity - 0.15) / 0.25))
        except Exception:
            return 0.5
    
    def _heuristic_prompt_match(self, img, prompt_text="", prompt_key=""):
        """Smart heuristic based on prompt key + text."""
        # Face present check
        if self.face_app is not None:
            try:
                faces = self.face_app.get(img)
                if not faces:
                    return 0.1  # no face → no match
                det_conf = faces[0].det_score
            except Exception:
                det_conf = 0.8
        else:
            det_conf = 0.8
        
        # Check key features in prompt key
        key_lower = (prompt_key + " " + prompt_text).lower()
        
        # Smile detection (heuristic face analysis)
        has_smile = "smile" in key_lower or "laugh" in key_lower
        has_kiss = "kiss" in key_lower or "tongue" in key_lower
        has_neutral = "neutral" in key_lower or "calm" in key_lower
        has_surprise = "surprise" in key_lower or "intense" in key_lower
        has_cry = "cry" in key_lower or "mascara" in key_lower
        has_eye_roll = "eye_roll" in key_lower or "rolled" in key_lower
        
        # Base score: face exists
        base = 0.60 + det_conf * 0.25
        
        # Emotion-specific
        if has_neutral:
            return min(1.0, base + 0.10)  # easiest
        elif has_smile:
            return min(1.0, base + 0.05)
        elif has_kiss:
            return min(1.0, base - 0.05)  # harder
        elif has_cry or has_eye_roll:
            return min(1.0, base - 0.15)  # hardest
        elif has_surprise:
            return min(1.0, base - 0.05)
        else:
            return min(1.0, base)
    
    def score_image(self, img_or_path, prompt_text="", prompt_key=""):
        """
        Full composite score for one image.
        
        Args:
            img_or_path: cv2 image array or path string
            prompt_text: full prompt text
            prompt_key: prompt identifier (e.g. 'neutral_direct')
        
        Returns:
            total_score: float 0-1
            details: dict of per-metric scores
        """
        if isinstance(img_or_path, (str, Path)):
            img = cv2.imread(str(img_or_path))
            if img is None:
                return 0.0, {"error": "cannot read image", "face_consistency": 0.0,
                            "anatomy": 0.0, "image_quality": 0.0, "artifacts": 0.0,
                            "prompt_match": 0.0}
        else:
            img = img_or_path
        
        scores = {
            "face_consistency": self.face_similarity(img),
            "anatomy": self.anatomy_score(img),
            "image_quality": self.sharpness_score(img),
            "artifacts": self.artifact_score(img),
            "prompt_match": self.prompt_match(img, prompt_text, prompt_key),
        }
        
        total = sum(scores[k] * self.weights.get(k, 0.0)
                    for k in scores if k in self.weights)
        
        return max(0.0, min(1.0, total)), scores
