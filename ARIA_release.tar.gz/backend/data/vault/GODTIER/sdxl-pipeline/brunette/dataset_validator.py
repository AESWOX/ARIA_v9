"""
dataset_validator.py — Validate Phase A generation output.

Сканирует папку с результатами генерации, для каждого изображения
считает quality score, выдаёт отчёт с проваленными промптами
и командами для регенерации.

Использование:
    python dataset_validator.py /path/to/output --ref ref_face_1024.png
    python dataset_validator.py /path/to/output --ref ref_face_1024.png --threshold 0.85
    python dataset_validator.py /path/to/output --csv report.csv
"""

import os
import re
import sys
import csv
from pathlib import Path
from collections import defaultdict
from quality_scorer import QualityScorer


class DatasetValidator:
    """Validate directory of generated images against quality thresholds."""

    def __init__(self, output_dir, ref_path="ref_face_1024.png",
                 threshold=0.85, weights=None):
        self.output_dir = Path(output_dir)
        self.threshold = threshold
        self.scorer = QualityScorer(ref_image_path=ref_path)
        self.weights = weights
    
    def _parse_tag(self, filename):
        """Extract prompt key and seed from filename.
        
        Expected format: tag_00001_.png → (key, seed)
        """
        stem = Path(filename).stem
        # Strip trailing _00001_ pattern
        m = re.match(r'(.+?)_s(\d+)(?:_\d+)?$', stem)
        if m:
            return m.group(1), int(m.group(2))
        # Try: key_seed_num pattern
        m = re.match(r'(.+?)_(\d+)(?:_\d+)?$', stem)
        if m:
            return m.group(1), int(m.group(2))
        return stem, 0
    
    def scan(self):
        """Scan directory, score images, return grouped results."""
        exts = (".png", ".jpg", ".jpeg", ".webp")
        results = []
        
        for impath in sorted(self.output_dir.iterdir()):
            if impath.suffix.lower() not in exts:
                continue
            
            tag, seed = self._parse_tag(impath.name)
            prompt = tag.replace("_", " ")  # rough prompt estimate
            
            total, details = self.scorer.score_image(
                str(impath), prompt=prompt, weights=self.weights
            )
            
            results.append({
                "file": impath.name,
                "path": str(impath),
                "tag": tag,
                "seed": seed,
                "score": total,
                "passed": total >= self.threshold,
                "details": details,
            })
        
        return results
    
    def report(self, results):
        """Generate text report."""
        total = len(results)
        passed = [r for r in results if r["passed"]]
        failed = [r for r in results if not r["passed"]]
        
        lines = []
        lines.append("=" * 68)
        lines.append("📊 DATASET VALIDATION REPORT")
        lines.append("=" * 68)
        lines.append(f"  Directory: {self.output_dir}")
        lines.append(f"  Threshold: {self.threshold}")
        lines.append(f"  Total images: {total}")
        lines.append(f"  Passed: {len(passed)} ({len(passed)/total*100:.1f}%)")
        lines.append(f"  Failed: {len(failed)} ({len(failed)/total*100:.1f}%)")
        lines.append("")
        
        if failed:
            # Group by tag for failed
            failed_by_tag = defaultdict(list)
            for r in failed:
                failed_by_tag[r["tag"]].append(r)
            
            lines.append("❌ FAILED PROMPTS:")
            for tag in sorted(failed_by_tag.keys()):
                items = failed_by_tag[tag]
                scores = ", ".join(f"s{i['seed']}={i['score']:.3f}" for i in items)
                lines.append(f"  {tag}: {scores}")
            
            # Show top 5 lowest scores
            lines.append("")
            lines.append("🔻 Lowest scores:")
            for r in sorted(failed, key=lambda x: x["score"])[:5]:
                d = r["details"]
                lines.append(f"  {r['file']}: {r['score']:.4f} "
                             f"(face={d.get('face_sim',0):.3f} "
                             f"anat={d.get('anatomy',0):.3f} "
                             f"sharp={d.get('sharpness',0):.3f})")
            
            lines.append("")
            lines.append(f"To regenerate failed prompts:")
            regen_tags = sorted(set(r["tag"] for r in failed))
            if regen_tags:
                lines.append(f"  python gen_phaseA_sdxl.py --regenerate \"{','.join(regen_tags)}\"")
        
        # Stats by category
        lines.append("")
        lines.append("📈 Score distribution:")
        bins = [(0.9, 1.0), (0.8, 0.9), (0.7, 0.8), (0.6, 0.7), (0.0, 0.6)]
        for lo, hi in bins:
            count = sum(1 for r in results if lo <= r["score"] < hi)
            bar = "█" * count if count <= 50 else "█" * 50 + f" ({count})"
            lines.append(f"  {lo:.1f}-{hi:.1f}: {bar} {count}")
        
        # Per-prompt summary
        lines.append("")
        lines.append("📋 Per-prompt scores (avg across seeds):")
        by_tag = defaultdict(list)
        for r in results:
            by_tag[r["tag"]].append(r["score"])
        for tag in sorted(by_tag.keys()):
            avg = sum(by_tag[tag]) / len(by_tag[tag])
            bar = "🟢" if avg >= self.threshold else "🔴"
            lines.append(f"  {bar} {tag}: avg {avg:.3f}")
        
        lines.append("")
        lines.append("=" * 68)
        if len(passed) / total >= 0.85:
            lines.append("✅ DATASET PASSES — ready for training")
        else:
            pct = len(failed) / total * 100
            lines.append(f"⚠️  {(pct):.0f}% failed — regenerate before training")
        
        return "\n".join(lines)
    
    def save_csv(self, results, csv_path="validation_report.csv"):
        """Save detailed results to CSV."""
        with open(csv_path, "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            w.writerow(["file", "tag", "seed", "total_score", "face_sim",
                        "anatomy", "sharpness", "artifacts", "prompt_match",
                        "passed"])
            for r in results:
                d = r["details"]
                w.writerow([r["file"], r["tag"], r["seed"], r["score"],
                           d.get("face_sim", 0), d.get("anatomy", 0),
                           d.get("sharpness", 0), d.get("artifacts", 0),
                           d.get("prompt_match", 0), r["passed"]])
        print(f"  CSV saved: {csv_path}")


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Validate Phase A dataset")
    parser.add_argument("directory", help="Output directory with generated images")
    parser.add_argument("--ref", default="ref_face_1024.png",
                        help="Reference face image")
    parser.add_argument("--threshold", type=float, default=0.85,
                        help="Quality threshold (default: 0.85)")
    parser.add_argument("--csv", default=None,
                        help="Save CSV report to path")
    parser.add_argument("--weights", type=float, nargs=5,
                        default=[0.45, 0.20, 0.15, 0.10, 0.10],
                        metavar=("FACE", "ANAT", "SHARP", "ARTIF", "PROMPT"),
                        help="Weights: face anatomy sharpness artifacts prompt")
    args = parser.parse_args()
    
    weights = {
        "face_sim": args.weights[0],
        "anatomy": args.weights[1],
        "sharpness": args.weights[2],
        "artifacts": args.weights[3],
        "prompt_match": args.weights[4],
    }
    
    validator = DatasetValidator(args.directory, ref_path=args.ref,
                                  threshold=args.threshold, weights=weights)
    print("🔍 Scanning directory...")
    results = validator.scan()
    
    report = validator.report(results)
    print(report)
    
    if args.csv:
        validator.save_csv(results, args.csv)
