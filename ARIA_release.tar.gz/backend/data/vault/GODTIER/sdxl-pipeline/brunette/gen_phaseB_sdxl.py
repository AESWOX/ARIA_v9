#!/usr/bin/env python3
"""
gen_phaseB_sdxl.py — SDXL Phase B: Body LoRA Dataset
Генерит full body с ControlNet Depth + OpenPose.
Автоматически проверяет similarity через IP-Adapter лицо.

Использование:
  python gen_phaseB_sdxl.py                    # bigLust_v16
  python gen_phaseB_sdxl.py --bigLust           # bigLust_v16
  python gen_phaseB_sdxl.py --sfw-only          # только SFW
  python gen_phaseB_sdxl.py --nsfw-only         # только NSFW
"""
import os, sys, json, yaml, time, random, argparse
from datetime import datetime

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DEFAULT_CONFIG = os.path.join(SCRIPT_DIR, "unified_config_brunette.yaml")

def load_cfg(path=None):
    path = path or DEFAULT_CONFIG
    with open(path) as f:
        return yaml.safe_load(f)

cfg = load_cfg()


def build_body_workflow(seed, pos, cfg, ckpt, pose_type="depth"):
    """
    ControlNet: depth (default) or pose (openpose).
    """
    gen = cfg["generation"]
    hires = cfg["hires_fix"]
    neg = cfg["negative_prompt"]
    loras = cfg["lora_stack"]
    ip = cfg["identity"]["ip_adapter"]
    cn = cfg["phaseB"]["controlnet"]

    if pose_type == "pose":
        cn_model = cn["pose_model"]
        cn_weight = cn["pose_weight"]
    else:
        cn_model = cn["model"]
        cn_weight = cn["weight"]

    nodes = {
        "1": {"class_type": "CheckpointLoaderSimple", "inputs": {"ckpt_name": ckpt}},
        "2": {"class_type": "CLIPSetLastLayer", "inputs": {"clip": ["1", 1], "stop_at_clip_layer": gen["clip_layer"]}},
        "3": {"class_type": "IPAdapterUnifiedLoader", "inputs": {
            "model": ["1", 0], "preset": ip["preset"],
            "ipadapter": ip["model"], "cache_mode": "disabled"
        }},
        "4": {"class_type": "IPAdapterAdvanced", "inputs": {
            "ipadapter": ["3", 0], "model": ["3", 1], "image": ["14", 0],
            "weight": 0.55, "weight_type": "linear", "noise": 0.0,
            "embeds_scaling": "K+V", "start_at": ip["start_at"], "end_at": ip["end_at"]
        }},
        "5": {"class_type": "ControlNetLoader", "inputs": {"control_net_name": cn_model}},
        "6": {"class_type": "CLIPTextEncode", "inputs": {"text": pos, "clip": ["2", 0]}},
        "7": {"class_type": "CLIPTextEncode", "inputs": {"text": neg, "clip": ["2", 0]}},
        "8": {"class_type": "EmptyLatentImage", "inputs": {"width": gen["resolution"][0], "height": gen["resolution"][1], "batch_size": 1}},
        "9": {"class_type": "KSampler", "inputs": {
            "seed": seed, "steps": gen["steps"], "cfg": gen["cfg"],
            "sampler_name": gen["sampler"], "scheduler": gen["scheduler"], "denoise": 1.0,
            "model": ["4", 0], "positive": ["6", 0], "negative": ["7", 0],
            "latent_image": ["8", 0]
        }},
        "14": {"class_type": "LoadImage", "inputs": {"image": cfg["identity"]["reference"]}},
        "15": {"class_type": "SaveImage", "inputs": {"images": ["9", 0], "filename_prefix": ""}},
    }

    # LoRA chain
    prev_model = "1"
    for i, lora in enumerate(loras):
        node_id = str(17 + i)
        nodes[node_id] = {"class_type": "LoraLoaderNode", "inputs": {
            "model": [prev_model, 0], "clip": [prev_model, 1],
            "lora_name": lora["name"],
            "strength_model": lora["weight_model"] * 0.7,  # чуть слабее на body
            "strength_clip": lora["weight_clip"] * 0.7
        }}
        prev_model = node_id

    nodes["3"]["inputs"]["model"] = [prev_model, 0]
    nodes["4"]["inputs"]["ipadapter"] = ["3", 0]
    nodes["4"]["inputs"]["model"] = ["3", 1]

    if hires["enabled"]:
        nodes["10"] = {"class_type": "LatentUpscaleBy", "inputs": {
            "upscale_method": hires["upscale_method"], "scale_factor": hires["scale_factor"],
            "latent": ["9", 0]
        }}
        nodes["11"] = {"class_type": "KSampler", "inputs": {
            "seed": seed + 1, "steps": hires["steps"], "cfg": hires["cfg"],
            "sampler_name": gen["sampler"], "scheduler": gen["scheduler"],
            "denoise": hires["denoise"],
            "model": ["4", 0], "positive": ["6", 0], "negative": ["7", 0],
            "latent_image": ["10", 0]
        }}
        nodes["12"] = {"class_type": "VAEDecode", "inputs": {"samples": ["11", 0], "vae": ["13", 0]}}
        nodes["13"] = {"class_type": "VAELoader", "inputs": {"vae_name": gen["vae"]}}
        nodes["15"]["inputs"]["images"] = ["12", 0]

    return nodes


def submit(api, wf):
    import requests
    r = requests.post(f"{api}/prompt", json={"prompt": wf}, timeout=30)
    r.raise_for_status()
    return r.json().get("prompt_id", "?")


def wait_queue(api, interval=30, max_checks=25):
    import requests
    for i in range(max_checks):
        time.sleep(interval)
        try:
            q = requests.get(f"{api}/queue", timeout=10).json()
            running = len(q.get("queue_running", []))
            pending = len(q.get("queue_pending", []))
            print(f"  [{i*interval+interval}s] running={running} pending={pending}")
            if running == 0 and pending == 0:
                print("  -> Queue empty")
                return
        except Exception as e:
            print(f"  [{i*interval+interval}s] check failed: {e}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default=DEFAULT_CONFIG)
    parser.add_argument("--checkpoint", default="Lustify_apexV8.safetensors")
    parser.add_argument("--bigLust", action="store_true")
    parser.add_argument("--api", default="http://127.0.0.1:8188")
    parser.add_argument("--base-seed", type=int, default=0)
    parser.add_argument("--sfw-only", action="store_true")
    parser.add_argument("--nsfw-only", action="store_true")
    args = parser.parse_args()

    cfg = load_cfg(args.config)
    ckpt = "Lustify_apexV8.safetensors" if args.bigLust else args.checkpoint
    api = args.api
    seed = args.base_seed or int(time.time() * 100) % 999999999
    neg = cfg["negative_prompt"]
    phaseB = cfg["phaseB"]
    n_cand = phaseB["candidates_per_pose"]

    all_jobs = []

    # ── SFW poses ──
    if not args.nsfw_only:
        print(f"\n{'='*60}")
        print(f"PHASE B — Body SFW (ControlNet {phaseB['controlnet']['model']})")
        print(f"{'='*60}\n")
        s = seed
        for pose_cat, prompts in phaseB["poses_sfw"].items():
            for i, p in enumerate(prompts):
                for v in range(n_cand):
                    fname = f"body_sfw_{pose_cat}_{i}_s{v}"
                    wf = build_body_workflow(s, p, cfg, ckpt, "depth")
                    wf["15"]["inputs"]["filename_prefix"] = f"phaseB/{fname}"
                    all_jobs.append((fname, p, s, wf, "depth"))
                    s += 1
                    # второй вариант — OpenPose
                    fname2 = f"body_sfw_{pose_cat}_{i}_{v}_pose"
                    wf2 = build_body_workflow(s, p, cfg, ckpt, "pose")
                    wf2["15"]["inputs"]["filename_prefix"] = f"phaseB/{fname2}"
                    all_jobs.append((fname2, p, s, wf2, "pose"))
                    s += 1

    # ── NSFW poses ──
    if not args.sfw_only:
        print(f"\n{'='*60}")
        print(f"PHASE B — Body NSFW (ControlNet {phaseB['controlnet']['model']})")
        print(f"{'='*60}\n")
        s = seed + 50000
        for pose_cat, prompts in phaseB["poses_nsfw"].items():
            for i, p in enumerate(prompts):
                for v in range(n_cand):
                    fname = f"body_nsfw_{pose_cat}_{i}_s{v}"
                    wf = build_body_workflow(s, p, cfg, ckpt, "depth")
                    wf["15"]["inputs"]["filename_prefix"] = f"phaseB/{fname}"
                    all_jobs.append((fname, p, s, wf, "depth"))
                    s += 1

    print(f"  Submitting {len(all_jobs)} body jobs...")
    for fname, pos, sval, wf, ctype in all_jobs:
        try:
            pid = submit(api, wf)
            print(f"  OK {fname} seed={sval} cn={ctype} pid={pid}")
        except Exception as e:
            print(f"  FAIL {fname}: {e}")

    if all_jobs:
        print(f"\n  -> Waiting queue ({len(all_jobs)} jobs)...")
        wait_queue(api)

        print("  Generating .txt reports...")
        for fname, pos, sval, wf, ctype in all_jobs:
            rpt_path = os.path.join(SCRIPT_DIR, f"{fname}.txt")
            with open(rpt_path, "w") as f:
                f.write(f"===== PHASE B — {fname} =====\n")
                f.write(f"Date: {datetime.now().strftime('%Y-%m-%d %H:%M')}\n")
                f.write(f"Checkpoint: {ckpt}\n")
                f.write(f"ControlNet: {ctype}\n")
                f.write(f"Seed: {sval}\n\n")
                f.write(f"── Positive ──\n{pos}\n\n")
                f.write(f"── Negative ──\n{neg}\n")

    print(f"\n{'='*60}")
    print(f"PHASE B COMPLETE — {len(all_jobs)} images")
    print(f"{'='*60}")


if __name__ == "__main__":
    main()
