---
status: working
tags: [godtier, sdxl-pipeline, brunette]
---
# SDXL Generation Stack — Brunette

> Дата: 2026-07-09  
> Чекпоинт: **Lustify_apexV8** (основной) / **lustify_apexV8** (альтернатива)  
> Референс: `ref_face_1024.png`  
> Папка скриптов: `~/Desktop/WORK/today_gens/`

---

## 📋 Состав стека

| Файл | Назначение |
|------|------------|
| [`prompts_brunette.yaml`](./prompts_brunette.yaml) | **Prompt Library** — 17 emotions + 12 orbitals + 10 hairstyles + 6 bust + 5 styles (все в SDXL-стиле) |
| [`unified_config_brunette.yaml`](./unified_config_brunette.yaml) | Единый конфиг персонажа (checkpoint, LoRA, IP-Adapter, gen params) |
| [`gen_phaseA_sdxl.py`](./gen_phaseA_sdxl.py) | Phase A: загружает промиты из библиотеки, генерит всё через ComfyUI API |
| [`gen_phaseB_sdxl.py`](./gen_phaseB_sdxl.py) | Phase B: генерация тела с ControlNet Depth/OpenPose |
| [`tag_dataset.py`](./tag_dataset.py) | Теггирование датасета (WD14 / Florence-2 / prompt-derived) |
| [`gen_batch7.py`](./gen_batch7.py) | Базовый batch (для справки — lustify_apexV8)

Также:
- [`gen_output/`](../gen_output/README.md) — старые результаты
- [`gen_preview/`](../gen_preview/README.md) — превью

---

## ⚙️ Pipeline

### Phase A — Face LoRA

```bash
# Lustify_apexV8 (основной)
python gen_phaseA_sdxl.py --api http://127.0.0.1:8188

# APEX (альтернатива)
python gen_phaseA_sdxl.py --apex

# Только эмоции / только bust / только orbitals
python gen_phaseA_sdxl.py --emotions-only
python gen_phaseA_sdxl.py --bust-only
python gen_phaseA_sdxl.py --orbitals-only

# Фиксированный seed
python gen_phaseA_sdxl.py --base-seed 424242
```

### Phase B — Body LoRA

```bash
python gen_phaseB_sdxl.py
python gen_phaseB_sdxl.py --sfw-only   # только SFW
python gen_phaseB_sdxl.py --nsfw-only  # только NSFW
```

### Tagging → OneTrainer

```bash
# Prompt-derived (без моделей)
python tag_dataset.py --copy-only

# WD14 (требует onnxruntime + модель)
python tag_dataset.py --wd14

# Florence-2 (требует GPU, transformers)
python tag_dataset.py --florence --max 200
```

Результат: папка `tagged/` с изображениями + `.txt` файлами.

---

## 🔧 Как это работает

### Architecture (ComfyUI API Workflow)

```
ref_face_1024.png
  │
  ▼
CheckpointLoaderSimple [Lustify_apexV8]
  │
  ├─► LoRA: RealSkin_xxXL_v1 @ 0.6
  │     │
  │     └─► LoRA: DetailedEyes_V3 @ 0.5
  │           │
  │           ├─► CLIPSetLastLayer (-2)
  │           │     ├─► CLIPTextEncode (pos)
  │           │     └─► CLIPTextEncode (neg)
  │           │
  │           └─► IPAdapterUnifiedLoader [PLUS FACE]
  │                 │
  │                 └─► IPAdapterAdvanced [0.7 linear, K+V, 0→0.8]
  │                       │
  │                       ▼
  │                 KSampler (30 steps, CFG 6.0, dpmpp_2m_sde + karras)
  │                       │
  │                 LatentUpscaleBy (1.5× bicubic)
  │                       │
  │                 KSampler (22 steps, denoise 0.35)
  │                       │
  │                 VAEDecode [sdxl_vae]
  │                       │
  │                       ▼
  │                 SaveImage
  │
  └─► Dependencies
        - LoRA: RealSkin_xxXL_v1 (skin texture fix)
        - LoRA: DetailedEyes_V3 (eye detail)
        - IP-Adapter: ip-adapter-plus-face_sdxl_vit-h.safetensors
        - VAE: sdxl_vae.safetensors
```

### Key Params

| Параметр | Значение | Причина |
|----------|----------|---------|
| Checkpoint | Lustify_apexV8 | Мягче, лучше для инфлюенсера |
| Resolution | 832×1216 (4:5) | Портретный формат, нет склейки |
| IP-Adapter weight | 0.7 linear K+V | Identity без перекоса стиля |
| IP-Adapter end_at | 0.8 | Отключается на поздних шагах (меньше копирования) |
| Denoise | 0.35 | Меньше артефактов при hires |
| LoRA body | 0.7× face weight | Слабее на body, чтобы не дублировать лицо |
| CLIP layer | -2 | Немного стиля, не только реализм |

### Emotional Block (SDXL Style)

SDXL (особенно Lustify_apexV8) лучше работает с:
- **Короткими промтами** (не T5-длинными как Flux) — 15-25 слов
- **Прямыми описаниями** позы и эмоции
- **Без сложной композиции** — SDXL сам понимает композицию
- **"Detailed skin texture, pores"** — must have для реализма

Сравнение Flux vs SDXL промтов:
```
Flux (legacy): "a young woman with a warm genuine smile, looking directly at the camera with bright eyes..."
SDXL (наш):   "young woman, front facing, direct eye contact with camera, genuine warm smile, detailed skin texture, pores"
```

SDXL короче, без артиклей, через запятую — как в Danbooru-тегах.

---

## 📊 Target Output

### Phase A (Face)
- 17 emotions × 3 seeds = **51 faces**
- 6 bust × 2 seeds = **12 bust**
- 12 orbitals × 2 seeds = **24 orbitals**
- 10 hairstyles × 2 seeds = **20 hairstyles**
- 5 styles × 2 seeds = **10 styles**
- **Total: ~117 images**

### Phase B (Body)
- 6 SFW poses × 2 ControlNet = **24 body**
- 4 NSFW × 2 seeds = **8 body**
- **Total: ~32 images**

### OneTrainer
- Face LoRA: rank 32, LR 1e-4, 12 epochs, trigger: `brunette_face`
- Body LoRA: rank 64, LR 5e-5, 10 epochs, trigger: `brunette_body`

---

## 📁 Структура на RunPod

```
/workspace/output/brunette/
├── phaseA/
│   ├── front_smile_s0_00001_.png
│   ├── front_smile_s0_00001_.txt
│   ├── bust_sfw_0_s0_00001_.png
│   ├── orb_front_0_s0_00001_.png
│   └── ...
├── phaseB/
│   ├── body_sfw_standing_0_s0_00001_.png
│   ├── body_sfw_standing_0_s0_pose.png
│   └── ...
└── tagged/
    ├── phaseA/  (for OneTrainer training)
    └── phaseB/  (for OneTrainer training)

/workspace/dataset/brunette/
├── face/
│   ├── img_001.png
│   ├── img_001.txt
│   └── ...
└── body/
    ├── img_001.png
    ├── img_001.txt
    └── ...
```

---

## 🔄 Команды для RunPod

```bash
# Phase A
cd /workspace && python gen_phaseA_sdxl.py

# Tagging
cd /workspace && python tag_dataset.py --copy-only

# Phase B (после проверки faces)
cd /workspace && python gen_phaseB_sdxl.py

# Copy to OneTrainer
cp -r /workspace/output/brunette/tagged/phaseA/* /workspace/dataset/brunette/face/
cp -r /workspace/output/brunette/tagged/phaseB/* /workspace/dataset/brunette/body/
```
