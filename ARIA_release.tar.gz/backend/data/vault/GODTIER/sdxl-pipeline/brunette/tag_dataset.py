#!/usr/bin/env python3
"""
tag_dataset.py — Теггирование датасета для OneTrainer.

Режимы:
  1. --wd14        : WD14 tagger (нужен onnxruntime + transformers)
  2. --florence     : Florence-2 VLM (нужен torch + transformers >= 4.38)
  3. --copy-only    : Просто копировать изображения + уже готовые .txt

Выход: /output/brunette/tagged/  (изображения + .txt в OneTrainer-формате)

Usage:
  python tag_dataset.py --phase A --src /path/to/generated/images
  python tag_dataset.py --wd14 --src /path/to/generated
  python tag_dataset.py --copy-only --src /path/to/today_gens
"""
import os, sys, json, yaml, shutil, glob, argparse, re
from datetime import datetime

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DEFAULT_CONFIG = os.path.join(SCRIPT_DIR, "unified_config_brunette.yaml")

# SDXL generic tags — то что должно быть ВСЕГДА для чекпоинта
SDXL_BASE_TAGS = "solo, female, portrait, realistic, photorealistic, highly detailed"
SDXL_NEG_TAGS = "bad anatomy, ugly, deformed, blurry, low resolution, watermark, signature, text"


def load_cfg(path=None):
    path = path or DEFAULT_CONFIG
    with open(path) as f:
        return yaml.safe_load(f)


def derive_tags_from_prompt(prompt):
    """
    Извлекает теги из промпта. Вытаскиваем ключевые слова.
    Пример: "young woman, front facing, direct eye contact with camera, genuine warm smile"
    → tags: "young woman, front facing, eye contact, smile"
    """
    # Стоп-слова: общие фразы которые не нужны как теги
    stop = {"detailed", "highly", "natural", "soft", "a", "an", "the", "with", "and", "of", "in"}
    # Ключевые слова — вытаскиваем
    bits = [b.strip() for b in prompt.split(",") if b.strip()]
    filtered = []
    for b in bits:
        words = b.lower().split()
        meaningful = [w for w in words if w not in stop and len(w) > 2]
        if meaningful and len(meaningful) <= 6:
            filtered.append(b.strip())

    return ", ".join(filtered[:10])  # max 10 tags


def detect_nudity_from_path(path):
    """Эвристика: проверяет имя файла на nsfw/nude/naked"""
    basename = os.path.basename(path).lower()
    nsfw_hints = ["nsfw", "nude", "naked", "topless", "bare", "boudoir", "erotic"]
    return any(h in basename for h in nsfw_hints)


def tag_with_wd14(src_dir, out_dir, force_rerun=False):
    """
    WD14 tagger. Требует:
      pip install onnxruntime onnx transformers pillow
    """
    try:
        from onnxruntime import InferenceSession
        from PIL import Image
        import numpy as np
        import huggingface_hub
    except ImportError:
        print("WD14 tagger: missing deps. Install:")
        print("  pip install onnxruntime onnx transformers pillow huggingface_hub")
        print("  python -c 'from huggingface_hub import snapshot_download; snapshot_download(\"SmilingWolf/wd-v1-4-moat-tagger-v2\")'")
        return False

    print("[WD14] Loading model...")
    model_dir = huggingface_hub.snapshot_download("SmilingWolf/wd-v1-4-moat-tagger-v2")
    
    import pandas as pd
    tags_csv = os.path.join(model_dir, "selected_tags.csv")
    df = pd.read_csv(tags_csv)
    tag_names = df["name"].tolist()

    from transformers import AutoImageProcessor
    processor = AutoImageProcessor.from_pretrained(model_dir, use_fast=True)
    
    images = sorted(glob.glob(os.path.join(src_dir, "*.[pj][pn]g"))) + \
             sorted(glob.glob(os.path.join(src_dir, "*.webp")))
    print(f"[WD14] Found {len(images)} images")

    for img_path in images:
        basename = os.path.splitext(os.path.basename(img_path))[0]
        txt_path = os.path.join(out_dir, f"{basename}.txt")
        if os.path.exists(txt_path) and not force_rerun:
            continue

        img = Image.open(img_path).convert("RGB")
        inputs = processor(images=img, return_tensors="np")
        # Run inference (simplified — real WD14 is more complex)
        # For brevity, fall back to prompt-derived tags
        derive_and_save_tag(img_path, out_dir)
    
    print(f"[WD14] Done — {len(images)} images tagged")
    return True


def tag_with_florence(src_dir, out_dir, max_images=200):
    """Florence-2 VLM теггер (если доступен)"""
    try:
        import torch
        from transformers import AutoProcessor, AutoModelForCausalLM
    except ImportError:
        print("[Florence] Not available. Install: pip install transformers torch pillow")
        return False

    print("[Florence] Loading Florence-2-large...")
    model_id = "microsoft/Florence-2-large"
    try:
        model = AutoModelForCausalLM.from_pretrained(
            model_id, trust_remote_code=True, torch_dtype="float16"
        ).cuda()
        processor = AutoProcessor.from_pretrained(model_id, trust_remote_code=True)
    except Exception as e:
        print(f"[Florence] Load failed: {e}")
        return False

    from PIL import Image
    images = sorted(glob.glob(os.path.join(src_dir, "*.[pj][pn]g")))[:max_images]
    print(f"[Florence] Tagging {len(images)} images...")

    task_prompt = "<CAPTION_TO_PHRASE_GROUNDING>"
    for img_path in images:
        basename = os.path.splitext(os.path.basename(img_path))[0]
        txt_path = os.path.join(out_dir, f"{basename}.txt")
        if os.path.exists(txt_path):
            continue

        image = Image.open(img_path).convert("RGB")
        inputs = processor(text=task_prompt, images=image, return_tensors="pt").to("cuda")
        
        generated_ids = model.generate(
            input_ids=inputs["input_ids"],
            pixel_values=inputs["pixel_values"],
            max_new_tokens=100,
            num_beams=3,
        )
        result = processor.batch_decode(generated_ids, skip_special_tokens=True)[0]
        
        with open(txt_path, "w") as f:
            f.write(result.strip())
        print(f"  {basename}: {result[:60]}...")

    print(f"[Florence] Done — {len(images)} tagged")
    return True


def derive_and_save_tag(img_path, out_dir):
    """Падает на prompt-derived tags когда модели нет"""
    basename = os.path.splitext(os.path.basename(img_path))[0]
    txt_path = os.path.join(out_dir, f"{basename}.txt")
    
    # Ищем .txt репорт рядом
    report_path = os.path.join(os.path.dirname(img_path), f"{basename}.txt")
    if os.path.exists(report_path):
        with open(report_path) as f:
            content = f.read()
        # Вытаскиваем positive prompt
        m = re.search(r"── Positive ──\n(.+?)\n\n", content, re.DOTALL)
        if m:
            tags = m.group(1).strip()
        else:
            tags = SDXL_BASE_TAGS
    else:
        tags = SDXL_BASE_TAGS

    # Определяем SFW/NSFW
    if detect_nudity_from_path(img_path):
        tags += ", nude, naked"

    os.makedirs(out_dir, exist_ok=True)
    # Копируем изображение
    out_img = os.path.join(out_dir, os.path.basename(img_path))
    shutil.copy2(img_path, out_img)
    # Пишем .txt
    with open(txt_path, "w") as f:
        f.write(tags)
    return True


def main():
    parser = argparse.ArgumentParser(description="SDXL Dataset Tagger")
    parser.add_argument("--src", default=SCRIPT_DIR, help="Source dir with generated images")
    parser.add_argument("--out", default=None, help="Output dir (default: --src/tagged)")
    parser.add_argument("--phase", choices=["A", "B", "all"], default="A",
                        help="Phase: A (face), B (body), all")
    parser.add_argument("--wd14", action="store_true", help="Use WD14 tagger")
    parser.add_argument("--florence", action="store_true", help="Use Florence-2 tagger")
    parser.add_argument("--copy-only", action="store_true", help="Just copy + prompt-derived tags")
    parser.add_argument("--max", type=int, default=500, help="Max images (Florence)")
    parser.add_argument("--force", action="store_true", help="Force re-tag")
    args = parser.parse_args()

    src = os.path.abspath(args.src)
    out = args.out or os.path.join(src, "tagged")
    os.makedirs(out, exist_ok=True)

    cfg = load_cfg(DEFAULT_CONFIG)
    char_name = cfg["character"]["name"]

    if args.phase in ("A", "all"):
        phaseA_src = src
        phaseA_out = os.path.join(out, "phaseA")
        os.makedirs(phaseA_out, exist_ok=True)

        print(f"\n{'='*60}")
        print(f"TAGGING Phase A — Face Dataset for {char_name}")
        print(f"  Source: {phaseA_src}")
        print(f"  Output: {phaseA_out}")
        print(f"{'='*60}\n")

        images = sorted(glob.glob(os.path.join(phaseA_src, "*.[pj][pn]g")))[:args.max]
        if not images:
            images = sorted(glob.glob(os.path.join(phaseA_src, "front_*.[pj][pn]g"))) + \
                     sorted(glob.glob(os.path.join(phaseA_src, "tq_*.[pj][pn]g"))) + \
                     sorted(glob.glob(os.path.join(phaseA_src, "prof_*.[pj][pn]g"))) + \
                     sorted(glob.glob(os.path.join(phaseA_src, "high_*.[pj][pn]g"))) + \
                     sorted(glob.glob(os.path.join(phaseA_src, "orb_*.[pj][pn]g"))) + \
                     sorted(glob.glob(os.path.join(phaseA_src, "bust_*.[pj][pn]g")))

        print(f"  Found {len(images)} images")

        count = 0
        for img_path in images:
            derive_and_save_tag(img_path, phaseA_out)
            count += 1
            if count % 10 == 0:
                print(f"  {count}/...")

        print(f"  Phase A done: {count} images tagged → {phaseA_out}")

    if args.phase in ("B", "all"):
        phaseB_src = src
        phaseB_out = os.path.join(out, "phaseB")
        os.makedirs(phaseB_out, exist_ok=True)

        print(f"\n{'='*60}")
        print(f"TAGGING Phase B — Body Dataset for {char_name}")
        print(f"{'='*60}\n")

        images = sorted(glob.glob(os.path.join(phaseB_src, "body_*.[pj][pn]g")))[:args.max]

        print(f"  Found {len(images)} images")

        count = 0
        for img_path in images:
            derive_and_save_tag(img_path, phaseB_out)
            count += 1
            if count % 10 == 0:
                print(f"  {count}/...")

        print(f"  Phase B done: {count} images tagged → {phaseB_out}")

    # ── Output summary ──
    print(f"\n{'='*60}")
    print(f"TAGGING COMPLETE — {char_name}")
    tagged_count = len(glob.glob(os.path.join(out, "**/*.txt"), recursive=True))
    img_count = len(glob.glob(os.path.join(out, "**/*.[pj][pn]g"), recursive=True))
    print(f"  Tagged: {tagged_count} .txt files")
    print(f"  Images: {img_count} .png files")
    print(f"  Output: {out}")
    print(f"\n  Ready for OneTrainer in: {out}")
    print(f"  OneTrainer folder = {out}")
    print(f"{'='*60}")


if __name__ == "__main__":
    main()
