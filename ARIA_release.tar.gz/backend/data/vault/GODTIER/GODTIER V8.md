---
created: 2026-06-27
updated: 2026-06-28
tags: [godtier, v8, pipeline, ai-character, sdxl]
source: WORK/WAR333_GODTIER_OMNI/docs/*.md
---

# GODTIER V8

> Пайплайн генерации AI-персонажей. SDXL-only, bigLust_v16 — основа.
> Версия 8 — полный цикл: Stage 0 (препродакшн) → Phase A (обучение) → Phase B (продакшн).

## Трёхфазная архитектура

```
STAGE 0 (ПРЕПРОДАКШН)
  ├── 0.1 Сбор 360° датасета (110+ фото)
  ├── 0.2 Depth Maps + OpenPose экстракция
  ├── 0.3 Face embeddings (InsightFace)
  ├── 0.4 Пост-процессинг датасета (SUPIR → FaceDetailer → чистка)
  ├── 0.5 Captioning (WD14Tagger + Florence2)
  └── 0.6 Character Sheet (3-5 эталонных листа)

PHASE A (ОБУЧЕНИЕ LoRA)
  ├── A.1 Face LoRA (rank=32, 20-30 эпох)
  ├── A.2 Body LoRA (rank=64, 15-20 эпох)
  ├── A.3 Style LoRA / Emotion LoRA (опционально)
  ├── A.4 DMD2 LoRA (8 шагов, CFG=1)
  └── A.5 Тестовая валидация (10 промптов SFW+NSFW)

PHASE B (ПРОДАКШН)
  ├── B.1 Multi-ControlNet генерация (Depth+OpenPose+Canny)
  ├── B.2 Face preservation (PuLID+IP-Adapter+FaceDetailer — 3 слоя)
  ├── B.3 LoRA Stack (лицо+тело+skin+hands+body_slider+nsfw+dmd2)
  ├── B.4 Пост-процессинг (SUPIR→FaceDetailer→Detail Daemon→Clarity→FaceFusion)
  ├── B.5 Спецэффекты (тату/пирсинг/дреды)
  ├── B.6 Видео (WAN2.1 + PuLID + TeaCache)
  └── B.7 Авто-постинг (n8n/browser-use/ECC)
```

## Чекпоинты (SDXL ONLY)

| Модель | Размер | Назначение | Статус |
|--------|--------|-----------|--------|
| **bigLust_v16** 🏆 | 6.6GB | **Лучший для всего**: SFW, NSFW, Futa, GFE | ✅ |
| lust1 | 6.6GB | NSFW (⚠️ **БИТЫЙ** — не использовать) | ❌ |
| insta1 | 6.6GB | Instagram-стиль | ✅ |
| zt3 | 11.7GB | ZImageTurbo (быстрые gen) | ⬜ |
| klein3 | 17.3GB | Flux.2 Klein (макс качество, медленно) | ⬜ |
| eryn1 | 15.3GB | Ernie (новая архитектура) | ⬜ |

## LoRA Stack (новые из Deploy Plan)

| LoRA | ⭐ | Назначение | Вес |
|------|---|-----------|-----|
| char_face_lora | — | Лицо персонажа | 0.6-0.8 |
| char_body_lora | — | Тело персонажа | 0.4-0.6 |
| hands_xl | 289K | Качество рук | 0.6-0.8 |
| realistic_skin_texture | 166K | Детализация кожи | 0.4-0.6 |
| body_type_slider_pony_v1 | 70.9K | Контроль телосложения | 0.5-1.0 |
| nsfw_master | 202K | Усиление NSFW | 0.5-0.8 |
| dmd2_lora | — | 8-шаговая генерация | 1.0 |
| aesthetic_quality_modifiers | 127K | Эстетика (⚠️ проверить SDXL) | 0.6-1.0 |

## Baseline параметры (из тестов CivitAI)

| Параметр | SDXL Production | DMD2 (быстрая) |
|---|---|---|
| **Sampler** | **DPM++ 2M SDE** ❗ | dpmpp_2m_sde_gpu |
| **Steps** | **50** ❗ | 4-8 |
| **CFG** | **7** ❗ | 1.0 |
| **Resolution** | **1024×1496** ❗ | 1024×1496 |
| LoRA | none (для начала) | DMD2 @ 1.0 |

> ⚠️ **Три главные ошибки:** 1) Без SDE кожа пластиковая. 2) 25 шагов не хватает — нужно 50. 3) CFG 4.5 слишком низкий — 7 даёт контраст.

## Новые инструменты (из V8 Deploy Plan)

| Инструмент | ⭐ | Замена |
|---|---|---|
| **FaceFusion** | 28.8K | CodeFormer (не обновлялся с 2022) |
| **Clarity Upscaler** | 5K | SUPIR (тяжёлый, 6GB) |
| **ECC (everything-claude-code)** | 116K | Агент-харнес |
| **Free Claude Code** | 18.8K | Бесплатный Claude API |
| **Crawl4AI** | 67.4K | Веб-краулер |

## Deploy стратегия

| Вариант | Время | Описание |
|---|---|---|
| Golden archive + sync | **~12-15 мин** ⚡ | b2 download golden_pod_light.tar.gz + b2 sync чекпоинтов |
| Docker образ | **~4-5 мин** 🚀 | Свой шаблон на RunPod со всем внутри |
| Постоянный под 24/7 | **2 мин** 🎯 | ComfyUI уже запущен, модели загружены |

## Структура на B2 (ALEX.STORAGE)

```
ALEX.STORAGE:
├── models/
│   ├── checkpoints/       # bigLust_v16, insta1...
│   ├── loras/              # hands_xl, skin_texture, body_slider, nsfw_master...
│   ├── controlnet/         # depth, openpose, canny, tile, ip-adapter-faceid
│   ├── upscalers/          # SUPIR, 4x-UltraSharp, Clarity_Upscaler
│   ├── face_tools/         # pulid, insightface, facefusion
│   └── video/              # Wan2.1, pulid_flux
├── training/{character}/
│   ├── face/
│   ├── body/
│   └── style/
├── output/{character}/{date}/
│   ├── raw/
│   ├── upscaled/
│   └── final/
└── workflows/
```

## Замены устаревших компонентов

| Было | Проблема | Стало |
|---|---|---|
| CodeFormer (GFPGAN) | Не обновлялся с 2022 | **FaceFusion** ⭐28.8K |
| SUPIR только | Тяжёлый, 6GB | **Clarity Upscaler** ⭐5K |
| ControlNet 1.0 | Архив 3 года | ControlNet-v1-1 |
| A1111 | Последний релиз Feb 2025 | ComfyUI v0.25.0+ |

## Тестовые персонажи
1. **Girl** — 832×1216 (→ 1024×1496)
2. **Milf** — 832×1216 (→ 1024×1496)
3. **Trans** — 832×1216 (→ 1024×1496)

## Связи
- [[GODTIER V8 Workflow Spec]] — полный workflow с нодами
- [[GODTIER V8 Project Spec]] — проект мониторинга
- [[ComfyUI]] — рендер-движок
- [[STACK/RunPod-Playbook]] — GPU поды
- [[B2 Storage]] — чекпоинты
- [[COMFY-KB/models/checkpoints/bigLust_v16]] — модель
- [[Loop-Engineering]] — пайплайн как loop
- [[AI Видео Генерация]] — видео-модели
