---
created: 2026-06-29
tags: [ai-influencer, lora, pipeline, production, controlnet, deploy]
---

# AI Influencer Production Pipeline — Full Report

> Полный пайплайн создания AI-персонажа от генерации до продакшна.
> **Цель:** 2 LoRA (face + body) на персонажа, ControlNet-only (без PuLID), полный цикл < 3 часов.
> **GPU:** A5000 ($0.16/h), ComfyUI + OneTrainer

---

## ═══════ ФАЗА 0: СТЕК ═══════

### Чекпоинт: Lustify_apexV8 (6.5GB)
**Лучший для:** лиц, анатомии, NSFW, детализации кожи

### Базовые параметры генерации
| Параметр | Production | Быстрый тест |
|----------|-----------|-------------|
| Семплер | **dpmpp_2m_sde** | lcm |
| Steps | **50** | 8 |
| CFG | **7** | 1 |
| Resolution | **1024×1496** | 1024×1496 |
| LoRA | None (база) | DMD2 @ 1.0 |

---

## ═══════ ФАЗА 1: LoRA СТЕК ═══════

### 2-фазное обучение (на персонажа)

```
ФАЗА A: Face LoRA (rank 32, 5-10 эпох)
  Датасет: 50-100 крупных планов лиц (1024×1024)
  Цель: консистентное лицо во всех ракурсах

ФАЗА B: Body LoRA (rank 64, 10-20 эпох)  
  Датасет: 100-200 full-body (1024×1496 или 1024×1024)
  ⚠️ Face LoRA заморожен во время Body training
  Цель: консистентное тело, одежда, позы

РЕЗУЛЬТАТ: 2 LoRA на персонажа (face + body) → НЕ МЕРЖИТЬ
```

### Параметры обучения (OneTrainer)

| Параметр | Face LoRA | Body LoRA |
|----------|-----------|-----------|
| **Rank** | 32 | 64 |
| **Alpha** | 32 | 64 |
| **Эпохи** | 5-10 | 10-20 |
| **LR** | 2e-4 (AdamW) | 1.5e-4 (AdamW) |
| **Resolution** | 1024×1024 | 1024×1024 или 1024×1536 |
| **Batch size** | 4 | 4 |
| **Оптимизатор** | AdamW8bit | AdamW8bit |
| **LR scheduler** | cosine + 10% warmup | cosine + 10% warmup |
| **Датасет** | 50-100 лиц | 100-200 фулбоди |

### Инференс — LoRA порядок и веса

| # | LoRA | Вес | Зачем |
|---|------|-----|-------|
| 1 | **Face LoRA** (твой) | **0.8-1.0** | 🏆 Лицо персонажа |
| 2 | **Body LoRA** (твой) | **0.6-0.9** | 🏆 Тело, одежда |
| 3 | **Hand XL v5.5** | 0.4-0.7 | Руки (без кошмаров) |
| 4 | **Skin Texture XL v4** | 0.3-0.5 | Кожа не пластик |
| 5 | **Touch of Realism V2** | 0.4-0.6 | Фотореализм |
| 6 | **Add Detail Slider** | 0.3-0.5 | Мелкие детали |
| 7 | **Detailed Perfection** | 0.2-0.4 | Опционально |
| 8 | **DMD2** | 0.3-0.6 | Быстрая генерация |

> **Золотое правило:** Если стак >3 LoRA — снижать каждый вес на 20-30%

---

## ═══════ ФАЗА 2: ПОСТ-ПРОДАКШН ═══════

### PuLID vs ControlNet — вердикт

| Техника | Консистенция лица | Когда использовать |
|---------|------------------|-------------------|
| **PuLID SDXL** | ⭐⭐⭐⭐⭐ Идеально | Тяжёлые позы, профиль, далёкие планы |
| **IP-Adapter FaceID v2** | ⭐⭐⭐⭐ Хорошо | **Рекомендовано (без PuLID)** |
| **FaceDetailer** | ⭐⭐⭐ Средне | Только пост-процессинг, не айдишник |
| **ControlNet один** | ⭐ Не работает | Не может лицо, только позу |

### ✅ ПОЗЫ + ЛИЦО (без PuLID)

```yaml
ControlNet Union ProMax (3 слоя):
  Depth:    weight 0.75, start 0.0, end 0.9  # форма тела
  OpenPose: weight 0.85, start 0.0, end 0.95 # поза, руки
  Canny:    weight 0.30, start 0.2, end 0.8  # края (опционально)

IP-Adapter FaceID Plus v2:  weight 0.85  # лицо персонажа

FaceDetailer (Impact Pack):
  detector: yolov8x-face  # детектор лиц
  denoise:  0.30          # не > 0.35 иначе лицо меняется
  guide_size: 512
  force_inpaint: true
```

### Апскейлеры — сравнение

| Комбо | Детализация | Лицо | Скорость |
|-------|------------|------|----------|
| **4x-UltraSharp + FaceDetailer** ⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐ | Быстро |
| SUPIR + FaceDetailer | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | **Очень медленно** |
| Clarity Upscaler | ⭐⭐⭐ | ⭐⭐ | Мгновенно |

**Рекомендация:** 4x-UltraSharp (2048×2992) → FaceDetailer (denoise 0.3)

---

## ═══════ ФАЗА 3: ПАЙПЛАЙН ТРЕНИРОВОК ═══════

### Датасет (150 изображений)

| Категория | Кол-во | Что |
|-----------|--------|-----|
| **SFW Портреты** | 30 | Фронт, ¾, профиль, разные эмоции |
| **SFW Bust** | 20 | Грудь+лицо, разные наряды |
| **SFW Full body** | 25 | Стоя, сидя, лёжа |
| **SFW Орбитали** | 10 | 8 ракурсов вокруг |
| **SFW Причёски** | 10 | 3-4 причёски |
| **SFW Аксессуары** | 5 | Очки, шляпы |
| **NSFW Бельё** | 15 | Полупрозрачное |
| **NSFW Topless** | 12 | Грудь |
| **NSFW Full nude** | 13 | Полностью |
| **NSFW Позы** | 10 | Специфические |
| **TOTAL** | **150** | **65% SFW + 35% NSFW** |

### Автотаггинг (WD14 Tagger)

```bash
# Формат: Danbooru-style, comma-separated
# Пример: 1girl, blonde hair, blue eyes, smile, portrait, 
#          looking at viewer, detailed background
# OneTrainer читает из image_name.txt рядом с image.png

# Запуск:
wd14-tagger --input_dir /data/dataset \
  --output_dir /data/tagged \
  --general_threshold 0.35 \
  --character_threshold 0.85 \
  --remove_underscore
```

---

## ═══════ ФАЗА 4: ВРЕМЯ И ДЕНЬГИ ═══════

### Расписание (на персонажа)

| Операция | Время | GPU | Стоимость |
|----------|-------|-----|-----------|
| Генерация 150 gen (batch 4) | **5 мин** | A5000 | $0.013 |
| WD14 таггинг 150 img | **2.5 мин** | CPU | $0.007 |
| Face LoRA (rank 32, 30 эпох) | **84 мин** 🏆 | A5000 | $0.225 |
| Body LoRA (rank 64, 20 эпох) | **65 мин** | A5000 | $0.173 |
| Upload + overhead | **12 мин** | — | $0.032 |
| **Тотал** | **~2.8 часа** ✅ | **A5000** | **$0.45** 🏆 |

### Масштабирование

| Персонажей | Часов | Стоимость | Времени |
|-----------|-------|-----------|---------|
| 1 | 2.8 | **$0.45** | 1 день |
| 5 | 14 | **$2.25** | 2 дня |
| 10 | 28 | **$4.50** | 3-4 дня |
| 20 | 56 | **$9.00** | неделя |

> **$0.45 за готового AI-инфлюенсера (2 LoRA + 150 gen + таги)**

---

## ═══════ ФАЗА 5: ИНФРАСТРУКТУРА ═══════

### 3-функциональный под

```yaml
Образ: кастомный Docker (golden-deploy)
Размер: 10-12GB (CUDA + Python + OneTrainer + ComfyUI + rclone)

Жизненный цикл:
  1. Pod стартует → golden_deploy.sh (2 мин)
  2. ComfyUI: генерация датасета (5 мин)
  3. WD14: таггинг (2.5 мин)
  4. OneTrainer: Face LoRA (84 мин)
  5. OneTrainer: Body LoRA (65 мин)
  6. rclone upload на B2 (2 мин)
  7. curl DELETE API → автотерминейт (потери 0)
  
Скрипт: entrypoint.sh — запускает фазы последовательно
На выходе: 2 LoRA + 150 gen + таги → на B2
```

### Deploy время (сравнение)

| Метод | Время | Статус |
|-------|-------|--------|
| 🚀 **Golden archive (текущий)** | **~2 мин** | ✅ Готов |
| Docker образ (будущее) | ~10 сек (pull) + 30 сек init | 🟡 В планах |
| С нуля (deploy.sh) | ~40 мин | ❌ Не используем |

---

## ═══════ ФАЗА 6: НОД ГРАФ ═══════

### Production граф (без PuLID)

```
1. Load Checkpoint (Lustify_apexV8)
2. CLIP Text Encode (промпт)
3. IP-Adapter FaceID v2 (вес 0.85, ref face)
4. ControlNet Union ProMax × 3:
   - Depth (0.75, 0.0-0.9)
   - OpenPose (0.85, 0.0-0.95)  
   - Canny (0.3, 0.2-0.8)
5. LoRA Stack (face 0.9 + body 0.7 + hand 0.5 + skin 0.3 + ...)
6. KSampler (dpmpp_2m_sde, 50 steps, CFG 7)
7. 💾 Save Image (1024×1496)
8. ⬆️ 4x-UltraSharp (2048×2992)
9. 🔍 FaceDetailer (yolov8x, denoise 0.3)
10. 💾 Save Image final (2048×2992)
```

---

## ═══════ ИТОГИ ═══════

### ✅ Что готово сейчас

| Компонент | Статус |
|-----------|--------|
| Golden archives на B2 | ✅ base (229MB) + nodes (144MB) ✅ |
| Models upload | ⏳ 24GB льётся |
| Golden deploy script | ✅ `WORK/ШОТ/golden_deploy.sh` |
| 30 test images on B2 | ✅ `gen_tests/2026-06-29/` |
| Best config identified | ✅ Lustify_apexV8 + dpmpp_2m_sde + 50 steps + CFG 7 |
| Vault report | ✅ `SDXL Test Report 29 June.md` |
| Skill: golden-deploy | ✅ Создан |

### 🟡 Что нужно доделать

1. **Скачать Hand XL / Skin Texture / Touch of Realism LoRA** — CivitAI блокирует RunPod IP, нужно через браузер или локально
2. **OneTrainer архив** — установить на под и создать golden_ot.tar.zst
3. **Docker образ** — для деплоя за 10 сек вместо 2 мин
4. **Использовать bigLust_v16** — основная production модель
5. **Проверить работу face LoRA + body LoRA вместе** — после первого обучения

### 📊 Итоговая стоимость AI-инфлюенсера

```
Расходы на персонажа:
  Генерация:     $0.013  (5 мин A5000)
  Обучение:      $0.398  (2.5 часа A5000)  
  Загрузка:      $0.032  (2 мин)
  ─────────────────────────
  ИТОГО:         $0.45  ✅ < 50 центов!

Доход (Fanvue/Clips4Sale/TG):
  50 подписчиков × $10/мес = $500/мес
  ROI: 1 подписчик = 111 персонажей ⚡
```

---

## Связи
- [[STACK/SDXL Test Report 29 June]] — качество генераций
- [[Golden Deploy]] — быстрый деплой
- [[COMFY-KB/models/checkpoints/bigLust_v16]] — чекпоинт
- [[B2 Storage]] — bucket
- skill: `golden-deploy` — процедура
- [[GODTIER V8]] — пайплайн версия 8
