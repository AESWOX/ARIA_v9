---
status: working
tags: [godtier]
---
# Golden InstantID — Full Restore Guide
## Date: 2026-07-06

## What's in golden_instantid.tar.gz (562MB)
```
custom_nodes/          — ComfyUI_InstantID, ComfyUI-Impact-Pack, ComfyUI_IPAdapter_plus, 
                         ComfyUI-Detail-Daemon, PuLID_ComfyUI, etc WITH all patches
models/onnx/           — face_yolov8m.onnx (YOLOv8m face for FaceDetailer)
models/insightface/    — antelopev2 (glintr100) + buffalo_l models
models/ultralytics/    — face_yolov8m.onnx
input/                 — blonde_ref.png
output/                — ALL generated images (72+ PNGs)
user/                  — ComfyUI settings
```

## Models to download SEPARATELY (on B2 already):
| Model | Location | Size |
|-------|----------|------|
| Lustify_apexV8 | b2:ALEX.STORAGE/models/sdxl/checkpoints/ | 6.5GB |
| Lustify_apexV8 | b2:ALEX.STORAGE/models/sdxl/checkpoints/ | 6.5GB |
| ip-adapter.bin | b2: (downloaded from HF) | 1.6GB |
| instantid_controlnet.safetensors | b2: (downloaded from HF) | 2.5GB |
| ip-adapter-faceid-plusv2_sdxl.bin | b2: (downloaded from HF) | 1.4GB |
| ip-adapter-faceid-plusv2_sdxl_lora.safetensors | b2: (downloaded from HF) | 355MB |
| sdxl_vae.safetensors | b2:ALEX.STORAGE/models/sdxl/vae/ | 335MB |

## Applied Patches (included in archive):
1. `custom_nodes/ComfyUI_InstantID/InstantID.py:217` — FaceAnalysis name="antelopev2", providers=["CPUExecutionProvider"]
2. `custom_nodes/ComfyUI-Impact-Pack/modules/impact/impact_onnx.py` — +YOLO patch (auto-detect YOLO format)
3. `custom_nodes/ComfyUI-Impact-Pack/modules/impact/yolo_patch.py` — YOLO inference handler
4. `custom_nodes/PuLID_ComfyUI/pulid.py:240` — providers=["CPUExecutionProvider"]

## Restore Steps:
```bash
# 1. Deploy fresh RunPod pod (template 2lv7ev3wfp)
# 2. Restore ComfyUI
rclone copy b2:ALEX.STORAGE/deploy_bundle/golden_instantid.tar.gz /tmp/
tar xzf /tmp/golden_instantid.tar.gz -C /workspace/runpod-slim/ComfyUI/

# 3. Download checkpoints
rclone copy b2:ALEX.STORAGE/models/sdxl/checkpoints/Lustify_apexV8.safetensors /workspace/runpod-slim/ComfyUI/models/checkpoints/
rclone copy b2:ALEX.STORAGE/models/sdxl/checkpoints/Lustify_apexV8.safetensors /workspace/runpod-slim/ComfyUI/models/checkpoints/

# 4. Download remaining models from HF (use HF_TOKEN from APY/)

# 5. Start ComfyUI
cd /workspace/runpod-slim/ComfyUI
python3 main.py --listen 0.0.0.0 --port 8188 --highvram --enable-manager
```

## Best Settings (as of 2026-07-06):
```
Identity:       InstantID (ip=1.0, cn=0.7) + FaceID Plus v2 (ip=0.5, fid=1.2)
Checkpoint:     Lustify_apexV8
Size:           832x1216
Sampler:        dpmpp_2m_sde / karras, 30 steps
CFG:            4.0
Prompt:         нейтральный (без blue eyes / blonde hair)
Negative:       deformed, blurry face, bad anatomy, extra limbs, ugly, low quality, cartoon, 3d render
```

## Running Scripts (on pod):
```bash
python3 -u /workspace/bootstrap_block1.py   # Block 1 - Orbital angles
python3 -u /workspace/gen_dataset_bootstrap.py  # Full dataset
python3 -u /workspace/faceid_tune.py        # Weight tuning
```

## B2 Backup Structure:
```
b2:ALEX.STORAGE/
  deploy_bundle/
    golden_instantid.tar.gz     — ComfyUI + configs + PNGs (562MB)
    golden_comfyui.tar          — Full original ComfyUI (53.7GB)
  backups/
    2026-07-06/
      work_archive.tar.gz       — Scripts + docs + gen_output (41MB)
      scripts_pod.tar.gz        — Pod scripts (2.2KB)
  models/sdxl/checkpoints/      — Lustify_apexV8
  models/sdxl/ipadapter/        — IP-Adapter models
  models/sdxl/pulid/            — PuLID models
  models/sdxl/vae/              — VAE models
  models/shared/face_detect/    — face_yolov8m.pt
```
