---
status: working
tags: [godtier]
---
# 2026-07-06 — SDXL Face LoRA Bootstrap Project (Part 1)

## Цель
Обучение character LoRA на базе одного референса (blonde_ref.png) для жёсткого Identity Lock без InstantID/IP-Adapter во время inference.

## Референс
- **Файл:** `blonde_ref.png`
- **Описание:** блондинка, серо-голубые глаза, мягкие черты, нюдовые губы, естественная кожа

## Рабочий стек генерации датасета
```
Generator:     ComfyUI v0.26.2 (RTX 3090, RunPod $0.22/h)
Checkpoint:    Lustify_apexV8.safetensors (6.5GB)
VAE:           sdxl_vae.safetensors
CLIP skip:     -2

Identity 1 — InstantID (cubiq):
  ModelLoader:    ip-adapter.bin (1.6GB)
  FaceAnalysis:   antelopev2 → glintr100 (CPU)
  ControlNet:     instantid_controlnet.safetensors (2.5GB)
  Apply:          ApplyInstantIDAdvanced
                  ip_weight=1.0, cn_strength=0.7
                  start_at=0.0, end_at=0.9

Identity 2 — IP-Adapter FaceID Plus v2:
  Loader:         IPAdapterUnifiedLoaderFaceID → FACEID PLUS V2
  LoRA:           ip-adapter-faceid-plusv2_sdxl_lora.safetensors (355MB)
  Model:          ip-adapter-faceid-plusv2_sdxl.bin (1.4GB)
  InsightFace:    antelopev2
  IPAdapterFaceID: weight=0.5, weight_faceidv2=1.2, embeds_scaling=V only

Generation:
  Size:           832×1216
  Sampler:        dpmpp_2m_sde / karras
  Steps:          30
  CFG:            4.0
  NS:             нейтральный (без blue eyes / blonde hair в промпте)
```

## Промпт-шаблон
```
Positive: masterpiece, best quality, beautiful blonde woman, [ANGLE], [EMOTION], 
          detailed face, realistic skin texture, [LIGHTING], [HAIR], 
          looking at viewer, sharp focus, 8k

Negative: deformed, blurry face, bad anatomy, extra limbs, ugly, low quality, 
          cartoon, painting, 3d render, plastic skin, overexposed, underexposed
```

### Категории генерации

**Углы:** straight on, 3/4 left/right, side profile left/right, low angle, high angle, over the shoulder, dynamic orbit

**Эмоции:** neutral, soft smile, wide smile, serious, seductive, surprised, angry, sad, flirty wink, confident

**Причёски:** loose natural, sleek straight, wavy, ponytail, messy bedhead, wet hair, braids, windblown

**Освещение:** soft window, golden hour, dramatic side, studio softbox, rim lighting, moody low key, harsh sunlight, candlelight

## План действий
1. ✅ Настроен стек InstantID + FaceID Plus v2
2. ❏ Генерация 40-60 сырых изображений (bootstrap)
3. ❏ Жёсткий отбор 25-40 лучших
4. ❏ Капшенинг через BLIP + ручная правка
5. ❏ Regularization images 80-150
6. ❏ Тренировка LoRA (Kohya_ss/OneTrainer)
7. ❏ Тестирование

## Текущий статус тестов identity
| Дата | Комбинация | Результат |
|------|-----------|-----------|
| 6 июл | IP-Adapter Plus Face + CLIP Vision | "похоже, но не тот же человек" |
| 6 июл | InstantID + buffalo_l | несовместимый эмбеддинг |
| 6 июл | InstantID + antelopev2 | лучше, но стиль чекпоинта |
| 6 июл | InstantIDAdvanced ip=1.0 cn=0.8 CFG=4.0 | ближе, губы/глаза уплывают |
| 6 июл | InstantIDAdvanced ip=1.0 cn=1.0 | структурно лучше, стиль Lustify |
| 6 июл | FaceID v2 + InstantID cn=0.7 | ✅ рабочая комбинация |
| 6 июл | FaceID v2 ip=0.5 fid=1.2 — лучший баланс | ✅ фикс для датасета |
