---
created: 2026-07-14
updated: 2026-07-14
tags: [database-index, master]
---

# Story Database — Мастер-индекс

## 🔹 Ветка SOLO (600 шт)

### MIA (милфа, 33)
| ID | Название | Локация | Паттерн | Файл |
|----|----------|---------|---------|------|
| MIA-SO-008 | «Паркинг» | Машина, подземный паркинг | Almost Caught | Car/ |
| MIA-SO-009 | «Сверхурочные» | Пустой офис | Timed Risk | Office-Study/ |

### SASHA (дочка, 22)
| ID | Название | Локация | Паттерн | Файл |
|----|----------|---------|---------|------|
| SASHA-SO-008 | «Находка» | Спальня | First Discovery | Bedroom/ |
| SASHA-SO-009 | «Скамейка» | Городской парк | Public Risk | Outdoor/ |

### NADIA (транс, 28)
| ID | Название | Локация | Паттерн | Файл |
|----|----------|---------|---------|------|
| NADIA-SO-003 | «Зеркало» | Спальня | Ritual / Prep | Trans/ |
| NADIA-SO-004 | «Уборная» | Клуб | Extreme Risk | Trans/ |

## 🔸 Ветка LESBIAN (200 шт) — 🚧 пусто
_Ожидает генерации. Приоритет: MIA+SASHA._

## 🔹 Ветка GIRL+TRANS (200 шт) — 🚧 пусто
_Ожидает генерации. Приоритет: NADIA+MIA/SASHA._

---

## Поиск по тегам

**По персонажам:** `#mia` `#sasha` `#nadia`
**По веткам:** `#solo` `#lesbian` `#girl-trans`
**По локациям:** `#car` `#office` `#park` `#bedroom` `#club` `#bathroom`
**По паттернам:** `#almost-caught` `#first-time` `#public-risk` `#ritual` `#extreme-risk`
**По игрушкам:** `#toy` `#dildo` `#vibrator` `#plug`
**По-русски:** `#миа` `#саша` `#надия` `#соло`
