---
created: 2026-07-14
tags: [database, top50, best-of]
---

# Топ-50 Самых Сильных Сюжетов

**Критерии отбора:**

1. ⭐⭐⭐⭐⭐ Risk/Excitement factor
2. ⭐⭐⭐⭐⭐ Visual potential (best for AI generation)
3. ⭐⭐⭐⭐⭐ Uniqueness (not generic)
4. ⭐⭐⭐⭐⭐ Series potential (can be expanded)
5. ⭐⭐⭐⭐⭐ Hook power (first 10 frames grab attention)

---

## Распределение топ-50

| Категория | Количество |
|-----------|-----------|
| Solo | 25 |
| Lesbian | 15 |
| Trans | 10 |

---

*Будет заполнен после генерации базы.*
