---
created: 2026-07-14
tags: [database, tags, search, filter, INDEX]
---

# Теги для поиска — Tag System

## Иерархия тегов

### Категория
- `#solo` `#lesbian` `#trans` `#futanari` `#femboy` `#threesome` `#group`

### Подкатегория
- `#home-tease` `#risky-public` `#car` `#balcony` `#elevator`
- `#office` `#outdoor` `#mirror` `#selfie` `#innocent-to-slutty`
- `#roommates` `#stepsisters` `#college` `#best-friends`
- `#secret-girlfriend` `#reveal` `#dom-trans` `#sub-trans`

### Риск
- `#low-risk` `#medium-risk` `#high-risk` `#extreme-risk`

### POV
- `#pov` `#hidden-cam` `#cctv` `#selfie` `#third-person`

### Внешность
- `#blonde` `#brunette` `#redhead` `#asian` `#latina` `#eastern-european`
- `#alternative` `#tattooed` `#natural` `#freckles` `#glasses`

### Тело
- `#petite` `#athletic` `#curvy` `#slim` `#hourglass` `#tall`

### Характер
- `#shy` `#playful` `#dominant` `#bratty` `#loving` `#manipulative`
- `#nervous` `#confident` `#mischievous` `#sweet`

### Элементы
- `#exhibitionism` `#voyeurism` `#cheating` `#toys` `#strapon`
- `#bondage` `#spanking` `#roleplay` `#uniform` `#cosplay`
- `#lingerie` `#naked` `#panties` `#stockings` `#heels`

### Локации
- `#bedroom` `#bathroom` `#kitchen` `#living-room` `#balcony`
- `#rooftop` `#car` `#elevator` `#office` `#fitting-room`
- `#pool` `#beach` `#forest` `#parking-lot` `#hotel` `#airbnb`

---

## Поисковые запросы

Примеры:
- `#solo #high-risk #pov #exhibitionism` → самые острые сюжеты
- `#lesbian #risky-public #brunette` → лесби в публичных местах
- `#trans #dom-trans #reveal` → доминантные транс с reveal
