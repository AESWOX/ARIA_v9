---
created: 2026-07-14
updated: 2026-07-14
tags: [research, trends, analysis, methodology]
---

# TREND-RESEARCH — Аналитика Трендов

**Назначение:** Исследовательская база для контент-стратегии
**Методология:** 3 parallel subagents + прямые curl запросы + Pornhub Insights data

---

## Файлы

| Файл | Что содержит | Статус |
|------|-------------|--------|
| [[CONTENT/TREND-RESEARCH/2026-porn-trends-analysis]] | Pornhub Insights 2025-2026: категории, поиск, демография | ✅ |
| [[CONTENT/TREND-RESEARCH/viral-format-catalog]] | Топ-30+ виральных форматов и story templates | ✅ Complete (subagent #2) |
| [[CONTENT/TREND-RESEARCH/studio-archetype-catalog]] | **✅ Complete** — Brazzers, Vixen, BangBros, TeamSkeet, Naughty America, RealityKings — 60+ archetypes |
| [[CONTENT/TREND-RESEARCH/site-inventory-analysis]] | Топ-20+ порносайтов: traffic, ниши, тренды | ✅ Complete (SimilarWeb) |

---

## Ключевые находки (предварительно)

### Пересечение категорий — что растёт одновременно:

```
Role Play (+98%) + Office (+62%) + Boss (+175%) = Power Dynamics контент
Lesbian #1 + Trans #2 (+5) + Femboy в топ-10 = LGBTQ+ доминирует
Amateur тренд + Risky Public = почти поймали
POV + Podcast (+327%) + Gaming (+283%) = Immersive контент
```

### Формула вирального сюжета:

```
Girl Next Door + Innocent Face + Public Location + Risk of Being Caught + POV
```

---

## Методология исследования

### Источники данных:

| Tier | Тип | Доступность |
|------|-----|-------------|
| 🟢 | Pornhub Insights (WP blog) | ✅ ДАННЫЕ ЕСТЬ |
| 🟡 | XVideos / XNXX tags | Через curl (SPA — может не работать) |
| 🟡 | SimilarWeb traffic | Через curl |
| 🔴 | OnlyFans / Fanvue internal | Недоступны |
| 🟡 | Industry reports | Через web_search |
| 🟢 | Subagent analysis | ✅ Dispatched (3 parallel) |

### Что ждём от subagent #1:
- Топ-20+ сайтов с traffic rank
- Категории каждого сайта
- Trend metadata

### Что ждём от subagent #2:
- Виральные паттерны: локации, архетипы, risk dynamics
- Конкретные цифры по категориям
- Продолжительность видео, first-frame hook

### Что ждём от subagent #3:
- Каталог студийных форматов (30+)
- Характерные dynamics, dialogue hooks
- Pacing структуры
