---
created: 2026-07-14
updated: 2026-07-14
tags: [content, stories, database, ai-influencer]
---

# CONTENT — Контент-Стратегия и База Сюжетов

**Ветка:** 10-я архитектурная ветка
**Назначение:** Производство контента — от сюжетов до готовых видео для AI-инфлюенсеров
**Цель:** База 1000 порно-сюжетов (2026) для генерации через Lora моделей AI-инфлюенсеров + ComfyUI/SDXL

---

## Содержание ветки

| Раздел | Что содержит | Статус |
|--------|-------------|--------|
| [[CONTENT/production-plan-v2]] | **Главный план**: архитектура, персонажи (MIA/SASHA/NADIA), референсы, приоритеты | ✅ Complete |
| [[CONTENT/STORY-DATABASE/INDEX]] | Главная база 1000 сюжетов | 🚧 В работе |
| [[CONTENT/STORY-DATABASE/Solo/INDEX]] | Solo (600 сюжетов) — 60% | 🚧 |
| [[CONTENT/STORY-DATABASE/Lesbian/INDEX]] | Lesbian (200 сюжетов) — 20% | 🚧 |
| [[CONTENT/STORY-DATABASE/Trans/INDEX]] | Girl+Trans (200 сюжетов) — 20% | 🚧 |
| [[CONTENT/STORY-DATABASE/Top50/INDEX]] | Топ-50 самых сильных сюжетов | 🚧 |
| [[CONTENT/STORY-DATABASE/Tags/INDEX]] | Теги для поиска и фильтрации | 🚧 |
| [[CONTENT/STORY-TEMPLATE/INDEX]] | Шаблон заполнения + примеры | ✅ |
| [[CONTENT/STORY-TEMPLATE/creation-demo-step-by-step]] | Пример создания сюжета от данных до файла | ✅ Demo |
| [[CONTENT/TREND-RESEARCH/INDEX]] | Аналитика трендов 2025-2026 | ✅ Complete |

---

## Пропорции базы (v2 — распределение по персонажам)

| Категория | Количество | Персонажи |
|-----------|-----------|-----------|
| **Solo — MIA** (милфа) | 250 | MILF solos, office, risky, home |
| **Solo — SASHA** (дочка) | 250 | Young solos, mirror, innocent→slutty |
| **Solo — NADIA** (транс) | 100 | Trans solo tease |
| **Lesbian — MIA + SASHA** | 100 | MILF + Young (самая виральная пара) |
| **Lesbian — MIA + MIA** | 50 | Two mature women |
| **Lesbian — SASHA + SASHA** | 50 | Two young women |
| **Girl+Trans — SASHA + NADIA** | 100 | Young + Trans |
| **Girl+Trans — MIA + NADIA** | 60 | MILF + Trans |
| **Trans solo — NADIA** | 40 | NADIA alone |
| **Total** | **1000** | **3 персонажа, 9 матчингов** |

---

## Форматы вывода

- **Markdown** — для Obsidian и ручного просмотра
- **JSON** — для программной генерации промптов (ComfyUI)
- **CSV** — для датасетов и табличного анализа

---

## Связанные проекты

- [[GODTIER/AI Influencer Pipeline]] — производственный пайплайн
- [[COMFY-KB/models/checkpoints/bigLust_v16]] — основная модель генерации
- [[CONTENT/TREND-RESEARCH/2026-porn-trends-analysis]] — полный анализ трендов

---

## Статус производства

- [x] Фаза 1: Research трендов (3 parallel subagents completed) ✅
- [x] Фаза 2: Создание шаблона + инфраструктуры в Obsidian ✅
- [x] Фаза 2.5: План производства v2 (персонажи, матчинг, референсы) ✅
- [ ] Фаза 3: Генерация 1000 сюжетов (MD+JSON+CSV)
- [ ] Фаза 4: Валидация и топ-50
- [ ] Фаза 5: Интеграция с ComfyUI pipeline
