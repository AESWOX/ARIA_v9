---
created: 2026-07-14
tags: [quality, standards, validation]
---

# Quality Gates — Критерии Качества Сюжетов

## 1. Визуализируемость (AI-генерация)

| Критерий | Проверка | Pass/Fail |
|----------|----------|-----------|
| Первые 10 кадров описывают чёткие сцены для AI генерации | Каждый кадр содержит визуальные детали (свет, поза, ракурс, выражение лица) | ✅ |
| Героиня описана консистентно | Внешность не меняется между кадрами | ✅ |
| Outfit указан | AI должен знать, во что одета героиня | ✅ |
| Освещение указано в мудборде | Минимум 1 тип освещения | ✅ |

## 2. Оригинальность

| Проверка | Критерий |
|----------|----------|
| No duplicate scenarios | Каждый сюжет имеет уникальную комбинацию локация + героиня + риск |
| No "just porn" — must have story arc | Нужны setup → tease → build-up → climax → hook |
| 5 continuation variants are distinct | Варианты не повторяют друг друга по направлению |

## 3. Engagement Factors

| Фактор | Вес | Почему |
|--------|-----|--------|
| Risk/Taboo element | ⭐⭐⭐⭐⭐ | Доказано анализом: High Risk = High Engagement |
| Emotional journey | ⭐⭐⭐⭐ | Shy → confident, nervous → aroused — character arc |
| POV immersion | ⭐⭐⭐⭐ | FirstPerson / HiddenCam повышает вовлечение |
| Contrast | ⭐⭐⭐ | Innocent face + slutty body = viral contrast |
| Realism | ⭐⭐⭐ | AI-генерация требует реалистичных сцен |

## 4. Распределение по уровням риска (целевое)

| Уровень | Процент | Количество |
|---------|---------|------------|
| Low (дома, приватно) | 15% | 150 |
| Medium (полу-публично) | 25% | 250 |
| High (риск быть замеченной) | 40% | 400 |
| Extreme (almost caught, public) | 20% | 200 |

## 5. Распределение по локациям (целевое)

| Локация | Процент | Количество |
|---------|---------|------------|
| Home (bedroom/bathroom/living room/kitchen) | 25% | 250 |
| Risky Public (elevator/balcony/rooftop/car) | 25% | 250 |
| Office / Study | 15% | 150 |
| Outdoor / Nature | 10% | 100 |
| Selfie / Mirror | 10% | 100 |
| Other (fitting room/airbnb/pool/hotel) | 15% | 150 |

## 6. Распределение по внешности (целевое)

| Внешность | Solo | Lesbian | Trans | Всего |
|-----------|------|---------|-------|-------|
| Blonde | 120 | 40 | 30 | 190 |
| Brunette | 150 | 50 | 40 | 240 |
| Redhead | 60 | 20 | 20 | 100 |
| Asian | 60 | 20 | 30 | 110 |
| Latina | 60 | 20 | 30 | 110 |
| Eastern European | 60 | 20 | 20 | 100 |
| Alternative/Tattooed | 60 | 20 | 20 | 100 |
| Multiple in one scene | — | 10 | 10 | 20 |
| **Total** | **600** | **200** | **200** | **1000** |

## 7. Распределение по характерам (равномерно)

shy, playful, dominant, bratty, loving, manipulative, nervous, confident, mischievous, sweet — примерно поровну
