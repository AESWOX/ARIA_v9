---
created: 2026-07-14
updated: 2026-07-14
tags: [template, story-quality, content-standards]
---

# Шаблон Сюжета — Story Template v1.0

## Стандарт качества

Каждый сюжет проходит 3 проверки:

1. **Оригинальность** — не повторяет другие сюжеты в базе
2. **Визуализируемость** — можно сгенерировать в 10 кадрах (первые ~1 минута AI-видео)
3. **Вовлечение** — содержит элемент риска, эмоции или неожиданности

---

## Формат сюжета (Markdown)

```markdown
### [#ID] Название сюжета
**EN:** English Title
**RU:** Русское название

**Описание:**
[4-7 предложений. Progression: setup → tease → build-up → risk → climax/hook]

**Героиня:**
- Возрастной вайб: [18-22 / 23-28 / 29-35 / 35+]
- Внешность: [blonde/brunette/redhead/asian/latina/eastern-european/alternative/tanned]
- Тело: [petite/athletic/curvy/slim/hourglass]
- Особенности: [tattooed/pierced/natural/freckles/glasses]
- Характер: [shy/playful/dominant/bratty/loving/manipulative/nervous/confident/mischievous]
- Вайб: [girl-next-door/ice-queen/bad-girl/innocent/party-girl/alternative]

**Локация:**
- Место: [конкретное место]
- Тип: [Home/RiskyPublic/Car/Office/Outdoor/Selfie/Other]
- Риск: [Low / Medium / High / Extreme]
- Контекст риска: [кого могут застать, почему это опасно]

**Ключевые элементы:**
- Outfit: [конкретный наряд]
- Tease: [чем дразнит]
- Build-up: [как нарастает напряжение]
- Climax: [кульминация]
- Hook: [зацепка для продолжения]

**10 кадров (первые ~60 сек видео):**
1. [Кадр 1 — установка сцены/локации]
2. [Кадр 2 — героиня входит/начинает действие]
3. [Кадр 3 — tease элемент]
4. [Кадр 4 — нарастание]
5. [Кадр 5 — risk/напряжение]
6. [Кадр 6 — build-up]
7. [Кадр 7 — момент "почти попались"]
8. [Кадр 8 — peak tension]
9. [Кадр 9 — climax/release]
10. [Кадр 10 — afterglow/hook на продолжение]

**POV стиль:** [FirstPerson / HiddenCam / Selfie / CCTV / ThirdPerson]

**Мудборд:**
- 🎨 Настроение 1: [например: warm amber lighting, cozy]
- 🎨 Настроение 2: [например: clandestine, thrilling]
- 🎨 Настроение 3: [например: intimate, voyeuristic]

**5 вариантов продолжения (5-8 мин):**
1. [Вариант 1 — направление экшна]
2. [Вариант 2 — альтернативное развитие]
3. [Вариант 3 — поворот/неожиданность]
4. [Вариант 4 — риск эскалация]
5. [Вариант 5 — эмоциональная концовка]

**Теги:** #solo #home-tease #blonde #shy #high-risk #pov
```

---

## Формат JSON

```json
{
  "id": "S-H-001",
  "title_en": "The Window Reflection",
  "title_ru": "Отражение в окне",
  "description": "After a long shower...",
  "heroine": {
    "age_vibe": "23-28",
    "appearance": "brunette",
    "body": "athletic",
    "features": ["tattooed", "natural"],
    "personality": "playful",
    "vibe": "bad-girl"
  },
  "location": {
    "place": "apartment living room, floor-to-ceiling windows",
    "type": "Home",
    "risk": "High",
    "risk_context": "Neighbors across the street can see silhouettes"
  },
  "elements": {
    "outfit": "white towel only",
    "tease": "slow undressing, dancing to music",
    "build_up": "moving closer to window, knowing neighbors watch",
    "climax": "intense orgasm against the glass",
    "hook": "notices someone watching from the building opposite"
  },
  "frames": [...],
  "pov": "FirstPerson",
  "moodboard": ["warm amber lighting", "clandestine", "voyeuristic"],
  "continuations": [...],
  "tags": ["solo", "home-tease", "brunette", "playful", "high-risk", "pov", "exhibitionism"]
}
```

---

## Формат CSV

```csv
id,title_en,title_ru,category,subcategory,heroine_age,heroine_appearance,heroine_body,heroine_personality,location_type,risk_level,pov_style,tags
S-H-001,The Window Reflection,Отражение в окне,Solo,Home Tease,23-28,brunette,athletic,playful,Home,High,FirstPerson,"solo,home-tease,brunette"
```

---

## Связанные файлы

- [[CONTENT/STORY-TEMPLATE/filled-example-1]] — Пример заполненного сюжета
- [[STORY-TEMPLATE/quality-gates]] — Критерии качества сюжетов
