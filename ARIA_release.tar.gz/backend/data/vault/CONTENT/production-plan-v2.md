---
created: 2026-07-14
updated: 2026-07-14
tags: [architecture, plan, production, content-strategy]
---

# Production Architecture & Story Generation Plan v2.0

## 1. АРХИТЕКТУРА ВЕТОК

```
БАЗОВЫЙ ПРОДАКШЕН (AI-инфлюенсеры: MIA, SASHA, NADIA)
  │
  └── НОВАЯ ВЕТКА: ВИДЕО+
        ├── 1. SOLO (600) — MIA или SASHA или NADIA
        ├── 2. LESBIAN (200) — MIA+SASHA, MIA+MIA, SASHA+SASHA
        └── 3. GIRL + TRANS (200) — SASHA+NADIA, MIA+NADIA, NADIA solo

❗ СТРОГИЕ ПРАВИЛА:
  - Никаких мужчин в кадрах. Максимум — транс (NADIA).
  - 3+ персонажа в одной сцене — НЕТ (заметка на будущее).
  - Каждый сюжет строго по своей ветке: SoloSolo, LesbianLesbian, TransTrans.
```

## 2. ПЕРСОНАЖИ И ИХ ВИРАЛЬНЫЕ РЕФЕРЕНСЫ (без дипфейков)

### MIA — милфа, 33 года
| Параметр | Описание |
|----------|----------|
| **Внешность** | Тёмно-русые/каштановые волосы в объёмном пучке, тёмно-ореховые глаза, высокие скулы, овально-сердцевидное лицо |
| **Тело** | Стройное с формами, грудь полная, спортивная подтянутая |
| **Стиль** | Элегантный: чёрный шёлк, глубокое декольте, серебряные серьги |
| **Характер** | Уверенная, опытная, сексуально зрелая |
| **Вайб** | Ice queen → melting interior |
| **Звёздный референс (vibe)** | Angela White (топ-2 Pornhub 2025) — та же mature brunette уверенность |
| **Для Solo** | Home tease, office, risky public — везде с элементом "я знаю, чего хочу" |
| **Для Lesbian** | Доминирующая/опытная пара для SASHA |
| **Для Trans** | Принимающая/исследующая пара для NADIA |

### SASHA — дочка, 22 года
| Параметр | Описание |
|----------|----------|
| **Внешность** | Каштановые с медовыми прядями, волнистые до плеч, тёмно-карие глаза, ярко-красная помада |
| **Тело** | Стройное хрупкое, изящное, длинная шея, грудь умеренная |
| **Стиль** | Ретро: блузка в горошек, глубокий V-вырез |
| **Характер** | Невинная с искоркой, застенчивая переходящая в игривую |
| **Вайб** | Girl next door → secret slut |
| **Звёздный референс (vibe)** | Alex Adams (топ-1 Pornhub 2025) — молодая, темноволосая, естественная красота |
| **Для Solo** | Innocent→slutty трансформация, selfie, mirror |
| **Для Lesbian** | Невинная/исследующая пара для MIA |
| **Для Trans** | Первый опыт с транс-женщиной |

### NADIA — транс-женщина, 28 лет
| Параметр | Описание |
|----------|----------|
| **Внешность** | Длинные чёрные волнистые волосы до середины спины, светло-голубые/сине-зелёные глаза, пухлые губы (филлер) |
| **Тело** | Песочные часы: тонкая талия, широкие бёдра, крупные ягодицы, большая грудь (импланты) |
| **Стиль** | Гламурный: белый кроп-топ, золотая цепочка |
| **Характер** | Уверенная, игривая, сексуально раскрепощённая |
| **Вайб** | Glamazon — роскошная и доминантная |
| **Звёздный референс (vibe)** | Emma Rose (топ-1 транс Pornhub 2 года подряд) |
| **Для Solo** | Trans tease, mirror selfie, risky public |
| **Для Lesbian** | Пара с MIA или SASHA |
| **Для Trans** | Girl+Trans динамика — доминантная или покорная |

## 3. МАТЧИНГ ПЕРСОНАЖЕЙ ПО ВЕТКАМ

### SOLO (600) — каждый персонаж отдельно

| Персонаж | Количество | Основные подкатегории |
|----------|-----------|----------------------|
| **MIA solo** | 250 | Home Tease (60), Office/Study (50), Risky Public (40), Car/Balcony (30), Mirror/Selfie (30), Outdoor (20), Innocent→Slutty (20) |
| **SASHA solo** | 250 | Home Tease (60), Innocent→Slutty (50), Mirror/Selfie (40), Risky Public (30), Outdoor (30), Car/Balcony (20), Office/Study (20) |
| **NADIA solo** | 100 | Trans tease (30), Mirror/Selfie (20), Risky Public (20), Home (15), Outdoor (15) |

### LESBIAN (200) — пары

| Пара                      | Количество | Динамика                                                                       |
| ------------------------- | ---------- | ------------------------------------------------------------------------------ |
| **MIA + SASHA**           | 100        | MILF + Young — опытная учит невинную (самая виральная! "Lesbian MILF" ↑ +129%) |
| **MIA + MIA** (дубль)     | 50         | Две зрелые женщины — равная, страстная динамика                                |
| **SASHA + SASHA** (дубль) | 50         | Две молодые — нежная, исследовательская, soft sensual                          |

### GIRL + TRANS (200) — девушка + транс

| Пара                         | Количество | Динамика                                                                                |
| ---------------------------- | ---------- | --------------------------------------------------------------------------------------- |
| **SASHA + NADIA**            | 100        | Young girl + Trans — первый опыт, acceptance story ("transgender fucks girl" top query) |
| **MIA + NADIA**              | 60         | MILF + Trans — опытная женщина и транс ("trans threesome" ↑ +67%, без третьего)         |
| **NADIA solo** (trans tease) | 40         | NADIA одна — trans solos, "trans amateur" ↑ +49%                                        |

## 4. ФОРМАТ КАЖДОГО СЮЖЕТА

```markdown
### [ID] Название (EN)
**Персонаж:** MIA / SASHA / NADIA
**Категория:** Solo / Lesbian / Girl+Trans
**Подкатегория:** Home Tease / Risky Public / Office / ...

**Описание (4-7 предложений):**
[Progression: setup → tease → build-up → risk → climax → hook]

**Референс видео:**
- Ссылка: https://[tube-site].com/watch?v=...
- Транскрипция (первые 60 сек): [краткое описание что происходит в референсе]

**10 кадров (первые ~60 сек AI-видео):**
[1-10 кадров с ракурсами]

**5 вариантов развития (по 5 слов):**
1. [направление — 5 слов]
2. [направление — 5 слов]
3. [направление — 5 слов]
4. [направление — 5 слов]
5. [направление — 5 слов]

**Теги:** #персонаж #категория #локация #риск #внешность
```

## 5. ВИРАЛЬНЫЕ ПРИОРИТЕТЫ ПО ВЕТКАМ

### 🥇 SOLO — что цепляет больше всего

| Приоритет | Сюжет | Почему вирально |
|-----------|-------|-----------------|
| #1 | **MIA: Office late night, almost caught** | Role Play ↑ +98%, Office sex ↑ +62%, CEO ↑ +388% |
| #2 | **SASHA: Mirror selfie → innocent discovery** | Solo Female ↑ +10 спотов, "Natural beauty" ↑ +124% |
| #3 | **NADIA: Balcony trans tease, neighbor watches** | Trans #2, Exhibitionism, POV |
| #4 | **MIA: Morning bathroom routine, no makeup** | "No makeup" ↑ +136%, Amateur aesthetic |
| #5 | **SASHA: Fitting room, door not fully closed** | Risky Public, "almost caught", POV |

### 🥇 LESBIAN — что цепляет

| Приоритет | Сюжет                                               | Почему вирально                          |
| --------- | --------------------------------------------------- | ---------------------------------------- |
| #1        | **MIA + SASHA: Step-mom teaches step-daughter**     | Lesbian #1, "Lesbian MILF" ↑ +129%       |
| #2        | **SASHA + SASHA: College roommates, truth or dare** | Best friends transitioning, soft sensual |
| #3        | **MIA + MIA: Two MILFs, afternoon session**         | Mature #5, "Real woman" ↑ +98%           |

### 🥇 GIRL + TRANS — что цепляет

| Приоритет | Сюжет | Почему вирально |
|-----------|-------|-----------------|
| #1 | **SASHA + NADIA: First time with a trans girl** | "transgender fucks girl" top query |
| #2 | **MIA + NADIA: MILF discovers trans lover** | Trans #2, "Trans amateur" ↑ +49% |
| #3 | **NADIA solo: Trans girl next door** | Femboy в топ-10 впервые |

## 6. РЕФЕРЕНСЫ ЗВЁЗД ДЛЯ AI (без дипфейков)

| Наш персонаж | Референс (vibe) | Почему |
|-------------|----------------|--------|
| **MIA** | **Angela White** (топ-2 PH) | Brunette, mature, confident, large breasts — same energy |
| **MIA** (альт) | **Violet Myers** (топ-3 PH) | Alternative MILF vibe |
| **SASHA** | **Alex Adams** (топ-1 PH) | Young, dark hair, natural beauty, most searched |
| **SASHA** (альт) | **Lana Rhodes** | Retro pinup vibe |
| **NADIA** | **Emma Rose** (топ-1 Trans 2 года) | Most iconic trans performer |
| **NADIA** (альт) | **Daisy Taylor** | Soft, feminine trans aesthetic |

> **Важно:** Референсы — это vibe, energy, styling. Не дипфейк. AI генерирует НОВОЕ лицо с похожим типом внешности.

## 7. РАСПРЕДЕЛЕНИЕ РИСКА ПО ПЕРСОНАЖАМ

| Персонаж | Low | Medium | High | Extreme |
|----------|-----|--------|------|---------|
| **MIA** | 15% | 20% | 45% | 20% |
| **SASHA** | 20% | 30% | 40% | 10% |
| **NADIA** | 15% | 25% | 45% | 15% |
| **Total** | **150** | **250** | **400** | **200** |

## 8. ЧТО ДАЛЬШЕ — ПОШАГОВО

| Шаг | Действие | Количество |
|-----|----------|-----------|
| 1 | **Первая пачка: SOLO (MIA) — 50 сюжетов** | ✅ Готово к старту |
| 2 | SOLO (SASHA) — 50 сюжетов | ⏳ |
| 3 | SOLO (NADIA) — 20 сюжетов | ⏳ |
| 4 | LESBIAN (MIA+SASHA) — 50 сюжетов | ⏳ |
| 5 | Добивка SOLO — оставшиеся сюжеты | ⏳ |
| 6 | GIRL + TRANS — 50 сюжетов | ⏳ |
| 7 | Добивка LESBIAN + TRANS | ⏳ |
| 8 | Top50 + JSON/CSV экспорт | 📦 |
