---
created: 2026-06-29
tags: [deploy, test, lora, post-processing, plan]
---

# Второй деплой — План действий

## ФАЗА 0: Инфраструктура
- [ ] Создать под A5000 (template ComfyUI CUDA 13)
- [ ] rclone golden архивы (base + nodes + 23.5GB models)
- [ ] Скачать: GonzaLomo XL v7 (2951793), Pikon-Realism (2296481)
- [ ] Скачать LoRA: Chiaroscuro (2953608), Cinematic color grading (2942709)
- [ ] Скопировать референс блондинки на под

## ФАЗА 1: LoRA стек под 3 типа композиций

### 👤 FACE (портрет, крупный план)
```
Face LoRA (0.9) + Body LoRA (0.3) 
+ Skin Texture (0.4) + Detailed Perfection (0.3)
+ IP-Adapter FaceID (0.85) — лицо как на референсе
+ FaceDetailer (denoise 0.3) — чистка лица
+ 4x-UltraSharp → 2048×2992
```

### 👚 BUST (по грудь)
```
Face LoRA (0.7) + Body LoRA (0.5) 
+ Hand Detail (0.5) + Touch Realism (0.4) 
+ Chiaroscuro Lighting (0.3) — киношный свет
+ Skin Texture (0.3) + Add Detail (0.3)
+ IP-Adapter FaceID (0.75)
+ ControlNet OpenPose (0.7) — поза
+ FaceDetailer (0.25)
+ 4x-UltraSharp → 2048×2992
```

### 🧍 FULL BODY
```
Body LoRA (0.9) + Face LoRA (0.6)
+ Hand Detail (0.6) + Touch Realism (0.4) 
+ Cinematic color grading (0.3)
+ ControlNet OpenPose (0.85) — вся поза
+ ControlNet Depth (0.75) — форма тела
+ IP-Adapter FaceID (0.6)
+ FaceDetailer (0.2)
+ 4x-UltraSharp → 2048×2992
```

## ФАЗА 2: Тесты (одинаковый промпт, все чекпоинты)

**Чекпоинты:** bigLust_v16, photo5, GonzaLomo XL, Pikon-Realism, insta1
**Семплер:** dpmpp_2m_sde, 50 steps, CFG 7
**Промпт:** описывает референс (блондинка, серо-голубые глаза, и т.д.)

Орбитали: front, ¾L, ¾R, profile
Эмоции: neutral, smile, serious

## ФАЗА 3: Пост-обработка (не только апскейл)

```
RAW генерация (1024×1496)
  ↓
ControlNet Union: Depth + OpenPose + Canny
  ↓
IP-Adapter FaceID v2 — консистентное лицо
  ↓
FaceDetailer (yolov8x-face, denoise 0.3) — чистое лицо
  ↓
HandDetailer — исправление рук
  ↓
4x-UltraSharp — апскейл до 2048×2992
  ↓
CodeFormer — финальная реставрация лица (если нужно)
  ↓
WAS Node Suite — контраст/насыщенность
```

## ФАЗА 4: Анализ
- Сравнить 5 чекпоинтов по качеству (лицо, тело, детали)
- Найти идеальный LoRA стек под каждую композицию
- Топ чекпоинт → остальные удалить с B2
- Отчёт в Vault

## Docker — после всего
- Собрать образ с готовым стеком
- Деплой за 30 сек вместо 10-16 мин
