---
tags: [project, hermes, sdxl, lora, b2, deploy]
created: 2026-07-06
---
# B2 Readiness Report — SDXL Production Stack

> Проверено: 2026-06-27 через b2 CLI
> Статус: PRE-PRODUCTION — всё готово к тестам, кроме LoRA

---

## ✅ Чекпоинты — ЕСТЬ (6,6 GB каждый)

| Файл | На B2 | Для чего | Годен? |
|---|---|---|---|
| `photo5.safetensors` | ✅ | Основной бесплатный | ✅ |
| `photo4.safetensors` | ✅ | Запасной | ✅ |
| `insta1.safetensors` | ✅ | Instagram стиль | ✅ |
| `Lustify_apexV8.safetensors` | ✅ | **NSFW explicit, trans** | ✅ |
| `lust1.safetensors` | ✅ | **⚠️ БИТЫЙ** — не использовать | ❌ |
| `realistic_freedom_omega` | ✅ | Альтернатива | ✅ |
| `sdxl_yamers_realistic5` | ✅ | Альтернатива | ✅ |
| `unnamed_ixl_realistic` | ✅ | Альтернатива | ✅ |

### ❌ MISSING (нужно решить)
| Чекпоинт | Цена | Нужен? |
|---|---|---|
| **Photo6** | $5.50 (pay) | 🟡 **НУЖЕН** — лучший Photo |
| **Ultra3/Ultra5** | Pay-only | 🟡 **НУЖЕН** — макс детализация |
| **Hyper1** | Pay | 🔴 Низкий приоритет |

---

## ✅ LoRA — КРИТИЧЕСКАЯ ПРОБЛЕМА

### Есть на B2 (SDXL)
| LoRA | В B2 | Комментарий |
|---|---|---|
| **DMD2_sdxl.safetensors** | ✅ | Для тестов (8 steps) |

### ❌ НУЖНО СКАЧАТЬ (SDXL)
| LoRA | ⭐ | Вес | CivitAI URL |
|---|---|---|---|
| **Hand XL v5.5** | 39K DL | 0.6-0.8 | civitai.com/models/... |
| **skin texture XL v4** | 28K DL | 0.5-0.7 | civitai.com/models/... |
| **Touch of Realism V2** 🔥 | 19K DL | 0.5-1.0 | civitai.com/models/... |
| **Add Detail - Slider SDXL** | 10K DL | 1.0-2.0 | civitai.com/models/... |
| **Detailed Perfection** 🔥 | 124K DL | 0.5 | civitai.com/models/... |

### ❌ УБРАТЬ ИЗ СТЕКА (не SDXL)
| LoRA | Почему | Замена |
|---|---|---|
| nsfw_master | Только Flux | bigLust_v16 чекпоинт сам справляется |
| aesthetic_quality | Только Pony | Touch of Realism V2 |

---

## ✅ ControlNet — ГОТОВО

| Модель | На B2 | Вес | Назначение |
|---|---|---|---|
| **xinsirUnionProMax_v10_partial** | ✅ | 0.6 | Depth |
| (Union ProMax — одна модель на всё) | ✅ | 0.8 | OpenPose |
| | | 0.3 | Canny |
| | | 0.5 | Tile (upscale) |

---

## ✅ Face Preservation — ГОТОВО

| Компонент | На B2 | Вес |
|---|---|---|
| **PuLID SDXL** | ✅ | 0.5-0.8 |
| **IP-Adapter Plus SDXL** | ✅ | 0.7-1.0 |
| **IP-Adapter SDXL** | ✅ | 0.5 |
| **Image Encoder** | ✅ | — |

---

## ✅ Post-Processing — ГОТОВО

| Инструмент | На B2 |
|---|---|
| **FaceDetailer** (Impact Pack) | ✅ через deploy.sh |
| **4x-UltraSharp** | ✅ |
| **RealESRGAN x4+** | ✅ |
| **SUPIR** (v0F + v0Q) | 🟡 Move to upscale_models |

---

## 📋 ЧТО НУЖНО СДЕЛАТЬ (по приоритету)

| # | Задача | Статус | Кто |
|---|---|---|---|
| 1 | **Докачать Hand XL v5.5** — на B2 в `models/sdxl/loras/` | ⬜ | Hermes |
| 2 | **Докачать skin texture XL v4** — на B2 | ⬜ | Hermes |
| 3 | **Докачать Touch of Realism V2** — на B2 | ⬜ | Hermes |
| 4 | **Докачать Add Detail Slider SDXL** — на B2 | ⬜ | Hermes |
| 5 | **Докачать Detailed Perfection** — на B2 | ⬜ | Hermes |
| 6 | **Решить Photo6** — покупать $5.50 или нет? | ⬜ | Пользователь |
| 7 | **SUPIR → upscale_models** — server-side copy | ⬜ | Hermes |
| 8 | **Написать тестовый скрипт** — чекпоинты + LoRA | ⬜ | Hermes |
| 9 | **Написать batch gen скрипт** — mass production | ⬜ | Hermes |

---

## 📐 ИТОГОВЫЙ СТЕК (когда всё готово)

```
Чекпоинт:    Big Love Photo6 (или Photo5)
LoRA:        Hand XL v5.5 @0.6 + skin texture XL v4 @0.5 
             + Touch of Realism V2 @0.6 + Add Detail @1.5
ControlNet:  Xinsir Union ProMax v10 (depth 0.6, pose 0.8, canny 0.3)
Face:        PuLID SDXL @0.6 + IP-Adapter FaceID @0.8 + FaceDetailer
Post:        DetailDaemon (0.3) → 2x UltraSharp → FaceDetailer
Sampler:     DPM++ 2M Karras, 28 steps, CFG 4.5
Resolution:  832×1216 (4:5)
```
