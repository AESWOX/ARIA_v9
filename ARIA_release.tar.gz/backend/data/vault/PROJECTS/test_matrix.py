#!/usr/bin/env python3
"""
GODTIER V8 — Test Suite: Checkpoint + LoRA + Sampler Matrix
============================================================
Запуск: python test_matrix.py --comfy-url http://127.0.0.1:8188
Тестирует все комбинации чекпоинтов, LoRA и параметров.

Результат: папка test_results/ с подпапками по тестам + metadata.json
"""

import json, os, sys, time, uuid, copy, argparse
from pathlib import Path
from datetime import datetime
from typing import Optional

try:
    import requests
except ImportError:
    os.system(f"{sys.executable} -m pip install requests")
    import requests

# ═══════════════════════════════════════════════════════
# КОНФИГУРАЦИЯ ТЕСТОВ
# ═══════════════════════════════════════════════════════

BASE_PROMPT_POSITIVE = (
    "biglove_photo, (masterpiece:1.2), (best quality:1.2), "
    "photorealistic, detailed skin texture, "
    "young woman, 25 years old, symmetrical face, neutral expression, "
    "looking at viewer, studio lighting, soft shadows, depth of field, "
    "natural makeup, porcelain skin, simple background"
)

BASE_PROMPT_NEGATIVE = (
    "worst quality, low quality, blurry, ugly, distorted, deformed, "
    "bad anatomy, extra limbs, fused fingers, watermark, text, "
    "signature, logo, monochrome, grayscale, bad hands"
)

# Матрица тестов чекпоинтов
CHECKPOINT_TESTS = [
    # (id, checkpoint, sampler, steps, cfg, width, height, description)
    ("C-01", "photo5.safetensors",     "dpmpp_2m_karras", 28, 4.5, 832, 1216, "Photo5 baseline"),
    ("C-02", "photo4.safetensors",     "dpmpp_2m_karras", 28, 4.5, 832, 1216, "Photo4 baseline"),
    ("C-03", "Lustify_apexV8.safetensors","dpmpp_2m_karras", 28, 4.5, 832, 1216, "Lustify baseline"),
    ("C-04", "insta1.safetensors",     "dpmpp_2m_karras", 28, 4.5, 832, 1216, "Insta1 baseline"),
    ("C-05", "photo5.safetensors",     "dpmpp_2m_karras", 25, 4.0, 832, 1216, "Photo5 softer"),
    ("C-06", "photo5.safetensors",     "dpmpp_2m_karras", 30, 5.0, 832, 1216, "Photo5 max quality"),
    ("C-07", "photo5.safetensors",     "euler",           28, 4.5, 832, 1216, "Photo5 Euler"),
    ("C-08", "photo5.safetensors",     "ddim",            28, 4.5, 832, 1216, "Photo5 DDIM"),
    ("C-09", "Lustify_apexV8.safetensors","dpmpp_2m_karras", 20, 3.5, 832, 1216, "Lustify fast"),
    ("C-10", "Lustify_apexV8.safetensors","dpmpp_2m_karras", 25, 5.0, 832, 1216, "Lustify max CFG"),
]

# Матрица тестов LoRA
LORA_TESTS = [
    # (id, loras_list, description)
    # loras_list: [(name, weight), ...]
    ("L-01", [],                                                   "No LoRA — reference"),
    ("L-02", [("HandXL_v55.safetensors", 0.6)],                    "Hands only"),
    ("L-03", [("HandXL_v55.safetensors", 0.8)],                    "Hands max"),
    ("L-04", [("skin_texture_v4.safetensors", 0.5)],               "Skin only"),
    ("L-05", [("skin_texture_v4.safetensors", 0.7)],               "Skin max"),
    ("L-06", [("touch_of_realism_v2.safetensors", 0.6)],           "Realism only"),
    ("L-07", [("HandXL_v55.safetensors", 0.6),
              ("skinTexture_v4.safetensors", 0.5)],              "Hands + Skin"),
    ("L-08", [("HandXL_v55.safetensors", 0.6),
              ("skinTexture_v4.safetensors", 0.5),
              ("touch_of_realism_v2.safetensors", 0.6)],         "Hands + Skin + Realism"),
    ("L-09", [("HandXL_v55.safetensors", 0.6),
              ("skinTexture_v4.safetensors", 0.5),
              ("touch_of_realism_v2.safetensors", 0.6),
              ("add_detail_sdxl.safetensors", 1.5)],             "Full stack"),
    ("L-10", [("HandXL_v55.safetensors", 0.6),
              ("skinTexture_v4.safetensors", 0.5),
              ("touch_of_realism_v2.safetensors", 0.6),
              ("detailed_perfection.safetensors", 0.5)],         "Full + DetailPerfection"),
]


class ComfyClient:
    """Minimal ComfyUI API client for testing."""
    
    def __init__(self, base_url: str):
        self.base_url = base_url.rstrip("/")
    
    def queue_prompt(self, workflow: dict) -> str:
        resp = requests.post(f"{self.base_url}/prompt", json={"prompt": workflow}, timeout=30)
        resp.raise_for_status()
        return resp.json()["prompt_id"]
    
    def wait_for_completion(self, prompt_id: str, timeout: int = 300) -> dict:
        start = time.time()
        while time.time() - start < timeout:
            resp = requests.get(f"{self.base_url}/history/{prompt_id}", timeout=10)
            if resp.status_code == 200 and resp.json().get(prompt_id):
                return resp.json()[prompt_id]
            time.sleep(2)
        raise TimeoutError(f"Prompt {prompt_id} did not complete in {timeout}s")
    
    def get_image(self, filename: str, subfolder: str = "") -> bytes:
        resp = requests.get(
            f"{self.base_url}/api/view",
            params={"filename": filename, "subfolder": subfolder, "type": "output"},
            timeout=30
        )
        resp.raise_for_status()
        return resp.content


def build_sdxl_workflow(checkpoint: str, prompt: str, negative: str,
                        sampler: str, steps: int, cfg: float,
                        width: int, height: int,
                        loras: list = None) -> dict:
    """Build minimal SDXL workflow for testing."""
    loras = loras or []
    
    wf = {
        "3": {"class_type": "KSampler", "inputs": {
            "seed": 42, "steps": steps, "cfg": cfg,
            "sampler_name": sampler, "scheduler": "karras",
            "denoise": 1.0, "model": ["4", 0],
            "positive": ["6", 0], "negative": ["7", 0],
            "latent_image": ["5", 0]
        }},
        "4": {"class_type": "CheckpointLoaderSimple", "inputs": {
            "ckpt_name": checkpoint
        }},
        "5": {"class_type": "EmptyLatentImage", "inputs": {
            "width": width, "height": height, "batch_size": 1
        }},
        "6": {"class_type": "CLIPTextEncode", "inputs": {
            "text": prompt, "clip": ["4", 1]
        }},
        "7": {"class_type": "CLIPTextEncode", "inputs": {
            "text": negative, "clip": ["4", 1]
        }},
        "8": {"class_type": "VAEDecode", "inputs": {
            "samples": ["3", 0], "vae": ["4", 2]
        }},
        "9": {"class_type": "SaveImage", "inputs": {
            "images": ["8", 0], "filename_prefix": "test"
        }},
    }
    
    # Add LoRAs
    model_node = "4"
    clip_node = "4"
    clip_out = 1
    lora_idx = 20
    for lora_name, weight in loras:
        wf[str(lora_idx)] = {"class_type": "LoraLoader", "inputs": {
            "model": [model_node, 0], "clip": [clip_node, clip_out],
            "lora_name": lora_name,
            "strength_model": weight, "strength_clip": weight
        }}
        model_node = str(lora_idx)
        clip_node = str(lora_idx)
        clip_out = 1
        lora_idx += 1
    
    if loras:
        wf["3"]["inputs"]["model"] = [model_node, 0]
        wf["6"]["inputs"]["clip"] = [clip_node, 1]
        wf["7"]["inputs"]["clip"] = [clip_node, 1]
    
    return wf


def run_test_suite(comfy_url: str, output_dir: Path):
    """Run all checkpoint and LoRA tests."""
    client = ComfyClient(comfy_url)
    results = []
    
    print("=" * 60)
    print("PHASE 1: CHECKPOINT TESTS")
    print("=" * 60)
    
    for test_id, ckpt, sampler, steps, cfg, w, h, desc in CHECKPOINT_TESTS:
        print(f"\n[{test_id}] {desc}")
        wf = build_sdxl_workflow(ckpt, BASE_PROMPT_POSITIVE, BASE_PROMPT_NEGATIVE,
                                 sampler, steps, cfg, w, h)
        try:
            test_dir = output_dir / test_id
            test_dir.mkdir(parents=True, exist_ok=True)
            
            prompt_id = client.queue_prompt(wf)
            print(f"  Queue: {prompt_id}")
            history = client.wait_for_completion(prompt_id)
            
            for img_data in history.get("outputs", {}).get("9", {}).get("images", []):
                img_bytes = client.get_image(img_data["filename"], img_data.get("subfolder", ""))
                img_path = test_dir / f"{test_id}_{img_data['filename']}"
                img_path.write_bytes(img_bytes)
                print(f"  ✅ Saved: {img_path.name}")
            
            results.append({
                "test_id": test_id, "type": "checkpoint",
                "checkpoint": ckpt, "sampler": sampler,
                "steps": steps, "cfg": cfg,
                "description": desc, "status": "done"
            })
        except Exception as e:
            print(f"  ❌ FAILED: {e}")
            results.append({
                "test_id": test_id, "type": "checkpoint",
                "checkpoint": ckpt, "sampler": sampler,
                "steps": steps, "cfg": cfg,
                "description": desc, "status": "failed", "error": str(e)
            })
    
    print("\n" + "=" * 60)
    print("PHASE 2: LORA TESTS (using photo5 baseline)")
    print("=" * 60)
    
    for test_id, loras, desc in LORA_TESTS:
        print(f"\n[{test_id}] {desc}")
        wf = build_sdxl_workflow("photo5.safetensors", BASE_PROMPT_POSITIVE,
                                 BASE_PROMPT_NEGATIVE,
                                 "dpmpp_2m_karras", 28, 4.5, 832, 1216, loras)
        try:
            test_dir = output_dir / test_id
            test_dir.mkdir(parents=True, exist_ok=True)
            
            prompt_id = client.queue_prompt(wf)
            print(f"  Queue: {prompt_id}")
            history = client.wait_for_completion(prompt_id)
            
            for img_data in history.get("outputs", {}).get("9", {}).get("images", []):
                img_bytes = client.get_image(img_data["filename"], img_data.get("subfolder", ""))
                img_path = test_dir / f"{test_id}_{img_data['filename']}"
                img_path.write_bytes(img_bytes)
                print(f"  ✅ Saved: {img_path.name}")
            
            results.append({
                "test_id": test_id, "type": "lora",
                "loras": [{"name": n, "weight": w} for n, w in loras],
                "description": desc, "status": "done"
            })
        except Exception as e:
            print(f"  ❌ FAILED: {e}")
            results.append({
                "test_id": test_id, "type": "lora",
                "description": desc, "status": "failed", "error": str(e)
            })
    
    # Save metadata
    metadata = {
        "timestamp": datetime.now().isoformat(),
        "prompt_positive": BASE_PROMPT_POSITIVE,
        "prompt_negative": BASE_PROMPT_NEGATIVE,
        "seed": 42,
        "results": results
    }
    (output_dir / "metadata.json").write_text(
        json.dumps(metadata, indent=2, ensure_ascii=False)
    )
    
    print(f"\n{'=' * 60}")
    print(f"DONE. Results in: {output_dir}")
    print(f"Passed: {sum(1 for r in results if r['status'] == 'done')}/{len(results)}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="GODTIER V8 Test Suite")
    parser.add_argument("--comfy-url", default="http://127.0.0.1:8188")
    parser.add_argument("--output", "-o", default="./test_results")
    args = parser.parse_args()
    
    output_dir = Path(args.output)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    run_test_suite(args.comfy_url, output_dir)
