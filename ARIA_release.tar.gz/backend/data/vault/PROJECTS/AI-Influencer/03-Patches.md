---
tags: [ai-influencer, comfyui, patches, pulid, instantid]
created: 2026-07-06
---

# 03 — Патчи custom_nodes

> Все патчи уже вшиты в `golden_instantid.tar.gz`. При свежей установке — применить вручную.

---

## 🔧 1. PuLID → CPUExecutionProvider

**Файл:** `custom_nodes/PuLID_ComfyUI/pulid.py`, строка 240

**Проблема:** onnxruntime на RunPod не видит CUDA библиотеки (`libcublasLt.so.13`).

**Патч:**
```python
# БЫЛО:
model = FaceAnalysis(name="antelopev2", root=INSIGHTFACE_DIR, providers=[provider + 'ExecutionProvider',])

# СТАЛО:
model = FaceAnalysis(name="antelopev2", root=INSIGHTFACE_DIR, providers=["CPUExecutionProvider"])
```

**Команда:**
```bash
sed -i 's/providers=\[provider + .ExecutionProvider.,\]/providers=["CPUExecutionProvider"]/' \
  custom_nodes/PuLID_ComfyUI/pulid.py
```

**Почему ок:** Детекция лица — маленькая ONNX-модель (доли секунды на CPU).
Основная диффузия идёт на GPU через torch.

---

## 🔧 2. ComfyUI_InstantID → antelopev2 CPU

**Файл:** `custom_nodes/ComfyUI_InstantID/InstantID.py`, строка ~217

Аналогичный патч — замена провайдера на CPU.

---

## 🔧 3. ComfyUI-Impact-Pack → YOLO patch

**Файлы:**
- `custom_nodes/ComfyUI-Impact-Pack/modules/impact/impact_onnx.py`
- `custom_nodes/ComfyUI-Impact-Pack/modules/impact/yolo_patch.py`

Патч для авто-детекта формата YOLO (face_yolov8m.onnx).

---

## 📋 Все пропатченные ноды (входят в golden_instantid)

| Нода | Статус | Примечание |
|------|--------|-----------|
| PuLID_ComfyUI | ✅ CPU | providers=["CPUExecutionProvider"] |
| ComfyUI_InstantID | ✅ CPU | antelopev2 на CPU |
| ComfyUI-Impact-Pack | ✅ YOLO | face_yolov8m.onnx |
| ComfyUI_IPAdapter_plus | ✅ ОК | Работает без патча |
| ComfyUI-Detail-Daemon | ✅ ОК | Не требует патча |
