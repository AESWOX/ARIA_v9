---
status: reference
tags: [ai-influencer]
---
# 🎯 Что попробовать — после анализа 2026-07-08

## Проблемы (из вижн анализа Gemini 2.5 Flash)

| Проблема | Image score | Причина |
|----------|-------------|---------|
| Soap/plastic skin | 3-4/10 | Нет skin texture LoRA, neg prompt не хватает, denoise высокий |
| Face identity drift | 1-7/10 | IP weight 0.8 standard + V only выдаёт разные лица с разных углов |
| Double face | 1/10 tq_left | IPAdapter на профиле создаёт второй face в пустой области |
| Плохой background | | Hires denoise 0.45 слишком агрессивный для фона |
| Same face syndrome | | IPAdapter не даёт достаточно разнообразия черт |

## Что попробовать (приоритет)

### Pri 1: Skin texture fix (срочно!)
```yaml
- Add: RealSkin_xxXL_v1.safetensors LoRA (weight 0.6) — уже есть в loras/!
- Add: DetailedEyes_V3.safetensors LoRA (weight 0.5)
- Neg prompt ADD: "smooth skin, plastic skin, soap skin, fake skin, airbrushed"
- Pos prompt ADD: "detailed skin texture, pores, natural skin texture"
```

### Pri 2: Face identity стабильность
```yaml
- Change IP weight from 0.8 → 0.7 (soft identity)
- Add weight_type from "standard" → "linear" (gradual influence)
- Or embeds_scaling from "V only" → "K+V" (more identity features)
```

### Pri 3: Double face fix
```yaml
- ADD ControlNet Canny / Depth для профильных углов
- ИЛИ снизить hires denoise 0.45 → 0.30-0.35
- ИЛИ добавить в prompt: "single person, one person only"
```

### Pri 4: DetailDaemon (вместо FaceDetailer)
```yaml
- ADD DetailDaemonSamplerNode в hires pass
- detail_amount: 0.25-0.35
- start: 0.0, end: 0.7 (активен на 70% шагов)
- NOTA: DD не увеличивает VRAM — работает на уровне сэмплера
```

### Pri 5: Sampler эксперименты
```yaml
- Try: dpmpp_3m_sde + karras (более резкий, чем 2m)
- Try: euler + normal (проще, но меньше артефактов)
- CFG: 5.5 → 6.5 (чуть выше для деталей)
```

## Скрипт gen_batch7.py — что меняем

```python
# 1. LoRA лоад (через LoraLoaderNode)
"15": {"class_type": "LoraLoaderNode", 
       "inputs": {"model": ["1", 0], "clip": ["1", 1], 
                  "lora_name": "RealSkin_xxXL_v1.safetensors", 
                  "strength_model": 0.6, "strength_clip": 0.6}}

# 2. IP weight 0.8 → 0.7, embeds "V only" → "K+V"
# "weight": 0.7, "weight_type": "linear", "embeds_scaling": "K+V"

# 3. Negative prompt ADD: smooth skin, plastic skin, soap skin

# 4. Positive prompt ADD: detailed skin texture, pores

# 5. Hires denoise: 0.45 → 0.35 (меньше артефактов)
```

## Структура gen_batch7.py nodes

```
[1] CheckpointLoader → model, clip, vae
[15] LoraLoader(model=[1,0], clip=[1,1], RealSkin_xxXL) → model, clip  ← NEW
[2] CLIPSetLastLayer(clip)
[3] IPAdapterUnifiedLoader
[4] LoadImage(ref)
[5] IPAdapter(weight=0.7, linear, K+V)
[6-7] CLIPTextEncode(pos+neg)
[8] EmptyLatentImage(832×1216)
[9] KSampler(30 steps, cfg=6.0)
[10] LatentUpscale(1248×1824)
[11] KSampler(22 steps, denoise=0.35)
[12-13] VAEDecode → SaveImage
```

## Порядок тестирования

1. Сначала Pri 1 (RealSkin LoRA) — проверить что нет OOM
2. Если ок — Pri 2 (IP 0.7 linear K+V)
3. Pri 4 (DD) — если нужны ещё детали
4. Если double face — Pri 3

## Что НЕ трогаем (проверено рабочие)
- ✅ Checkpoint: Lustify_apexV8
- ✅ IPAdapter preset: PLUS FACE
- ✅ Sampler: dpmpp_2m_sde karras (пока)
- ✅ Resolution chain: 832×1216 → 1248×1824
- ✅ Base steps: 30
