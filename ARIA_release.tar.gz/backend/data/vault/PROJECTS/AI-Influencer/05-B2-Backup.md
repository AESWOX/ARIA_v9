---
tags: [ai-influencer, b2, storage, backup, deploy]
created: 2026-07-06
updated: 2026-07-07
---

# 05 — B2: deploy/ — ЕДИНАЯ ТОЧКА ВХОДА

> **Bucket:** `ALEX.STORAGE`
> **Status 2026-07-07:** Все 63 GB успешно залиты. Старые бэкапы удалены.
> **Deploy команда:** `rclone sync` с 8 потоками — 5 минут на разворот.

---

## 🗺️ deploy/ — текущая структура (единственная активная)

| Путь | Размер | Назначение |
|------|--------|-----------|
| **`deploy/comfyui-models/`** | **62.85 GB** | Все модели ComfyUI по папкам (checkpoints, ipadapter, lora, vae, controlnet, facedetection, instantid, pulid, upscale, insightface) |
| **`deploy/comfyui-runtime/`** | **65 MB** | Код ComfyUI + custom_nodes + `.venv-cu128` (системный, флаг `--system-site-packages`) |
| **`deploy/scripts/`** | **19 файлов** | Все скрипты + `requirements.txt` + `pip_freeze.txt` |
| **`deploy/work_export.tar.gz`** | **233 MB** | Все генерации, воркфлоу, основные скрипты |

### deploy/comfyui-models/ — детально по папкам

| Папка | Что | Примерный размер |
|-------|-----|-----------------|
| `checkpoints/` | `Lustify_apexV8.safetensors` (6.5GB), `bigLove_photo6.safetensors` (6.5GB) | ~13.5 GB |
| `ipadapter/sdxl_models/` | `faceid.plusv2.sdxl.bin`, `ip-adapter-faceid-plusv2_sdxl.bin`, `ip-adapter-plus-face_sdxl_vit-h.safetensors` и др. | ~3 GB |
| `lora/` | 31 LoRA (char_face_lora, body, hands, skin, nsfw_master, aesthetic и др.) | ~2 GB |
| `controlnet/` | `controlnet-union-sdxl-1.0/` (Union ProMax), `tile` | ~8 GB |
| `vae/` | `sdxl_vae.safetensors`, `pixel_space` | ~400 MB |
| `insightface/` | `buffalo_l`, `antelopev2` | ~1 GB |
| `instantid/` | `instantid-ip-adapter.bin` | ~500 MB |
| `pulid/` | `ip-adapter_pulid_sdxl_fp16.safetensors` (791 MB) | ~800 MB |
| `facedetection/` | `face_yolov8m.pt` | ~50 MB |
| `upscale_models/` | `4x-UltraSharp.pth`, `lollipop` | ~2 GB |
| `image_encoder/` | CLIP vision, EVA CLIP | ~6 GB |

### deploy/comfyui-runtime/ — что внутри

| Компонент | Путь на поде | Размер |
|-----------|-------------|--------|
| ComfyUI main | `/workspace/runpod-slim/ComfyUI/` | ~150 MB |
| Custom nodes | `ComfyUI/custom_nodes/` | ~50 MB |
| .venv | `.venv-cu128/` (system-site-packages, пустышка) | ~1 MB |
| `requirements.txt` + `pip_freeze.txt` | — | текст |

> **Важно:** `.venv-cu128` создан с `--system-site-packages`. Все зависимости (включая Torch 1.3GB) — системные из образа `runpod/comfyui:cuda13.0`. Для редеплоя достаточно `requirements.txt` + `pip install`.

### deploy/scripts/ — 19 файлов

Список и назначение — в [[06-Scripts]].

---

## 📦 deploy_bundle/ — СТАРЫЙ (жив, но не точка входа)

| Файл | Размер | Назначение |
|------|--------|-----------|
| **golden_comfyui.tar** | **53.7 GB** | ⚠️ **НЕ ИСПОЛЬЗОВАТЬ для деплоя.** Заменён на `deploy/comfyui-models/` + `deploy/comfyui-runtime/` |
| golden_comfyui_base.tar.zst | 240 MB | Не актуален |
| golden_models.tar.zst | 25.2 GB | Не актуален |
| golden_nodes.tar.zst | 151 MB | Не актуален |
| **golden_instantid.tar.gz** | **562 MB** | **ЖИВ.** Доп слой InstantID (если надо быстро) |

> **Решение:** `deploy_bundle/` остаётся как исторический бэкап. Новая точка входа — `deploy/`.

---

## 🗑️ Удалённый мусор (2026-07-07)

| Файл | Размер | Почему |
|------|--------|--------|
| `comfyui_FULL_backup_2026-07-01.tar.gz` | 22 GB | Старый бэкап, заменён deploy/ |
| `backups/2026-07-06/work_archive.tar.gz` | 41 MB | Старый, неактуальный |
| `backups/2026-07-06/scripts_pod.tar.gz` | ~1 MB | Заменён deploy/scripts/ |
| `backups/runpod_work_2026-07-06.tar.gz` | 13 KB | Заменён deploy/scripts/ |
| `test_direct_upload.txt` | — | Тестовый файл |
| `comfyui-deploy-20260707/` | 63 GB | Временная ветка, заменена на deploy/ |
| `workspace-archives/` | ~1 GB | Старые архивы |

---

## 🏗️ Архитектура деплоя (как это работает)

```mermaid
flowchart TD
    B2[ALEX.STORAGE/deploy/] --> Models[comfyui-models/]
    B2 --> Runtime[comfyui-runtime/]
    B2 --> Scripts[scripts/]
    B2 --> Work[work_export.tar.gz]

    Models -->|rclone sync 8 потоков| Pod[Новый под RunPod]
    Runtime -->|rclone sync| Pod
    Scripts -->|rclone sync| Pod
    Work -->|rclone copy| Pod

    Pod -->|pip install -r requirements.txt| Venv[.venv готов]
    Pod -->|tar -xzf work_export| Workspace[Все генерации + воркфлоу]
```

**Скорость на поде (измерено 2026-07-07):**
- `curl` тест (100 MB): **97.4 MiB/s**
- `rclone copy` (1 GB): **88 MiB/s**
- Полный редеплой (63 GB моделей + runtime): **~5 минут**

---

## 🔧 Команды для деплоя (скопировать в SSH на новый под)

```bash
# 1. Модели (параллельно, 8 потоков)
rclone sync b2:ALEX.STORAGE/deploy/comfyui-models/ \
  /workspace/runpod-slim/ComfyUI/models/ --transfers=8

# 2. Runtime (параллельно)
rclone sync b2:ALEX.STORAGE/deploy/comfyui-runtime/ \
  /workspace/runpod-slim/ComfyUI/ --transfers=8

# 3. Скрипты
rclone sync b2:ALEX.STORAGE/deploy/scripts/ \
  /workspace/deploy_scripts/ --transfers=4

# 4. Архив генераций
rclone copy b2:ALEX.STORAGE/deploy/work_export.tar.gz \
  /workspace/work_export.tar.gz --progress
cd /workspace && tar -xzf work_export.tar.gz

# 5. Зависимости (если не системные)
pip install -r /workspace/deploy_scripts/requirements.txt
```

---

## 📊 Итого по B2

| Метрика | Значение |
|---------|----------|
| Bucket | ALEX.STORAGE |
| deploy/ общий | **62.85 GB** |
| deploy/comfyui-models/ | **62.78 GB** |
| deploy/comfyui-runtime/ | **65 MB** |
| deploy/scripts/ | **19 файлов** |
| deploy/work_export.tar.gz | **233 MB** |
| deploy_bundle/ (жив) | **~53 GB** |
| Очищено мусора | **~85 GB** |

---

**Связанные страницы:**
- [[02-RunPod-Deploy]] — деплой пода
- [[09-Deploy-Procedure]] — **пошаговая инструкция деплоя** 🎯
- [[06-Scripts]] — скрипты с пода
- [[08-ComfyUI-Architecture]] — архитектура ComfyUI
- [[B2 Storage]] — общая Wiki по B2
