---
tags: [ai-influencer, comfyui, architecture, custom-nodes, models]
created: 2026-07-07
---

# 08 — ComfyUI: Архитектура и кастомные узлы

> **Платформа:** RunPod (a5000/3090/4090, image `runpod/comfyui:cuda13.0`)
> **ComfyUI версия:** последняя из `runpod/comfyui:cuda13.0`
> **Модели:** все в `deploy/comfyui-models/` на B2 (62.85 GB)

---

## 🧩 Кастомные узлы (custom_nodes)

Все кастомные узлы установлены на поде в `/workspace/runpod-slim/ComfyUI/custom_nodes/`.

| Узел/пакет | Версия | Назначение | Статус |
|-----------|--------|-----------|--------|
| **ComfyUI-InstantID** | — | InstantID: ApplyInstantID, ApplyInstantIDAdvanced, FaceKeypointsPreprocessor | ✅ Активен |
| **ComfyUI_IPAdapter_plus** | — | IPAdapter: FaceID Plus v2, Style Transfer, Composition, Regional, 20+ нод | ✅ Активен |
| **PuLID_ComfyUI** | — | PuLID: Load, Apply, ApplyAdvanced, InsightFace, EvaClip | ❌ Не используется |
| **ComfyUI-Face-Style-Preset** | — | FaceDetailer пресеты (A_Magazine_Cinematic, B_Smartphone, и др.) | ✅ Активен |
| **ComfyUI-Impact-Pack** | — | FaceDetailer (YOLOv8m, CodeFormer), детекция | ✅ Активен |
| **ComfyUI-Detail-Daemon** | — | Detail Daemon — микро-детализация текстур | ✅ Активен |
| **ComfyUI-ControlNet-Union** | — | controlnet-union-sdxl-1.0 (все типы CN в одной модели) | ✅ Активен |
| **ComfyUI-VideoHelperSuite** | — | Видео утилиты | ✅ Активен |

**Связанные скрипты:**
- `run_15_sweep.py` использует: InstantIDAdvanced + IPAdapterFaceID
- `run_pulid.py` использует: PuLIDApplyAdvanced + (опционально) InstantID/FaceID
- `run_sys1.py` использует: IPAdapterFaceID + ControlNetUnion (OpenPose)

---

## 📁 Модели по папкам на B2 (deploy/comfyui-models/)

```mermaid
flowchart LR
    subgraph B2[ALEX.STORAGE/deploy/comfyui-models/]
        CKPT[checkpoints/]
        IPAD[ipadapter/sdxl_models/]
        LORA[lora/]
        CN[controlnet/]
        VAE[vae/]
        INS[insightface/]
        ID[instantid/]
        PUL[pulid/]
        FD[facedetection/]
        UP[upscale_models/]
        IE[image_encoder/]
        OTH[clip/ diffusers/ style_models/]
    end
```

### checkpoint/*.safetensors (SDXL)

| Файл | Размер | Назначение |
|------|--------|-----------|
| Lustify_apexV8.safetensors | 6.5 GB | Запасной, стилизация |
| bigLove_photo6.safetensors | 6.5 GB | Альтернативный (лица/анатомия) |

### ipadapter/sdxl_models/ — identity

| Файл | Размер | Назначение |
|------|--------|-----------|
| `faceid.plusv2.sdxl.bin` | 336 MB | IP-Adapter FaceID Plus v2 — текстура лица |
| `ip-adapter-faceid-plusv2_sdxl.bin` | 336 MB | То же (дубль?) |
| `ip-adapter-plus-face_sdxl_vit-h.safetensors` | 400 MB | Face детализация |
| `ip-adapter-plus_sdxl_vit-h.safetensors` | 400 MB | Стилевой перенос |
| `ip-adapter_sdxl_vit-h.safetensors` | 400 MB | Базовый IP-Adapter |
| `faceid.plusv2.sdxl.lora.safetensors` | 100 MB | LoRA для FaceID |
| `ip-adapter-faceid-plusv2_sdxl_lora.safetensors` | 100 MB | LoRA для FaceID (дубль?) |

### controlnet/ — ControlNet Union

| Файл | Размер |
|------|--------|
| `controlnet-union-sdxl-1.0/` (директория) | 7.9 GB |
| `controlnet-union-sdxl-1.0/config.json` | конфиг |
| `controlnet-union-sdxl-1.0/config_promax.json` | ProMax конфиг |

**Поддерживаемые типы:** Canny, Depth, Normal BAE, OpenPose, MLSD, Lineart, Anime Lineart, Soft Edge, Segmentation, Inpaint, Tile

### lora/ — 31 LoRA

| LoRA | Strength | Назначение |
|------|----------|-----------|
| char_face_lora | 0.6-0.8 | Лицо персонажа |
| char_body_lora | 0.4-0.6 | Тело персонажа |
| hands_xl | 0.6-0.8 | Качество рук |
| realistic_skin_texture | 0.4-0.6 | Детализация кожи |
| body_type_slider_pony_v1 | 0.5-1.0 | Контроль телосложения |
| nsfw_master | 0.5-0.8 | Усиление NSFW |
| aesthetic_quality_modifiers | 0.6-1.0 | Эстетика, свет |
| dmd2_lora | 1.0 | 8-шаговая генерация (быстро) |
| + ещё 23 — полный список в `pip_freeze.txt` / `lora_links.txt` | |

### insightface/ — детекция лиц

| Файл | Размер | Назначение |
|------|--------|-----------|
| `buffalo_l/` | ~500 MB | InsightFace детектор (основной) |
| `antelopev2/` | ~500 MB | InsightFace детектор (альтернативный) |

### instantid/

| Файл | Размер |
|------|--------|
| `instantid-ip-adapter.bin` | ~500 MB |

### pulid/ — НЕ ИСПОЛЬЗУЕТСЯ

| Файл | Размер | Почему |
|------|--------|--------|
| `ip-adapter_pulid_sdxl_fp16.safetensors` | 791 MB | PuLID модель — **кал, не работает** |
| `pulid_v1.1.safetensors` | ~300 MB | Несовместима (ключи id_adapter) |

### upscale_models/ — апскейлеры

| Файл                    | Размер  |
| ----------------------- | ------- |
| `4x-UltraSharp.pth`     | ~50 MB  |
| `lollipop` (директория) | ~500 MB |

### image_encoder/ — CLIP/EVA

| Файл | Размер |
|------|--------|
| `CLIP-ViT-bigG-14-laion2B-39B-b160k.safetensors` | ~3 GB |
| `EVA02_CLIP_L_336_psz14_s6B.pt` | ~900 MB |

### vae/ — VAE

| Файл | Размер |
|------|--------|
| `sdxl_vae.safetensors` | 335 MB |

---

## 🧬 Workflow архитектура (test_workflow.json)

Базовый workflow использован во всех тестах (`test_workflow.json`):

```
[3] LoadImage (zg_64.jpg) ──→ [4] VAEEncode ──→ [15] KSampler ──→ VAEDecode ──→ [17] SaveImage
    ↑                             ↑
[6] IPAdapterFaceID          [1] CheckpointLoader
    ↑                             ↑
[8] InstantID ← [11] ControlNetLoader
```

**Ключевые узлы:**
- **Node 1:** CheckpointLoader (Lustify_apexV8)
- **Node 3:** LoadImage (референс `zg_64.jpg`)
- **Node 6:** IPAdapterFaceID (входы: model, ipadapter, image)
- **Node 8:** ApplyInstantIDAdvanced (входы: model, instantid, insightface, controlnet)
- **Node 11:** ControlNetLoader
- **Node 15:** KSampler (DPM++ 2M SDE + Karras)
- **Node 17:** SaveImage (filename_prefix: `test_faceid_instantid`)

### PuLID workflow (история, отменён)

```
PuLIDModelLoader ──→ ApplyPulidAdvanced ──→ KSampler
PuLIDEvaClipLoader ──→↑
InsightFaceLoader ──→↑
LoadImage ──→↑
```

---

## ⚙️ Параметры ComfyUI

| Параметр | Значение |
|----------|----------|
| Image | `runpod/comfyui:cuda13.0` |
| CUDA | 13.0 |
| Torch | 2.10.0+cu130 |
| Python | 3.12 |
| Установленное: | facexlib, timm, ftfy (для PuLID), opencv-python 4.13.0 |
| Входные порты | 8188 (API), 8888 (UI), 22 (SSH) |

**Питфоллы:**
- `python3` = Python 3.2.2 (старый!) — всегда использовать `python`, а не `python3`
- `.venv-cu128` — системный (`--system-site-packages`), pip install идёт в системный python
- PuLID требует `facexlib`, `timm`, `ftfy` — без них узлы PuLID не регистрируются

---

**Связанные страницы:**
- [[01-Gen-Stack]] — параметры генерации
- [[05-B2-Backup]] — deploy/ на B2
- [[ComfyUI]] — общая Wiki по ComfyUI
- [[ControlNet_IPAdapter_PuLID]] — Wiki по identity узлам
