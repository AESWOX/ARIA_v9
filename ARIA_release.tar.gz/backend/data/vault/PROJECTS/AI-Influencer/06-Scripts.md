---
tags: [ai-influencer, scripts, reference, deploy]
created: 2026-07-06
updated: 2026-07-07
---

# 06 — Скрипты: полный реестр (2026-07-07)

> **Источник:** `/workspace/` на поде RunPod + `deploy/scripts/` на B2.
> **19 скриптов** загружены на B2 в `ALEX.STORAGE/deploy/scripts/`.
> **Локально:** `~/Desktop/WORK/SCRIPTS/` + рабочие скрипты на десктопе.

---

## 📁 Скрипты генерации (на поде, /workspace/)

| Скрипт | Назначение | Статус |
|--------|-----------|--------|
| `run_15_sweep.py` | 15 конфигураций InstantID/FaceID с разными ip/weight/cfg — поиск лучшего лица | ✅ Использован |
| `run_sys1.py` | Система 1: Heavy FaceID + OpenPose (устарел, не использован) | ❌ Отменён |
| `run_pulid.py` | 5 конфигураций PuLID (чистый + комбо с InstantID/FaceID) | ❌ PuLID = кал |
| `compare_faces.py` | Сравнение лиц через InsightFace (cosine similarity) | ✅ Использован |
| `face_compare.py` | Старая версия сравнения (заменена на `compare_faces.py`) | ⚠️ Не актуален |
| `inspect_wf.py` | Инспекция `test_workflow.json` — разбор структуры узлов | ✅ Использован |
| `check_pulid.py` | Проверка регистрации узлов PuLID в ComfyUI | ✅ Использован |
| `run_10tests.py` | 10 тестовых генераций (ранняя версия, заменена sweep) | ⚠️ Заменён |

### run_15_sweep.py — основной инструмент тестирования

**Архитектура:**
```python
CONFIGS = [
    # (ip, fid, cn, cfg)
    (0.60, 1.1, 0.75, 4.0),  # cfg01
    (0.65, 1.2, 0.80, 3.8),  # cfg02
    (0.70, 1.2, 0.80, 4.0),  # cfg03
    (0.75, 1.3, 0.85, 3.7),  # cfg04
    (0.80, 1.3, 0.85, 3.5),  # cfg05
    (0.85, 1.4, 0.90, 3.8),  # cfg06
    (0.85, 1.5, 0.85, 4.0),  # cfg07
    (0.90, 1.5, 0.90, 3.6),  # cfg08
    (0.90, 1.6, 0.95, 3.5),  # cfg09 🥇
    (0.85, 1.6, 0.90, 3.6),  # cfg10
    (0.95, 1.5, 0.85, 3.5),  # cfg11
    (0.80, 1.5, 0.95, 3.8),  # cfg12
    (0.70, 1.6, 0.90, 3.7),  # cfg13
    (0.95, 1.4, 0.85, 3.6),  # cfg14
    (0.75, 1.5, 0.85, 4.0),  # cfg15
]
```

**Параметры:** DPM++ 2M SDE + Karras, 40 steps, 832×1216, CFG из конфига (3.5-4.0).

### run_pulid.py — 5 конфигураций PuLID (отменён)

```python
CONFIGS = [
    # (puLID_weight, fidelity, noise, CFG, ip_weight, cn_strength, weight_faceidv2)
    (0.80, 8, 0.0, 3.5, None, None, None),     # Config 1 — Базовый стабильный
    (0.92, 7, 0.0, 3.3, None, None, None),     # Config 2 — Баланс
    (1.05, 6, 0.05, 3.1, None, None, None),    # Config 3 — Сильный identity
    (0.75, 8, 0.0, 3.4, 0.55, 0.8, None),     # Config 4 — PuLID + InstantID
    (0.85, 8, 0.0, 3.2, None, None, 1.45),     # Config 5 — PuLID + FaceID
]
```

**Решение:** PuLID = кал. Не использовать. См. [[07-Decision-Log#2026-07-07]].

---

## 📁 Скрипты деплоя (локально, ~/Desktop/WORK/SCRIPTS/runpod/)

| Скрипт | Назначение | Комментарий |
|--------|-----------|-------------|
| `deploy_pod.py` | Создать под A5000→3090→4090 | ✅ Работает |
| `terminate_pod.py` | Убить под (HTTP 204) | ✅ Работает |
| `pod_details.py` | Детали пода (ID, IP, cost/h) | ✅ |
| `pod_connect.py` | SSH + порты для пода | ✅ |
| `check_pods.py` | Все активные поды | ✅ |
| `check_gpus.py` | Доступные GPU COMMUNITY | ✅ |

---

## 📁 Утилиты (на поде, /workspace/scripts/)

| Файл | Назначение |
|------|-----------|
| `do_backup.py` | Бэкап output на B2 |
| `do_golden.py` | Создать golden архив |
| `golden_backup.py` | Бэкап всего workspace на B2 |
| `gen_script.py` | Генерация (утилита) |
| `gen_script2.py` | Генерация (утилита) |

---

## 📁 Скрипты с десктопа (C:/Users/User/Desktop/)

| Скрипт | Назначение | Дата |
|--------|-----------|------|
| `get_pod_id.py` | Получить ID пода через RunPod API | 2026-07-07 |
| `list_pods.py` | Список подов через RunPod API | 2026-07-07 |
| `find_pod.py` | Найти активный под по GPU | 2026-07-07 |
| `kill_pod.py` | Терминировать под по ID | 2026-07-07 |
| `run_pulid.py` | PuLID генерации (отменён, история) | 2026-07-07 |
| `run_15_sweep.py` | 15 конфигов InstantID/FaceID | 2026-07-06 |
| `compare_faces.py` | Сравнение лиц InsightFace | 2026-07-06 |

---

## 📦 Реестр на B2 (deploy/scripts/)

```
deploy/scripts/
├── requirements.txt          — pip freeze ComfyUI
├── pip_freeze.txt            — полный список пакетов
├── run_15_sweep.py           — 15 конфигов InstantID/FaceID
├── run_pulid.py              — PuLID конфиги (история)
├── run_sys1.py               — Система 1 (история)
├── compare_faces.py          — сравнение лиц
├── face_compare.py           — старая версия
├── inspect_wf.py             — инспекция workflow
├── check_pulid.py            — проверка PuLID узлов
├── run_10tests.py            — тесты (ранняя версия)
├── do_backup.py              — бэкап output
├── do_golden.py              — golden архив
├── golden_backup.py          — бэкап workspace
├── gen_script.py             — утилита
├── gen_script2.py            — утилита
└── (и ещё ~4 файла)
```

---

**Связанные страницы:**
- [[01-Gen-Stack]] — стек генерации
- [[05-B2-Backup]] — B2 deploy/
- [[08-ComfyUI-Architecture]] — архитектура
