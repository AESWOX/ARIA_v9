---
tags: [ai-influencer, post-processing, detail-daemon, upscale, facedetailer, colormatch]
created: 2026-07-06
updated: 2026-07-06
---

# 04 — Пост-процессинг (топ качество)

> Полный Stage 5 pipeline из GODTIER V8 + урезанная версия для RunPod.
> Три уровня повышения качества. Без галлюцинаций.

---

## 📐 Production Pipeline (GODTIER V8)

```
[5] VAE Decode (из Stage 1)
  ↓
[24] DetailDaemon (strength 0.3-0.5, radius 2)
  ↓
[25] Tile ControlNet (strength 0.5) + conditioning
  ↓
[26] Ultimate SD Upscale (4x-UltraSharp, 2x, tile 512)
  ↓
[27] FaceDetailer (CodeFormer fidelity 0.7-0.9, YOLOv8m)
  ↓
[28] ColorMatch (strength 0.3)
  ↓
SAVE / OUTPUT
```

---

## 📐 RunPod Pipeline (урезанный, gen_batch5.py)

```
KSampler (832×1216, 30 steps, denoise 1.0)
  ↓
1. Detail Daemon (amount 0.1-0.3)
  ↓
2. LatentUpscale (→1248×1824, bilinear 1.5x)
  ↓
3. KSampler #2 (20 steps, denoise 0.45) — HiRes fix
  ↓
VAEDecode
  ↓
4. FaceDetailer (YOLOv8m, denoise 0.4, guide 512)
  ↓
SaveImage
```

---

## 1️⃣ Detail Daemon (DD)

**Нода:** `ComfyUI-Detail-Daemon`

| Параметр | Production | RunPod |
|----------|-----------|--------|
| strength | 0.3-0.5 | 0.1-0.3 |
| radius | 2 | — |
| detail_amount | — | 0.1-0.3 |
| start_at | — | 0.2 (% шагов) |
| end_at | — | 0.8 (% шагов) |

Добавляет текстуру кожи, поры, микро-детали без галлюцинаций.

---

## 2️⃣ HiRes Fix (только RunPod)

**Ноды:** `LatentUpscale` + второй `KSampler`

| Этап | Размер | Steps | Denoise |
|------|--------|-------|---------|
| Первый проход | 832×1216 | 30 | 1.0 |
| Upscale (bilinear) | **1248×1824** | — | — |
| HiRes fix | 1248×1824 | **20** | **0.45** |

Апскейл в латентном пространстве перед декодингом — без потери качества.

---

## 3️⃣ Ultimate SD Upscale (Production)

**Ноды:** `Tile ControlNetApply` + `Ultimate SD Upscale`

| Параметр | Значение |
|----------|----------|
| Модель апскейла | 4x-UltraSharp.pth |
| Scale | 2x |
| Tile width | 512 |
| Tile height | 512 |
| ControlNet Tile | strength 0.5 |

В production — после DetailDaemon, до FaceDetailer.

---

## 4️⃣ FaceDetailer

**Ноды:** `ONNXDetectorProvider` + `FaceDetailer`

| Параметр | Production | RunPod |
|----------|-----------|--------|
| Детектор | face_yolov8m.onnx | face_yolov8m.onnx |
| Модель ресэмпла | CodeFormer | CodeFormer |
| fidelity | 0.7-0.9 | — |
| denoise | — | 0.4 |
| guide_size | 512 | 512 |
| max_size | 1024 | 1024 |
| bbox_dilation | 20 | 10 |
| bbox_crop_factor | 3.0 | 3.0 |
| steps | 15 | 15 |
| feather | 20 | 20 |
| noise | 0.25 | — |
| force_inpaint | True | True |

Inpaint лица с лёгким ресемплом. Только улучшение существующего, без изменения формы.

**Post-Upscale FaceDetailer (Production):** финальный проход после апскейла.
CodeFormer с fidelity 0.7-0.9 — чинит артефакты от апскейла.

---

## 5️⃣ ColorMatch (Production)

**Нода:** `ColorMatch`

| Параметр | Значение |
|----------|----------|
| Reference | reference_image |
| Strength | 0.3 |

Выравнивает цвета финального изображения под референс.
Мягко — без перебивки оригинальных цветов.

---

## 🏗️ Структура генерации

```
📁 gen_output/
  ├── raw/           ← до пост-процессинга (Stage 1-4)
  ├── upscaled/      ← после апскейла (до FaceDetailer)
  ├── final/         ← готовые к публикации (полный pipeline)
  └── metadata.json  ← промпты, seed, параметры
```

---

## 6️⃣ Groq vision — оценка качества (TODO)

**Идея:** Не хардкодить параметры пост-процессинга, а:
1. Сгенерировать изображение
2. Отправить в Groq vision (llama-3.2-90b-vision) для оценки
3. Groq решает: нужен ли FaceDetailer, какой denoise, какой апскейл
4. Применить пост-процессинг по рекомендации

**Статус:** ❌ Не реализовано. Groq ключи все 403.
**Замена:** Gemini 2.5 Flash через Google AI Studio — работает, протестировано на 20 картинках.
