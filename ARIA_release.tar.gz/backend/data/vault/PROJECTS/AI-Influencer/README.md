---
tags: [ai-influencer, runpod, sdxl, generation, comfyui, godtier]
created: 2026-07-06
updated: 2026-07-06
---

# 🎬 AI-Influencer — Главная

> Проект: генерация AI-персонажей для инфлюенсер-контента
> База: GODTIER V8 Workflow Spec (полный 6-стадийный пайплайн)
> RunPod-стек: урезанная версия для быстрой генерации датасета

---

## 📋 Структура ветки

| Файл | О чём |
|------|-------|
| [[01-Gen-Stack]] | **Стек генерации:** модели, параметры, controlnet, lora, type presets |
| [[02-RunPod-Deploy]] | Деплой/терминейт пода, SSH, прокси, полные скрипты |
| [[03-Patches]] | Патчи PuLID, InstantID, Impact-Pack |
| [[04-PostProcessing]] | **Detail Daemon, HiRes Fix, FaceDetailer, ColorMatch** |
| [[05-B2-Backup]] | Карта B2: что где лежит |
| [[06-Scripts]] | Все скрипты: назначение, порядок запуска |
| [[07-Decision-Log]] | Хронология решений и почему |

---

## 🏗️ Полный Production Pipeline (GODTIER V8)

```
STAGE 0 — ПРЕПРОДАКШН (датасет → captioning → char sheet)
PHASE A — ОБУЧЕНИЕ LoRA (face rank=32, body rank=64, DMD2)

Stage 1 — BASE GEN: Lustify_apexV8, DPM++ 2M SDE, 50 steps, CFG 7, 1024×1496
Stage 2 — CONTROLNET: ZoeDepth(0.6) → OpenPose(0.8) → Canny(0.3) → Tile(0.5)
Stage 3 — FACE: PuLID(0.5-0.8) → IP-Adapter FaceID(0.7-1.0) → FaceDetailer
Stage 4 — LORA: face→body→hands→skin→body_slider→nsfw→aesthetic→dmd2
Stage 5 — POST: DetailDaemon → Tile CN → 2x UltraSharp → FaceDetailer → ColorMatch
Stage 6 — CONTENT: кадрирование → captioning → публикация
```

> **⚠️ Критично:** Без SDE кожа пластиковая. 30 шагов не хватает — 50. CFG 4.5 низкий — 7.

---

## ⚡ RunPod Workflow (урезанный, gen_batch5.py)

```
Reference (blonde_ref.png) → InstantID(ip=1.0,cn=0.7) + FaceID v2(0.5,1.2)
  → KSampler(832×1216, Lustify_apexV8, CFG=4.0, 30 steps, DPM++ 2M SDE)
  → Detail Daemon → LatentUpscale(1.5x) → KSampler#2(denoise 0.45)
  → FaceDetailer(YOLOv8m, denoise 0.4) → Save (1248×1824)
```

---

## 🔗 Связанные страницы

- `01-WIKI/GODTIER V8.md` — полный пайплайн
- `01-WIKI/GODTIER V8 Workflow Spec.md` — детальный spec (514 строк, 28 нод)
- [[AI Influencer Pipeline]] — общий пайплайн
- [[RunPod]] — база по RunPod
- [[ComfyUI]] — база по ComfyUI
- [[SDXL Big Love]] — чекпоинты Big Love

---

## ⚡ Быстрые ссылки

- **Деплой пода:** `~/Desktop/WORK/SCRIPTS/runpod/deploy_pod.py`
- **Терминейт:** `~/Desktop/WORK/SCRIPTS/runpod/terminate_pod.py <id> --force`
- **Основной архив:** `b2:ALEX.STORAGE/deploy_bundle/golden_comfyui.tar` (53.7GB)
- **Доп. слой InstantID:** `b2:ALEX.STORAGE/deploy_bundle/golden_instantid.tar.gz` (562MB)
- **Скрипты + README:** `b2:ALEX.STORAGE/deploy_bundle/pod_deploy_latest_v2.tar.gz` (16KB)
- **SSH ключ:** `~/.ssh/runpod_key`
- **API ключ:** `~/Desktop/WORK/APY/RUNPOD/RUNPOD_2.txt`
