---
tags: [ai-influencer, runpod, deploy, procedure, step-by-step]
created: 2026-07-08
---

# 09 — Деплой: пошаговая инструкция (copy-paste ready)

> **⚠️ УСТАРЕЛО. Единственный источник правды: `SCRIPTS/runpod/MASTER-POD-CHECKLIST.md`**

- **Описание:** `/c/Users/User/Desktop/WORK/SCRIPTS/runpod/MASTER-POD-CHECKLIST.md`
- **Дата:** 2026-07-08
- **Что там:** деплой, B2 sync, зависимости, модели, pipeline, pitfalls, финансы

---

## Быстрый старт (copy-paste)

```bash
cd ~/Desktop/WORK/SCRIPTS/runpod
python deploy_pod.py
# Ждать SSH, записать ID:IP:PORT

rclone sync ALEX:ALEX.STORAGE/deploy/comfyui-models/ /workspace/runpod-slim/ComfyUI/models/ --transfers=8
pip install ultralytics insightface opencv-python-headless facexlib piexif scikit-image

cd /workspace/runpod-slim/ComfyUI
nohup python3 main.py --listen 0.0.0.0 --port 8188 > /tmp/comfyui.log 2>&1 &
```

---

Ниже — Legacy. Не редактировать, не использовать для деплоя новых подов.
> Основана на тестах 2026-07-07 (под `03c1yq6mniki24`, RTX 3090, 150GB, ~6 часов live).  
> **Время полного разворота: ~5 минут** (измерено 88-97 MiB/s с B2).

---

## ⚠️ КРИТИЧЕСКИЕ ПРАВИЛА

| Правило | Почему |
|---------|--------|
| **Только `deploy_pod.py` (SDK). Никакого curl REST v1!** | REST v1 не даёт SSH. SDK (GraphQL) шлёт `startSsh: true`. |
| **Только `terminate_pod.py`. Никогда `stop_pod()`!** | STOP = EXITED = деньги капают. DELETE = HTTP 204 = реально удалён. |
| **После деплоя ждать 3-5 минут** | A5000 грузится дольше 3090. Не убивать раньше времени. |
| **Всегда `python`, не `python3`** | `python3` на ПК = Python 3.2.2 (нет f-strings). `python` = 3.11.15. |
| **Диск 200 GB** | 50 GB не хватило (63 GB моделей + генерации + LoRA тренировка). |

---

## 🔧 Шаг 1: Деплой пода

**Только через SDK (deploy_pod.py):**

```bash
cd ~/Desktop/WORK/SCRIPTS/runpod

# Авто (A5000 → 3090):
python deploy_pod.py

# Или принудительно:
python deploy_pod.py a5000        # A5000, $0.16/h (дефолт)
python deploy_pod.py 3090         # 3090,  $0.22/h
python deploy_pod.py 4090 lora    # 4090, ТОЛЬКО обучение LoRA, $0.34/h
```

Скрипт сам читает ключ из `~/Desktop/WORK/APY/RUNPOD/RUNPOD_2.txt`.

**После деплоя записать:** ID пода, IP, SSH-порт, proxy URL.

---

## ⏳ Шаг 2: Ждать 3-5 минут

**Не проверять через 30 секунд.** A5000 загружает контейнер 2-5 минут. Проверить готовность:

```bash
ssh -i ~/.ssh/runpod_key -p <PORT> -o StrictHostKeyChecking=no root@<IP>
```

Если SSH не поднялся — подождать ещё 1-2 минуты и повторить.

---

## 📦 Шаг 3: Залить всё с B2 (параллельно)

В SSH на поде:

```bash
# 3.1. Настроить rclone
cat > /root/.rclone_b2.conf << 'EOF'
[ALEX]
type = b2
account = <B2_ACCOUNT_ID>
key = <B2_APP_KEY>
EOF

# 3.2. Модели (8 потоков, ~4 минуты, можно в фоне)
rclone sync ALEX:ALEX.STORAGE/deploy/comfyui-models/ \
  /workspace/runpod-slim/ComfyUI/models/ --transfers=8 2>&1 &

# 3.3. Runtime (4 потока, ~30 секунд)
rclone sync ALEX:ALEX.STORAGE/deploy/comfyui-runtime/ \
  /workspace/runpod-slim/ComfyUI/ --transfers=4 2>&1 &

# 3.4. Скрипты (4 потока, ~10 секунд)
rclone sync ALEX:ALEX.STORAGE/deploy/scripts/ \
  /workspace/scripts/ --transfers=4

# 3.5. Архив генераций (3 секунды)
rclone copy ALEX:ALEX.STORAGE/deploy/work_export.tar.gz \
  /workspace/work_export.tar.gz --progress
cd /workspace && tar -xzf work_export.tar.gz
```

> **Важно:** Модели и runtime можно синхронизировать параллельно (разные targets не конфликтуют).  
> Проверять прогресс: `ps aux | grep rclone | wc -l` — должно быть 2 процесса.

---

## 🐍 Шаг 4: Зависимости

```bash
pip install -r /workspace/scripts/requirements.txt
```

> `.venv-cu128` создан с `--system-site-packages` — все основные зависимости (Torch 1.3GB) системные из образа `runpod/comfyui:cuda13.0`. `pip install` идёт в системный python, не в венв.

---

## 🚀 Шаг 5: Запуск ComfyUI

```bash
cd /workspace/runpod-slim/ComfyUI

# Убить старый процесс (если есть)
pkill -f 'python.*main.py' 2>/dev/null; sleep 2

# Запустить
nohup python main.py --listen 0.0.0.0 --port 8188 --highvram \
  --enable-manager > /workspace/cui.log 2>&1 &

# Проверить через 10-15 секунд
sleep 10
curl -s http://127.0.0.1:8188/object_info | head -1
```

**Ожидаемый результат:** `{"3": ... }` — ComfyUI API отвечает.

---

## ✅ Шаг 6: Проверка всего стека

```bash
# SSH работает
hostname

# GPU видна
nvidia-smi --query-gpu=name,memory.total --format=csv,noheader

# ComfyUI API жив
curl -s http://127.0.0.1:8188 | head -1

# Модели на месте
ls /workspace/runpod-slim/ComfyUI/models/checkpoints/ | head -5
ls /workspace/runpod-slim/ComfyUI/models/ipadapter/sdxl_models/ | head -5
ls /workspace/runpod-slim/ComfyUI/models/lora/ | head -5

# rclone синхронизация завершена
ps aux | grep rclone | grep -v grep
# Если ничего не вывело — синхронизация завершена

# Можно запустить тестовую генерацию
python /workspace/scripts/run_15_sweep.py --test-only
```

---

## 🔫 Шаг 7: Терминейт

```bash
cd ~/Desktop/WORK/SCRIPTS/runpod
python terminate_pod.py <POD_ID>
# HTTP 204 = успешно
```

**Никогда:** `stop_pod()`, `curl REST stop`, `runpod.stop_pod()`.

---

## 🐛 Питфоллы (из реальных тестов)

| Проблема | Симптом | Решение |
|----------|---------|---------|
| SSH не поднялся | timeout / connection refused | Ждать 3-5 мин. Если >10 мин — RunPod COMMUNITY сбой, передеплоить |
| `python3` SyntaxError | `SyntaxError: invalid syntax` на f-strings | Использовать `python`, не `python3` |
| API key маскируется | HTTP 403 / Bearer *** | Скрипты читают ключ сами из файла. Не вставлять ключ в команду. |
| 50 GB disk full | ComfyUI падает при генерации | След. раз **200 GB** (отредактировать deploy_pod.py) |
| rclone завис | Процесс висит часами | `kill <PID>` и перезапустить с `--timeout=30m` |
| ComfyUI Queue не очищается | Старые промпты блокируют новые | `curl -X POST http://127.0.0.1:8188/queue` с пустым телом |
| PuLID узлы не регистрируются | `IMPORT FAILED` в логе | Нужны `facexlib`, `timm`, `ftfy` (НЕ ИСПОЛЬЗОВАТЬ PuLID ВООБЩЕ) |
| Proxy показывает "Waiting for service" | 503 / 502 | Проверить SSH. Если SSH есть — ComfyUI просто не запущен. |

---

## 📊 Замеры скорости

| Тест | Скорость |
|------|----------|
| curl download 100 MB | 97.4 MiB/s |
| rclone copy 1 GB | 88 MiB/s |
| Полный deploy (63 GB models + runtime) | ~5 минут |
| SSH до готовности | 2-5 минут (зависит от GPU) |

---

## 🗺️ Схема

```mermaid
flowchart LR
    A[deploy_pod.py] -->|ждёт 3-5 мин| B[SSH на под]
    B -->|параллельно| C[rclone sync models 8 потоков]
    B -->|параллельно| D[rclone sync runtime 4 потока]
    C -->|~4 мин| E[Зависимости pip install]
    D -->|~30 сек| E
    E --> F[Запуск ComfyUI]
    F --> G[Проверка API]
    G --> H{Готово?}
    H -->|да| I[Генерация]
    H -->|нет| J[Чек лог cui.log]
    J --> F
    I --> K[terminate_pod.py]
```

---

## 🔗 Связанные страницы

- [[01-Gen-Stack]] — параметры генерации
- [[02-RunPod-Deploy]] — скрипты деплоя/терминейта
- [[05-B2-Backup]] — структура deploy/ на B2
- [[07-Decision-Log]] — почему deploy/ а не golden_comfyui.tar
- [[08-ComfyUI-Architecture]] — custom_nodes и модели
- [[STACK/RunPod GPU Deployment History]] — скилл агента (всегда загружать перед деплоем)
