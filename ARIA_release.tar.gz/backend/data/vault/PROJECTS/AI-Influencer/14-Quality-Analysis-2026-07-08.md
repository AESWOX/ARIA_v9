---
status: reference
tags: [ai-influencer]
---
# Полный анализ качества генераций — 8 июля 2026

## Методология
- 15 изображений, 5 углов × 3 случайных сида
- Визуальный анализ: **Gemini 2.5 Flash** (11/15 пробили NSFW-фильтр)
- Параметры: IPAdapter 0.8 standard, embeds V only, CFG 5.5, dpmpp_2m_sde, 30+22 steps, denoise 0.45
- Чекпоинт: lustify_apexV8.safetensors
- **Без FaceDetailer, без SAM, без DetailerDaemon** (OOM protection)
- Разрешение: 832×1216 → upscale ×1.5 → 1248×1824

## Итоговая таблица (1-10)

| Изображение | ID | SKIN | SHP | LGT | EXP | BG | **AVG** |
|-------------|----|------|-----|-----|-----|----|----|
| **prof_right_neutral_s2** | **9** | **9** | **9** | **9** | **9** | **7** | **8.7** 🏆 |
| high_surprised_s0 | 10 | 9 | 10 | 9 | 8 | 9 | 9.2 |
| front_smile_s1 | 9 | 6 | 7 | 9 | 8 | 9 | 8.0 |
| high_surprised_s1 | 9 | 6 | 7 | 9 | 8 | 9 | 8.0 |
| prof_right_neutral_s1 | 9 | 7 | 7 | 9 | 9 | 4 | 7.5 |
| tq_left_serious_s2 | 9 | 7 | 6 | 8 | 9 | 5 | 7.3 |
| tq_right_happy_s2 | 8 | 5 | 4 | 8 | 9 | 4 | 6.3 |
| tq_right_happy_s0 | 7 | 6 | 6 | 7 | 5 | 4 | 5.8 |
| tq_left_serious_s1 | 6 | 4 | 3 | 7 | 5 | 2 | 4.5 |
| high_surprised_s2 | 9 | 6 | 4 | 6 | 7 | 2 | 5.7 |
| tq_right_happy_s1 | 8 | 4 | 3 | 6 | 5 | 2 | 4.7 |
| **tq_left_serious_s0** | **2** | **5** | **4** | **8** | **8** | **3** | **5.0** 💀 |

**Заблокированы NSFW-фильтром:** front_smile_s0, front_smile_s2, prof_right_neutral_s0

## Топ-5 проблем (по частоте в 11 изображениях)

### 1. 🔴 SKIN TEXTURE: Soap/Plastic Skin (8/11 — 73%)
Средняя оценка: **5.7/10**. Хуже всего на tq_right_happy_s1 (4/10).
```
Цитаты Gemini:
- "Skin texture too smooth"
- "Somewhat plastic skin"
- "Skin texture overly smooth"
- "Slight plastic skin texture"
```
**Причина:** Нет LoRA на текстуру кожи. IPAdapter сглаживает. CFG 5.5 слишком низкий для нашего стека.

### 2. 🔴 BACKGROUND: Артефакты (9/11 — 82%)
Средняя оценка: **4.5/10**. Катастрофа на всех tq_right_happy (2-4/10).
```
Цитаты:
- "Background heavily pixelated grid"
- "Heavily blurred, distorted background"
- "Incoherent, blurry background artifacts"
- "Heavy horizontal line artifacts"
```
**Причина:** Hires pass denoise 0.45 слишком агрессивный — разваливает фон.

### 3. 🟡 SHARPNESS: Нечёткость (7/11 — 64%)
Средняя оценка: **5.3/10**.
```
- "Hair lacks realistic detail" 
- "Hair and skin blurry"
- "Lack of overall image sharpness"
```
**Причина:** 30+22 steps без FaceDetailer — не хватает циклов refinement.

### 4. 🟡 FACE IDENTITY: Дрейф (5/11 — 45%)
Средняя: **7.8/10**, но разброс **2→10**.
```
Лучшие: prof_right_neutral (9/9), front-facing (9/10)
Худшие: tq_left_serious (2/6) — MULTIPLE FACES!
```
**Причина:** IPAdapter 0.8 standard + V only не удерживает лицо на 3/4 профилях. При нулевом пустом фоне IPAdapter создаёт второй face в пустой области.

### 5. 🟢 EXPRESSION: Uncanny valley (4/11 — 36%)
Средняя: **7.0/10**, но провалы:
```
- tq_right_happy_s0: "Uncanny expressions, stiff lips" (5/10)
- tq_left_serious_s1: stiff (5/10)
```
**Причина:** Отсутствие FaceDetailer = нет refinement улыбок.

## Аномалии по seed'ам

Каждый угол имеет **3 сида** — и результаты ДРАМАТИЧЕСКИ отличаются:

| Угол | Seed s0 | Seed s1 | Seed s2 | Разброс |
|------|---------|---------|---------|---------|
| tq_left_serious | **5.0** 💀 | 4.5 | 7.3 | **3.0** |
| tq_right_happy | 5.8 | 4.7 | 6.3 | 1.6 |
| high_surprised | 9.2 🏆 | 8.0 | 5.7 | **3.5** |
| prof_right_neutral | blocked | 7.5 | **8.7** 🏆 | ~1.2 |
| front_smile | blocked | 8.0 | blocked | ~N/A |

**Вывод:** Качество полностью зависит от seed'а. При случайных сидах 1 из 3 получается "топ", 1 из 3 — мусор.

## Эталонный результат

🏆 **prof_right_neutral_s2** — единственное изображение с ТОП-оценками:
```
ID:9  SKIN:9  SHP:9  LGT:9  EXP:9  BG:7  AVG:8.7
```
**Что в нём иначе:** seed + случайное совпадение IPAdapter с профилем. При том же пайплайне.

## Проблемы вне Gemini-анализа (мои)

1. **Без FD/SAM/DD** — нет face refinement на уровне hair/pores/eyes
2. **IPAdapter с V only** — слабый перенос identity на 3/4 углах
3. **Hires pass denoise 0.45** — ломает фон, не хватает на детализацию лица
4. **No skin LoRA** — soap skin без текстурных LoRA
5. **Случайные сиды** — 67% времени качество мусорное, только каждый 3й seed хороший

## Что менять — приоритеты (из 13-What-To-Try-Next.md)

```
1. RealSkin_xxXL_v1 LoRA (0.6) → soap skin fix
2. IP weight 0.7 linear + K+V → identity стабильность
3. Denoise 0.45→0.35 → background fix
4. CFG 5.5→6.0 → чёткость
5. DetailedEyes_V3 LoRA (0.5) → sharpness eyes
```
