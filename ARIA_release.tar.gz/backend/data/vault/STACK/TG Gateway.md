---
created: 2026-06-27
updated: 2026-06-29
tags: [hermes, gateway, telegram, vbs, windows, integration]
---

# TG Gateway

> Telegram-вход в Hermes Agent. Основной способ взаимодействия с системой удалённо.
> Работает через VBS Looper (без окон) + gateway процесс.

---

## Архитектура

```mermaid
graph TB
    Phone[📱 Telegram @esWox] -->|сообщение| Bot[🤖 TG Bot]
    Bot -->|webhook/long-poll| Gateway[TG Gateway PID 2248]
    Gateway --> Hermes[Hermes Agent]
    Hermes -->|ответ| Gateway
    Gateway -->|ответ| Bot
    Bot -->|сообщение| Phone

    Swarm[Swarm Worker PID 7572] -.->|сложные задачи| Gateway
    CC[CC v3 :8766] -.->|UI управление| Gateway
    Hermes -->|голосовые| STT[STT whisper.cpp]
```

---

## Компоненты

### Gateway процесс
| Атрибут | Значение |
|---------|----------|
| **Процесс** | `pythonw -m hermes_cli.main gateway run --replace` |
| **PID** | ~2248 |
| **Окно** | Нет (pythonw + VBS) |
| **Запуск** | Через VBS Looper в Startup |
| **Перезапуск** | `--replace` флаг (убивает старый, запускает новый) |

### VBS Looper
```vbs
Set WshShell = CreateObject("WScript.Shell")
WshShell.Run """pythonw -m hermes_cli.main gateway run --replace""", 0, False
```

**Что делает VBS:**
- `WScript.Shell` — создаёт shell-объект
- `Run cmd, 0, False` — 0 = hide window, False = не ждать завершения
- Единственный способ запустить pythonw без консольного окна на Windows

### Swarm интеграция
```vbs
Set WshShell = CreateObject("WScript.Shell")
WshShell.Run """pythonw agent_swarm.py""", 0, False
```

---

## Установка и запуск

### Шаг 1: Получить TG Bot Token
```bash
# В Telegram: @BotFather
# /newbot → HermesGatewayBot → получаешь токен
# Токен в: WORK/APY/TG_TOKEN.txt
```

### Шаг 2: Настроить Hermes
```bash
# Telegram token
hermes config set tg.token "your_bot_token_here"

# Использовать long-polling (не webhook — локальный ПК без статического IP)
hermes config set tg.polling true

# Разрешить доставку файлов
hermes config set media_delivery_allow_dirs ["C:/Users/User/Desktop/WORK", "C:/Users/User/Desktop/WORK/SECOND_BRAIN"]
```

### Шаг 3: Запустить Gateway
```bash
# Через Hermes CLI:
pythonw -m hermes_cli.main gateway run --replace

# Или через скрипт:
bash ~/Desktop/WORK/run_gateway_with_swarm.bat
```

### Шаг 4: Добавить в автозагрузку
Создать `.vbs` в `shell:startup`:
```vbs
' C:\Users\User\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup\hermes_gateway.vbs
Set WshShell = CreateObject("WScript.Shell")
WshShell.Run """pythonw -m hermes_cli.main gateway run --replace""", 0, False
WshShell.Run """pythonw agent_swarm.py""", 0, False
```

---

## Возможности

### Что можно делать через TG

| Команда/Действие | Описание |
|-----------------|----------|
| **Текстовое сообщение** | Отправить задачу Hermes |
| **Голосовое сообщение** | STT → текст → задача (через whisper.cpp) |
| **Фото** | vision_analyze (через Gemini Flash) |
| **Файл** | Сохранить в WORK/ |
| `/task <описание>` | Отправить в Swarm (сложные задачи) |
| `/status` | Статус системы |
| `/help` | Список команд |

### MEDIA доставка

Результаты (изображения, файлы) отправляются через MEDIA:
```python
# В ответе: MEDIA:/path/to/generated/image.png
# → отправляется как файл в Telegram
```

**Разрешённые папки (config):**
- `C:/Users/User/Desktop/WORK/`
- `C:/Users/User/Desktop/WORK/SECOND_BRAIN/`

---

## Мониторинг и отладка

### Проверка статуса
```bash
hermes gateway status
# → PID + Scheduled Task + статус

# Или прямо:
ps aux | grep pythonw | grep gateway
```

### Логи
Логи gateway хранятся в `~/AppData/Local/hermes/logs/`:
```bash
ls -la ~/AppData/Local/hermes/logs/ | grep gateway
```

### Типичные проблемы

| Проблема | Причина | Решение |
|----------|---------|---------|
| Бот не отвечает | Gateway не запущен | `hermes gateway status` → запустить |
| `pythonw` не запускается | Нет в PATH | Использовать полный путь |
| VBS не работает | Startup папка не та | Проверить `shell:startup` |
| Сообщение пришло, ответа нет | Gateway упал | Перезапустить с `--replace` |
| Файл не отправляется | Путь вне allow_dirs | Добавить в `media_delivery_allow_dirs` |
| Голосовое не распознаётся | STT не настроен | Проверить whisper.cpp установку [[STT Speech-to-Text]] |

---

## Процессы (Windows)

```mermaid
graph LR
    VBS[VBS Looper Startup] --> GW[pythonw gateway PID 2248]
    VBS --> SW[pythonw swarm PID 7572]
    GW --> Hermes
    Hermes --> DASH[python -m dashboard PID 7352]
    Hermes --> STT[whisper-cli.exe]
    SW --> Queue[queue.txt]
```

---

## VBS на Windows

### Почему VBS, не .bat?
| Способ | Окно | Работает? |
|--------|------|-----------|
| `.bat` с `pythonw` | **Всё равно показывает окно** | ❌ |
| `.bat` с `start /MIN` | Минимизированное, но видно | ❌ |
| `.vbs` с `Run cmd, 0, False` | **Совсем без окон** | ✅ |
| PowerShell скрытый | Требует доп. настроек | ⚠️ |
| Scheduled Task | Работает, но сложнее | ⚠️ |

**Вывод:** VBS — единственный надёжный способ запуска без окон на Windows.

### Создание VBS через Python (для deploy)
```python
vbs_content = '''Set WshShell = CreateObject("WScript.Shell")
WshShell.Run """pythonw -m hermes_cli.main gateway run --replace""", 0, False
WshShell.Run """pythonw agent_swarm.py""", 0, False
'''
with open("hermes_startup.vbs", "w") as f:
    f.write(vbs_content)
```

---

## Связи
- [[Hermes Agent]] — база (полная страница)
- [[Swarm Оркестратор]] — параллельные задачи
- [[Командный Центр CC v3]] — UI (вкладка Swarm)
- [[Windows Специфика]] — VBS, процессы
- [[STT Speech-to-Text]] — голосовые сообщения
- [[Hermes Error Troubleshooting]] — решения проблем
