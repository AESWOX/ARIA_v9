---
created: 2026-06-27
tags: [command-center, cc, ui, dashboard]
---

# Командный Центр (CC v3)

> HERMES Command Center v3 — единый интерфейс управления. Порт 8766.

## Адрес
`http://localhost:8766`

## 10 вкладок

| # | Вкладка | Назначение |
|---|---|---|
| 1 | Dashboard | Статус системы |
| 2 | Swarm | Управление swarm-задачами |
| 3 | GODTIER | Управление пайплайном генерации |
| 4 | Trading | Quant-трейдинг |
| 5 | RunPod | GPU поды |
| 6 | B2 | Backblaze B2 Storage |
| 7 | System | Мониторинг системы |
| 8 | Terminal | Встроенный терминал |
| 9 | Downloads | Загрузки |
| 10 | Analytics | Аналитика |

## Аутентификация
- **Localhost:** auth middleware отключена — все API без токена
- **Логин:** Aeswox222 / Hacker222 (sessionStorage 'token')
- **Внешний доступ:** через .env auth

## GODTIER Panel (бывш. 8765)
Полностью объединена в CC v3. Старые панели удалены.

## Технически
- **Стек:** FastAPI + vanilla JS
- **Харднено:** XSS выпилен, bind 127.0.0.1, .env auth
- **Запуск:** `pythonw server.py`

## Связи
- [[Hermes Agent]] — база
- [[GODTIER V8]] — пайплайн
- [[Swarm Оркестратор]] — вкладка
