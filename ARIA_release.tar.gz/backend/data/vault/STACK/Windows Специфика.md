---
created: 2026-06-27
tags: [windows, vbs, subprocess, console]
---

# Windows Специфика

> Windows 10. Git-bash (MSYS). Subprocess quirks.

## Shell
- **Не PowerShell, не cmd** — git-bash / MSYS
- POSIX-синтаксис: `ls`, `&&`, одинарные кавычки
- MSYS-пути: `/c/Users/User/...` работают
- PowerShell builtins НЕ работают

## VBS Launcher (без окон)

```vbs
Set WshShell = CreateObject("WScript.Shell")
WshShell.Run """pythonw server.py""", 0, False
```

Единственный способ запустить .bat / pythonw без консольного окна.
`start /MIN` в .bat всё равно показывает окно.

## CREATE_NO_WINDOW (subprocess)

```python
creationflags = 0x08000000  # CREATE_NO_WINDOW
```

Добавлять для всех внешних .exe (b2.exe, wmic, curl.exe).
**Исключение:** `b2 file upload` ломается с этим флагом.

## DNS Fix (aiohttp на Windows)

```python
resolver = aiohttp.AsyncResolver(nameservers=['8.8.8.8', '1.1.1.1'])
connector = aiohttp.TCPConnector(resolver=resolver, family=0)
```

aiodns fails on Windows. Использовать для всех aiohttp API вызовов.

## Paths
- Home: `C:\Users\User`
- WORK: `C:\Users\User\Desktop\WORK`
- Hermes: `~/AppData/Local/hermes/`
- APY (ключи): `WORK/APY/`
- Audio cache: `~/AppData/Local/hermes/audio_cache/`

## Связи
- [[Hermes Agent]] — работает под Windows
- [[TG Gateway]] — VBS Looper
- [[B2 Storage]] — CREATE_NO_WINDOW
