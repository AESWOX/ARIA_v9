---
created: 2026-06-27
tags: [hermes, error, 500, api, troubleshooting]
source: session 20260626_152454_4602cc
---

# Hermes Error Troubleshooting

> Сборник решённых проблем и ошибок.

## B2 Upload — 500 Internal Server Error

**Симптом:** POST /api/b2/upload → 500, `get_input_stream error`
**Дата:** 26 июня 2026
**Причина:** UV python зомби-процессы держали старый код b2.py
**Решение:** Убить все UV python процессы → перезапустить сервер
**Подробно:** [[B2 Debugging UV Zombies]]

## Cross-Device Session Loss

**Симптом:** Пользователь дал задачу на ПК (TUI), спрашивает в TG — я не вижу
**Дата:** 26 июня 2026
**Причина:** Mid-turn сообщения могут теряться при кросс-девайс сессиях
**Решение:** `session_search()` с browse для поиска сессии с ПК
**Подробно:** В памяти: правило кросс-девайс контекста

## RunPod GPU: N/A

**Симптом:** Под RUNNING, но GPU: N/A
**Дата:** 26 июня 2026
**Причина:** REST API не выделяет GPU. Использовать SDK/GraphQL.
**Решение:** Ждать 2-3 мин. Если `costPerHr $0.00` >30 сек — убить.
**Подробно:** [[STACK/RunPod GPU Deployment History]]

## Vision не работает

**Симптом:** vision_analyze выдаёт ошибку или мусор
**Причина:** Конфиг `auxiliary.vision` не настроен (читает не `vision`, а `auxiliary.vision`)
**Решение:** 
```bash
hermes config set auxiliary.vision.provider google
hermes config set auxiliary.vision.model "gemini-2.5-flash"
```
**Подробно:** [[Hermes Agent]] — раздел Config

## Связи
- [[Hermes Agent]] — база
- [[B2 Debugging UV Zombies]] — B2 fix
- [[STACK/RunPod GPU Deployment History]] — RunPod fix
