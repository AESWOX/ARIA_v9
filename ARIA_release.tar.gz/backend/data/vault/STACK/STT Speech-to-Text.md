---
created: 2026-06-27
updated: 2026-06-29
tags: [stt, whisper, voice, audio, speed, speech-to-text]
---

# STT Speech-to-Text

> Распознавание голосовых сообщений. Максимальная скорость на слабом CPU.
> Стек: whisper.cpp + tiny-q5_1 модель + Python обёртка.

---

## Архитектура

```mermaid
graph LR
    Voice[🎤 Голосовое .ogg] --> Python[stt_whisper_cpp.py]
    Python --> Whisper[whisper-cli.exe]
    Whisper --> Model[ggml-tiny-q5_1.bin]
    Model --> Result[JSON: {text: \"...\"}]
    Result --> Hermes[Hermes Agent]
```

---

## Стек

| Компонент | Версия | Путь | Описание |
|-----------|--------|------|----------|
| **whisper.cpp** | v1.9.1 | `~/bin/whisper.cpp/Release/whisper-cli.exe` | C++ реализация Whisper |
| **Модель** | tiny-q5_1 | `~/bin/whisper.cpp/Release/ggml-tiny-q5_1.bin` | 31MB, квантованная |
| **Обёртка** | Python | `~/bin/stt_whisper_cpp.py` | Вызов whisper-cli + парсинг JSON |
| **Fallback** | faster-whisper | — | Если whisper-cli не доступен |

### Почему whisper.cpp
- **Скорость:** C++ нативная, без Python overhead
- **Квантование:** q5_1 даёт минимум потери качества при 31MB
- **Лёгкость:** 31MB модель vs 1.5GB у large-v3
- **Простота:** один бинарник, без зависимостей

### Почему tiny-q5_1 (не base/small/medium)
| Модель | Размер | RAM | Скорость на i3-8145U | Качество |
|--------|--------|-----|---------------------|----------|
| tiny-q5_1 | 31MB | ~300MB | ⚡ **~80x realtime** | Достаточно для речи |
| tiny (ориг) | 75MB | ~400MB | ~40x realtime | Такое же |
| base-q5_1 | 73MB | ~500MB | ~20x realtime | Чуть лучше |
| small-q5_1 | 233MB | ~1.2GB | ~8x realtime | Хорошее |
| medium-q5_1 | 769MB | ~3GB | ~3x realtime | Отличное |
| large-v3 | 3.1GB | ~10GB | ~0.8x realtime (медленнее реального времени) | Лучшее |

**Вывод:** tiny-q5_1 — оптимальный баланс скорость/качество на i3-8145U (4 ядра, 8 потоков). 30 сек речи → ~2-4 сек.

---

## Производительность

### Замеры на i3-8145U (4 треда)

| Длительность аудио | Время обработки | Множитель |
|-------------------|----------------|-----------|
| 5 сек (короткая команда) | **~0.3 сек** ⚡ | 16x realtime |
| 15 сек (синтез тест) | **1.67 сек** ⚡ | 9x realtime |
| 30 сек (типичное голосовое) | **~2-4 сек** ⚡ | 7-15x realtime |
| 60 сек (длинное) | **~5-8 сек** | 7-12x realtime |

### Оптимизации (встроены в stt_whisper_cpp.py)

| Параметр | Значение | Эффект |
|----------|---------|--------|
| Модель | `tiny-q5_1` (31MB) | Минимум загрузки |
| `-t 4` | 4 треда | Оптимум для i3-8145U (2 физических ядра, 4 логических) |
| `-l ru` | Явный язык | Без auto-detect (экономит ~30% времени) |
| `--vad` | VAD фильтр | Вырезает тишину, ускоряет на 10-30% |
| `-np` | Без печати progress | Меньше I/O |
| `--no-timestamps` | Без временных меток | Чистый текст |
| `-otxt` | Вывод в txt | Минимальный парсинг |

---

## Установка

### Шаг 1: Скачать whisper-cli.exe
```bash
curl -sL -o ~/bin/whisper.zip https://github.com/ggml-org/whisper.cpp/releases/download/v1.9.1/whisper-bin-x64.zip
cd ~/bin
unzip whisper.zip
mv Release whisper.cpp
rm whisper.zip
```

### Шаг 2: Скачать модель
```bash
curl -sL -o ~/bin/whisper.cpp/Release/ggml-tiny-q5_1.bin \
  https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-tiny-q5_1.bin
```

### Шаг 3: Создать Python обёртку
Файл: `~/bin/stt_whisper_cpp.py`

```python
#!/usr/bin/env python3
"""STT через whisper.cpp — макс скорость."""
import subprocess, json, sys, os

WHISPER_CLI = os.path.expanduser("~/bin/whisper.cpp/Release/whisper-cli.exe")
MODEL = os.path.expanduser("~/bin/whisper.cpp/Release/ggml-tiny-q5_1.bin")

def transcribe(audio_path: str) -> str:
    cmd = [
        WHISPER_CLI,
        "-m", MODEL,
        "-f", audio_path,
        "-l", "ru",
        "-t", "4",
        "--vad",
        "--no-timestamps",
        "-np",
        "-otxt",
    ]
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        return f"Error: {result.stderr.strip()}"
    
    # Ищем текст после последней строки с временной меткой
    lines = result.stdout.strip().split('\n')
    text_lines = [l for l in lines if l and not l.startswith('[')]
    return ' '.join(text_lines).strip() if text_lines else ""

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: stt_whisper_cpp.py <audio.ogg>")
        sys.exit(1)
    text = transcribe(sys.argv[1])
    print(json.dumps({"text": text}, ensure_ascii=False))
```

---

## Использование

### CLI
```bash
python ~/bin/stt_whisper_cpp.py голосовое.ogg
# → {"text": "расшифрованный текст"}
```

### В Python коде
```python
import subprocess, json

def stt(audio_path: str) -> str:
    result = subprocess.run(
        ["python", "~/bin/stt_whisper_cpp.py", audio_path],
        capture_output=True, text=True
    )
    data = json.loads(result.stdout)
    return data.get("text", "")

# Использование:
text = stt("voice_note_2026-06-29.ogg")
print(f"Распознано: {text}")
```

### Интеграция с Hermes Gateway
В конфиге Hermes (`config.yaml`):
```yaml
stt:
  provider: custom
  command: python ~/bin/stt_whisper_cpp.py {audio_path}
```

---

## Fallback faster-whisper

Если whisper-cli не доступен (не скачан, битый):

```bash
pip install faster-whisper
```

```python
from faster_whisper import WhisperModel

model = WhisperModel("tiny", device="cpu", compute_type="int8")
segments, info = model.transcribe("audio.ogg", language="ru")
text = " ".join(seg.text for seg in segments)
```

**Производительность:** ~2x медленнее whisper.cpp на той же модели.

---

## Интеграция с Hermes

### Через TG Gateway
Когда пользователь шлёт голосовое в Telegram:
1. Gateway скачивает `.ogg` файл
2. Gateway вызывает `stt_whisper_cpp.py`
3. Текст сообщения передаётся в Hermes как обычный текст
4. Hermes отвечает текстом

### Через CLI (Desktop)
Пользователь говорит в микрофон:
1. Запись через `arecord` / `ffmpeg` → `.ogg`
2. Вызов `stt_whisper_cpp.py`
3. Текст → Hermes

---

## Известные проблемы

| Проблема | Причина | Решение |
|----------|---------|---------|
| Пустой текст | VAD вырезал речь | Убрать `--vad` |
| Китайские иероглифы | Не указан `-l ru` | Добавить `-l ru` |
| Медленно на русском | Auto-detect языка | Явно указать `-l ru` |
| Ошибка `access denied` | Windows защита | Запустить от имени пользователя |
| whisper-cli не найден | Не скачан | Проверить `ls ~/bin/whisper.cpp/Release/` |
| Длинные сообщения >60 сек | Процесс может упасть | Разбивать на чанки по 30-60 сек |

---

## Связи
- [[Hermes Agent]] — интеграция через gateway
- [[Windows Специфика]] — работает под git-bash
- [[TG Gateway]] — голосовые сообщения из Telegram
