---
created: 2026-07-02
updated: 2026-07-02
version: v1
tags: [runpod, comfyui, sdxl, deploy, b2, golden-archive, gpu, production]
status: рабочая
description: "Полный жизненный цикл RunPod — от старта пода до корректного завершения. SDXL (Big Love family), template 2lv7ev3wfp."
---

# RunPod Playbook v1

> **Рабочая версия.** Не редактировать напрямую — апгрейды через v2/v3.
> Источник: зафиксировано после двухдневного аудита (2026-06-29–30, 07-02).
**Правило:** TERMINATE всегда, НИКОГДА STOP — STOP держит под живым и жжёт $0.16-0.27/h.
**Метод:** Только через RunPod SDK. REST `/v2/*` мёртв.

---

## Этап 0 — Инвентаризация (актуально на 02.07.2026)

### ✅ Подтверждено

| Актив | Статус | Детали |
|-------|--------|--------|
| **RunPod API key** | ✅ **ЖИВОЙ** | `rpa_4EGLEG...` (APY/RUNPOD/RUNPOD_1.txt, 205b). Подтверждён через SDK: get_gpu(A5000) → Secure=True, Community=True |
| **Template 2lv7ev3wfp** | ✅ **РАБОТАЕТ** | ComfyUI - CUDA 13. Порты 8188+8888 встроены. container_disk=50GB |
| **Template d1zgyr7rjh** | ❌ **BROKEN** | Контейнер не стартует (uptime=0). НЕ ИСПОЛЬЗОВАТЬ |
| **REST API /v2/** | ❌ **МЁРТВ** | Все эндпоинты 404 с июня 2026. Только SDK/GraphQL |
| **RunPod SDK 1.10.0** | ✅ Установлен | `python -c "import runpod"` ✅ |
| **SSH ключ** | ✅ | `~/.ssh/runpod_key` + `runpod_key.pub` (сгенерирован 2026-06-26) |
| **B2 CLI** | ✅ | Установлен. Buckets: `ALEX.STORAGE`, `biglove-storage` |

### ✅ GPU доступность (проверено SDK, 02.07)

| GPU | VRAM | Secure | Community | COMMENT |
|-----|------|--------|-----------|---------|
| **RTX A5000** ⭐ | 24GB | **$0.27/h** | **$0.16/h** 🎯 | PRIMARY — самый дешёвый |
| **RTX 3090** | 24GB | $0.46/h | **$0.22/h** | Fallback 1 |
| **RTX A6000** | 48GB | $0.49/h | — | Fallback 2 |
| **RTX 4090** | 24GB | $0.69/h | $0.39/h | Для тренировок |

### ✅ B2 deploy_bundle/ (актуальные архивы для деплоя)

| Архив | Размер | Содержимое | Обновлён |
|-------|--------|-----------|----------|
| `golden_comfyui.tar` | **53.7 GB** | Полный ComfyUI + custom_nodes + модели + LoRA | 2026-06-30 |
| `golden_models.tar.zst` | **25.2 GB** | Чекпоинты + LoRA + VAE + CLIP + Upscaler | 2026-06-30 |
| `golden_comfyui_base.tar.zst` | 240 MB | ComfyUI код + deps | 2026-06-30 |
| `golden_nodes.tar.zst` | 151 MB | Custom nodes (Impact Pack, WAS, KJNodes...) | 2026-06-30 |
| `golden_onetrainer.tar` | 11 MB | OneTrainer (Nerogar) | 2026-06-30 |
| `golden_deploy.sh` | 1.3 KB | Скрипт деплоя за 2 мин | 2026-06-30 |
| `golden_config.md` | 1.9 KB | Конфиг промптов/LoRA | 2026-06-30 |
| `comfyui_FULL_backup_2026-07-01.tar.gz` | **22.2 GB** | Полный backup от 1 июля | 2026-07-01 |
| `restore_comfyui.sh` | 805 B | Скрипт восстановления | 2026-07-01 |
| `godtier_omni_v2.tar.gz` | 7.8 MB | Скрипты GODTIER | 2026-06-10 |
| `godtier_repos_v2.tar.gz` | 67 MB | Репозитории | 2026-06-11 |

### ✅ Чекпоинты на B2 (models/checkpoints/)

- `Lustify_apexV8.safetensors` — 6.9 GB (основной NSFW/SFW merge)
- `bigLove_photo6.safetensors` — 6.9 GB (SFW)
- `Lustify_apexV8.safetensors` — 6.9 GB (NSFW)

### ❌ Не проверено/требует уточнения

- **MEGA_SNAPSHOT / GODTIER_OMNI** — WAR333_GODTIER_OMNI archives были в Downloads (май 2026), но сейчас не найдены как структура. Возможно, ключевые скрипты уже интегрированы в deploy.sh v8.6 (3635 строк). Проверить при следующем запуске пода.
- **GraphQL метод B2-выгрузки** — не найден в TG-архивах. Используется `b2 file upload` / `rclone copy`.
- **36 custom nodes из MEGA_SNAPSHOT** — часть могла устареть за месяц. golden_comfyui.tar содержит актуальный набор.

---

## Этап 1 — Старт пода

### Precheck (обязательно перед созданием)

```bash
# 1. Проверить активные поды — если есть, не создавать новый
python /path/to/scripts/runpod/check_pod.py --all

# 2. Проверить GPU доступность
python /path/to/scripts/runpod/start_pod.py --check-gpu

# 3. Убедиться что нет забытых подов (killswitch)
```

### Создание пода

```bash
# Самый дешёвый вариант: A5000 Community Cloud $0.16/h
python /path/to/scripts/runpod/start_pod.py \
  --name "gen-girl-$(date +%Y%m%d_%H%M)" \
  --gpu "NVIDIA RTX A5000" \
  --cloud COMMUNITY

# Если A5000 недоступен — fallback на 3090 Community ($0.22/h)
# start_pod.py автоматически пробует: A5000 → 3090 → A6000
```

**Что делает скрипт:**
1. Читает ключ из `APY/RUNPOD/RUNPOD_1.txt`
2. Проверяет GPU доступность через `runpod.get_gpu()`
3. Создаёт под с template `2lv7ev3wfp`, image `runpod/comfyui:cuda13.0`
4. Ждёт готовности (polling до 5 мин): status=RUNNING, uptime>0, GPU!=N/A
5. Сохраняет информацию в `APY/runpod/active_pod.json`
6. Выводит: proxy URL, SSH команду, pod ID

**Параметры SDK — проверено работает (template_id + image_name обязательны вместе):**
```python
runpod.create_pod(
    name="gen-girl-20260702",
    image_name="runpod/comfyui:cuda13.0",    # обязательно!
    template_id="2lv7ev3wfp",                 # обязательно!
    gpu_type_id="NVIDIA RTX A5000",           # строка, НЕ массив
    cloud_type="COMMUNITY",                   # COMMUNITY | SECURE
    support_public_ip=True,
    start_ssh=True,
    gpu_count=1,
    volume_in_gb=0,                           # без network volume
    container_disk_in_gb=50,                  # НЕ container_disk_size_gb
    ports="8888/http,8188/http,22/tcp",
)
```

### Restore из snapshot/B2

```bash
# Подключиться к поду по SSH
ssh -o StrictHostKeyChecking=no -i ~/.ssh/runpod_key \
  -p <SSH_PORT> root@<SSH_IP>

# На поде: скачать и распаковать golden archive (2 минуты)
cd /workspace

# 1. Установить rclone (если нет)
curl -s https://rclone.org/install.sh | bash
mkdir -p /root/.config/rclone

# 2. Создать rclone.conf (скопировать с локальной машины)
# Локально: scp /path/to/rclone.conf root@pod:/root/.config/rclone/rclone.conf

# 3. Скачать golden archive
rclone copy b2:ALEX.STORAGE/deploy_bundle/golden_comfyui.tar /workspace/ --progress
# ≈ 2-3 мин при 310 MB/s

# 4. Проверка целостности (checksum)
# golden_comfyui.tar — 53.7 GB, нет отдельного .sha256 файла
# Альтернатива: проверить что файл открывается корректно
tar -tf golden_comfyui.tar 2>/dev/null | head -5 && echo "ARCHIVE OK" || echo "ARCHIVE CORRUPT"

# 5. Распаковать
mkdir -p /workspace/runpod-slim
tar -xf /workspace/golden_comfyui.tar -C /workspace/runpod-slim/
# ≈ 30-60 сек

# 6. Проверить целостность распакованного
ls -la /workspace/runpod-slim/ComfyUI/models/checkpoints/ | head -5
ls -la /workspace/runpod-slim/ComfyUI/models/loras/ | head -5
```

### Время и стоимость запуска

| Фаза | Время | Стоимость | Примечание |
|------|:-----:|:---------:|-----------|
| Создание пода (API + GPU allocation) | 30-120 сек | $0.001-0.005 | Счётчик ещё не пошёл |
| Ждать RUNNING + uptime > 0 | 1-5 мин | $0.003-0.013 | GPU выделяется |
| Golden archive download | 2-3 мин | $0.005-0.008 | 53.7 GB @ 310 MB/s |
| Распаковка | 30-60 сек | $0.001-0.003 | tar -xf |
| **TOTAL до готовности** | **~5-10 мин** | **~$0.01-0.03** | |

**GPU-время в час:** A5000 Community $0.16/h, Secure $0.27/h.

**Бюджет сессии (пример):** 30 мин генерации = $0.08 (Community) или $0.14 (Secure).

---

## Этап 2 — Рабочий цикл

### Запуск ComfyUI workflow

**На поде (через SSH):**
```bash
# 1. Если ComfyUI ещё не запущен — запустить
bash /workspace/runpod-slim/ComfyUI/deploy_workflow.sh

# Или руками:
pkill -f "main.py" 2>/dev/null; sleep 2
cd /workspace/runpod-slim/ComfyUI
python3 main.py --listen 0.0.0.0 --port 8188 --cpu-vae > /workspace/comfyui.log 2>&1 &

# 2. Отправить workflow через API
WORKFLOW_FILE="workflows/my_workflow.json"
PROXY_URL="https://<PODHOSTID>-8188.proxy.runpod.net"

# Прочитать workflow и подставить Seed
SEED=$RANDOM
WORKFLOW=$(cat "$WORKFLOW_FILE" | sed "s/__SEED__/$SEED/g")

# Отправить
PROMPT_ID=$(curl -s -X POST "$PROXY_URL/prompt" \
  -H "Content-Type: application/json" \
  -d "{\"prompt\":$WORKFLOW,\"client_id\":\"hermes\"}" | \
  python3 -c "import sys,json; print(json.load(sys.stdin).get('prompt_id',''))")

echo "Prompt ID: $PROMPT_ID"
```

### Агент-взаимодействие с подом

**Правила (чтобы избежать 245K токенов как в прошлый раз):**
- Только **один SSH вызов** на команду (не tail -f, не интерактив)
- Polling статуса — короткий HTTP GET на `/queue`, не полный лог
- Загрузка на B2 — через rclone с пода (не через local)
- Минимальный toolset: `terminal` + `file`, без `browser`/`vision`/`web`

**Минимальный шаблон для агента:**
```
# Создать под → дождаться готовности:
python start_pod.py --name gen-girl-20260702

# Задеплоить golden archive (на поде):
rclone copy b2:ALEX.STORAGE/deploy_bundle/golden_comfyui.tar ./
tar -xf golden_comfyui.tar

# Запустить генерацию (1 вызов):
PROMPT_ID=$(curl -s -X POST "$PROXY_URL/prompt" -H "Content-Type: application/json" \
  -d "{\"prompt\":$WORKFLOW,\"client_id\":\"hermes\"}" | python3 -c "import sys,json;print(json.load(sys.stdin)['prompt_id'])")

# Проверить статус (1 короткий GET):
curl -s "$PROXY_URL/history/$PROMPT_ID" | python3 -c "import sys,json;d=json.load(sys.stdin);print('Done' if d.get('status',{}).get('completed') else 'running')"

# Скачать (1 вызов):
rclone copy /workspace/runpod-slim/ComfyUI/output/ b2:ALEX.STORAGE/generations/2026-07-02/

# TERMINATE (1 вызов):
python stop_pod.py
```

### Мониторинг статуса

```bash
# Короткая проверка — жив ли под и работает ли ComfyUI
python /path/to/scripts/runpod/check_pod.py

# Watch mode (обновление каждые 15 сек)
python /path/to/scripts/runpod/check_pod.py --watch

# Ручная проверка через proxy (если нужен быстрый curl)
curl -s "https://<PODHOSTID>-8188.proxy.runpod.net/queue"

# Via ComfyUI API — сколько в очереди, сколько генерится сейчас
# Возврат: {"queue_running": 1, "queue_pending": 2}
```

**⚠️ Важно:** `uptimeSeconds: 0` НЕ означает что под не работает. ComfyUI может быть жив через proxy даже когда API показывает uptime=0.

### Забор результата

**Метод 1 — rclone с пода на B2 (рекомендуется, если под жив + SSH):**
```bash
# На поде:
rclone copy /workspace/runpod-slim/ComfyUI/output/ \
  b2:ALEX.STORAGE/generations/$(date +%Y-%m-%d)/ --progress
```

**Метод 2 — ComfyUI API download (если SSH недоступен):**
```bash
# Скачать через proxy
curl -o result.png "$PROXY_URL/api/view?filename=output.png&type=output&subfolder="
```

**Метод 3 — через fetch_results.py:**
```bash
python /path/to/scripts/runpod/fetch_results.py
# Автоматически: SSH→rclone, fallback→proxy download, fallback→local upload
```

**Цель:** < 2 минут от "стоп" до "результаты на B2".

---

## Этап 3 — Апгрейды/эволюция

### Versioning-дисциплина

| Версия | Статус | Где | Когда |
|--------|--------|-----|-------|
| **v1** (эта) | ✅ **Рабочая** | `01-WIKI/RunPod-Playbook.md` | 2026-07-02 |
| v2 | 🟡 В разработке | `01-WIKI/RunPod-Playbook-v2.md` | TBD |
| v7-v11 | 🔴 Архив | archive/godtier, command_center/ | Май-июнь 2026 |

**Правила:**
- Никогда не редактировать рабочую версию напрямую — создавать `-v2`, потом promote
- В памяти хранить ТОЛЬКО номер текущей рабочей версии
- Промежуточные попытки — в архив, не затирают рабочую

### Добавление новых LoRA/моделей

```bash
# 1. На поде (текущая сессия):
cd /workspace/runpod-slim/ComfyUI
# Качать новую LoRA в models/loras/
wget "https://civitai.com/api/download/models/{versionId}?token={token}" \
  -O models/loras/new_lora.safetensors --max-time 600

# 2. Протестировать (не ломая текущий workflow):
# Создать workflow в копии — не редактировать working workflow
cp workflows/working.json workflows/test_new_lora.json

# 3. Если тест прошёл — обновить golden archive на B2:
tar -uf golden_comfyui_new.tar \
  /workspace/runpod-slim/ComfyUI/models/loras/new_lora.safetensors
rclone copy golden_comfyui_new.tar b2:ALEX.STORAGE/deploy_bundle/

# 4. Promote: НЕ удалять старый golden_comfyui.tar.
# Новый называть golden_comfyui_v2.tar
# Старый оставить как fallback
```

### Обновление playbook

Когда пайплайн меняется:
1. Создать копию: `01-WIKI/RunPod-Playbook-v2.md`
2. Внести изменения в v2
3. Протестировать на реальном поде
4. Если тест прошёл — поменять `status: рабочая` в v2, убрать из v1
5. В памяти (и search-before-acting) будет только актуальная версия

---

## Этап 4 — Завершение пода

### Чеклист перед остановкой

- [ ] Результаты сохранены на B2? (`python fetch_results.py`)
- [ ] Все новые модели/LoRA залиты на B2?
- [ ] Конфиги/workflows сохранены?
- [ ] Нет активных генераций в очереди? (`check_pod.py` или `/queue`)

### Терминирование (только SDK, REST мёртв)

```bash
# Вариант 1 — через скрипт (читает active_pod.json)
python /path/to/scripts/runpod/stop_pod.py

# Вариант 2 — убить конкретный под
python /path/to/scripts/runpod/stop_pod.py --pod POD_ID

# Вариант 3 — убить все поды (если что-то забыли)
python /path/to/scripts/runpod/stop_pod.py --all
```

`terminate_pod()` внутри: `runpod.terminate_pod(pod_id)` через GraphQL (SDK).
Подтверждение: `get_pod()` возвращает TERMINATED или выбрасывает исключение (под удалён).
**НЕ ИСПОЛЬЗОВАТЬ `curl -X DELETE`** — REST `/v1/pods` возвращает 404, под не удаляется.

### Проверка что GPU-биллинг прекратился

```bash
# 1. Проверить через SDK — под должен исчезнуть из списка
python /path/to/scripts/runpod/check_pod.py --all
# Ожидаемый вывод: "No active pods found."

# 2. Альтернатива — через SDK get_pods() (НЕ curl — REST мёртв):
python3 -c "
import runpod
with open('APY/RUNPOD/RUNPOD_1.txt') as f:
    runpod.api_key = [l.strip() for l in f if l.startswith('rpa_')][0]
pods = runpod.get_pods()
print(f'Active pods: {len(pods)}')
"
# Если нет активных подов — биллинг остановлен. Если всё ещё RUNNING — terminate не сработал.

### Killswitch — автоматическая защита от забытых подов

**Зачем:** Забытый под на ночь = $1.28-2.16 (8 ч × $0.16-0.27/h). Уже было однажды.

**Как настроен:**
```bash
# Cron job: каждые 3 мин, no_agent=True (без LLM, без токенов)
# Убивает поды с uptime > 15 мин без активной генерации
# Hard limit: любой под с uptime > 90 мин (даже с активностью)
```

**Проверить что killswitch активен:**
```bash
hermes cron list | grep killswitch
```

**Если killswitch не настроен — добавить:**
```python
cronjob(
    action='create',
    name='runpod-killswitch',
    schedule='every 3m',
    script='runpod_killswitch.py',
    no_agent=True,
    enabled_toolsets=['terminal'],
)
```

### Аварийное завершение (пропустил чеклист)

Если под убивается аварийно (сбой соединения, забыл killswitch):
1. **Данные не пропадают** — ComfyUI output/ хранится на поде. Пока под жив (хотя бы 15 мин по killswitch) — можно успеть скачать.
2. **B2 как страховка** — если настроен auto-upload результатов (в deploy workflow), каждый результат дублируется на B2 сразу после генерации.
3. **Худший сценарий** — под убили до upload. Результаты потеряны. Перегенерировать.
4. **Профилактика:** каждый деплой workflow должен включать `rclone copy output/ b2:...` как часть скрипта.

---

## Полный pipeline (одна команда)

```bash
# Весь цикл: создать → задеплоить → сгенерировать → забрать → убить
python start_pod.py && \
python check_pod.py --pod $(python -c "import json;print(json.load(open('APY/runpod/active_pod.json'))['pod_id'])") && \
# ... отправить workflow через SSH/proxy ...
python fetch_results.py && \
python stop_pod.py
```

---

## Скрипты

| Файл | Назначение | Зависимости |
|------|-----------|-------------|
| `scripts/runpod/start_pod.py` | Создание пода + ожидание GPU | RunPod SDK, ключ |
| `scripts/runpod/stop_pod.py` | TERMINATE пода(ов) | RunPod SDK, ключ |
| `scripts/runpod/check_pod.py` | Мониторинг: жив/очередь/cтоимость | RunPod SDK + HTTP |
| `scripts/runpod/deploy_workflow.sh` | Развёртывание ComfyUI на поде | SSH на под |
| `scripts/runpod/fetch_results.py` | Забор результатов (SSH→B2 / proxy) | RunPod SDK, b2 CLI |

**Все скрипты:** `WORK/scripts/runpod/`

---

## Питфоллы (добыто кровью)

| Проблема | Симптом | Решение |
|----------|---------|---------|
| API key masking | curl/patch заменяет `rpa_...` на `***` | Читать ключ из файла через Python (не через shell) |
| template_id + image_name | `QueryError: Container image name is required` | Передавать **оба** параметра вместе |
| container_disk_in_gb | `TypeError: unexpected keyword argument` | Использовать `_in_gb`, не `_size_gb` |
| uptimeSeconds: 0 | API показывает 0, но ComfyUI работает | Проверять через proxy, не через API |
| SSH + pkill | SSH сессия умирает после pkill | pkill и nohup в разных SSH вызовах |
| --normalvram | `unrecognized arguments: --normalvram` | Заменить на `--normal-vram` (ComfyUI 0.26+) |
| --high-vram | Флаг не существует в этой версии | Убрать флаг совсем |
| REST API /v2/* мертв | 404 на все эндпоинты | Использовать Python SDK (GraphQL) |
| Cloudflare Error 1010 | 403 при curl запросах | SDK использует GraphQL — обходит CF |
| GPU:N/A | Под RUNNING, но GPU не выделен | costPerHr=0 → TERMINATE, не ждать |
