---
created: 2026-06-29
tags: [deploy, golden, archive, optimization, runpod]
---

# Golden Deploy — 2-Minute Pod Setup

> **Raw sources absorbed:** `2026-06-30-tz-golden-pod` · `2026-06-30-golden-config-v2`

> Система быстрого развёртывания RunPod пода с ComfyUI + SDXL генерацией.
> **Цель:** от создания пода до готовности к генерации — < 2 минут.

---

## Архитектура

```mermaid
graph LR
    B2[B2 ALEX.STORAGE] -->|golden archives| Pod[RunPod A5000]
    
    subgraph "deploy_bundle/"
        Base[golden_comfyui_base.tar.zst - 230MB]
        Nodes[golden_nodes.tar.zst - 145MB]
        Models[golden_models.tar.zst - 24GB]
        Script[golden_deploy.sh]
    end
    
    Base --> Extract1[ComfyUI code + deps]
    Nodes --> Extract2[Impact Pack + WAS + KJNodes]
    Models --> Extract3[bigLust_v16 + photo4 + insta1 + VAE + CLIP + Upscaler]
```

## Расписание деплоя

| Фаза | Сек | Что происходит |
|------|-----|---------------|
| rclone config | 2 | B2 авторизация |
| Download base + nodes | 5 | 375MB при 70MB/s |
| Download models | 60-90 | 24GB при ~300MB/s (B2 CDN cached) |
| Extract archives | 20-40 | zstd + tar |
| Verify + start ComfyUI | 5 | Health check |
| **TOTAL** | **~90-120** | **< 2 минут 🚀** |

## Архивы на B2

### Архитектурные архивы (для деплоя с нуля)
| Архив | Размер | Содержимое | Обновляется |
|-------|--------|-----------|------------|
| `golden_comfyui_base.tar.zst` | 230MB | ComfyUI код, Python зависимости | Редко |
| `golden_nodes.tar.zst` | 145MB | Custom nodes (Impact Pack, WAS, KJNodes, Manager, Civilcomfy) | При добавлении нод |
| `golden_models.tar.zst` | 24GB | checkpoints/, loras/, vae/, clip/, upscale_models/ | При смене моделей |

### Быстрый backup (2026-07-01)
| Архив | Размер | Содержимое |
|-------|--------|-----------|
| `comfyui_backup_2026-07-01.tar.gz` | **3.2 GB** | custom_nodes/ + models/ (controlnet, ipadapter, upscale) + input/ — **без чекпоинтов** |
| `restore_comfyui.sh` | 765 B | Скрипт восстановления |

**Restore процедура (2 мин):**
```bash
# 1. Создать под: шаблон 2lv7ev3wfp, Community Cloud ($0.16/h)
# 2. b2 authorize-account ... && b2 file download b2://ALEX.STORAGE/comfyui_backup_2026-07-01.tar.gz /tmp/backup.tar.gz
# 3. tar xzf /tmp/backup.tar.gz -C /workspace/runpod-slim/
# 4. Скачать чекпоинты с CivitAI (bigLust_v16 6.5GB + Lustify_apexV8 6.5GB)
# 5. Запустить ComfyUI
```

**Что работает сразу:**
- FaceDetailer + Detail Daemon ✅
- ControlNet Depth (xinsir, 2.4GB) ✅
- IP-Adapter Plus Face (809MB) ✅ — но нужен CLIP Vision
- 4x-UltraSharp Hires ✅

**Не работает:**
- IP-Adapter — ❌ без CLIP Vision (ViT-bigG) — **критичный блокер**
- ControlNet OpenPose — ❌ 0 байт (обрыв)
- Чекпоинты — ❌ надо качать с CivitAI

## Создание архивов (на поде)

```bash
cd /workspace/runpod-slim

# Base (без моделей)
tar --exclude=models -cf - ComfyUI/ | zstd -10 -o gold_comfyui_base.tar.zst -

# Модели (все safetensors)
tar -cf - ComfyUI/models/checkpoints/ ComfyUI/models/loras/ \
  ComfyUI/models/vae/ ComfyUI/models/clip/ \
  ComfyUI/models/upscale_models/ | zstd -8 -o gold_models.tar.zst -

# Upload
rclone copy /workspace/gold_*.tar.zst b2_storage:ALEX.STORAGE/deploy_bundle/
```

## Процесс деплоя

```bash
# 1. Создать под на RunPod с template "ComfyUI - CUDA 13"
# 2. SSH подключиться
# 3. Запустить:
bash /workspace/deploy_bundle/golden_deploy.sh
# 4. Через 2 мин — ComfyUI на localhost:8188 ✅
```

---

## ═══════ LORA СТЕКИ SDXL (С ПОЛНЫМИ URL) ═══════

> Источник: `2026-06-30-tz-golden-pod` — оригинальное ТЗ с полными CivitAI URL

### Стек 1: Универсальная база (кожа + детализация)

| LoRA | URL | Вес |
|------|-----|-----|
| Detail Tweaker XL | `civitai.com/models/122359` | 0.5-0.8 |
| Skin Realism (Acne, Imperfections) | `civitai.com/models/248951` | 0.4-0.6 |
| Realistic Skin Texture (Detailed Skin) | `civitai.com/models/580857` | кросс-модель |
| xl_more_art-full / Better Picture | `civitai.com/models/126343` | общий буст |
| Realism Lora By Stable Yogi (SDXL) | `civitai.com/models/1100721` | всё-в-одном |

### Стек 2: Лицо + Глаза (портреты)

| LoRA | URL | Вес |
|------|-----|-----|
| Better Faces LoRA | `civitai.com/models/301988` | 0.5-0.7 |
| DetailedEyes_XL | `civitai.com/models/120723` | детальные глаза |
| Better Portraits - Better Eyes | `civitai.com/models/1492801` | 0.5-0.7 |
| Eye Detail LoRA | `civitai.com/models/1300857` | совместим |
| Polyhedron_all (skin/hands/eyes) | `civitai.com/models/135160` | 0.4-0.55 |

### Стек 3: Руки + Пальцы

| LoRA | URL | Вес |
|------|-----|-----|
| ClearHandsXL | `civitai.com/models/132884` | 0.6-1.0 |
| Hands XL (multi-model) | `civitai.com/models/200255` | популярный |
| Hand Fixer Concept LoRA | `civitai.com/models/845407` | триггер handfixer |
| SDXL Cross Style Hand Fixing | `civitai.com/models/211577` | |

### Стек 4: Полное тело + Гиперреализм

| LoRA | URL |
|------|-----|
| Realism Lora By Stable Yogi Pony | `civitai.com/models/1098033` |
| Detail Slider LoRA | `civitai.com/models/402462` |
| Real Skin Slider | `civitai.com/models/1486921` |

### Стек 5: Максимальный гиперреализм

| LoRA | URL |
|------|-----|
| ReaLora/Realistic | `civitai.com/models/137258` |
| Perfect Eyes SDXL | `civitai.com/models/256740` |
| Eye Concept SDXL | `civitai.com/models/2070056` |

### Дополнительные LoRA (стилизация)

| LoRA | URL |
|------|-----|
| Subtle Styles | `civitai.com/models/1115264` |
| Subtle Lighting | `civitai.com/models/1534772` |
| Subtle Physique | `civitai.com/models/1569830` |
| Subtle Poses | `civitai.com/models/1444070` |
| Subtle UltraRes | `civitai.com/models/1480555` |

### Источники с civitai.red

| LoRA | URL |
|------|-----|
| Big Love Photo1 (SFW) | `civitai.red/models/897413 (v2857189)` |
| Lustify SDXL NSFW | `civitai.red/models/573152 (v2808677)` |
| Apex Flow Highres | `civitai.red/models/2503119` |

---

## ═══════ WORKFLOW COMFYUI ═══════

```
Checkpoint (bigLust_v16)
→ LoRA Stack (max 4-6, weights 0.4-0.8)
→ IPAdapter FaceID Plus v2 (HF)
→ ControlNet ×3 (Union ProMax: Depth + OpenPose + Canny)
→ KSampler (dpmpp_2m_sde, 50 steps, CFG 7)
→ Detail Daemon (0.15-0.25, start 0.2, end 0.8)
→ VAE Decode
→ FaceDetailer (yolov8x-face, denoise 0.3)
→ 4x-UltraSharp upscale
→ Save Image
```

### Detail Daemon Setup
- **Node:** `Jonseed/ComfyUI-Detail-Daemon` (установить в custom_nodes/)
- detail_amount: **0.1-0.5** (старт 0.2, энд 0.8)
- LyingSigmaSampler: dishonesty_factor -0.03 to -0.07
- Не LoRA — отдельный нод граф, добавляет микро-детализацию через SamplerCustom

### ComfyUI запуск (проверено 2026-07-01)
- **Флаг `--high-vram`:** НЕ РАБОТАЕТ (unrecognized arguments)
- **Рабочая команда:** `python3 main.py --listen 0.0.0.0 --port 8188`
- **Detail Daemon custom node:** git clone Jonseed/ComfyUI-Detail-Daemon

### GODTIER GEN v1 (2026-07-01)
- Флагманский скрипт генерации: `godtier_gen_v1.py`
- 4:5 (1024×1280) — строгий формат
- Random seeds
- 10 динамических body промптов (full body, bust, half body, close up)
- 3-раундовый LoRA тестинг: core → extended → full stack
- Detail Daemon (0.3-0.5) + LyingSigmaSampler (-0.03 to -0.07)
- **sfw_gen_fixed.py результат:** 64/66 OK, 2 timeout

### Чекпоинты (актуально на 2026-07-01)
- **bigLove_photo6** (6.6GB) ✅ — SFW Photo6
- **bigLust_v16** (6.6GB) ✅ — лучший NSFW
- **Lustify_apexV8** (6.6GB) ✅ — новый NSFW чекпоинт (civitai.red #573152 v2808677)
- **test_photo5** (6.6GB) — запасной (не удалён)
- LoRA: 31 .safetensors (StS_PonyXL_Detail_Slider, skin_texture_xl_v4, BetterFaces, polyhedron, DetailedEyes_V3, etc.)
- Detail Daemon + LyingSigmaSampler установлены
- OneTrainer: клонирован (12MB) — ещё не архивирован

---

## ═══════ SFW vs NSFW СТРАТЕГИЯ ═══════

| Аспект | SFW (Instagram/TikTok) | NSFW (Big Love) |
|--------|-----------------------|------------------|
| Чекпоинт | RealVisXL или Juggernaut XL | Big Love Photo1 |
| LoRA кол-во | 5-6 | 3-5 |
| Негатив | Очень сильный | Слабый/средний |
| Лицо | average face + 4ng3l face | remarkable face |
| Промпт | natural, amateur, candid | soft/dramatic light, pro photo |
| Детали | FaceDetailer + Inpaint на руки | ControlNet + Subtle Physique |

---

## ═══════ GOLDEN ARCHIVES STATUS ═══════

| Архив | Размер | Статус |
|-------|--------|--------|
| `golden_comfyui_base.tar.zst` | 240MB | ✅ Готов |
| `golden_nodes.tar.zst` | 144MB (+ Detail Daemon) | ✅ Готов |
| `golden_models.tar.zst` | 23.5GB | 🟡 Нужно добавить LoRA |
| `golden_onetrainer.tar.zst` | — | ❌ Создать |

---

## ═══════ POD WORK ORDER ═══════

Последовательность действий при деплое нового пода:

1. **Деплой** `golden_deploy.sh` → ComfyUI за 2 мин
2. **Custom nodes** `git clone ComfyUI-Detail-Daemon` в `custom_nodes/`
3. **LoRA** Скачать ВСЕ LoRA через экспорт токена CivitAI
4. **OneTrainer** Создать `golden_onetrainer.tar.zst`
5. **Датасет** Сгенерировать (ControlNet, 100% лицо)
6. **Обновить** `golden_models.tar.zst` (включить LoRA)
7. **Залить** всё на B2
8. **Терминировать** под

---

## Связи
- [[STACK/SDXL Test Report 29 June]] — анализ качества
- [[Deploy Script]] — старый deploy.sh v8.6
- [[B2 Storage]] — bucket структура
- [[GODTIER V8]] — пайплайн
- [[AI Influencer Pipeline]] — полный цикл создания персонажа
- `2026-06-30-tz-golden-pod` — raw source: LoRA URL и ТЗ
- `2026-06-30-golden-config-v2` — raw source: v2 конфиг
- `GOLDEN_DEPLOY_v2` — сводный master-документ
- skill: `golden-deploy` — процедура деплоя
