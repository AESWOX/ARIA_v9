---
created: 2026-07-22
updated: 2026-07-22
tags: [runpod, deployment, history, alias]
status: alias
---
# RunPod GPU Deployment History

Сводная alias-страница для старых ссылок на историю деплоя.

## Смотреть в первую очередь
- [[STACK/RunPod-Playbook]] — текущий production playbook
- [[STACK/Golden Deploy]] — быстрый golden deploy
- [[PROJECTS/AI-Influencer/09-Deploy-Procedure]] — процедура деплоя в проекте
- [[_archive/RunPod]] — архив старых заметок по RunPod
