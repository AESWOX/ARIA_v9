---
created: 2026-06-27
tags: [b2, debugging, uv, zombie-processes]
source: session 20260626_152454_4602cc
---

# B2 Debugging — UV Python Zombies

> Проблема: B2 upload падал с `get_input_stream error`. Решение: убить UV python зомби.

## Симптомы
- `POST /api/b2/upload` → 500 Internal Server Error
- `get_input_stream error` в b2sdk
- Каждый перезапуск сервера не помогал

## Корень проблемы
На порту 8766 висели **6 UV python зомби-процессов** со СТАРЫМ кодом b2.py.

Когда сервер "перезапускался":
1. Новый процесс не мог забиндиться — старый UV держал порт
2. Старый UV имел старый b2.py с багом upload
3. `b2.exe` с `creationflags=CREATE_NO_WINDOW` ломал `get_input_stream`

## Решение

```bash
# Убить ВСЕ UV python процессы, держащие порт
wmic process where "commandline like '%%roaming%%uv%%python%%server.py%%'" get processid
# Kill each PID
taskkill //F //PID <PID>
# Проверить чистоту
netstat -ano | grep ":8766 " | grep LISTEN || echo "CLEAN"
```

## Правило
**Перед запуском любого сервера на Windows:**
1. `netstat -ano | grep :<PORT>` — проверить кто держит порт
2. Если UV python — убить через wmic
3. Ждать 3-5 секунд после kill
4. Только потом запускать сервер

## Связи
- [[B2 Storage]] — b2.exe quadk
- [[Windows Специфика]] — subprocess, CREATE_NO_WINDOW
- [[Командный Центр CC v3]] — сервер на 8766
