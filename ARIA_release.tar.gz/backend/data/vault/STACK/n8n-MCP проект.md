---
created: 2026-06-27
updated: 2026-06-28
tags: [n8n, mcp, typescript, orchestration]
source: WORK/AI/n8n-mcp/
---

# n8n-MCP проект

> TypeScript MCP-сервер для доступа AI к n8n нодам.
> Путь: `WORK/AI/n8n-mcp/`
> Статус: установлен, n8n-mcp на :3100/mcp → 200 OK
> Последняя версия: **v2.59.2** (2026-06-19, bundles n8n 2.26.2)

## Архитектура

```
src/
├── loaders/          # NPM package loader
├── parsers/          # Node parser + property extractor
├── mappers/          # Documentation mapping
├── database/         # SQLite + FTS5 + adapter (better-sqlite3 / sql.js)
├── services/         # Property filter, validators (4 profiles), templates,
│                     # expression validator, workflow validator, type structures
├── types/            # Type structures, instance context, session state
├── constants/        # 22 complete type structures
├── mcp/              # MCP server (stdio + http), tool definitions
├── templates/        # Workflow templates from n8n.io (2,700+)
├── scripts/          # Rebuild, validate, test scripts
└── utils/            # Console, logger
```

## Последние изменения (v2.59.x)

| Версия | Дата | Новое |
|--------|------|-------|
| **2.59.2** | 2026-06-19 | `MULTI_TENANT_ALLOW_CONCURRENT_SESSIONS` — разрешить конкурентные сессии для одного instance (multi-tenant). Security: uuid 10→14, vitest 3.2.4→3.2.6, vite 6.0→6.4.3 |
| **2.59.0** | 2026-06-18 | `n8n_get_workflow mode="filtered"` — читать отдельные ноды без полного workflow |
| **2.58.0** | 2026-06-17 | Полная цепочка diff-based редактирования: diff → apply → validate — автономно в одном инструменте |

## Competitive Analysis: n8n-mcp vs Official n8n MCP

Дата: 2026-06-19 (обновление April 2026).
Источник: `WORK/AI/n8n-mcp/docs/competitive-analysis-june-2026.md` (28KB, 285 строк)

### Ключевые выводы

- **Официальный MCP обогнал по diff-редактированию:** в n8n 2.27.0 source `update_workflow` теперь использует 14 op types (diff-based), а не full-code rewrite. На stable канале пока ещё full-rewrite — преимущество n8n-mcp по токенам держится сейчас, но сойдёт при релизе 2.27.x.
- **Долгосрочные отличия n8n-mcp (moat):**
  - 🏆 **2,700+ workflow templates** — у официального ноль
  - 🏆 **Community/custom-node coverage** — ~1,845 нод (816 core + 1,029 community) против только built-in у официального
  - 🏆 **Credentials CRUD** — у официального read-only
  - 🏆 **Instance audit / security scan** — у официального нет
  - 🏆 **Workflow version history & rollback** — у официального только soft-delete
  - 🏆 **Multi-instance / SaaS** — n8n-mcp multi-tenant; официальный 1:1
  - 🏆 **`patchNodeField`** — surgical find/replace внутри поля (официальный `setNodeParameter` не умеет)
- **Валидация:** n8n-mcp глубже (4 named profiles, by-ID, 13-fix autofix). Официальный на stable канале пропускает broken configs как `valid:true`.
- **В чём официальный сильнее:** publish/unpublish lifecycle, project/folder placement, pin-data testing, native in-instance (без API ключа).

## Документация (20+ файлов)

### Deployment
- [[STACK/SELF_HOSTING]] — npx, Docker, Railway
- [[STACK/N8N_DEPLOYMENT]] — production
- [[STACK/RAILWAY_DEPLOYMENT]] — cloud
- [[STACK/DOCKER_TROUBLESHOOTING]] — Docker issues

### IDE Setup
- CLAUDE_CODE_SETUP.md, CODEX_SETUP.md, CURSOR_SETUP.md
- VS_CODE_PROJECT_SETUP.md, WINDSURF_SETUP.md, ANTIGRAVITY_SETUP.md

### Security
- SECURITY_HARDENING.md — trust model, hardening
- THREAT_MODEL.md — security analysis

## Skills (7 шт)
- `n8n-workflow-patterns` — webhook, scheduled, HTTP, database, AI
- `n8n-validation-expert` — validation + ERROR_CATALOG
- `n8n-node-configuration` — node setup + patterns
- `n8n-mcp-tools-expert` — MCP tools
- `n8n-expression-syntax` — expressions
- `n8n-code-python` — Python в n8n

## CLI commands
```bash
cd WORK/AI/n8n-mcp
npm run build         # Build TypeScript
npm run rebuild       # Rebuild node database
npm start             # MCP stdio mode
npm run start:http    # MCP HTTP mode (:3000)
npm test              # Run tests
```

## Связи
- [[GODTIER V8 Project Spec]] — часть проекта (P1)
- [[Hermes Agent]] — интеграция через MCP
