---
created: 2026-06-27
updated: 2026-06-29
tags: [hermes, deploy, install, comfyui, onetrainer, runpod]
---

# Deploy Script (deploy.sh v8.6)

> Основной скрипт развёртывания полной инфраструктуры генерации на RunPod.
> Разработан для RunPod模板 (template) — выполняется один раз при старте пода.

---

## Файл

| Атрибут | Значение |
|---------|----------|
| **Путь** | `WORK/ШОТ/deploy.sh` |
| **Размер** | 3635 строк |
| **Версия** | v8.6 |
| **Для** | RunPod template `d1zgyr7rjh` |
| **OS** | RunPod Template Linux (Ubuntu 22.04) |
| **GPU** | A5000 / A6000 / 4090 / 3090 |

---

## Что делает (полная развёртка)

### Фаза 1: Базовая инфраструктура
| Шаг | Действие | Описание |
|-----|----------|----------|
| 1.1 | `apt update && apt upgrade` | Системные пакеты |
| 1.2 | Установка Python 3.10 + pip | Основной стек |
| 1.3 | Установка CUDA toolkit | Если не предустановлен |
| 1.4 | Установка git, wget, curl, unzip | Утилиты |
| 1.5 | Создание venv | Изолированное окружение |

### Фаза 2: ComfyUI
| Шаг | Действие | Версия |
|-----|----------|--------|
| 2.1 | `git clone https://github.com/comfyanonymous/ComfyUI` | Последняя |
| 2.2 | `pip install -r requirements.txt` | Все зависимости |
| 2.3 | Установка доп. зависимостей | torch, xformers, diffusers |

### Фаза 3: OneTrainer (LoRA обучение)
| Шаг | Действие | Назначение |
|-----|----------|------------|
| 3.1 | `git clone https://github.com/Nerogar/OneTrainer` | LoRA training |
| 3.2 | `pip install -r requirements.txt` | Зависимости |
| 3.3 | Конфигурация по умолчанию | SDXL, rank=32/64 |

### Фаза 4: Custom Nodes (ComfyUI)
| Нода | Назначение | Критичность |
|------|-----------|-------------|
| **Impact Pack** | Детекторы: face_yolov8m, hand_yolov8n, body, eye | 🔴 Обязательно |
| **ControlNet** | Позы: depth, openpose, canny, tile | 🔴 Обязательно |
| **IPAdapter** | Style transfer + FaceID | 🔴 Обязательно |
| **ReActor** | Лицо (аналог FaceFusion) | 🟡 Важно |
| **WAS Node Suite** | Утилиты | 🟡 Важно |
| **ComfyUI Manager** | Управление нодами | 🟢 Удобно |
| **ComfyUI Custom Scripts** | Доп. скрипты | 🟢 Удобно |

### Фаза 5: Модели с B2 (ALEX.STORAGE)
Качает все необходимые модели через b2 CLI / rclone:

**Чекпоинты (с B2):**
- `photo5.safetensors` (6.6 GB) — основной
- `photo6.safetensors` (6.6 GB) — если есть
- `Lustify_apexV8.safetensors` (6.6 GB) — NSFW
- `insta1.safetensors` (6.6 GB) — Instagram стиль

**LoRA (с B2):**
- `dmd2_sdxl.safetensors` — быстрая генерация
- `hands_xl.safetensors` — качество рук (если добавлен)
- `skin_texture_xl.safetensors` — кожа (если добавлен)

**ControlNet (с B2):**
- `xinsirUnionProMax_v10_partial.safetensors` — универсальная

**Face Preservation (с B2):**
- `pulid_sdxl.safetensors`
- `ip-adapter-plus_sdxl.safetensors`
- `ip-adapter_sdxl.safetensors`
- `image_encoder.safetensors`

### Фаза 6: Detailer стек
| Модель | Размер | Назначение |
|--------|--------|-----------|
| `face_yolov8m.pt` | ~50 MB | Детектор лиц |
| `hand_yolov8n.pt` | ~20 MB | Детектор рук |
| `clarity_upscaler.pth` | ~200 MB | Апскейл |
| `4x_ultrasharp.pt` | ~100 MB | Альтернативный апскейл |

---

## Критические фиксы

### --normal-vram (НЕ --normalvram)
```bash
# В ComfyUI 0.26.0+ флаг изменился:
# НЕ работает:
python main.py --normalvram
# РАБОТАЕТ:
python main.py --normal-vram
```

### Порты — ставить ОБА с первого раза
```bash
# Шаблон RunPod: Template Ports
8888  # Jupyter (опционально)
8188  # ComfyUI (обязательно)
22    # SSH (автоматически)
```

**Почему важно:** Если порт 8188 не указан при создании пода, ComfyUI будет недоступен через RunPod proxy. Пересоздать под = новая зарядка моделей.

### CUDA версия
RunPod Template Linux обычно имеет CUDA 12.x. Если нет:
```bash
# Установка CUDA 12.1
wget https://developer.download.nvidia.com/compute/cuda/12.1.0/local_installers/cuda_12.1.0_530.30.02_linux.run
```

---

## Варианты развёртывания

| Вариант | Время | Описание |
|---------|-------|----------|
| **Golden archive + b2 sync** | ~12-15 мин | Скачать `golden_pod_light.tar.gz` (~13GB) с B2, распаковать + докачать модели |
| **Docker образ** | ~4-5 мин 🚀 | Свой шаблон на RunPod с предустановленным всем внутри |
| **Постоянный под 24/7** | ~2 мин 🎯 | ComfyUI уже запущен, модели предзагружены |

**Текущий статус:** Используем Вариант 1 (golden archive). Docker образ в планах.

---

## Структура после деплоя

```
/workspace/
├── ComfyUI/
│   ├── main.py
│   ├── custom_nodes/
│   │   ├── ComfyUI-Impact-Pack/
│   │   ├── ComfyUI-ControlNet/
│   │   ├── ComfyUI-IPAdapter/
│   │   └── ComfyUI-ReActor/
│   └── models/
│       ├── checkpoints/
│       │   ├── photo5.safetensors
│       │   ├── Lustify_apexV8.safetensors
│       │   └── insta1.safetensors
│       ├── loras/
│       ├── controlnet/
│       ├── upscale_models/
│       ├── ultralytics/
│       └── ipadapter/
│
├── OneTrainer/
└── venv/
```

---

## Проверка успешного деплоя

```bash
# 1. ComfyUI запущен?
curl -s http://localhost:8188/system_stats | jq .

# 2. GPU определён?
nvidia-smi --query-gpu=name,memory.total --format=csv

# 3. Модели на месте?
ls -la /workspace/ComfyUI/models/checkpoints/
ls -la /workspace/ComfyUI/models/loras/

# 4. Ноды загружены?
ls /workspace/ComfyUI/custom_nodes/ | wc -l
# Ожидание: 5+ нод
```

---

## История версий deploy.sh

| Версия | Дата | Изменения |
|--------|------|-----------|
| v8.0 | 26 июня | Базовая установка ComfyUI + OneTrainer |
| v8.1 | 26 июня | Добавлены custom nodes (Impact, ControlNet, IPAdapter) |
| v8.2 | 26 июня | Добавлен Detailer стек (yolo, upscaler) |
| v8.3 | 27 июня | Добавлена загрузка моделей с B2 |
| v8.4 | 27 июня | Добавлены fix `--normal-vram` (```-> `--normal-vram`) |
| v8.5 | 27 июня | Оптимизация порядка загрузки (модели параллельно) |
| v8.6 | 27 июня | Финальная: golden archive поддержка, все пути проверены |

---

## Связи
- [[ComfyUI]] — цель установки (полная страница)
- [[GODTIER V8]] — пайплайн генерации
- [[RunPod]] — где запускается (GPU поды)
- [[SDXL Big Love]] — чекпоинты
- [[B2 Storage]] — откуда качаются модели
