---
status: redirect
tags: [redirect, review]
redirect_to: [[90-REVIEW/STUBS/STACK/SELF_HOSTING.review]]
reason: stub note; external docs not imported
---
# SELF_HOSTING

Эта заметка вынесена из активного контура качества.
См. [[90-REVIEW/STUBS/STACK/SELF_HOSTING.review]].
