---
created: 2026-06-27
tags: [b2, inventory, models, sdxl, lora]
source: WORK/command_center/static/B2_DATABASE.md
---

# B2 Database Inventory

> Полный инвентарь ALEX.STORAGE. Дата: 2026-06-26.

## 1. Архивы среды

| Архив | Размер | Статус |
|---|---|---|
| `comfy_nodes_33_20260611_125456.tar.zst` | 394 MB | 🟡 УСТАРЕЛ (15 дней) |

### План: 3 новых архива
- **A1** — `venv_comfyui_engine.tar.zst` (~500 MB) — venv + ComfyUI base + 12 nodes
- **A2** — `venv_onetrainer.tar.zst` (~2-3 GB) — OneTrainer + kohya + diffusers
- **A3** — `venv_production_gold.tar.zst` (~60+ GB) — A1 + все модели + LoRAs

## 2. Чекпоинты SDXL (на B2)

| Файл | Размер | Статус |
|---|---|---|
| photo4.safetensors | 6.6 GB | ✅ |
| photo5.safetensors | 6.6 GB | ✅ |
| lust1.safetensors | 6.6 GB | ✅ (НО битый — не использовать) |
| insta1.safetensors | 6.6 GB | ✅ |
| Lustify_apexV8.safetensors | 6.6 GB | ✅ |
| realistic_freedom_omega.safetensors | 6.6 GB | ✅ |
| sdxl_yamers_realistic5.safetensors | 6.6 GB | ✅ |
| unnamed_ixl_realistic.safetensors | 6.6 GB | ✅ |

**В local_staging (нужен move):**
bigaspV25_v25 (1.6 GB), bigLove_insta1 🔴 дубль, bigLove_lust1 🔴 дубль, bigLove_photo4 🔴 дубль

**MISSING (качать):** photo6, ultra3, ultra5, hyper1, zt3, klein3, eryn1, gwen1-2

## 3. VAE / CLIP
- `sdxl_vae.safetensors` ✅
- `sdxl_clip.safetensors` ✅

## 4. ControlNet
- `xinsirUnionProMax_v10_partial.safetensors` ✅
- Ещё 3 в local_staging (move)
- **MISSING:** depth_zoe, openpose, canny, tile, ip-adapter-faceid

## 5. IP-Adapter / PuLID
- IP-Adapter SDXL ✅, IP-Adapter Plus ✅, image_encoder ✅
- PuLID SDXL ✅
- Ещё 2 в local_staging (move)

## 6. LoRAs
Полный список см. в `B2_DATABASE.md` (331 строка).

## Связи
- [[B2 Storage]] — хранилище
- [[SDXL Big Love]] — модели
- [[GODTIER V8]] — пайплайн
- [[GODTIER V8 Project Spec]] — проект
