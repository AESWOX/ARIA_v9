---
created: 2026-06-27
updated: 2026-06-29
tags: [b2, storage, backblaze, cloud, s3, backup]
---

# B2 Storage

> Backblaze B2 — **ALEX.STORAGE**. S3-совместимое облачное хранилище.
> Используется как основной durable storage для моделей, архивов и выходных данных генерации.

---

## Общая информация

| Параметр | Значение |
|----------|----------|
| **Провайдер** | Backblaze B2 Cloud Storage |
| **Bucket** | `ALEX.STORAGE` |
| **Тип** | S3-совместимый (не обычный S3) |
| **S3 Endpoint** | `https://s3.us-west-004.backblazeb2.com` |
| **Регион** | US West 004 |
| **Цена** | $0.006/GB/мес (в 5 раз дешевле AWS S3) |
| **Скачивание** | Бесплатно до 3x upload volume |
| **Назначение** | Основной storage: модели, архивы, выходные gen |

---

## rclone конфигурация

```ini
[alex_storage]
type = b2
account = 00575a97f3577ed0000000001
key = K005E3wFWuVFM4SuAkuY8UtfTzfdwrQ
endpoint = 
```

### Варианты доступа

**Через rclone (рекомендовано):**
```bash
rclone ls alex_storage:ALEX.STORAGE/models/checkpoints/
rclone copy alex_storage:ALEX.STORAGE/models/checkpoints/photo5.safetensors ./models/
rclone sync ./output/ alex_storage:ALEX.STORAGE/output/ --progress
```

**Через b2 CLI v4 (родной):**
```bash
b2 authorize-account 00575a97f3577ed0000000001 K005E3wFWuVFM4SuAkuY8UtfTzfdwrQ
b2 file list ALEX.STORAGE
b2 file upload ALEX.STORAGE models/checkpoints/photo6.safetensors /local/path/photo6.safetensors
```

**Через S3 API (для кода):**
```python
import boto3
s3 = boto3.resource('s3',
    endpoint_url='https://s3.us-west-004.backblazeb2.com',
    aws_access_key_id='00575a97f3577ed0000000001',
    aws_secret_access_key='K005E3wFWuVFM4SuAkuY8UtfTzfdwrQ')
bucket = s3.Bucket('ALEX.STORAGE')
for obj in bucket.objects.filter(Prefix='models/checkpoints/'):
    print(obj.key)
```

---

## Структура bucket

```
ALEX.STORAGE/
├── models/
│   ├── checkpoints/           # 🟢 Big Love family (6.6GB каждый)
│   │   ├── photo4.safetensors       # ✅ Базовая
│   │   ├── photo5.safetensors       # ✅ Рекомендованная (бесплатно)
│   │   ├── lust1.safetensors        # ❌ БИТЫЙ — не использовать
│   │   ├── insta1.safetensors       # ✅ Instagram стиль
│   │   ├── Lustify_apexV8.safetensors  # ✅ Лучший NSFW
│   │   ├── realistic_freedom_omega  # ✅ Альтернатива
│   │   ├── sdxl_yamers_realistic5   # ✅ Альтернатива
│   │   └── unnamed_ixl_realistic    # ✅ Альтернатива
│   │
│   ├── loras/                 # 🟡 Критически мало
│   │   └── dmd2_sdxl.safetensors    # ✅ Есть
│   │   # ❌ Нужно: Hand XL, skin texture, Touch of Realism, Add Detail
│   │
│   ├── controlnet/            # 🟢 Готово
│   │   ├── xinsirUnionProMax_v10_partial.safetensors
│   │   └── ... (ещё 3 в local_staging)
│   │
│   ├── upscale_models/        # 🟢 Готово
│   │   ├── 4x-UltraSharp.pth
│   │   └── RealESRGAN_x4.pth
│   │
│   ├── face_tools/            # 🟢 Готово
│   │   ├── pulid_sdxl.safetensors
│   │   ├── ip-adapter-plus_sdxl.safetensors
│   │   ├── ip-adapter_sdxl.safetensors
│   │   └── image_encoder.safetensors
│   │
│   └── video/                 # ⚪ Пусто (не актуально пока)
│
├── archives/                  # 🟢 Готово
│   ├── comfy_nodes_33_20260611_125456.tar.zst    # 394 MB (устарел)
│   ├── venv_comfyui_engine.tar.zst               # ~500 MB (venv + ComfyUI + 12 nodes)
│   ├── venv_onetrainer.tar.zst                   # ~2-3 GB (OneTrainer + kohya)
│   └── venv_production_gold.tar.zst              # ~60+ GB (всё вместе)
│
├── output/                    # ⚪ Пусто (ждёт генераций)
│   └── {character}/{date}/
│       ├── raw/
│       ├── upscaled/
│       └── final/
│
└── workflows/                 # ⚪ Пусто (ждёт ComfyUI workflows)
```

### Что MISSING (можно докачать)

| Категория | Конкретно | Приоритет |
|-----------|-----------|-----------|
| **Чекпоинты** | photo6 ($5.50), ultra3/5, zt3 | 🟡 Средний |
| **LoRA** | Hand XL v5.5 (⭐39K DL), skin texture XL v4 (⭐28K DL), Touch of Realism V2 (⭐19K DL), Add Detail Slider (⭐10K DL), Detailed Perfection (⭐124K DL) | 🔴 Высокий |
| **ControlNet** | depth_zoe, openpose, canny, tile, ip-adapter-faceid | 🟡 Средний |

---

## Проблемы и их решения

### Проблема 1: `get_input_stream error` при upload
**Симптом:** POST /api/b2/upload → 500, `get_input_stream error`
**Причина:** Windows `creationflags=CREATE_NO_WINDOW` (0x08000000) ломает `b2 file upload`
**Решение:**
```python
# УБРАТЬ creationflags для b2 file upload
subprocess.run(cmd, capture_output=True)  # БЕЗ creationflags

# Для ls / rm / cat можно оставить
subprocess.run(cmd, capture_output=True, creationflags=0x08000000)
```
**Статус:** Исправлено, см. [[B2 Debugging UV Zombies]]

### Проблема 2: `bad_auth_token`
**Симптом:** `b2 authorize-account` → `bad_auth_token`
**Причина:** B2 ключи в `WORK/.env` могут быть маскированы (одинаковые 25-символьные строки)
**Решение:** Проверить через `b2 authorize-account` с raw hex ключами из `WORK/APY/B2*.txt`
**Статус:** Открыто

### Проблема 3: `SignatureDoesNotMatch`
**Симптом:** S3 API запросы → `SignatureDoesNotMatch`
**Причина:** B2 key_id и app_key не совпадают по формату с AWS S3
**Решение:** Убедиться что используете правильный endpoint URL и не путаете key_id с app_key
**Статус:** Открыто

---

## Связь с RunPod

B2 — единственный способ быстро передать модели на RunPod:

```bash
# На RunPod (в deploy.sh):
rclone copy alex_storage:ALEX.STORAGE/models/checkpoints/photo5.safetensors /workspace/ComfyUI/models/checkpoints/ --progress

# С RunPod на B2 (выходные gen):
rclone copy /workspace/output/ alex_storage:ALEX.STORAGE/output/$(date +%Y%m%d)/ --progress
```

**Почему не Network Volumes:** B2 уже основной storage, Network Volumes на RunPod не нужны (см. [[Decision-Log]]).

---

## Архивные образы

| Образ | Содержимое | Размер | Назначение |
|-------|-----------|--------|-----------|
| `venv_comfyui_engine` | Python venv + ComfyUI v0.26.0 + 13 custom nodes | ~500 MB | Быстрый старт на новом поде |
| `venv_onetrainer` | Python venv + OneTrainer + kohya_ss + diffusers | ~2-3 GB | LoRA training |
| `venv_production_gold` | Всё вместе + модели + LoRA + ControlNet | ~60+ GB | Полный production (редко) |

**Стратегия:** На каждый под качаем `venv_comfyui_engine` + модели по необходимости. Полный образ — только для production подов.

---

## Связи
- [[SDXL Big Love]] — модели на B2 (полная страница с чекпоинтами)
- [[B2 Database Inventory]] — полный инвентарь всех файлов на B2
- [[GODTIER V8]] — пайплайн генерации
- [[RunPod]] — загрузка моделей на GPU поды
- [[B2 Debugging UV Zombies]] — решение проблемы upload
- [[Decision-Log]] — почему Network Volumes не используем
