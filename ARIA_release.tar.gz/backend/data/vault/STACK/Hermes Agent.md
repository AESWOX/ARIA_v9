---
created: 2026-06-27
tags: [hermes, ai-agents, config, windows]
---

# Hermes Agent

> Локальный AI-агент от Nous Research. Основа всей инфраструктуры.

## Конфигурация

**Главный конфиг:** `~/AppData/Local/hermes/config.yaml`
**Профили:** `~/.hermes/profiles/<name>/` (default — активный)
**Провайдер:** DeepSeek (оркестратор), OpenRouter Gemini 2.5 Flash (vision free-tier)

## Ключевые фишки

| Фича | Значение |
|---|---|
| **Vision** | `auxiliary.vision.provider = google`, `model = gemini-2.5-flash` |
| **DNS fix** | `force_ipv4=true` — aiohttp + AsyncResolver |
| **Memory** | `memory_char_limit = 8000` (вшито) |
| **Скиллы** | `~/AppData/local/hermes/skills/` — процедурная память |

## Провайдеры

- **DeepSeek** — основной, оркестратор
- **OpenRouter** — Gemini 2.5 Flash (vision, бесплатно)
- **GitHub Models** — gpt-4o-mini (150 req/day, запасной)

## Loop Engineering в Hermes

| Loop Component | Реализация |
|---|---|
| Automation | `cronjob` — cron, расписание |
| Skill | `skill_manage/view` — SKILL.md |
| State | `memory` + `session_search` |
| Verifier | `delegate_task` — отдельные агенты |
| Worktrees | `delegate_task` — изолированные terminal |
| Connectors | Telegram Gateway, API tools, MCP |

---

## Computer-Use / Vision (cua-driver)

**Status (2026-06-30):** ✅ Исправлен и включён осознанно.

| Компонент | Статус |
|-----------|--------|
| **cua-driver** | `enabled: true`, `args: ["mcp"]` (список, не строка) |
| **MCP-транспорт** | ❌ Исключён для capture/list_windows — рвётся на больших ответах |
| **CLI-bridge** | ✅ PRIMARY путь (создан 2026-06-30) |

### CLI-bridge (cua_cli_bridge.py)
Основной способ получения визуальной информации. Обходит сломанный MCP-транспорт.

**Производительность:** ~1.8s / 1568×844 / 150+ элементов.

**Fallback chain:**
```
agent задача
  → cua_cli_bridge.capture()          # ~1.8s, 150+ элементов, скриншот
  → если CLI упал → cua_vision_fallback  # ~15s, мыльное описание
  → MCP — не используется для capture/list_windows
```

**Файлы:**
| Файл | Назначение |
|------|-----------|
| `cua_cli_bridge.py` | **PRIMARY** — capture + list_windows через `cua-driver call` |
| `cua_vision_fallback.py` | Fallback 2-го порядка (только если CLI упал) |
| `cua_watchdog.py` | Supervisor для named pipe |
| `local_vision.py` | Deprecated (старый PowerShell вариант) |

---

## Swarm: agent_swarm_v5.py

**Создан:** 2026-06-30 (982 строки) — ждёт тестов.

| Компонент | Статус |
|-----------|--------|
| KeyPoolManager — 17 ключей, per-key RPM/RPD/cooldown | ✅ |
| decompose_task() → JSON TaskSpec[] | ✅ |
| Multi-round audit (MAX_ROUNDS=3, threshold=0.8) | ✅ |
| progress.json логирование каждого раунда + причина остановки | ✅ |
| key_log DB таблица | ✅ |
| Интеграция в run_gateway_with_swarm.bat | ⏸️ ждёт |

**Примечание:** Пайплайн decompose→dispatch→audit живёт в swarm daemon (agent_swarm.py). Hermes-агент не использует swarm для своих задач — исполняет напрямую (архитектурное решение).

---

## Config Write Protocol (2026-06-30)

| Тип записи | Инструмент | Действует на |
|------------|-----------|-------------|
| Скаляры (enabled, name) | `hermes config set` | ✅ |
| Списки/словари (args) | terminal python | ✅ (не hermes config set) |
| Другие файлы | write_file/patch | ✅ |
| config.yaml | write_file/patch | ❌ **ЗАБЛОКИРОВАНО** |

**Pitfall:** `hermes config set` для списков пишет как строку. Чинить через terminal python.

---

## MCP-серверы (2026-07-01)

| Сервер | Статус | Примечание |
|--------|--------|------------|
| **cua-driver** | ✅ Включён | Был `enabled: true` ещё до 12:45 01.07 (не новая правка) |
| **obsidian** | ❌ Не запущен | Obsidian.exe не найден в процессах. REST API на 27124 не слушает. MCP стартуют лениво — при первом запросе от агента. Требует ручного запуска Obsidian или LOOPER restart. |
| **n8n** | ❌ Выключен | `enabled: false`, процесс не запущен |

---

## Vision Fallback (LLM) — 2026-07-01

Создана много-провайдерная система vision с fallback и ротацией ключей:

```
Primary: Google Gemini (gemini-2.0-flash via GEMINI_API_KEY)
  ↓ fallback на 400/401/429
Groq pool: 10 ключей, Llama 4 Scout, авто-ротация
```

Подробнее: [[Vision Fallback (LLM)]]

| Тест | Результат |
|------|-----------|
| Happy path Google | ✅ Success |
| Gemini→Groq fallback | ✅ Success (разный текст = разные провайдеры) |
| Ключевая ротация в пуле | ✅ Пропустил пустой + мёртвый ключ, использовал живой |

---

## Config Analysis (2026-07-01)

**Diff между бэкапом 12:45 и текущим конфигом:**

| Элемент | Был в бэкапе 12:45 | Изменилось |
|---------|-------------------|------------|
| **cua-driver MCP** | ✅ `enabled: true` | Не менялось — не моя правка |
| **obsidian MCP** | ✅ Секция была | Не менялось — не моя правка |
| **obsidian-mcp-server.js** | Файл существовал (mtime 13:23) | Не менялось |
| **model провайдер** | `provider: deepseek` | Стало `model: nous` (кем-то между 12:45-15:00) |
| **vision_fallback** | ❌ Не было секции | ✅ Добавлена (Groq pool 10 ключей) |
| **vision** | `openrouter` + `gemini-2.5-flash` | ✅ `google` + `gemini-2.0-flash` |

**Credential_pool error:** Не критично — не используется для активных функций. Диагностировано, не трогать.

---

## Автозапуск (2026-07-01)

- **ТОЛЬКО LOOPER** — `Hermes_Gateway_LOOPER.vbs` в Startup
- **Порядок запуска LOOPER:** Swarm → GODTIER Panel (8765) → Command Center (8766) → Gateway (блокирующий)
- **Scheduled Task `Hermes_Gateway`** — УДАЛЁН
- Запрещено: `hermes gateway run` вручную
- **MEMORY.md** (WORK/docs/): три обязательных потока — TG Gateway, GODTIER Panel, Command Center

---

## Лимит итераций (2026-06-30)

- `max_turns = 40`
- Batch-задачи по 5–7
- progress.json на диск после каждого подшага
- `delegate_task` для параллельных подзадач

---

## Протокол верификации write (2026-06-30)

После каждой записи → `read_file` + выписка изменённых строк/diff.

---

## Связи
- [[STACK/Командный Центр CC v3]] — UI управления
- [[TG Gateway]] — входной канал
- [[Swarm Оркестратор]] — мульти-агент
