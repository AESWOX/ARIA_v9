---
created: 2026-06-28
updated: 2026-06-29
tags: [runpod, cron, killswitch, monitoring]
---

# Killswitch Cronjob

> Avtomaticheskiy zashchitnik ot prostoya na RunPod.

## Sozdan: 28 iyunya 2026
Posle togo kak pod provisel noch i szheg ${"$"}8.

## Konfiguratsiya

| Parametr | Znachenie |
|----------|-----------|
| Job ID | 240e9b28e081 |
| Interval | kazhdye 3 min |
| Mode | no_agent=True (LLM ne ispolzuetsya) |
| Script | runpod_killswitch.py |

## Logika raboty

1. **Proverka ComfyUI:** GET /queue, GET /history
2. **Idle check:** esli queue pust i history ne obnovlyalas >5 min → DELETE
3. **Hard limit:** uptime >90 min → DELETE
4. **Bez predyprezhdeniy** — udalenie nemedlenno

## Istoriya

- 28 iyunya: sozdan posle ${"$"}8 prostoya
- 28 iyunya: ubil полезный pod (idle check srabotal slishkom bystro)
- 29 iyunya: nastroen s 5-min idle i 90-min hard limit

## Script

Hranitsya v Hermes scripts dir: ~/AppData/Local/hermes/scripts/runpod_killswitch.py

## Vazhno

- Pri aktivnoy rabote (generatsii, obuchenii) idle ne narastaet
- Esli nuzhno pod na >90 min — prodlit vruchnuyu ili omenit cron
- Cron ne ispolzuet LLM → 0 zatrat na tokeny

## 🔗 Cross-links
- [[02-TAGS/MOC-Ошибки-и-Решения]]
- [[STACK/RunPod GPU Deployment History]]
