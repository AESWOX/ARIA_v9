---
status: canonical
tags: [master-plan, cleanup, qa, navigation]
updated: 2026-07-22
---
# MASTER PLAN — SECOND_BRAIN ideal snapshot

## Базовый выбор
За основу взят `SECOND_BRAIN_clean_2026-07-22`, потому что это единственная версия из четырёх с нулём битых wikilinks и полной кириллицей в именах файлов.

## Что считается canonical
- активные operational playbook'и;
- подтверждённые decision notes;
- технические базы знаний и project docs без broken link / syntax проблем;
- навигационные MOC-страницы.

## Что выведено из активного графа
- stub-заметки без законченного содержания;
- спорные project snapshots из `03-PROJECTS/`;
- raw provenance и архивный слой;
- любые файлы, завязанные на отсутствующие локальные артефакты.

## Архитектура после рефакторинга
- `00-META/` — управляющие документы и QA
- `02-TAGS/` — основная навигация
- `STACK/`, `DECISIONS/`, `GODTIER/`, `COMFY-KB/`, `PROJECTS/`, `CONTENT/`, `AGENTS/`, `SIGNALS/` — активный контур
- `90-REVIEW/` — всё, что требует ручного решения
- `00-RAW/` и `_archive/` — provenance / historical context

## Принципы поддержки качества
1. Никаких битых внутренних ссылок.
2. Никаких active-note со статусом stub.
3. Никаких локальных `file:///` зависимостей в canonical-контуре.
4. Любая спорная заметка идёт в `90-REVIEW/`.
5. Redirect-заметки допустимы, если сохраняют совместимость старых ссылок.
