# QA Registry — 2026-07-22

## Summary
- **archive**: 7
- **canonical**: 162
- **provenance**: 3
- **review**: 10
- **review-needed**: 4
- **template**: 3

## Per-file inventory

| path | quality_bucket | syntax | md_links | wiki_links | notes |
|---|---|---|---|---|---|
| `00-META/CLEANUP-REPORT-2026-07-22.md` | canonical | ok | ok | ok | - |
| `00-META/MASTER-PLAN-2026-07-22.md` | canonical | ok | ok | ok | - |
| `00-RAW/агент/memory-dump-2026-07-10.md` | provenance | ok | ok | ok | raw source layer |
| `00-RAW/агент/memory-dump-2026-07-13.md` | provenance | ok | ok | ok | raw source layer |
| `00-RAW/агент/memory-dump-2026-07-14.md` | provenance | ok | ok | ok | raw source layer |
| `02-TAGS/INDEX.md` | canonical | ok | ok | ok | - |
| `02-TAGS/MOC-Инфраструктура.md` | canonical | ok | ok | ok | - |
| `02-TAGS/MOC-Методологии.md` | canonical | ok | ok | ok | - |
| `02-TAGS/MOC-Ошибки-и-Решения.md` | canonical | ok | ok | ok | - |
| `03-PROJECTS/AI-Influencer/2026-07-13-phasea-v5-backup-restore.md` | canonical | ok | ok | ok | redirect note |
| `03-PROJECTS/AI-Influencer/audit-b2-2026-07-13.md` | canonical | ok | ok | ok | redirect note |
| `90-REVIEW/INDEX.md` | review | ok | ok | ok | review branch |
| `90-REVIEW/NEXT-TZ-FOR-AGENT-2026-07-22.md` | review | ok | ok | ok | review branch |
| `90-REVIEW/PROJECT-SNAPSHOTS/AI-Influencer/2026-07-13-phasea-v5-backup-restore.md` | review | ok | ok | ok | review branch |
| `90-REVIEW/PROJECT-SNAPSHOTS/AI-Influencer/audit-b2-2026-07-13.md` | review | ok | ok | ok | review branch |
| `90-REVIEW/STUBS/PIPELINE/FaceFusion.review.md` | review | ok | ok | ok | review branch; stub status |
| `90-REVIEW/STUBS/STACK/DOCKER_TROUBLESHOOTING.review.md` | review | ok | ok | ok | review branch; stub status |
| `90-REVIEW/STUBS/STACK/N8N_DEPLOYMENT.review.md` | review | ok | ok | ok | review branch; stub status |
| `90-REVIEW/STUBS/STACK/RAILWAY_DEPLOYMENT.review.md` | review | ok | ok | ok | review branch; stub status |
| `90-REVIEW/STUBS/STACK/SELF_HOSTING.review.md` | review | ok | ok | ok | review branch; stub status |
| `90-REVIEW/STUBS/VAULT/Линковка.review.md` | review | ok | ok | ok | review branch; stub status |
| `AGENTS/AI-агенты.md` | canonical | ok | ok | ok | - |
| `AGENTS/Swarm Оркестратор.md` | canonical | ok | ok | ok | - |
| `AGENTS/Как это работает.md` | canonical | ok | ok | ok | - |
| `COMFY-KB/INDEX.md` | canonical | ok | ok | ok | - |
| `COMFY-KB/generation-log/2026-07-08-b2-test-generations.md` | canonical | ok | ok | ok | - |
| `COMFY-KB/models/checkpoints/Lustify_apexV8.md` | canonical | ok | ok | ok | - |
| `COMFY-KB/models/checkpoints/bigLust_v16.md` | canonical | ok | ok | ok | - |
| `COMFY-KB/models/controlnet/controlnet-union-sdxl-1.0.md` | canonical | ok | ok | ok | - |
| `COMFY-KB/models/controlnet/instantid_controlnet.md` | canonical | ok | ok | ok | - |
| `COMFY-KB/models/controlnet/openpose-sdxl-1.0.md` | canonical | ok | ok | ok | - |
| `COMFY-KB/models/detectors/face_yolov8m.md` | canonical | ok | ok | ok | - |
| `COMFY-KB/models/detectors/hand_yolov8n.md` | canonical | ok | ok | ok | - |
| `COMFY-KB/models/ipadapter/ip-adapter-faceid-plusv2_sdxl.md` | canonical | ok | ok | ok | - |
| `COMFY-KB/models/ipadapter/ip-adapter-plus-face_sdxl_vit-h.md` | canonical | ok | ok | ok | - |
| `COMFY-KB/models/ipadapter/ip-adapter_sdxl_vit-h.md` | canonical | ok | ok | ok | - |
| `COMFY-KB/models/loras/DetailedEyes_V3.md` | canonical | ok | ok | ok | - |
| `COMFY-KB/models/loras/HandsXL_v1.md` | canonical | ok | ok | ok | - |
| `COMFY-KB/models/loras/RealSkin_xxXL_v1.md` | canonical | ok | ok | ok | - |
| `COMFY-KB/nodes/ApplyInstantID.md` | canonical | ok | ok | ok | - |
| `COMFY-KB/nodes/ApplyInstantIDAdvanced.md` | canonical | ok | ok | ok | - |
| `COMFY-KB/nodes/ControlNetApplyAdvanced.md` | canonical | ok | ok | ok | - |
| `COMFY-KB/nodes/FaceDetailer.md` | canonical | ok | ok | ok | - |
| `COMFY-KB/nodes/HandsDetailer.md` | canonical | ok | ok | ok | - |
| `COMFY-KB/nodes/IPAdapterFaceID.md` | canonical | ok | ok | ok | - |
| `COMFY-KB/nodes/KSampler.md` | canonical | ok | ok | ok | - |
| `COMFY-KB/nodes/UltralyticsDetectorProvider.md` | canonical | ok | ok | ok | - |
| `COMFY-KB/params/cfg-guidance.md` | canonical | ok | ok | ok | - |
| `COMFY-KB/params/controlnet-strength.md` | canonical | ok | ok | ok | - |
| `COMFY-KB/params/denoise-strength.md` | canonical | ok | ok | ok | - |
| `COMFY-KB/params/ipadapter-weight.md` | canonical | ok | ok | ok | - |
| `COMFY-KB/params/sampler-scheduler.md` | canonical | ok | ok | ok | - |
| `COMFY-KB/postprocessing/face-restore.md` | canonical | ok | ok | ok | - |
| `COMFY-KB/postprocessing/frequency-separation.md` | canonical | ok | ok | ok | - |
| `COMFY-KB/postprocessing/upscale.md` | canonical | ok | ok | ok | - |
| `COMFY-KB/quality-and-consistency/face-similarity-playbook.md` | canonical | ok | ok | ok | - |
| `COMFY-KB/quality-and-consistency/failure-patterns.md` | canonical | ok | ok | ok | - |
| `COMFY-KB/quality-and-consistency/known-good-configs.md` | canonical | ok | ok | ok | - |
| `CONTENT/INDEX.md` | canonical | ok | ok | ok | - |
| `CONTENT/STORY-DATABASE/Girl-Trans/INDEX.md` | canonical | ok | ok | ok | - |
| `CONTENT/STORY-DATABASE/INDEX.md` | canonical | ok | ok | ok | - |
| `CONTENT/STORY-DATABASE/Lesbian/INDEX.md` | canonical | ok | ok | ok | - |
| `CONTENT/STORY-DATABASE/Solo/Bedroom/SASHA-SO-008-found-it.md` | canonical | ok | ok | ok | - |
| `CONTENT/STORY-DATABASE/Solo/Car/MIA-SO-008-parking-garage.md` | canonical | ok | ok | ok | - |
| `CONTENT/STORY-DATABASE/Solo/INDEX.md` | canonical | ok | ok | ok | - |
| `CONTENT/STORY-DATABASE/Solo/Office-Study/MIA-SO-009-overtime.md` | canonical | ok | ok | ok | - |
| `CONTENT/STORY-DATABASE/Solo/Outdoor/SASHA-SO-009-the-bench.md` | canonical | ok | ok | ok | - |
| `CONTENT/STORY-DATABASE/Tags/INDEX.md` | canonical | ok | ok | ok | - |
| `CONTENT/STORY-DATABASE/Top50/INDEX.md` | canonical | ok | ok | ok | - |
| `CONTENT/STORY-DATABASE/Trans/INDEX.md` | canonical | ok | ok | ok | - |
| `CONTENT/STORY-DATABASE/Trans/NADIA-SO-003-the-mirror.md` | canonical | ok | ok | ok | - |
| `CONTENT/STORY-DATABASE/Trans/NADIA-SO-004-the-stall.md` | canonical | ok | ok | ok | - |
| `CONTENT/STORY-TEMPLATE/INDEX.md` | canonical | ok | ok | ok | - |
| `CONTENT/STORY-TEMPLATE/creation-demo-step-by-step.md` | review-needed | ok | ok | ok | stub status |
| `CONTENT/STORY-TEMPLATE/filled-example-1.md` | review-needed | ok | ok | ok | stub status |
| `CONTENT/STORY-TEMPLATE/quality-gates.md` | canonical | ok | ok | ok | - |
| `CONTENT/TREND-RESEARCH/2026-porn-trends-analysis.md` | canonical | ok | ok | ok | - |
| `CONTENT/TREND-RESEARCH/INDEX.md` | canonical | ok | ok | ok | - |
| `CONTENT/TREND-RESEARCH/site-inventory-analysis.md` | review-needed | ok | ok | ok | stub status |
| `CONTENT/TREND-RESEARCH/studio-archetype-catalog.md` | canonical | ok | ok | ok | - |
| `CONTENT/TREND-RESEARCH/viral-format-catalog.md` | review-needed | ok | ok | ok | stub status |
| `CONTENT/production-plan-v2.md` | canonical | ok | ok | ok | - |
| `DECISIONS/Decision-Flow.md` | canonical | ok | ok | ok | - |
| `DECISIONS/Decision-Log.md` | canonical | ok | ok | ok | - |
| `DECISIONS/HERMES.md` | canonical | ok | ok | ok | - |
| `DECISIONS/Known-Risks.md` | canonical | ok | ok | ok | - |
| `GODTIER/2026-07-06-face-lora-bootstrap.md` | canonical | ok | ok | ok | - |
| `GODTIER/AI Influencer Pipeline.md` | canonical | ok | ok | ok | - |
| `GODTIER/AI-Adult-Content-Bible-2026.md` | canonical | ok | ok | ok | - |
| `GODTIER/GODTIER V8 Project Spec.md` | canonical | ok | ok | ok | - |
| `GODTIER/GODTIER V8 Workflow Spec.md` | canonical | ok | ok | ok | - |
| `GODTIER/GODTIER V8.md` | canonical | ok | ok | ok | - |
| `GODTIER/LEGACY-AUDIT/01-runtime-legacy-audit-full.md` | canonical | ok | ok | ok | - |
| `GODTIER/LEGACY-AUDIT/02-runtime-legacy-audit-part2-full.md` | canonical | ok | ok | ok | - |
| `GODTIER/LEGACY-AUDIT/INDEX.md` | canonical | ok | ok | ok | - |
| `GODTIER/golden_instantid_restore.md` | canonical | ok | ok | ok | - |
| `GODTIER/sdxl-pipeline/brunette/MASTER-POD-CHECKLIST.md` | canonical | ok | ok | ok | - |
| `GODTIER/sdxl-pipeline/brunette/README.md` | canonical | ok | ok | ok | - |
| `GODTIER/sdxl-pipeline/brunette/__pycache__/dataset_validator.cpython-313.pyc` | canonical | ok | ok | ok | - |
| `GODTIER/sdxl-pipeline/brunette/__pycache__/gen_batch7.cpython-313.pyc` | canonical | ok | ok | ok | - |
| `GODTIER/sdxl-pipeline/brunette/__pycache__/gen_phaseA_sdxl.cpython-313.pyc` | canonical | ok | ok | ok | - |
| `GODTIER/sdxl-pipeline/brunette/__pycache__/gen_phaseB_sdxl.cpython-313.pyc` | canonical | ok | ok | ok | - |
| `GODTIER/sdxl-pipeline/brunette/__pycache__/post_process.cpython-313.pyc` | canonical | ok | ok | ok | - |
| `GODTIER/sdxl-pipeline/brunette/__pycache__/quality_scorer.cpython-313.pyc` | canonical | ok | ok | ok | - |
| `GODTIER/sdxl-pipeline/brunette/__pycache__/tag_dataset.cpython-313.pyc` | canonical | ok | ok | ok | - |
| `GODTIER/sdxl-pipeline/brunette/dataset_validator.py` | canonical | ok | ok | ok | - |
| `GODTIER/sdxl-pipeline/brunette/gen_batch7.py` | canonical | ok | ok | ok | - |
| `GODTIER/sdxl-pipeline/brunette/gen_phaseA_sdxl.py` | canonical | ok | ok | ok | - |
| `GODTIER/sdxl-pipeline/brunette/gen_phaseB_sdxl.py` | canonical | ok | ok | ok | - |
| `GODTIER/sdxl-pipeline/brunette/post_process.py` | canonical | ok | ok | ok | - |
| `GODTIER/sdxl-pipeline/brunette/prompts_brunette.yaml` | canonical | ok | ok | ok | - |
| `GODTIER/sdxl-pipeline/brunette/quality_scorer.py` | canonical | ok | ok | ok | - |
| `GODTIER/sdxl-pipeline/brunette/tag_dataset.py` | canonical | ok | ok | ok | - |
| `GODTIER/sdxl-pipeline/brunette/unified_config_brunette.yaml` | canonical | ok | ok | ok | - |
| `GODTIER/sdxl-pipeline/gen_output/README.md` | canonical | ok | ok | ok | - |
| `GODTIER/sdxl-pipeline/gen_preview/README.md` | canonical | ok | ok | ok | - |
| `INDEX.md` | canonical | ok | ok | ok | - |
| `PIPELINE/AI Видео Генерация.md` | canonical | ok | ok | ok | - |
| `PIPELINE/Checkpoint Parameters.md` | canonical | ok | ok | ok | - |
| `PIPELINE/Checkpoint_Merging.md` | canonical | ok | ok | ok | - |
| `PIPELINE/ComfyUI.md` | canonical | ok | ok | ok | - |
| `PIPELINE/ComfyUI_Workflow_Nodes.md` | canonical | ok | ok | ok | - |
| `PIPELINE/Dataset_Captioning.md` | canonical | ok | ok | ok | - |
| `PIPELINE/DoRA_Parameters.md` | canonical | ok | ok | ok | - |
| `PIPELINE/FaceFusion.md` | canonical | ok | ok | ok | redirect note |
| `PIPELINE/Generation_Parameters.md` | canonical | ok | ok | ok | - |
| `PIPELINE/LoRA Dataset Guide.md` | canonical | ok | ok | ok | - |
| `PIPELINE/LoRA_Parameters.md` | canonical | ok | ok | ok | - |
| `PIPELINE/Template-vs-No-Template.md` | canonical | ok | ok | ok | - |
| `PIPELINE/Upscalers.md` | canonical | ok | ok | ok | - |
| `PIPELINE/VRAM_Optimization_3090.md` | canonical | ok | ok | ok | - |
| `PIPELINE/Vision Fallback (LLM).md` | canonical | ok | ok | ok | - |
| `PROJECTS/AI-Influencer/01-Gen-Stack.md` | canonical | ok | ok | ok | - |
| `PROJECTS/AI-Influencer/02-RunPod-Deploy.md` | canonical | ok | ok | ok | - |
| `PROJECTS/AI-Influencer/03-Patches.md` | canonical | ok | ok | ok | - |
| `PROJECTS/AI-Influencer/04-PostProcessing.md` | canonical | ok | ok | ok | - |
| `PROJECTS/AI-Influencer/05-B2-Backup.md` | canonical | ok | ok | ok | - |
| `PROJECTS/AI-Influencer/06-Scripts.md` | canonical | ok | ok | ok | - |
| `PROJECTS/AI-Influencer/07-Decision-Log.md` | canonical | ok | ok | ok | - |
| `PROJECTS/AI-Influencer/08-ComfyUI-Architecture.md` | canonical | ok | ok | ok | - |
| `PROJECTS/AI-Influencer/09-Deploy-Procedure.md` | canonical | ok | ok | ok | - |
| `PROJECTS/AI-Influencer/12-Generation-2026-07-08.md` | canonical | ok | ok | ok | - |
| `PROJECTS/AI-Influencer/13-What-To-Try-Next.md` | canonical | ok | ok | ok | - |
| `PROJECTS/AI-Influencer/14-Quality-Analysis-2026-07-08.md` | canonical | ok | ok | ok | - |
| `PROJECTS/AI-Influencer/README.md` | canonical | ok | ok | ok | - |
| `PROJECTS/B2 Readiness Report.md` | canonical | ok | ok | ok | - |
| `PROJECTS/Business Plans.md` | canonical | ok | ok | ok | - |
| `PROJECTS/Deploy 2 Plan.md` | canonical | ok | ok | ok | - |
| `PROJECTS/Testing Matrix.md` | canonical | ok | ok | ok | - |
| `PROJECTS/__pycache__/test_matrix.cpython-313.pyc` | canonical | ok | ok | ok | - |
| `PROJECTS/test_matrix.py` | canonical | ok | ok | ok | - |
| `SIGNALS/Loop-Engineering.md` | canonical | ok | ok | ok | - |
| `SIGNALS/Quant Trading.md` | canonical | ok | ok | ok | - |
| `STACK/B2 Database Inventory.md` | canonical | ok | ok | ok | - |
| `STACK/B2 Debugging UV Zombies.md` | canonical | ok | ok | ok | - |
| `STACK/B2 Storage.md` | canonical | ok | ok | ok | - |
| `STACK/DOCKER_TROUBLESHOOTING.md` | canonical | ok | ok | ok | redirect note |
| `STACK/Deploy Script.md` | canonical | ok | ok | ok | - |
| `STACK/Golden Deploy.md` | canonical | ok | ok | ok | - |
| `STACK/Hermes Agent.md` | canonical | ok | ok | ok | - |
| `STACK/Hermes Error Troubleshooting.md` | canonical | ok | ok | ok | - |
| `STACK/Killswitch-Cronjob.md` | canonical | ok | ok | ok | - |
| `STACK/N8N_DEPLOYMENT.md` | canonical | ok | ok | ok | redirect note |
| `STACK/RAILWAY_DEPLOYMENT.md` | canonical | ok | ok | ok | redirect note |
| `STACK/RunPod GPU Deployment History.md` | canonical | ok | ok | ok | - |
| `STACK/RunPod-Playbook.md` | canonical | ok | ok | ok | - |
| `STACK/SDXL Test Report 29 June.md` | canonical | ok | ok | ok | - |
| `STACK/SELF_HOSTING.md` | canonical | ok | ok | ok | redirect note |
| `STACK/STT Speech-to-Text.md` | canonical | ok | ok | ok | - |
| `STACK/Storage_B2_Structure.md` | canonical | ok | ok | ok | - |
| `STACK/TG Gateway.md` | canonical | ok | ok | ok | - |
| `STACK/Telegram_Bot_HyperAgent.md` | canonical | ok | ok | ok | - |
| `STACK/Windows Специфика.md` | canonical | ok | ok | ok | - |
| `STACK/n8n-MCP проект.md` | canonical | ok | ok | ok | - |
| `STACK/Командный Центр CC v3.md` | canonical | ok | ok | ok | - |
| `Templates/MOC-страница.md` | template | ok | ok | ok | template file |
| `Templates/RAW-заметка.md` | template | ok | ok | ok | template file |
| `Templates/Wiki-страница.md` | template | ok | ok | ok | template file |
| `VAULT/Second-Brain.md` | canonical | ok | ok | ok | - |
| `VAULT/Statuses.md` | canonical | ok | ok | ok | - |
| `VAULT/Линковка.md` | canonical | ok | ok | ok | redirect note |
| `VAULT/Удалённые-проекты.md` | canonical | ok | ok | ok | - |
| `_archive/ControlNet_IPAdapter_PuLID.md` | archive | ok | ok | ok | archived layer |
| `_archive/NEEDS_YOUR_CALL.md` | archive | ok | ok | ok | archived layer |
| `_archive/RunPod.md` | archive | ok | ok | ok | archived layer |
| `_archive/SDXL Big Love Prompts.md` | archive | ok | ok | ok | archived layer |
| `_archive/SDXL Big Love.md` | archive | ok | ok | ok | archived layer |
| `_archive/WHY_ARCHIVED.md` | archive | ok | ok | ok | archived layer |
| `_archive/n8n-MCP.md` | archive | ok | ok | ok | archived layer |