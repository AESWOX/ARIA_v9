---
created: {{date:YYYY-MM-DD}}
updated: {{date:YYYY-MM-DD}}
status: raw
type: 
tags: [template, raw]
source: 
processed_into: 
---
# {{title}}

## Суть


## Ключевые моменты


## Теги
