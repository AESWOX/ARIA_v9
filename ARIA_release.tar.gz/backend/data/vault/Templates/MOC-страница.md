---
created: {{date:YYYY-MM-DD}}
updated: {{date:YYYY-MM-DD}}
status: draft
tags: [moc, index]
aliases: []
source: 
---

# 🗺️ MOC: {{title}}

> 

## Ссылки

### 

### 

## Связи
- [[]]
