---
created: {{date:YYYY-MM-DD}}
updated: {{date:YYYY-MM-DD}}
status: draft
tags: [template, wiki, obsidian]
aliases: []
source: 
---

# {{title}}

> Краткое описание сути.

## Концепция


## Детали


## Связи
- [[]]

## Источники
- 
