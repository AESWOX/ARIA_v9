---
name: loop-engineering-v1
description: Loop-Engineering v1.1 — 7-stage executor with integrity detectors, plan validation, secret scanning, optimistic locking, and delivery contract. Run after implementing the core agent loop to enforce quality gates.
---

# Loop-Engineering v1.1

Полный цикл loop-engineering с интеграцией integrity-детекторов, PlanStep-валидации, secret-scanner, optimistic locking и delivery-контракта.

## Структура

| Компонент | Файл | Назначение |
|-----------|------|------------|
| План | `ARIA_FULL_TZ_v1.md` | Единый документ требований (v1.1) |
| Модели | `aria/db/models.py` | `TaskPlan` + `IntegrityEvent` |
| Enum | `aria/db/enums.py` | `IntegrityVerdict`, `PlanStatus` |
| Миграция | `alembic/versions/*.py` | `78e21fd4becc` — add task_plans + integrity_events |
| Валидатор | `aria/core/plan_validator.py` | `PlanStep` Pydantic + replan policy (Oracle НАЕБАЛ при 3× invalid) |
| Детекторы | `aria/core/integrity.py` | 5 чистых функций (`file_content_hash`, `assert_file_changed`, `get_exit_code`, `has_junit_artifact`, `extract_covered_step_ids`) |
| SecretScanner | `aria/core/secretscanner.py` | 14 DENY_PATTERNS, ALLOWLIST, changed-only scan |
| Notifier | `aria/core/notifiers/` | Protocol + TelegramNotifier (timeout=10s, retry=2) |
| Locking | `aria/core/locking.py` | Optimistic lock + file-lock + TTL=30s, max 15 retries, backoff 0.5→5s |
| Executor | `aria/core/executor.py` | Stage 1–7, delivery contract, `_with_db_retry()` (3 retries) |
| Тесты | `tests/test_loop_engineering.py` | 55 тестов: детекторы, валидация, secret-scan, locking, delivery |

## Ключевые правила

1. **Plan перед действием** — каждый tool call следует плану (max 7 шагов)
2. **Read-after-write** — каждый write_file/patch обязан иметь read_file следом
3. **Запрет слов-подтверждений** — «готово», «исправлено» и т.д. запрещены без верификационного вызова
4. **НАЕБАЛ = hard fail** — retry запрещён для integrity-нарушений
5. **Oracle НАЕБАЛ** — 3 отклонения PlanStep валидатора = hard fail, escalation
6. **ЗАБЫЛ** — только по step_id/tool_call_ids, semantic matching исключён
7. **clean = critical_count == 0** — не путать с len(matches)==0!
8. **Notifier failure ≠ integrity-нарушение**
9. **Delivery note** — генерируется целиком из `plan_json + final_result_json`, ручной контент запрещён

## Использование

```python
from aria.core.executor import run_task
result = await run_task(task_id=..., plan_json=[...])
# result = {"status": "done"/"failed", "integrity_verdict": "pass_"/"naebal", "delivery_note": "..."}
```

## Важные уроки

- `ScanResult.clean` = `critical_count == 0`, NOT `len(matches) == 0`
- Delivery-контракт обрабатывает `final_result_json=None` → генерирует «Задача не завершена»
- `DENY_PATTERNS` расширены до 14: `sk-`, `sk-proj-`, `sk-ant-`, `AIza`, `ghp_`, `ghu_`, `github_pat_`, `hf_`, `pplx-`, `r8_`, `co-`, `pat-`, `gsk_`, `sk_`
- `ALLOWLIST` содержит 9 тестовых ключей (`test-`, `example-`, `fake-`, `placeholder-`, `YOUR_`, `xxxx`, etc.)
- PlanHistory retention: max 20 entries, shift oldest при превышении
- Lock TTL: 30s настраиваемый через `settings.lock_ttl_seconds`
