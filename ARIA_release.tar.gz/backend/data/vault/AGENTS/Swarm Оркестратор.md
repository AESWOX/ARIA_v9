---
created: 2026-06-27
updated: 2026-06-29
tags: [hermes, swarm, multi-agent, orchestrator, parallel]
---

# Swarm Оркестратор

> Мульти-агентная оркестрация для сложных задач.
> Реализация `/goal` из [[Loop-Engineering]] — одна задача разбивается на параллельные подзадачи.

---

## Архитектура

```mermaid
graph TD
    User[👤 Пользователь] --> TG[TG Gateway]
    User --> CLI[Hermes CLI]
    User --> CC[CC v3 UI]
    
    TG --> Hermes
    CLI --> Hermes
    CC --> Hermes
    
    Hermes{Hermes Agent} -- "Простая задача" --> Direct[🧑‍💻 Выполнить сам]
    Hermes -- "Сложная задача" --> Swarm[🐝 Swarm Оркестратор]
    
    Swarm --> Queue[📋 queue.txt]
    Queue --> Worker[🔧 Swarm Worker PID 7572]
    Worker --> Sub1[📎 Саб-агент 1]
    Worker --> Sub2[📎 Саб-агент 2]
    Worker --> Sub3[📎 Саб-агент 3]
    Sub1 --> Results[📝 results.txt]
    Sub2 --> Results
    Sub3 --> Results
    Results --> Hermes
    Hermes --> User
```

---

## Принцип работы

### Когда использовать Swarm
| Тип задачи | Использовать Swarm? | Пример |
|------------|-------------------|--------|
| 1-2 инструмента | ❌ НЕТ — сделать самому | «Открой файл config.yaml» |
| 3+ инструмента, линейно | ❌ НЕТ — последовательные вызовы | «Установи пакет, проверь, отпиши» |
| Параллельные исследования | ✅ ДА — delegate_task | «Найди 3 лучшие LoRA на CivitAI» |
| Мульти-агентный анализ | ✅ ДА — parallel tasks | «Проверь код, напиши тесты, сделай документацию» |
| Кросс-проверка | ✅ ДА — verifier pattern | «Создай промпт, другой агент проверит» |
| Любая задача где нужно 5+ вызовов | ✅ ДА | «Собери данные с 5 сайтов» |

**Ключевое правило:** DeepSeek = оркестратор. Простые задачи самому, сложные — в swarm.

### Как работает delegate_task
```python
# Внутренний механизм Hermes:
# 1. Вызов: delegate_task(goal="...", context="...", tasks=[...])
# 2. Каждый саб-агент получает:
#    - Свой изолированный контекст
#    - Свой terminal session
#    - Свой набор инструментов (toolsets)
# 3. Все сабы выполняются параллельно (до 3 одновременно)
# 4. Результаты возвращаются в основную сессию
# 5. Оркестратор собирает и анализирует
```

### Максимум параллельных сабов
**Конфиг:** `delegation.max_concurrent_children = 3` (настроено для этого пользователя)

**Что делать если нужно больше:** 
- Запустить batch (1 вызов с tasks=[task1, task2, task3])
- После завершения batch → запустить ещё batch
- ИЛИ увеличить лимит в `config.yaml`

**Nested delegation:** OFF (max_spawn_depth=1) — сабы не могут создавать свои сабы.

---

## Интеграции

### TG Gateway

**Hook:** `~/.hermes/hooks/tg-swarm-bridge/`

**Пользователь в Telegram:**
```
/task Создай 5 вариантов промптов для girl персонажа
```

**Что происходит:**
1. TG Gateway перехватывает `/task`
2. Пишет в `queue.txt`
3. Swarm worker читает queue.txt
4. Создаёт сабы для каждого варианта
5. Пишет результаты в `results.txt`
6. Отправляет ответ в Telegram через `notify_telegram()`

### Command Center CC v3

**API endpoints:**
| Endpoint | Метод | Назначение |
|----------|-------|-----------|
| `/api/swarm/task` | POST | Поставить задачу в очередь |
| `/api/swarm/status` | GET | Статус текущих задач |
| `/api/swarm/results` | GET | Получить результаты |

**Вкладка Swarm в CC v3:**
- Просмотр очереди задач
- Статус выполнения
- История результатов
- Кнопка «Отменить все»

---

## Процессы

| Процесс | Команда | PID (типичный) | Назначение |
|---------|---------|----------------|-----------|
| Swarm daemon | `pythonw agent_swarm.py` | 7572 | Обработка очереди |
| Dashboard | `python -m hermes_cli.main dashboard` | 7352 | UI мониторинг |
| Gateway | `pythonw -m hermes_cli.main gateway run --replace` | 2248 | Telegram вход |

**Проверка:**
```bash
# Живы ли процессы?
ps aux | grep pythonw

# Есть ли задачи в очереди?
cat ~/.hermes/hooks/tg-swarm-bridge/queue.txt

# Есть ли результаты?
cat ~/.hermes/hooks/tg-swarm-bridge/results.txt
```

---

## Скрипты и файлы

### tg-swarm-bridge hook

**Структура:**
```
~/.hermes/hooks/tg-swarm-bridge/
├── __init__.py
├── queue.txt        # Входящие задачи (одна строка = одна задача)
├── results.txt      # Результаты (JSON)
└── tg_swarm_bridge.py  # Мониторинг results.txt → TG
```

### agent_swarm.py
Основной воркер, запускается как демон:
```python
# Псевдокод:
while True:
    task = read_queue()         # Читаем queue.txt
    if task:
        subagents = spawn(task) # Создаём саб-агентов
        results = wait(subagents) # Ждём все
        write_results(results)    # Пишем в results.txt
        notify_telegram(results)  # Отправляем в TG
    sleep(5)  # Проверяем каждые 5 секунд
```

---

## Loop Engineering в Swarm

| Loop компонент | Реализация в Swarm |
|----------------|-------------------|
| **Automation** | `delegate_task` + cron для повторяющихся задач |
| **Skill** | `swarm-orchestrator` skill — процедура оркестрации |
| **State** | `queue.txt` + `results.txt` + Hermes memory |
| **Verifier** | Отдельный саб-агент проверяет результаты других сабов |
| **Worktrees** | Каждый саб-агент в изолированном terminal |
| **Connectors** | TG Gateway, CC v3 API, файловая система |

---

## Примеры использования

### Пример 1: Параллельное исследование
```python
delegate_task(goal="Исследовать 3 темы", tasks=[
    {"goal": "Найди лучшие LoRA для SDXL на CivitAI"},
    {"goal": "Проверь цены на RunPod GPU"},
    {"goal": "Собери статистику по AI контенту на Fanvue"}
])
```

### Пример 2: Verifier pattern
```python
# Генератор
result_1 = delegate_task(goal="Напиши 10 промптов для girl персонажа")

# Верификатор (использует другую модель)
result_2 = delegate_task(goal="Проверь промпты на качество и исправь ошибки",
    context=f"Промпты для проверки:\n{result_1}")
```

### Пример 3: Code review + tests
```python
delegate_task(
    goal="Проверить код и написать тесты",
    context="project_path: WORK/ШОТ/godtier_modular_final_verified/",
    tasks=[
        {"goal": "Проведи код-ревью Python файлов в папке"},
        {"goal": "Напиши pytest тесты для основных функций"},
        {"goal": "Проверь API endpoints через curl"}
    ]
)
```

---

## Troubleshooting

| Проблема | Причина | Решение |
|----------|---------|---------|
| Задача не выполняется | Swarm worker не запущен | `pythonw agent_swarm.py` |
| Результат не приходит в TG | TG hook не активен | Проверить `~/.hermes/hooks/tg-swarm-bridge/` |
| Слишком много сабов | Лимит 3 | Разбить на batches |
| Сабы падают с ошибкой | Нет контекста | Добавить больше context при вызове |
| `queue.txt` пустой, задача есть | Gateway не перехватил | Проверить TG hook |

---

## Связи
- [[Hermes Agent]] — база (полная страница)
- [[TG Gateway]] — канал входа
- [[Командный Центр CC v3]] — вкладка Swarm
- [[Loop-Engineering]] — теория мульти-агентов
- [[AI-агенты]] — сравнение фреймворков
- [[Как это работает]] — полный workflow
