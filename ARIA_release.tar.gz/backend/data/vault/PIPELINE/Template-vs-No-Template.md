---
created: 2026-06-29
updated: 2026-06-29
tags: [runpod, template, deploy, troubleshooting]
---

# Template vs No-Template (RunPod)

> Pochemu template ne startuet i chto s etim delat.

## Problema

RunPod template **d1zgyr7rjh** (runpod/pytorch:2.2.1) perestal rabotat s 29 iyunya.

## Sravnenie

| Aspekt | S template | Bez template |
|--------|-----------|-------------|
| Start | ❌ Container uptime = 0s | ✅ Normalny start |
| GPU | ❌ Ne vidno | ✅ A5000 rabotaet |
| Porty | ❌ Nedostupny | ✅ 8888+8188+22 |
| Template ID | d1zgyr7rjh | — |
| Kogda rabotal | 26 iyunya (stary klyuch) | 28-29 iyunya (novy klyuch) |

## Diagnostika

Template rabotaet so starym API klyuchom, NO ne rabotaet s novym. Pri etom tot zhe image **bez template** rabotaet s novym klyuchom.

**Vyvod:** Template khranit credentialy/state invalidny s novym klyuchom.

## Alternativa: ComfyUI CUDA 13

RunPod predlagaet oficialny shablon:
- ID: 2lv7ev3wfp
- Image: runpod/comfyui:cuda13.0
- Ports: 8188/http, 8888/http
- ComfyUI + dependency predustanovleny

**Ne testirovan** — net rabochego API klyucha.

## Rekomendatsiya

Sozdavat pody **bez template**, ukazyvaya image napryamuyu:
```python
config = {
    "image_name": "runpod/comfyui:cuda13.0",
    # NE ukazyvat template_id
}
```

## 🔗 Cross-links
- [[02-TAGS/MOC-Ошибки-и-Решения]]
- [[STACK/RunPod GPU Deployment History]]
