---
created: 2026-07-01
tags: [vision, fallback, config, llm, groq, gemini]
---

# Vision Fallback (LLM) — Multi-Provider Vision System

> **Создан:** 1 июля 2026 — в ответ на падения Gemini primary.
> **Raw source:** Session 20260701_151551_0c42ba74 (TG Gateway) + Session 20260701_150551_c1b960 (TUI)

---

## Архитектура

```
agent запрос с изображением
  → vision.primary (Google Gemini via GEMINI_API_KEY)
  │   → если 400/401/429 → vision_fallback (Groq pool)
  │       → rotation между 10 Groq-ключами
  │           → если все ключи исчерпаны → ошибка
  → Success: True (как только любой провайдер ответил)
```

## Компоненты

### Primary: Google Gemini
| Параметр | Значение |
|----------|----------|
| **Провайдер** | `google` |
| **API ключ** | `GEMINI_API_KEY` (AIzaSyDZ24...) |
| **Модель** | `gemini-2.0-flash` |
| **Статус** | ✅ Работает (после восстановления ключа) |

### Fallback pool: Groq
| Параметр | Значение |
|----------|----------|
| **Модель** | `meta-llama/llama-4-scout-17b-16e-instruct` (Llama 4, $0.11/M) |
| **Ключей в пуле** | 10 (GROQ_API_KEY, GROQ_API_KEY_2, ... GROQ_API_KEY_10) |
| **Ротация** | Авто при 400/401/429 → следующий ключ |
| **Пропуск пустых** | `key_env=GROQ_API_KEY` empty → skip |

## Тесты (1 июля 2026)

### TEST 1: Happy path Google ✅
```
Success: True
→ "A woman with freckles and long eyelashes looks directly forward."
```

### TEST 2: Broken Gemini → Groq fallback ✅
```
Primary vision (Google) failed: 400... Trying Groq fallback pool...
→ Success: True
→ "The image shows a close-up portrait of a woman's face."
```
**Разный текст = разные провайдеры** — Google и Groq дали разный анализ.

### TEST 3: Ротация внутри пула ✅
```
vision_fallback: key_env=GROQ_API_KEY empty, skip
vision_fallback: key_env=GROQ_API_KEY_2 retryable error (401), next key
→ Success: True (Groq key #3+)
```

## Конфигурация (config.yaml)

```yaml
vision_fallback:
  pool:
    - key_env: GROQ_API_KEY        # пустой — пропускается
    - key_env: GROQ_API_KEY_2      # мёртвый 401 — ротация
    - key_env: GROQ_API_KEY_3      # живой
    # ... до GROQ_API_KEY_10
  model: meta-llama/llama-4-scout-17b-16e-instruct
  provider: groq

vision:
  provider: google
  key_env: GEMINI_API_KEY
  model: gemini-2.0-flash
```

## История

- **До 1 июля:** vision шёл через `openrouter` + `google/gemini-2.5-flash`
- **1 июля 12:45 → 15:00:** Провайдер сменён на `google` + `gemini-2.0-flash`, добавлен `vision_fallback` с Groq pool
- **1 июля 15:08:** Рестарт гейтвея — все 3 теста пройдены ✅

## Связи
- [[Hermes Agent]] — основной конфиг агента
- [[TG Gateway]] — входной канал (где выполнялись тесты)
- [[Hermes Error Troubleshooting]] — ошибки vision провайдеров
