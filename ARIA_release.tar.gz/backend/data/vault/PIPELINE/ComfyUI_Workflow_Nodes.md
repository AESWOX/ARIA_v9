---
tags: [comfyui, workflow, nodes, godtier, reference]
type: reference
---

# ComfyUI — Воркфлоу и ноды (Full Reference)

## Базовые ноды пайплайна (txt2img SDXL)

### `CheckpointLoaderSimple`
- Загружает `MODEL`, `CLIP`, `VAE` из единого файла чекпоинта
- Для SDXL — оба текстовых энкодера (CLIP-L + CLIP-G) грузятся автоматически внутри одной ноды

### `CLIPTextEncode` (x2: positive/negative)
- `text` — сам промпт
- Для SDXL можно раздельно кодировать через `CLIPTextEncodeSDXL` с раздельными полями для CLIP-L/CLIP-G и `width/height/crop` conditioning (влияет на композицию через aesthetic score conditioning)

### `EmptyLatentImage`
- `width`, `height` — из bucketing-совместимых значений SDXL (1024×1024, 896×1152, 1152×896, и т.д.)
- `batch_size`

### `KSampler`
- `seed`, `steps`, `cfg`, `sampler_name`, `scheduler`, `denoise` — см. [[Generation_Parameters]]
- `KSamplerAdvanced` — доп. поля `start_at_step`/`end_at_step` для многоступенчатых пайплайнов (напр. base+refiner)

### `VAEDecode`
- Конвертирует latent → pixel space, финальное изображение

---

## LoRA/DoRA ноды

### `LoraLoaderModelOnly` / `LoraLoader`
- `lora_name`, `strength_model`, `strength_clip`
- `strength_model` влияет на UNet-эффект, `strength_clip` — на текстовый энкодер (независимо друг от друга!)
- Множественные LoRA — chain через несколько нод последовательно, каждая берёт MODEL/CLIP от предыдущей

---

## ControlNet ноды

### `ControlNetLoader` → `ControlNetApplyAdvanced`
- `strength`, `start_percent`, `end_percent` — см. [[ControlNet_IPAdapter_PuLID]]
- Препроцессоры (отдельные ноды): `CannyEdgePreprocessor`, `MiDaS-DepthMapPreprocessor`, `OpenposePreprocessor` — конвертируют исходное фото в conditioning-карту перед подачей в ControlNet

---

## IP-Adapter ноды (ComfyUI_IPAdapter_plus)

### `IPAdapterModelLoader` + `IPAdapterApply` / `IPAdapterAdvanced`
- `weight`, `weight_type`, `start_at`, `end_at` — см. [[ControlNet_IPAdapter_PuLID]]
- `CLIPVisionLoader` — обязательная зависимость, отдельно грузит image encoder

---

## PuLID ноды

### `PulidModelLoader` + `ApplyPulid`
- `weight` (id_weight), `start_at`, `attn_mask` (опционально, для ограничения области применения ID на лицо)
- Обычно требует `InsightFace` loader отдельной нодой для детекции лица на референсе

---

## Upscale ноды

### `UpscaleModelLoader` + `ImageUpscaleWithModel`
- Для ESRGAN-семейства — см. [[Upscalers]]

### Latent upscale (Hires-fix путь)
- `LatentUpscale` / `LatentUpscaleBy` → второй `KSampler` с `denoise 0.4-0.55` поверх — классический hires-fix воркфлоу без выхода в pixel space между шагами

### SUPIR (custom nodes, ComfyUI-SUPIR)
- Отдельный loader + sampler ноды, требуют доп. VRAM-менеджмент (см. [[VRAM_Optimization_3090]])

---

## Практический паттерн фазовой генерации (GODTIER, см. также [[ControlNet_IPAdapter_PuLID]])

Типичный граф:
```
CheckpointLoader → LoraLoader (x1-2) → ControlNetApply (pose/depth, weight 0.7, end 0.6)
                                      → IPAdapterApply (style, weight 0.5)
                                      → ApplyPulid (id, weight 0.8, start 0.1)
                → KSampler (steps 28, cfg 5.5)
                → VAEDecode
                → UpscaleModelLoader (4x-UltraSharp) → ImageUpscaleWithModel
                → LatentUpscale → KSampler #2 (denoise 0.45) → VAEDecode (финал)
```

---

## Автоматизация через API (для hyper_agent/Telegram-бота)
- ComfyUI поддерживает `/prompt` REST endpoint — принимает JSON-граф воркфлоу напрямую
- Воркфлоу экспортируется через "Save (API Format)" в UI → используется как шаблон, куда скрипт (hyper_agent) подставляет переменные (seed, prompt, LoRA) программно перед отправкой POST-запроса
- `/history/{prompt_id}` — polling для получения результата после отправки задачи

---

## Связанные заметки
- [[Generation_Parameters]]
- [[ControlNet_IPAdapter_PuLID]]
- [[Upscalers]]
- [[VRAM_Optimization_3090]]
