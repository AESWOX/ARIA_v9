---
status: redirect
tags: [redirect, review]
redirect_to: [[90-REVIEW/STUBS/PIPELINE/FaceFusion.review]]
reason: stub note; installation/version not verified
---
# FaceFusion

Эта заметка вынесена из активного контура качества.
См. [[90-REVIEW/STUBS/PIPELINE/FaceFusion.review]].
