---
created: 2026-06-27
tags: [video-generation, sdxl, ai, comparison]
source: 00-RAW/статьи/2026-06-27-data-video.md
---

# AI Видео Генерация

> Сравнение открытых моделей генерации видео для порно-сериалов.
> Цель: LTX-Video как основа, HunyuanVideo для коротких high-quality клипов.

---

## Сравнительная таблица

| Технология | VRAM | Разрешение | Длительность | ControlNet | ComfyUI | NSFW |
|---|---|---|---|---|---|---|
| **LTX-Video 13B distilled 🥇** | 6.2GB | 720p | **60 сек** | ✅ | ✅ | ✅ |
| **LTX-Video 2B** | 2.7GB | 480p | **60 сек** | ✅ | ✅ | ✅ |
| **HunyuanVideo 1.5 🥈** | ~14GB | 720p | 10 сек | ✅ LoRA | ✅ | ✅ |
| **Wan2.1 1.3B 🥉** | 8.19GB | 480p | 5 сек | ✅ VACE | ✅ | ✅ |
| **CogVideoX 1.5-5B** | 10GB | 1024² | 10 сек | ❌ | ⚠️ | ⚠️ |
| **Mochi 1** | 20GB | 480p | 5 сек | ❌ | ✅ | ❌ |
| **Pyramid-Flow** | <8GB | 480p | 10 сек | ❌ | ❌ | ✅ |

---

## LTX-Video 13B distilled 🥇

**Базовая модель для длинных сцен (до 60 сек)**

- **VRAM:** 6.2GB (13B модель) / 2.7GB (2B модель)
- **Длительность:** до 60 сек
- **Разрешение:** до 720p
- **ControlNet:** ✅ IC-LoRA Pose Control (human pose, depth, canny)
- **ComfyUI:** ✅ Native (официальные ноды)
- **NSFW:** ✅
- **GitHub:** Lightricks/LTX-Video

**Плюсы:** Самая длинная генерация, легковесная, ControlNet из коробки

---

## HunyuanVideo 1.5 🥈

**Для коротких высококачественных клипов**

- **VRAM:** ~14GB (1.5 улучшенная версия)
- **Длительность:** до 10 сек
- **Разрешение:** до 720p (с SR до 1080p)
- **ControlNet:** ✅ Через LoRA/Keyframe
- **ComfyUI:** ✅ Native
- **NSFW:** ✅
- **GitHub:** Tencent/HunyuanVideo

**Плюсы:** Лучшее качество из открытых, ControlNet

---

## Wan2.1 1.3B 🥉

**Fallback если VRAM мало**

- **VRAM:** 8.19GB
- **Длительность:** до 5 сек
- **Разрешение:** 480p
- **ControlNet:** ✅ VACE (все виды)
- **ComfyUI:** ✅ Native
- **NSFW:** ✅
- **Плюсы:** VACE ControlNet полный

---

## Рекомендация для порно-сериалов

1. **LTX-Video 13B** — основа (60 сек сцен)
2. **HunyuanVideo 1.5** — для коротких высококачественных клипов
3. **Wan2.1** — fallback если VRAM мало

---

## Связи

- [[GODTIER V8 Workflow Spec]] — этап видео
- [[ComfyUI]] — рендер-движок
- [[RunPod]] — GPU для генерации
