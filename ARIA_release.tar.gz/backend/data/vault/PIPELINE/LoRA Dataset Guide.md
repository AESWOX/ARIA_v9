---
created: 2026-06-27
tags: [lora, dataset, training, sdxl, onetrainer]
---

# LoRA Dataset — Полный Guide

> Для SDXL Big Love. 2 LoRA: Face + Body.
> Цель: консистентное лицо и тело на всех генерациях.

---

## 🧠 Теория — Как работает LoRA на SDXL

**LoRA (Low-Rank Adaptation)** — дообучение модели на конкретного персонажа.

**Архитектура SDXL:**
```
SDXL = UNet + CLIP (text encoder 1) + CLIP (text encoder 2) + VAE

LoRA встраивается в UNet cross-attention слои:
- rank=32 → ~50MB файл
- rank=64 → ~100MB файл
```

**Для консистентности нужно:**
1. Одни и те же reference лица — на ВСЕХ изображениях dataset
2. Разные ракурсы — чтобы LoRA поняла 3D структуру лица
3. Разные выражения — чтобы не переобучилась на конкретную эмоцию
4. Разное освещение — чтобы не выучила конкретный свет
5. Качественные изображения — без артефактов, шума, размытия

---

## 📊 Требования к количеству

### Минимальные требования (SDXL)

| LoRA | Min | Good | Optimal | Max |
|---|---|---|---|---|
| **Face** | 20 | 50-60 | 80-100 | 200+ |
| **Body** | 30 | 60-80 | 100-150 | 300+ |

**Почему:**
- **20 min:** LoRA выучит лицо, но будет переобучаться на конкретные позы/ракурсы
- **50-60 good:** Хороший баланс качество/скорость
- **80-100 optimal:** Идеально — все вариации покрыты
- **>100:** Diminishing returns, но лучше не бывает

### Для 3 персонажей:
| Персонаж | Face dataset | Body dataset | Всего |
|---|---|---|---|
| Girl | 60-80 | 80-100 | 140-180 |
| Milf | 60-80 | 80-100 | 140-180 |
| Trans | 60-80 | 80-100 | 140-180 |
| **TOTAL** | **180-240** | **240-300** | **420-540** |

---

## 🎯 Этап 1: Face LoRA Dataset

**Цель:** Научить SDXL генерировать ОДНО И ТО ЖЕ лицо персонажа с разных ракурсов

### Что нужно собирать

| Тип | Кол-во | Ракурсы | Требования |
|---|---|---|---|
| **Портреты (face only)** | 30-40 | Фронт (20), ¾ (15), профиль (5) | Шея и выше, лицо 70%+ кадра |
| **Bust (грудь+лицо)** | 20-30 | Фронт (15), ¾ (10), профиль (5) | До груди, лицо 50%+ кадра |
| **Emotions** | 15-20 | Фронт | 5-7 разных эмоций × 3 варианта |
| **Hairstyles** | 5-10 | Фронт + ¾ | 2-3 прически × 3-4 варианта |

**TOTAL:** ~70-100 изображений на персонажа

### Распределение по ракурсам

```
Фронт (0°):      30 шт — основа, главный ракурс
¾ (45°):         25 шт — переходный
¾ (315°):        15 шт — в другую сторону
Профиль (90°):   10 шт — для полноты
Профиль (270°):  10 шт — в другую сторону
                   —
TOTAL:           90 шт
```

### Распределение по эмоциям

| Эмоция | Кол-во | Prompt word |
|---|---|---|
| Нейтральная | 15 | "neutral expression" |
| Улыбка | 15 | "smiling, happy" |
| Серьёзная | 10 | "serious look" |
| Удивление | 8 | "surprised, open mouth" |
| Грустная | 8 | "sad expression" |
| Соблазнительная | 10 | "seductive look, smirking" |
| Смеющаяся | 5 | "laughing, joyful" |

### Технические требования (Face)

| Параметр | Значение | Почему |
|---|---|---|
| **Resolution** | 1024×1024 | SDXL оптимальный квадрат |
| **Min face size** | 70% кадра | Чтобы лицо было детально |
| **Background** | Uniform (белый/серый/чёрный) | Не отвлекает LoRA |
| **Освещение** | Soft diffused | Минимум теней на лице |
| **Шея** | Видна всегда | Чтобы не было "сломанной шеи" |
| **Волосы** | 2-3 причёски | Для разнообразия, но лицо то же |
| **Аксессуары** | Только если часть персонажа | Очки, серьги — опционально |

### Что НЕЛЬЗЯ использовать

- ❌ Размытые фото (< 1MP)
- ❌ Сильные shadows на лице
- ❌ Руки, закрывающие лицо
- ❌ Профиль с закрытым глазом
- ❌ Multiple faces на одном фото
- ❌ Watermarks, text, logos
- ❌ AI-generated артефакты (6 пальцев, искажения)

---

## 🎯 Этап 2: Body LoRA Dataset

**Цель:** Научить SDXL генерировать тело персонажа (пропорции, формы)

### Что нужно собирать

| Тип | Кол-во | Позы | Требования |
|---|---|---|---|
| **Full body** | 40-50 | Стоя (20), сидя (15), лёжа (15) | Видно всё тело, одежда/ню |
| **Half body** | 20-30 | ¾ вверх | Пояс и выше |
| **Bust** | 15-20 | Грудь подробно | Для анатомии груди |
| **Poses specific** | 15-20 | На коленях, руки вверх, etc | Разнообразие |

**TOTAL:** ~90-120 изображений на персонажа

### Распределение по одежде

| Тип одежды | Кол-во | Для чего |
|---|---|---|
| Одета (SFW) | 30-40 | База, обычная одежда |
| Бельё (Lingerie) | 15-20 | Эротика, нижнее бельё |
| Топлесс (NSFW) | 15-20 | Вид груди, плеч |
| Полностью nude | 15-20 | Анатомия тела |
| Спец. одежда | 10-15 | Разнообразие (платья, джинсы) |

### Технические требования (Body)

| Параметр | Значение | Почему |
|---|---|---|
| **Resolution** | 832×1216 (4:5) | SDXL оптимальный portrait |
| **Full body visible** | Да | Чтобы LoRA видела пропорции |
| **Background** | Plain или blur | Не отвлекает |
| **Освещение** | Even, studio-like | Минимум теней |
| **Поза** | Natural, не скрученная | Чтобы LoRA выучила анатомию |
| **Лицо** | То же самое | Консистентность с Face LoRA |

### Что НЕЛЬЗЯ использовать

- ❌ Обрезанные конечности (без кистей/стоп)
- ❌ Сильные ракурсы (снизу/сверху)
- ❌ Сложные фоны (лес, комната с деталями)
- ❌ Другие люди на фото
- ❌ Предметы, закрывающие тело

---

## 🔧 Этап 3: Pre-processing Dataset

### 3.1 Crop & Resize

```
Face LoRA:      1024×1024 (square)
Body LoRA:      832×1216 (4:5 portrait)
```

### 3.2 Captioning

Каждое изображение нужно подписать. Формат:

**Для Face LoRA:**
```text
woman with medium_length blonde hair, blue eyes, fair skin, 
neutral expression, looking at viewer, portrait, studio lighting
```

**Важные токены:**
- "woman" / "girl" — пол
- "blonde hair, blue eyes" — внешность
- "fair skin" — тон кожи
- "looking at viewer" — взгляд в камеру
- "portrait" / "headshot" — тип кадра
- Эмоция ("smiling", "neutral")
- "studio lighting" — освещение
- "simple background" — фон

### 3.3 Trigger Word

Для Big Love используется **`biglove_photo`** как триггер.
Это слово должно быть в caption каждого изображения.

### 3.4 WD14Tagger

Использовать WD14Tagger для автоматической генерации booru-тегов.
Потом вручную корректировать.

---

## 📐 Этап 4: Параметры обучения (OneTrainer)

### Face LoRA

| Параметр | Значение | Пояснение |
|---|---|---|
| **rank** | 32 | Для лица хватает 32 |
| **alpha** | 32 | alpha = rank (стандарт) |
| **lr** | 1e-4 | Learning rate для лица |
| **lr scheduler** | cosine | Плавное затухание |
| **epochs** | 20-30 | До сходимости loss |
| **resolution** | 1024×1024 | SDXL base |
| **batch size** | 2-4 | Зависит от VRAM |
| **optimizer** | AdamW8bit | Экономия памяти |
| **noise offset** | 0.05 | Для стабильности |
| **multires noise** | 0.15 | Для деталей |
| **network dim** | 32 | Размерность LoRA |
| **network alpha** | 32 | Масштаб |

### Body LoRA

| Параметр | Значение | Пояснение |
|---|---|---|
| **rank** | 64 | Для тела нужно больше |
| **alpha** | 64 | alpha = rank |
| **lr** | 5e-5 | Ниже чем для лица |
| **lr scheduler** | cosine | Плавное затухание |
| **epochs** | 15-20 | Тело быстрее учится |
| **resolution** | 1024×1536 (или 832×1216) | SDXL portrait |
| **batch size** | 1-2 | Больше VRAM |
| **optimizer** | AdamW8bit | |
| **network dim** | 64 | |
| **network alpha** | 64 | |

---

## 📁 Структура dataset на диске

```
📁 datasets/
  ├── 📁 girl_01/
  │   ├── 📁 face/
  │   │   ├── 📁 raw/              ← оригиналы (не обрезанные)
  │   │   ├── 📁 cropped/          ← 1024×1024, лицо по центру
  │   │   ├── 📁 tagged/           ← после WD14Tagger
  │   │   └── metadata.json       ← маппинг: файл → caption
  │   │
  │   └── 📁 body/
  │       ├── 📁 raw/
  │       ├── 📁 cropped/          ← 832×1216
  │       ├── 📁 tagged/
  │       └── metadata.json
  │
  ├── 📁 milf_01/
  │   └── ...
  └── 📁 trans_01/
      └── ...
```

---

## 📋 Итоговый чеклист

### Для каждого персонажа:

| Шаг | Что | Кол-во часов |
|---|---|---|
| 1 | Собрать 100 reference фото (face + body) | 2-3ч |
| 2 | Crop/resize: face → 1024², body → 832×1216 | 1ч |
| 3 | Caption каждое фото (WD14 + ручная правка) | 2-3ч |
| 4 | Clean: удалить дубли / брак / нерезкие | 30м |
| 5 | Train Face LoRA (rank=32, 20-30 epochs) | 1-2ч на RunPod |
| 6 | Train Body LoRA (rank=64, 15-20 epochs) | 2-3ч на RunPod |
| 7 | Test: генерация с LoRA, проверка лица | 30м |
| 8 | Итерация если плохо | +1-2ч |

**Total на 1 персонажа:** ~8-12 часов

**Total на 3 персонажа (girl + milf + trans):** ~24-36 часов

---

## 🚀 Production Pipeline

```
Reference Photos (100/char)
    ↓
Crop & Resize
    ↓
Caption (WD14 + manual)
    ↓
LoRA Training (OneTrainer на RunPod)
    │
    ├── 🟢 Face LoRA (.safetensors, ~50MB)
    └── 🟢 Body LoRA (.safetensors, ~100MB)
    ↓
Upload to B2: models/sdxl/loras/{char}_face_lora_v1.safetensors
                        models/sdxl/loras/{char}_body_lora_v1.safetensors
    ↓
Mass Generation (ComfyUI + ControlNet + Face/Body LoRA)
    ↓
500+ images/char → Fanvue/Clips4Sale/xHamster/Telegram
```

---

## ✅ SDXL-совместимые LoRA (из тестов)

> Проверено: какие LoRA реально работают под SDXL 1.0 (Big Love стек).
> Источник: `00-RAW/статьи/2026-06-27-data-lora`

### ❌ НЕ РАБОТАЮТ под SDXL 1.0

| LoRA | Причина |
|------|---------|
| **nsfw_master** | Flux/ZImageTurbo архитектура |
| **aesthetic_quality_modifiers** | Anima/NoobAI/Pony — не SDXL |
| **Detail Slider** (Shed_The_Skin) | Pony архитектура |
| **Body Type Slider** | Pony/Illustrious (нестабильно под SDXL) |

### ✅ РАБОТАЮТ под SDXL 1.0

| LoRA | Вес | Триггер | Примечание |
|------|-----|---------|------------|
| **Hand XL v5.5** | 0.6-0.8 | не нужен | Топ для рук, **обязателен** |
| **skin texture XL v4** | 0.5-0.7 | `skin texture style, detailed skin pore` | Детализация кожи |
| **DMD2 Speed LoRA** | 1.0 | — | Для тестов DMD2 режима |
| **Touch of Realism V2** | 0.5-1.0 | `touch-of-realismV2` | Лёгкий реализм |
| **Realism Lora by Stable Yogi** | 0.3-0.5 | — | Всё-в-одном |
| **Add Detail - Slider SDXL** | 1.0-2.0 | — | Добавляет детализацию |
| **Detailed Perfection style** | 0.5 | — | Руки+лицо+тело (альтернатива hands_xl) |

### 🔥 Рекомендуемый стек SDXL для Big Love

1. **Hand XL v5.5** (0.6-0.8) — руки
2. **skin texture XL v4** (0.5-0.7) — кожа
3. **Touch of Realism V2** (0.5-0.8) — реализм
4. **DMD2 Speed LoRA** (1.0) — для тестов
5. **Add Detail - Slider SDXL** (1.0-2.0) — детализация
6. **Detailed Perfection style** (0.5) — опционально

> ⚠️ **Важно:** `aesthetic_quality_modifiers` и `nsfw_master` были в старом стеке, но они **не работают** под SDXL! Убрать из загрузки и из Workflow Spec.

---

## Связи
- [[GODTIER V8 Workflow Spec]] — воркфлоу генерации
- [[GODTIER V8]] — пайплайн
- [[ComfyUI]] — рендер
- [[SDXL Big Love]] — модели
- [[AI Видео Генерация]] — видео
