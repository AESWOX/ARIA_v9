---
tags: [wiki, sdxl, lora]
created: 2026-07-06
---
# Полный разбор параметров чекпоинтов с CivitAI

> Источник: CivitAI API. Все примеры от авторов чекпоинтов.

---

## Photo5 (ID: 2602579, автор SubtleShader)

Все 10 примеров — **DMD2 режим**. Ни одного production примера.

| Параметр | DMD2 режим |
|---|---|
| **Sampler** | LCM |
| **Steps** | 8 |
| **CFG** | 1 |
| **Resolution** | 1024×1496 (native) |
| **Schedule** | Exponential |
| **LoRA** | dmd2_sdxl_4step_lora_fp16 @ 1.0 |

### Структура промптов DMD2
```
[subject], [pose], [clothing], [expression], [lighting], [background], 
texture, skin pores, detailed, <lora:dmd2_sdxl_4step_lora_fp16:1.0>
```

### Характерные теги
- `texture, skin pores` — ключевые для качества кожи
- `photorealistic, detailed skin texture`
- `cinematic lighting, soft lighting, natural lighting`
- Ракурсы: `low angle, from below, close-up, from above`

---

## Lustify_apexV8 (ID: 575395, автор waterdrinker)

Все 10 примеров — **Production**. Никаких LoRA.

| Параметр | Production |
|---|---|
| **Sampler** | **DPM++ 2M SDE** |
| **Steps** | **50** |
| **CFG** | **7** |
| **Resolution** | 1024×1496 (предпол.) |
| **Schedule** | — |
| **LoRA** | НЕТ |

### Структура промптов Production
```
(score_9,score_8_up,score_7_up:0.5), photo (medium), cinematic, 8k, 
[subject], [pose], [details], [анатомия]
```

### ИЛИ (без score)
```
photo (medium), 8k, high quality, cinematic, [subject], [pose], [details]
```

### Характерные черты Lustify промптов
1. **Pony scores** — `(score_9,score_8_up,score_7_up:0.5)` — Lustify поддерживает Pony теги
2. **photo (medium)** — тип фото (portrait/medium/full body)
3. **cinematic, 8k, high quality** — теги качества
4. **from above, from behind, from side** — ракурсы
5. Анатомия explicit: naked, breasts, pussy, anus, cameltoe, nipples
6. **Никаких LoRA** — чекпоинт сам даёт качество

### Примеры промптов
```
(score_9,score_8_up,score_7_up:0.5), photo (medium), 1girl, naked, cameltoe, 
looking at viewer, hand on ass, lying down on bed, thighhighs

photo (medium), cinematic, 8k, depth of field, portrait, full body, 1girl, 
slim, green eyes, braids, (freckles:0.8), sitting in bed, shy, hands, pussy
```

---

## Сравнительная таблица

| Параметр | Photo5 (DMD2) | Lustify_apexV8 (prod) | Наши вчерашние ❌ |
|---|---|---|---|
| **Sampler** | LCM | **DPM++ 2M SDE** | DPM++ 2M |
| **Steps** | 8 | **50** | 25 |
| **CFG** | 1 | **7** | 4.5 |
| **Resolution** | 1024×1496 | 1024×1496 | 832×1216 |
| **Schedule** | Exponential | — | Karras |
| **LoRA** | dmd2 @ 1.0 | **НЕТ** | НЕТ |

---

## Выводы

1. **Lustify_apexV8** — эталонный чекпоинт: DPM++ 2M SDE, 50 steps, CFG 7. Никаких LoRA.
2. **Photo5** — только DMD2 режим (LCM, 8 steps, CFG 1, Exponential) с dmd2 lora. Для продакшна те же параметры что Lustify.
3. **Ключевая ошибка**: я использовал DPM++ 2M (не SDE), 25 steps (нужно 50), CFG 4.5 (нужно 7).
4. **SDE имеет значение**: DPM++ 2M SDE добавляет стохастический шум = детали кожи.
5. **50 steps + CFG 7** — стандарт для максимального качества на SDXL.
6. **LoRA не нужны для качества** — правильные параметры семплера дают качество без LoRA.

## Рекомендуемый baseline для тестов
```
Sampler: DPM++ 2M SDE
Steps: 50
CFG: 7
Resolution: 1024×1496
Scheduler: Exponential (или default)
LoRA: none (для начала)
```
