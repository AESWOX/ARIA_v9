---
created: 2026-06-27
updated: 2026-06-29
tags: [comfyui, sdxl, nodes, install, workflow, render]
---

# ComfyUI

> SDXL рендер-движок. Версия 0.26.0 (на 27 июня 2026).
> Используется как основной генератор изображений в [[GODTIER V8]] пайплайне.

---

## Установка

### Через deploy.sh (рекомендовано)
```bash
# Весь стек устанавливается скриптом:
bash WORK/ШОТ/deploy.sh
# См. [[Deploy Script]] — детальная страница
```

### Вручную на RunPod
```bash
git clone https://github.com/comfyanonymous/ComfyUI /workspace/ComfyUI
cd /workspace/ComfyUI
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu121
pip install xformers diffusers opencv-python
```

---

## Запуск

### Production (RunPod)
```bash
cd /workspace/ComfyUI
python main.py --listen 0.0.0.0 --port 8188 --normal-vram
```

### Специфичные флаги
| Флаг | Назначение | Когда использовать |
|------|-----------|-------------------|
| `--listen 0.0.0.0` | Доступ снаружи | Всегда на RunPod |
| `--port 8188` | Порт (должен совпадать с RunPod template) | Всегда |
| `--normal-vram` | Оптимизация VRAM | На A5000 (24GB) — НУЖНО |
| `--low-vram` | Максимальная экономия | Если <12GB VRAM |
| `--high-vram` | Максимум скорости | Если >24GB VRAM |
| `--cpu` | CPU режим | Только для тестов |
| `--force-fp16` | Принудительный fp16 | Если модель в fp32 |
| `--disable-auto-launch` | Не открывать браузер | На RunPod (нет браузера) |

### Запуск через systemd (для постоянного пода)
```ini
[Unit]
Description=ComfyUI
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/workspace/ComfyUI
ExecStart=/workspace/ComfyUI/venv/bin/python main.py --listen 0.0.0.0 --port 8188 --normal-vram
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
```

---

## Критические фиксы

### --normal-vram vs --normalvram
```bash
# ComfyUI 0.24.0 и ниже:
python main.py --normalvram

# ComfyUI 0.25.0+ (включая 0.26.0):
python main.py --normal-vram    # с дефисом!

# Если ошибиться:
# python main.py --normalvram
# → ошибка: unrecognized arguments: --normalvram
```

### Порты — ставить ОБА при создании RunPod пода
```bash
# Template Ports:
8888  # Jupyter (опционально)
8188  # ComfyUI (обязательно!)
22    # SSH (ставится автоматически)
```

**Почему:** Без порта 8188 в template, ComfyUI будет недоступен через RunPod proxy. Пересоздание пода = новая загрузка моделей (12-15 мин).

### CUDA out of memory
Если валится с CUDA OOM на A5000 (24GB):
1. Используй `--normal-vram` (не low, не high)
2. Уменьши resolution: 1024×1496 → 832×1216
3. Отключи ненужные ноды (особенно ControlNet если не используется)
4. Проверь сколько процессов жрут VRAM: `nvidia-smi`

---

## Custom Nodes

### Обязательные (для GODTIER V8 workflow)

| Нода | Установка | Назначение |
|------|-----------|-----------|
| **ComfyUI Impact Pack** | `git clone` в custom_nodes | Детекторы: face_yolov8m, hand_yolov8n, ultralytics детектор |
| **ComfyUI ControlNet** | `git clone` | ControlNet Union ProMax |
| **ComfyUI IPAdapter** | `git clone` | IP-Adapter + PuLID |
| **ComfyUI ReActor** | `git clone` | Face swap (альтернатива PuLID) |

### Важные (расширяют возможности)

| Нода | Назначение |
|------|-----------|
| **WAS Node Suite** | Утилиты: изображение, маски, текст |
| **ComfyUI Manager** | Управление нодами через UI |
| **ComfyUI Custom Scripts** | Дополнительные скрипты |
| **Efficient Nodes** | Оптимизация workflow |
| **UltimateSDUpscale** | Tiled upscale (если SUPIR не используется) |

### Установка нод
```bash
cd /workspace/ComfyUI/custom_nodes

# Impact Pack (обязательно)
git clone https://github.com/ltdrdata/ComfyUI-Impact-Pack.git
cd ComfyUI-Impact-Pack
git submodule update --init --recursive
python install.py
cd ..

# ControlNet (обязательно)
git clone https://github.com/Fannovel16/comfyui_controlnet_aux.git

# IPAdapter (обязательно)
git clone https://github.com/cubiq/ComfyUI_IPAdapter_plus.git

# ReActor (важно)
git clone https://github.com/Gourieff/comfyui-reactor-node.git

# Остальные
git clone https://github.com/WASasquatch/was-node-suite-comfyui.git
git clone https://github.com/ltdrdata/ComfyUI-Manager.git
```

---

## API для удалённой генерации

ComfyUI имеет встроенный API для отправки workflow:

```python
import json
import requests
import urllib.request
import urllib.parse

def queue_prompt(prompt_workflow, server="http://localhost:8188"):
    """Отправить workflow в ComfyUI"""
    p = {"prompt": prompt_workflow}
    data = json.dumps(p).encode('utf-8')
    req = urllib.request.Request(f"{server}/prompt", data=data)
    return json.loads(urllib.request.urlopen(req).read())

def get_history(prompt_id, server="http://localhost:8188"):
    """Получить результат"""
    req = urllib.request.Request(f"{server}/history/{prompt_id}")
    return json.loads(urllib.request.urlopen(req).read())

# Загрузить workflow
with open('workflow_api.json', 'r') as f:
    workflow = json.load(f)

# Отправить на генерацию
result = queue_prompt(workflow)
prompt_id = result['prompt_id']
print(f"Prompt ID: {prompt_id}")

# Ждать и получить результат
import time
time.sleep(10)
history = get_history(prompt_id)
```

### Queue-based generation (наша стратегия)
Все промпты отправляются одной пачкой в очередь ComfyUI, а не по одному:
```python
# Отправить 20 промптов в очередь
for i, prompt in enumerate(prompts):
    workflow["6"]["inputs"]["text"] = prompt
    queue_prompt(workflow)
    print(f"Queued {i+1}/{len(prompts)}")

# ComfyUI обработает последовательно
# Overhead: ~2 сек на промпт вместо 30 сек
# 20 тестов = 68 сек вместо 10 минут
```
**См.** [[Decision-Log]] — Queue-based generation

---

## Оптимизация ComfyUI

### Память (VRAM)
| VRAM | Режим | Resolution | Что можно |
|------|-------|-----------|-----------|
| 8GB | `--low-vram` | 512×768 | Только простые gen |
| 12GB | `--normal-vram` | 832×1216 | SDXL + 1 ControlNet |
| 16GB | `--normal-vram` | 1024×1496 | SDXL + 2 ControlNet + PuLID |
| 24GB (A5000) | `--normal-vram` | 1024×1496 | SDXL + ControlNet + PuLID + IP-Adapter + FaceDetailer |
| 48GB (A6000/4090) | `--normal-vram` | 1600×2048 | Всё вместе + upscale |

### Скорость
| Модель | GPU | Шаги | Время/ген |
|--------|-----|------|-----------|
| SDXL (DPM++ 2M SDE) | A5000 | 50 | ~8-12 сек |
| SDXL (DMD2 LCM) | A5000 | 8 | ~1.5-2 сек |
| SDXL + ControlNet + PuLID | A5000 | 50 | ~15-20 сек |
| SDXL + ControlNet + PuLID + FaceDetailer | A5000 | 50 | ~20-30 сек |

### Batch size в очереди
ComfyUI может обрабатывать очередь автоматически — не нужно ждать каждую генерацию отдельно. Используй queue-based подход (см. API раздел).

---

## Troubleshooting

| Проблема | Причина | Решение |
|----------|---------|---------|
| `torch.cuda.OutOfMemoryError` | Не хватает VRAM | Уменьшить resolution, выключить лишние ноды, `--normal-vram` |
| `ModuleNotFoundError: No module named 'xformers'` | Не установлен xformers | `pip install xformers` |
| 502 Bad Gateway через RunPod | ComfyUI не запущен или не на том порту | Проверить `curl http://localhost:8188/system_stats` |
| `Could not find model` | Модель не скачана | Проверить `ls models/checkpoints/` |
| ComfyUI не видит ноды | Не установлены зависимости | `cd custom_nodes/<node> && python install.py` |
| `--normalvram` unrecognized | Версия 0.25+ | Использовать `--normal-vram` (с дефисом) |
| Workflow грузится с ошибками | Версия нод не совпадает | Через ComfyUI Manager → Install missing nodes |

---

## Версии ComfyUI

| Версия | Дата | Ключевые изменения |
|--------|------|-------------------|
| 0.24.0 | Март 2026 | Стабильная |
| 0.25.0 | Май 2026 | `--normalvram` → `--normal-vram` |
| 0.26.0 | Июнь 2026 | Текущая, новые фичи ControlNet |

**Наша версия:** 0.26.0 (через deploy.sh v8.6)

---

## Воркфлоу

Маппинг всех нод с входами/выходами — показывать при запросе. Основные воркфлоу для GODTIER V8 описаны в [[GODTIER V8 Workflow Spec]].

### SDXL базовый workflow (bare minimum)
```mermaid
graph LR
    CL[CheckpointLoader] --> KS[KSampler]
    CL --> VAE[VAEDecode]
    KS --> VAE
    VAE --> Save[SaveImage]
```

### SDXL Production workflow (GODTIER V8)
```mermaid
graph TD
    CL[CheckpointLoader] --> ControlNet[ControlNet Union]
    CL --> PuLID[PuLID Face]
    ControlNet --> KSampler
    PuLID --> KSampler
    LoRA[LoRA Stack] --> KSampler
    IP[IP-Adapter] --> KSampler
    KSampler --> FaceDetailer[FaceDetailer]
    FaceDetailer --> Upscale[Upscaler]
    Upscale --> Save
```

---

## Связи
- [[GODTIER V8]] — пайплайн (полная страница)
- [[GODTIER V8 Workflow Spec]] — детальный workflow с нодами
- [[SDXL Big Love]] — модели
- [[RunPod]] — GPU инфраструктура
- [[Deploy Script]] — установка
- [[B2 Storage]] — откуда качаются модели
