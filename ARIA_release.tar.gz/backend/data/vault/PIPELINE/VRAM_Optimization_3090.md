---
tags: [vram, optimization, rtx3090, sdxl, comfyui, godtier, reference]
type: reference
---

# VRAM-оптимизация — RTX 3090 (24GB), Full Pipeline

## Общие флаги/настройки (везде: обучение, генерация, апскейл)

### `precision` (fp16 / bf16 / fp32)
- `bf16` — предпочтительно на 3090 (Ampere, полная поддержка), стабильнее fp16 против NaN/overflow
- `fp16` — чуть быстрее, но больше риск NaN на DoRA/высоких LR
- `fp32` — только для финального мерджа/экспорта, не для тренировки/инференса (2x VRAM, 2x медленнее)

### `gradient_checkpointing`
- Пересчитывает активации на backward вместо хранения в памяти
- Экономия: **30-40% VRAM**, цена: **+15-20% времени** на шаг
- Включать всегда при тренировке LoRA/DoRA на 3090, кроме случаев когда датасет крошечный и батч=1 без него уже помещается

### `cache_latents` / `cache_latents_to_disk`
- Предрасчитывает VAE-latents датасета один раз перед тренировкой вместо каждый шаг
- Экономия VRAM + ускорение (VAE encode не гоняется на каждой итерации)
- `to_disk=True` — если датасет большой (100+ img) и не помещается в RAM

### `cache_text_encoder_outputs`
- Аналогично для CLIP text encoder — если капшены не меняются между эпохами (нет caption dropout!), можно закэшировать
- **Конфликт:** несовместимо с `caption_dropout_rate > 0` и `shuffle_caption=True` — кэш зафиксирует один вариант капшена

### `xformers` / `sdpa` (attention optimization)
- `sdpa` (PyTorch native scaled dot product attention) — на новых torch версиях быстрее/стабильнее xformers, рекомендуется по умолчанию
- `xformers` — старый стандарт, всё ещё рабочий, чуть больше VRAM экономит в некоторых конфигурациях

---

## По задачам

### Тренировка LoRA/DoRA SDXL
| Настройка | Значение |
|---|---|
| precision | bf16 |
| gradient_checkpointing | True |
| cache_latents | True |
| batch_size | 1 (DoRA) / 1-2 (LoRA) |
| optimizer | AdamW8bit (не Adam32bit — экономия ~2-3GB) |
| VRAM итог | ~14-18GB (LoRA) / ~16-20GB (DoRA) |

### Генерация (txt2img, SDXL 1024px)
| Настройка | Значение |
|---|---|
| precision | fp16 |
| attention | sdpa/xformers |
| batch_size | 4-6 без conditioning, 1-2 с ControlNet+IPAdapter+PuLID |
| VAE | fp16-fix VAE (избегает NaN на некоторых чекпоинтах) |

### Апскейл SUPIR
| Настройка | Значение |
|---|---|
| tile_size | 768-1024 (если апскейл сегментами) |
| precision | bf16 |
| VRAM итог | 18-22GB на 1024→2048, впритык — не гонять параллельно с другими процессами |

### Мердж чекпоинтов
- CPU/RAM-bound, не GPU — держать 32GB+ RAM, VRAM не критичен

---

## Диагностика OOM (частые причины на 3090)

1. **Параллельные процессы** — ComfyUI + отдельный тренировочный процесс одновременно = мгновенный OOM. Закрывать одно перед другим.
2. **Cache text encoder + caption dropout вместе** — не OOM, но тихая порча тренировки (кэш игнорирует dropout)
3. **Batch size без gradient checkpointing на DoRA** — DoRA прожорливее, `batch=2` без checkpointing легко вылетает даже на 24GB
4. **Утечка VRAM между генерациями в ComfyUI** — долгая сессия без перезапуска накапливает фрагментацию, помогает periodic `--reserve-vram` флаг или рестарт процесса раз в несколько часов при батч-генерации

---

## Мониторинг
- `nvidia-smi -l 1` — живой мониторинг в реальном времени во время тренировки/генерации
- Держать зазор **~1-2GB free** от максимума — драйвер/система резервируют часть, полное заполнение 24GB часто = мгновенный crash, а не graceful OOM

---

## Связанные заметки
- [[LoRA_Parameters]]
- [[DoRA_Parameters]]
- [[Generation_Parameters]]
- [[Upscalers]]
- [[ControlNet_IPAdapter_PuLID]]
- [[Checkpoint_Merging]]
