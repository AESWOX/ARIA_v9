---
created: 2026-07-22
updated: 2026-07-22
tags: [moc, troubleshooting, deployment, decisions, runpod]
---
# MOC — Ошибки и Решения

## Инциденты и разборы
- [[STACK/Hermes Error Troubleshooting]]
- [[STACK/B2 Debugging UV Zombies]]
- [[STACK/Killswitch-Cronjob]]
- [[DECISIONS/Known-Risks]]
- [[PROJECTS/Testing Matrix]]

## История деплоя
- [[STACK/RunPod GPU Deployment History]]
- [[STACK/Golden Deploy]]
- [[PROJECTS/AI-Influencer/09-Deploy-Procedure]]
