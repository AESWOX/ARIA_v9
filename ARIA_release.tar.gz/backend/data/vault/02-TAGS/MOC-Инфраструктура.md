---
created: 2026-07-22
updated: 2026-07-22
tags: [moc, infrastructure, stack, navigation]
---
# MOC — Инфраструктура

## Ядро
- [[STACK/Hermes Agent]]
- [[STACK/Командный Центр CC v3]]
- [[STACK/TG Gateway]]
- [[STACK/Telegram_Bot_HyperAgent]]

## Compute / Deploy
- [[STACK/RunPod-Playbook]]
- [[STACK/Golden Deploy]]
- [[STACK/Deploy Script]]
- [[STACK/SELF_HOSTING]]
- [[STACK/RAILWAY_DEPLOYMENT]]
- [[STACK/N8N_DEPLOYMENT]]

## Storage / Ops
- [[STACK/B2 Storage]]
- [[STACK/B2 Database Inventory]]
- [[STACK/Storage_B2_Structure]]
- [[STACK/B2 Debugging UV Zombies]]
- [[STACK/Killswitch-Cronjob]]
- [[STACK/Hermes Error Troubleshooting]]
