---
status: working
tags: [decisions]
---
## 2026-07-06 12:45 — Big Love окончательно удалён

**Решение:** Photo4, Photo5, Photo5_civitai, Photo6, insta1, lust1 — все версии Big Love удалены с B2 и пода.

**Оставлены на B2:**
- **Lustify_apexV8.safetensors** (6.5GB) — NSFW, основной
- **JibMix_v18_SkinSupreme** — диффузионка
- realistic_freedom_omega, yamers_realistic5, unnamed_ixl_realistic, zt3 — запасные

**Статус генераций:** IP-Adapter не завёлся (проблемы совместимости CLIP Vision + моделей). Нужен PuLID или правильный IP-Adapter стек.

---

## 2026-07-07 20:00 — Full deploy на B2 + терминация пода

**Решение:**
- Новая структура `deploy/` на B2 (62.85 GB) вместо старого `deploy_bundle/`
- `deploy/comfyui-models/` (62.78 GB) + `deploy/comfyui-runtime/` (65 MB) + `deploy/scripts/` (19 файлов)
- Под `03c1yq6mniki24` терминирован (HTTP 204)
- PuLID полностью отменён («пул айди — кал»)
- Obsidian docs AI-Influencer/01-08 полностью рефакторированы

**Статус:** готовы к редеплою по команде (~5 минут на разворот).

---

## 2026-07-13 — Phase A V5: 4 tar.zst архива на B2 + restore

**Решение:** Вместо pip install и rclone sync на каждом поде — единый бэкап в 4 архива с zstd -10. Восстановление за 86 секунд.

**Архивы на B2:**
- `comfyui-models.tar.zst` (34.2 GB) — все модели Phase A
- `comfyui-venv.tar.zst` (4.1 GB) — /usr/local/lib/python3.12/dist-packages/
- `comfyui-engine.tar.zst` (75 MB) — ComfyUI + custom_nodes
- `phaseA-full.tar.zst` (103 MB) — скрипты + cui.log + output

**Правила деплоя (строго):**
1. Терминейт под — НЕ ждать команды пользователя. Работа сделана → терминейт.
2. `fuser -k 8188/tcp` запрещён — убивает RunPod proxy. Только `kill $(pgrep -f "python3 main.py")`.
3. SSH таймауты при tar → lock-файлы.
4. zstd -19 медленный — всегда zstd -10.

**Баг:** Hairstyles в gen_phaseA_sdxl.py дают HTTP Error 400. Предположительно разный набор нод в workflow эмоций vs hairstyles. Не фикснуто.

---

## 2026-07-08 — Баг #1 (400 не вызывал rotation) + Runtime interception

**Контекст:** Весь день диагностики и фиксов бага #1 (Google Gemini 400 INVALID_ARGUMENT не распознавался как auth-ошибка, rotation не срабатывал).

### Закрыто

| Пункт | Статус | Доказательство |
|-------|--------|----------------|
| `_is_auth_error()` — matching HTTP 400 | ✅ | 3 уровня: (1) `details[].reason == "API_KEY_INVALID"`, (2) `error.message "api key"+"not valid"`, (3) `str(exc)` fallback. Live-тест на реальном 400 от Google API |
| Rotation chain — 400 triggers credential-pool rotation | ✅ | `FAILED before rotation (http_status=400)` → `marking GEMINI_API_KEY exhausted` → `retry after rotation` |
| False-positive test (image/payload errors) | ✅ | `INVALID_IMAGE_FORMAT` → False. `PAYLOAD_TOO_LARGE` → False |
| Non-vision aux regression | ✅ | `title_generation` с google/gemini-2.5-flash → `finish_reason='stop'`. 429 остался 429, не полез в auth-branch |
| Runtime interception write_file/patch | ✅ | Перехват в диспетчере тула (Python runtime, до исполнения). Bypass-proof |
| Runtime interception execute_code/terminal | ✅ | Текст-матчинг (`open("...")`, `>`). Не bypass-proof против обфускации — осознанно |
| One-shot .approved consumption | ✅ | `.approved` удаляется после первого использования |
| Client trace — 5 точек | ✅ | `call_llm.create`, `async_call_llm.create`, `FAILED before rotation`, `retry same_provider`, `retry after rotation`. Live на 400 и 429 |
| post_tool.py — .py-only dead-code | ✅ | Удалён. `grep "\.py" .hermes/hooks/post_tool.py` → только `_AUTOCOMMIT_EXTENSIONS` |
| pre_tool.py — human-in-the-loop | ✅ | Двухфазный approval: `.pending` → approve → `.approved` → PASS |
| post_tool.py — .env из auto-commit | ✅ | `grep \.env post_tool.py` → exit=1 |
| Дубли диагностики | ✅ | Не дубли — `_retry_cf` (sync) vs `_retry_cf_a` (async), 2 разные переменных |
| Regression detection в post_tool.py | ✅ | Сравнивает ВСЕ `.bak`, не только последний |

### Открыто (на будущие сессии)

| Пункт | Статус | Описание |
|-------|--------|----------|
| Coordination runtime ↔ hook | ⬜ | `pre_tool.py` создаёт новый `.pending` после того, как runtime потребил `.approved`. Цикл корректный, но хрупкий при параллельных вызовах |
| execute_code/terminal — bypass | ⬜ | Текст-матчинг, не bypass-proof. Обфускация (конкатенация пути, `os.rename`, `shutil.copy`, `subprocess.run(["cp",...])`) обходит защиту. Для полного закрытия нужен filesystem sandbox |
| 400 vs 429 client-type гипотеза | ⬜ | Опровергнута — оба используют `GeminiNativeClient`. Реальный корень был в `_is_auth_error()` |
| Dataview query-engine | ⬜ | Есть только templates, нет query-движка |
| Context Ladder | ⬜ | triggers, lazy rules, разделение system_prompt.py
