---
created: 2026-07-06
status: active
tags: [hermes, config, risk, infrastructure]
---

# Known Risks — известные риски конфигурации

> Задокументированы по результатам аудита 06.07.2026 (Часть D.1).

## Telegram gateway перезаписывает config.yaml без roundtrip

**Файл:** `plugins/platforms/telegram/adapter.py:2033`
**Что делает:** При создании новых DM topics Telegram gateway пишет в config.yaml через `_yaml.dump()` с `sort_keys=False`, а не через `atomic_roundtrip_yaml_update`.

**Риск:** Если gateway создаст новый DM topic — config.yaml перезапишется целиком. Кастомные комментарии, нестандартный порядок ключей и правки, внесённые вручную, будут потеряны.

**Статус:** ✅ Низкий — все DM topics уже созданы, новых не ожидается. Если потребуется новый topic — сделать это вручную через `hermes config set`, а не через gateway.

## In-memory guardrail-счётчики сбрасываются при рестарте

**Где:** `run_agent.py::_loop_guardrails_state` (dict в RAM)

**Риск:** После рестарта Hermes первые N ошибок не блокируются, пока счётчик не наберётся заново.

**Статус:** ✅ Принято — сброс при рестарте допустим, т.к. рестарты редки.

## Credential pool exhaustion state живёт только в RAM

**Где:** `agent/credential_pool.py`

**Риск:** После рестарта все ключи считаются свежими — rate-limited ключи сразу пойдут в работу.

**Статус:** ⚠️ Принято — rate limit сам восстановится через несколько вызовов.
