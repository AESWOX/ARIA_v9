---
tags: [comfy-kb, postprocessing]
status: reference
---

# Frequency Separation

## Текущий статус в PhaseA

> ⚠ **Не используется в текущем PhaseA pipeline.**

Frequency Separation — техника постобработки из BILLY-проекта, не внедрённая в PhaseA.

## Что это

Frequency Separation разделяет изображение на два частотных слоя:

- **Low frequency** (низкие частоты) — тон, цвет, освещение, ровные поверхности
- **High frequency** (высокие частоты) — текстура, поры, волосы, мелкие детали

Позволяет обрабатывать слои независимо (smooth на low, sharpen на high) без взаимного влияния.

## Для чего применяется в генерации изображений

| Операция | Low freq | High freq |
|---|---|---|
| Сглаживание кожи | ✅ Apply | ❌ Оставить |
| Повышение резкости | ❌ Оставить | ✅ Apply |
| Удаление артефактов | — | ✅ Selective blur |
| Цветокоррекция | ✅ Apply | ❌ Оставить |

## Почему не в PhaseA

PhaseA pipeline (gen_phaseA_sdxl.py) не содержит frequency-separation шага. Причины:

1. **FaceDetailer с inpaint** уже решает проблему лица без разделения частот
2. **Hires fix** (denoise=0.35) добавляет текстуру естественным образом
3. **Frequency separation** — ручная техника, плохо автоматизируется в ComfyUI пайплайне
4. Модели SDXL (через hires pass с karras scheduler) дают достаточно sharpness без постобработки

## Если бы внедрялся

Схема:
```
Output image → FreqSplit → Low → (smooth/blur) → FreqMerge → Final
                            High → (sharpen/unsharp mask)
```

В ComfyUI это реализуется через узлы `ImageBlur` → `ImageCompositeMasked` (subtract low from original = high), затем merge обратно.

## Связанные заметки

- [[face-restore]]
- [[upscale]]
- [[sampler-scheduler]]
