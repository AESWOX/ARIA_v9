---
tags: [comfy-kb, postprocessing, upscale]
status: reference
---

# Upscale

## PhaseA pipeline — upscale между base и hires KSampler

```
Base KSampler → LatentUpscale → Hires KSampler → VAE Decode
```

## Текущие значения (VERIFIED)

| Параметр | Значение |
|---|---|
| **Модель** | `4x-UltraSharp.pth` (63.9 MB, ✅ на B2) |
| **Метод** | `bicubic` (LatentUpscale) |
| **Target разрешение** | `[1248, 1824]` |
| **Множитель** | ×1.5 (от 832×1216) |
| **Слой** | между node 10 (base KSampler) и node 12 (hires KSampler) |

```yaml
# unified_config_brunette.yaml lines 14-17
hires:
  enabled: true
  target: [1248, 1824]
  method: bicubic
```

```python
# gen_phaseA_sdxl.py — node 11 (LatentUpscale), lines 94-96
"11": {"class_type": "LatentUpscale",
       "inputs": {"samples": ["10", 0],          # from base KSampler
                  "upscale_method": hires["method"],  # "bicubic"
                  "width": hw, "height": hh,     # 1248, 1824
                  "crop": "disabled"}},
```

## Почему bicubic в Latent Space?

- **LatentUpscale** работает в latent space (до VAE Decode) — апскейлит латентные карты, а не пиксели.
- **bicubic** выбран как простой, быстрый интерполяционный метод в latent space.
- Альтернативы: `nearest-exact` (быстрее, но пиксельнее), `lanczos` (чуть резче).
- Финальная резкость/детализация достигается через hires KSampler (denoise=0.35), а не через метод upscale.

## Разрешение

| Этап | Размер | Ширина | Высота |
|---|---|---|---|
| Base latent | 832×1216 | 832 | 1216 |
| После upscale | 1248×1824 | 1248 | 1824 |
| Множитель | ×1.5 | ×1.5 | ×1.5 |

## Модель: 4x-UltraSharp.pth

- Размер: 63.9 MB
- Статус: ✅ на B2 (загружена в ComfyUI/models/upscale_models/)
- Используется **после** основного pipeline (опционально), для финального пиксельного апскейла
- В текущем PhaseA pipeline не задействована — upscale делается в latent space через hires fix

## Связанные заметки

- [[denoise-strength]]
- [[sampler-scheduler]]
- [[frequency-separation]]
