---
tags: [comfy-kb, postprocessing]
status: reference
---

# Face Restore

## Текущий статус в PhaseA

> ⚠ **В PhaseA pipeline отсутствует отдельный face-restore шаг.**

FaceDetailer выполняет **inpaint-based рефайнмент** лица, а не классический face restore (GFPGAN/CodeFormer).

## FaceDetailer — что используется вместо face-restore

```yaml
# unified_config_brunette.yaml lines 57-68
detailer:
  face:
    enabled: true
    model: face_yolov8m.pt
    guide_size: 384
    max_size: 768
    feather: 20
    denoise: 0.30
    inpaint_model: true
    noise_mask: enabled
    noise_mask_feather: 10
    dilate: 10
    cycle: 1
```

```python
# gen_phaseA_sdxl.py — nodes 70-71 (FaceDetailer), lines 150-178
# FaceDetailer применяется ко всем генерациям
"inpaint_model": face_det.get("inpaint_model", True)  # inpaint-based рефайн
"denoise": face_det.get("denoise", 0.30)              # 0.30
"guide_size": 384
"max_size": 768
```

FaceDetailer в PhaseA:
- **inpaint_model=true** — использует inpainting для рефайна лица (перерисовывает область лица с учётом контекста)
- **denoise=0.30** — умеренная коррекция, не меняет черты
- **bbox_detector=face_yolov8m.pt** — детекция лиц YOLOv8
- Выполняется **после** VAE Decode (node 13), до SaveImage (node 14)

## Если face-restore нужен (гипотетически)

В классическом ComfyUI пайплайне face-restore ставится после SaveImage:

```
VAE Decode → FaceDetailer → (SaveImage)
                   ↓
            GFPGAN/CodeFormer → SaveImage
```

| Метод | Когда использовать |
|---|---|
| **GFPGAN** | Сильная коррекция, убирает артефакты генерации |
| **CodeFormer** | Более щадящая, сохраняет текстуру |
| **FaceDetailer** (inpaint) | Лучше для identity preservation (используется в PhaseA) |

## Почему FaceDetailer вместо GFPGAN/CodeFormer?

В PhaseA FaceDetailer выбран осознанно:
- GFPGAN/CodeFormer могут сглаживать/омолаживать лицо, теряя identity
- FaceDetailer с inpaint_model=true перерисовывает лицо с тем же промптом и IP-Adapter — identity сохраняется
- Но FaceDetailer ≠ face-restore. Это inpaint-based рефайн, а не пост-обработка

## Связанные заметки

- [[ipadapter-weight]]
- [[cfg-guidance]]
- [[denoise-strength]]
