---
tags: [comfy-kb, quality-and-consistency]
status: reference
---

# Face Similarity Playbook

> Статус: ЧЕРНОВИК — большинство полей [ГИПОТЕЗА] из-за отсутствия запусков после фикса багов

## Текущий лучший результат

**Нет ни одного подтверждённого замера face similarity после фикса багов 2026-07-10.**

- Последний прогон: 2026-07-09 — FAILED (0 изображений, ONNXDetector крашился)
- После фикса (ONNXDetector -> UltralyticsDetectorProvider + model chain fix): ни одного запуска
- До фикса: ~15% similarity (из комментария в коде, строка 150 gen_phaseA_sdxl.py)

## Что доказанно повышает консистентность (с цифрами)

| Изменение | Было | Стало | % до | % после | Дата | Подтверждение |
|--------|--------|--------|-------|---------|------|--------------|
| FaceDetailer получает модель ПОСЛЕ IP-Adapter (node 5), не ДО | model_in (LoRA stack) | ["5", 0] (post-IPAdapter) | ~15% | ? | 10.07 | gen_phaseA_sdxl.py:151 |
| ONNXDetector -> UltralyticsDetectorProvider | .onnx (Caffe) | .pt (Ultralytics) | CRASH | ? | 10.07 | gen_phaseA_sdxl.py:156 |

**Оба фикса не тестированы на поде.**

## Что доказанно ломает консистентность (антипаттерны)

| Действие | Механизм поломки | Источник |
|----------|-----------------|---------|
| FaceDetailer без IP-Adapter сигнала | Detailer ресемплит лицо без identity-референса | gen_phaseA_sdxl.py коммент:149 |
| .onnx модель в ONNXDetectorProvider | Caffe vs RGB препроцессор — разный цветовой порядок | audit-b2: блокер 1 |
| InstantID на orbits > 45° | Identity weight multiplier падает до 0.4 на профиле | facelora_config.yaml orbit_angle_multipliers |
| ApplyInstantIDAdvanced с noise=0.0 на non-front позах | Сильная привязка к фронтальной структуре | [ГИПОТЕЗА — не проверено] |

## Открытые гипотезы (не проверено)

| Гипотеза | Ожидание | Риск |
|----------|---------|------|
| Повысить IP-Adapter weight до 0.85-0.9 для orbits > 45° | Больше identity на профилях | Может перетянуть фронтальное лицо на профиль |
| FaceID v2 + InstantID вместе (как в faceid_v2_test.py) | Выше consistency | Вдвое больше VRAM |
| Уменьшить FaceDetailer denoise с 0.30 до 0.20 | Меньше изменения черт при рефайне | Меньше коррекции дефектов |
| ControlNet-Union вместо OpenPose для PhaseB | Обход блокера openpose | Неизвестное качество поз |
| CFD 4.0 вместо 6.0 для FaceID прогона | Меньше "перерисовывания" | Меньше следования промпту |

## Текущий блокер

**Нет ни одного успешного прогона после фикса.** Первый шаг:
1. Загрузить OpenPose на B2 (или переключиться на union-sdxl)
2. Создать venv на B2
3. preflight -> GO -> 5 тестовых генераций
4. Замерить face similarity через quality_scorer.py
5. Заполнить эту таблицу реальными цифрами
