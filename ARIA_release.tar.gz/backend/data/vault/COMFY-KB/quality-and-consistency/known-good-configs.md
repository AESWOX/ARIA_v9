---
tags: [comfy-kb, quality-and-consistency]
status: reference
---

# Known Good Configs

> Статус: ЧЕРНОВИК

**Нет ни одной подтверждённой конфигурации с приемлемым face similarity.**

Последний прогон (2026-07-09) завершился с 0 изображений — ONNXDetector крашился.

После фиксов (10.07) конфигурации не тестировались.

---

## Ближайшая цель: первая подтверждённая конфигурация

Как только будет выполнен preflight -> test generation:

```yaml
# Конфигурация для первого тестового прогона
# Дата: TBD
checkpoint: bigLust_v16.safetensors
vae: sdxl_vae.safetensors
ip_adapter: ip-adapter-plus-face_sdxl_vit-h.safetensors
ip_adapter_weight: 0.7
ip_adapter_weight_type: linear
ip_adapter_embeds_scaling: K+V
ip_adapter_start: 0.0
ip_adapter_end: 0.8
face_detector: face_yolov8m.pt
hand_detector: hand_yolov8n.pt
face_detailer_denoise: 0.30
face_detailer_guide_size: 384
face_detailer_max_size: 768
lora_realskin: 0.6
lora_detailedeyes: 0.5
lora_handssl: 0.45
cfg: 6.0
sampler: dpmpp_2m_sde
scheduler: karras
steps_base: 30
steps_hires: 22
hires_denoise: 0.35
hires_upscale: 1.5
controlnet_strength: 0.25 (PhaseB)
```

**Место для результатов:** этот блок будет заполнен после первого успешного прогона.

---

## Альтернативные конфиги для тестирования

После получения первой конфигурации, следующие гипотезы для сравнения:

1. **FaceID v2 вместо IP-Adapter Plus Face** — используя faceid_v2_test.py логику
2. **CFG 4.0 + IP-Adapter 0.8** — слабее контроль промпта, сильнее identity
3. **UltralyticsSmall вместо yolov8m** — быстрее, возможно хуже качество
4. **FaceDetailer denoise 0.20** — меньше изменения черт
5. **ControlNet-Union вместо OpenPose** — workaround для блокера openpose
