---
tags: [comfy-kb, comfyui, node, instantid]
status: reference
---

# ApplyInstantIDAdvanced

## Что делает (по факту кода/документации)

Продвинутая версия ApplyInstantID. Используется в нашем FaceID стеке (faceid_v2_test.py). В отличие от базовой ApplyInstantID, **требует ControlNet на входе** и дополнительный image-вход для ControlNet. Управляется через ip_weight, cn_strength, noise, combine_embeds.

**Главная особенность:** Advanced версия накладывает InstantID-адаптацию поверх IP-Adapter FaceID через отдельный ControlNet-канал. Это даёт контроль над тем, насколько сильно ControlNet-рамка (поза/структура) влияет на результат отдельно от влияния эмбеддингов лица.

## Входы

| Вход | Тип | Что подавать | Что будет если не то |
|------|-----|-------------|---------------------|
| `model` | MODEL | Модель после IPAdapterFaceID (нода 6 в faceid_v2_test.py: IPAdapterFaceID → MODEL + INSIGHTFACE) | Без этого не будет FaceID поверх InstantID |
| `instantid` | INSTANTID | Выход InstantIDModelLoader (ip-adapter.bin) | Ошибка типов |
| `insightface` | INSIGHTFACE | Выход InstantIDFaceAnalysis (antelopev2, CPU) | Нет эмбеддингов — нет адаптации |
| `control_net` | CONTROL_NET | ControlNetLoader → instantid_controlnet.safetensors | Ошибка: нода падает без control_net |
| `image` | IMAGE | То же референсное изображение (ref_face_1024.png / blonde_ref.png) | Используется и для ControlNet, и для эмбеддингов |
| `positive` | CONDITIONING | CLIPTextEncode положительного промпта | Мусор на выходе |
| `negative` | CONDITIONING | CLIPTextEncode отрицательного промпта | Мусор на выходе |

## Параметры

| Параметр | Диапазон | Дефолт | Эффект при увеличении | Эффект при уменьшении | Наблюдалось в наших тестах |
|----------|----------|--------|----------------------|----------------------|--------------------------|
| `ip_weight` | 0.0–2.0 | 1.0 | Сильнее идентичность, но может перебить промпт | Слабее идентичность, больше свободы | `ip_weight: 1.0` (faceid_v2_test.py) — полная сила InstantID |
| `cn_strength` | 0.0–1.0 | 0.7 | Жёстче рамка позы/структуры от ControlNet | Мягче рамка | `cn_strength: 0.7` (faceid_v2_test). В orbit-блоке facelora_config: 0.0 для emotions, 0.3 для bust |
| `start_at` | 0.0–1.0 | 0.0 | Позже начинает | Раньше начинает | `start_at: 0.0` — всегда с первого шага |
| `end_at` | 0.0–1.0 | 1.0 | Применяется до конца шагов | Раньше отключается | `end_at: 0.9` (faceid_v2_test). В facelora_config: 0.75 emotions, 0.7 bust |
| `noise` | 0.0–1.0 | 0.0 | Шум в адаптации (может помочь при оверфите) | Чистая адаптация | `noise: 0.0` (faceid_v2_test) |
| `combine_embeds` | average/concat | average | — | — | `combine_embeds: "average"` (faceid_v2_test). В IPAdapterFaceID используется "concat" |

## Зависимости от других нод

**Обязательный стек (faceid_v2_test.py line 40-70):**
1. `InstantIDModelLoader` → instantid_model = `ip-adapter.bin` (1.57 GB, в ComfyUI/models/instantid/)
2. `InstantIDFaceAnalysis` → provider = `CPU`, model = `antelopev2`
3. `ControlNetLoader` → control_net = `instantid_controlnet.safetensors` (2.33 GB, в ComfyUI/models/controlnet/)

**Опциональный стек поверх (faceid_v2_test.py line 27-33):**
1. `IPAdapterUnifiedLoaderFaceID` → preset = `FACEID PLUS V2`, lora_strength = `0.6`, provider = `CPU`
2. `IPAdapterInsightFaceLoader` → model_name = `antelopev2`, provider = `CPU`
3. `IPAdapterFaceID` → weight = `0.6`, weight_faceidv2 = `1.0`, weight_type = `linear`, combine_embeds = `concat`, start_at = `0.0`, end_at = `1.0`, embeds_scaling = `V only`

## Известные баги / ловушки в нашем пайплайне

1. **ApplyInstantIDAdvanced ≠ ApplyInstantID:** Попытка подключить control_net к базовой ноде упадёт. В faceid_v2_test.py строго зашита Advanced версия.
2. **Вес ControlNet (cn_strength) и угол съёмки:** В facelora_config.yaml identity_weights.orbit_angle_multipliers показывают, что на профильных ракурсах (90°+) InstantID/cn_strength должен падать до 0.25–0.08 — иначе "натягивает фронтальное лицо на боковой ракурс".
3. **ip-adapter.bin 1.57 GB:** Эта модель InstantID-specific, не путать со штатными IP-Adapter моделями.
4. **CPU для InsightFace:** В faceid_v2_test.py и facelora_config.yaml — provider: CPU. На GPU потребляет ~1.5 GB VRAM дополнительно, но быстрее.
5. **combine_embeds: average** — в InstantID стеке усреднение эмбеддингов. В IPAdapterFaceID (тот же файл) используется **concat**. Разное поведение склейки.

## Источник

- `faceid_v2_test.py` — строки 40-70: полная конфигурация ApplyInstantIDAdvanced
- `facelora_config.yaml` — identity_weights: instantid_weight = 0.55 (orbit/emotions), 0.5 (bust); instantid_cn_strength = 0.0/0.3; орбитальные мультипликаторы (0.0–1.0)
