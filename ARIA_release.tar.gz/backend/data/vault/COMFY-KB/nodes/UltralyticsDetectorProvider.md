---
tags: [comfy-kb, comfyui, node, detector]
status: reference
---

# UltralyticsDetectorProvider

## Что делает (по факту кода/документации)

Провайдер детектора для нод FaceDetailer. Загружает модель YOLOv8 из Ultralytics и подаёт bbox_detector на вход FaceDetailer/HandsDetailer.

**Замена ONNXDetectorProvider:** В июле 2026 года — переход с ONNXDetectorProvider (.onnx) на UltralyticsDetectorProvider (.pt). Исправило баг несовместимости форматов.

## Входы

| Вход | Тип | Что подавать | Что будет если не то |
|------|-----|-------------|---------------------|
| *(нет входов, только параметр)* | — | — | — |

## Параметры

| Параметр | Диапазон | Дефолт | Эффект при увеличении | Эффект при уменьшении | Наблюдалось в наших тестах |
|----------|----------|--------|----------------------|----------------------|--------------------------|
| `model_name` | список моделей | — | Выбирает модель детекции | — | **Face:** `face_yolov8m.pt`. **Hands:** `hand_yolov8n.pt` |

## Использование в PhaseA (два экземпляра)

| Экземпляр | ID ноды | model_name | Цель |
|-----------|---------|-----------|------|
| Face | 70 | `face_yolov8m.pt` | Детекция лица → FaceDetailer |
| Hands | 72 | `hand_yolov8n.pt` | Детекция рук → HandsDetailer |

face_yolov8m.pt (medium) точнее; hand_yolov8n.pt (nano) быстрее. Рук может быть 0-4 на кадр, лицо обычно одно.

## Зависимости от других нод

- **Ultralytics** (Python библиотека) — должна быть установлена в окружении ComfyUI
- **FaceDetailer** — bbox_detector вход
- **HandsDetailer** — bbox_detector вход

## Известные баги / ловушки в нашем пайплайне

1. **ONNX → Ultralytics миграция (2026-07-10):** Старый код использовал ONNXDetectorProvider + onnx модели. После обновления ComfyUI ONNX сломался. Фикс: UltralyticsDetectorProvider + .pt.
2. **Модели кэшируются Ultralytics:** После первой загрузки хранятся в ~/.ultralytics/. На RunPod первый запуск дольше.
3. **CUDA vs CPU:** Ultralytics автоматически использует CUDA если доступно. На 3090 — CUDA.
4. **bbox_detector выход:** Подаётся строго в FaceDetailer. Нельзя подать куда-то ещё.

## Источник

- `gen_phaseA_sdxl.py` — строки 117 (нода 70), строка 141 (нода 72)
- `unified_config_brunette.yaml` — detailer.face.model, detailer.hands.model
- `ultralytics_provider.py` — реализация провайдера
