---
tags: [comfy-kb, comfyui, node, sampler]
status: reference
---

# KSampler

## Что делает (по факту кода/документации)

Основной сэмплер диффузии. В PhaseA используется **два экземпляра** — base (step 1) и hires (step 2). Алгоритм `dpmpp_2m_sde` с scheduler `karras`.

**Двухступенчатый пайплайн:**
1. **Base KSampler** — генерация из шума (832×1216, denoise=1.0)
2. **LatentUpscale** (bicubic → 1248×1824)
3. **Hires KSampler** — рефайн (denoise=0.35)

## Входы

| Вход | Тип | Что подавать | Что будет если не то |
|------|-----|-------------|---------------------|
| `model` | MODEL | Модель после IPAdapterAdvanced (через LoRA) | Искажение стиля |
| `positive` | CONDITIONING | CLIPTextEncode (через ControlNetApplyAdvanced если use_controlnet) | Мусор на выходе |
| `negative` | CONDITIONING | CLIPTextEncode (через ControlNetApplyAdvanced если use_controlnet) | Мусор на выходе |
| `latent_image` | LATENT | EmptyLatentImage (base) или LatentUpscale (hires) | Ошибка размерности |

## Параметры

| Параметр | Диапазон | Дефолт | Эффект при увеличении | Эффект при уменьшении | Наблюдалось в наших тестах |
|----------|----------|--------|----------------------|----------------------|--------------------------|
| `seed` | int | — | — | — | Одинаковый для обоих KSampler |
| `steps` | 1–150 | 20 | Дольше, потенциально лучше детали | Быстрее, недо-сэмплировано | **Base:** 30. **Hires:** 22. FaceID: 30 |
| `cfg` | 1.0–30.0 | 7.0 | Точнее следует промпту (пережог) | Свободнее | `cfg: 6.0` (PhaseA). FaceID: `cfg: 4.0` |
| `sampler_name` | список | euler | — | — | `sampler_name: "dpmpp_2m_sde"` |
| `scheduler` | список | normal | — | — | `scheduler: "karras"` |
| `denoise` | 0.0–1.0 | 1.0 | Меньше изменений | Сильнее изменения | **Base:** 1.0. **Hires:** 0.35 |

## Таблица Base vs Hires

| Характеристика | Base (step 1) | Hires (step 2) |
|---------------|---------------|----------------|
| ID ноды | 10 | 12 |
| Вход latent | EmptyLatentImage (832×1216) | LatentUpscale (1248×1824) |
| steps | 30 | 22 |
| denoise | 1.0 | 0.35 |
| seed | SEED | SEED (тот же) |
| model | IPAdapterAdvanced → model | IPAdapterAdvanced → model |
| Выход → | LatentUpscale → hires KSampler | VAEDecode → FaceDetailer |

## Зависимости от других нод

- **IPAdapterAdvanced** — model
- **ControlNetApplyAdvanced** — positive/negative (если use_controlnet)
- **EmptyLatentImage** — base latent (832×1216)
- **LatentUpscale** — bicubic, 1248×1824
- **CLIPTextEncode (×2)** — промпты
- **VAEDecode** — на выходе hires

## Известные баги / ловушки в нашем пайплайне

1. **CFG разный:** PhaseA 6.0, FaceID 4.0. В InstantID стеке низкий CFG для свободы идентичности.
2. **Base denoise=1.0 всегда:** Hires denoise=0.35 — стандартный hires fix.
3. **seed одинаковый для обоих:** Важно для воспроизводимости.
4. **dpmpp_2m_sde + karras:** sde версия добавляет стохастичность. Не путать с dpmpp_2m.
5. **Steps 30+22=52:** На 3090 (~4 it/s на 832×1216): ~35s на изображение до детайлеров.

## Источник

- `gen_phaseA_sdxl.py` — строки 66-82: нода 10 + нода 12
- `unified_config_brunette.yaml` — generation: steps=30, cfg=6.0, sampler=dpmpp_2m_sde, scheduler=karras. hires: steps=22, denoise=0.35
- `faceid_v2_test.py` — KSampler steps=30, cfg=4.0, sampler_name=dpmpp_2m_sde, scheduler=karras, denoise=1.0
- `facelora_config.yaml` — generation: base_steps=30, base_cfg=6.0, hires_steps=20, hires_denoise=0.35
