---
tags: [comfy-kb, comfyui, node, postprocessing]
status: reference
---

# FaceDetailer

## Что делает (по факту кода/документации)

Детектирует и рефайнит (улучшает/перерисовывает) лицо на изображении. В PhaseA используется **всегда** — основной инструмент для улучшения качества лица после генерации.

Работает в паре с `UltralyticsDetectorProvider`, который подаёт bbox_detector. Использует модель `face_yolov8m.pt` для детекции лица, затем делает инпейнтинг лица с повышенным качеством.

**В конвейере PhaseA (gen_phaseA_sdxl.py):**
VAE Decode → **[FaceDetailer]** → [HandsDetailer, опционально] → SaveImage

## Входы

| Вход | Тип | Что подавать | Что будет если не то |
|------|-----|-------------|---------------------|
| `image` | IMAGE | Изображение с VAE Decode | Без изображения нечего улучшать |
| `model` | MODEL | Модель после LoRA цепочки | Без модели — инпейнтинг не сработает |
| `clip` | CLIP | CLIP после LoRA цепочки | Без CLIP — промпт не применится |
| `vae` | VAE | VAE (sdxl_vae.safetensors) | Ошибка декодирования |
| `positive` | CONDITIONING | Положительный CLIPTextEncode | Плохое качество инпейнтинга |
| `negative` | CONDITIONING | Отрицательный CLIPTextEncode | Плохое качество инпейнтинга |
| `detailer_hook` | DETAILER_HOOK | None | — |
| `bbox_detector` | BBOX_DETECTOR | UltralyticsDetectorProvider → face_yolov8m.pt | Не сработает детекция лица |
| `sam_model_opt` | SAM_MODEL | None | — |
| `segm_detector_opt` | SEGM_DETECTOR | None | — |

## Параметры

| Параметр | Диапазон | Дефолт | Эффект при увеличении | Эффект при уменьшении | Наблюдалось в наших тестах |
|----------|----------|--------|----------------------|----------------------|--------------------------|
| `guide_size` | 64–2048 | 384 | Детальнее референс для инпейнтинга | Меньше точность | `guide_size: 384` (unified_config_brunette.yaml face) |
| `max_size` | 64–4096 | 768 | Выше макс разрешение | Ниже качество при больших лицах | `max_size: 768` |
| `feather` | 0–100 | 20 | Мягче переход между инпейнт-областью и оригиналом | Чётче граница | `feather: 20` |
| `denoise` | 0.0–1.0 | 0.35 | Сильнее перерисовка лица (может убить идентичность) | Слабее изменения | `denoise: 0.30` — консервативный режим |
| `noise_mask` | enabled/disabled | enabled | — | — | `noise_mask: "enabled"` |
| `feather_mask` | disabled/enabled | disabled | — | — | `feather_mask: "disabled"` |
| `inpaint_model` | true/false | true | Использует модель инпейнтинга | Обычная диффузия | `inpaint_model: true` |
| `noise_mask_feather` | 0–100 | 20 | Мягче шумовая маска | Жёстче | `noise_mask_feather: 10` |
| `force_inpaint` | true/false | false | Всегда инпейнтинг | Только при детекции | `force_inpaint: true` |
| `cycle` | 1–10 | 1 | Несколько проходов рефайна | Один проход | `cycle: 1` |
| `wildcard` | string | "" | Не используется | — | `wildcard: ""` |
| `dilate` | 0–50 | 10 | Шире область инпейнтинга вокруг лица | Уже область | `dilate: 10` |
| `inpaint_mask` | true/false | true | Использовать маску | Не использовать | `inpaint_mask: true` |

## Зависимости от других нод

- **UltralyticsDetectorProvider** — обязательный источник bbox_detector (модель `face_yolov8m.pt`)
- **VAELoader** — sdxl_vae.safetensors
- **CheckpointLoaderSimple → LoRA цепочка** — model и clip

## Известные баги / ловушки в нашем пайплайне

1. **FaceDetailer для рук:** В PhaseA HandsDetailer использует ту же ноду FaceDetailer, но с hand_yolov8n.pt. См. [[HandsDetailer]].
2. **denoise=0.30 vs дефолт 0.35:** В unified_config_brunette.yaml face.denoise=0.30 — сознательно консервативный режим.
3. **force_inpaint=true:** Всегда делает инпейнтинг, даже если детектор не нашёл лицо.
4. **inpaint_model=true:** Требует наличие inpaint модели в ComfyUI.
5. **Ultralytics vs ONNX:** В июле 2026 был баг с ONNX — перешли на Ultralytics. См. [[UltralyticsDetectorProvider]].

## Источник

- `gen_phaseA_sdxl.py` — строки 117-138: нода 70 + нода 71
- `unified_config_brunette.yaml` — detailer.face: model=face_yolov8m.pt, guide_size=384, max_size=768, feather=20, denoise=0.30, inpaint_model=true
