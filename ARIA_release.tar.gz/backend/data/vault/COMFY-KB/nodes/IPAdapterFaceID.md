---
tags: [comfy-kb, comfyui, node, ipadapter]
status: reference
---

# IPAdapterFaceID (IPAdapterUnifiedLoaderFaceID + IPAdapterInsightFaceLoader + IPAdapterFaceID)

## Что делает (по факту кода/документации)

Составной стек из трёх нод для FaceID Plus v2 адаптации лица. Используется в **faceid_v2_test.py** (Full FaceID + InstantID пайплайн). В **PhaseA** (gen_phaseA_sdxl.py) используется альтернативный путь: `IPAdapterUnifiedLoader + IPAdapterAdvanced` (без FaceID, чисто IP-Adapter PLUS FACE).

**Архитектура стека:**
1. `IPAdapterUnifiedLoaderFaceID` — загружает IP-Adapter модель + LoRA для FaceID (preset: FACEID PLUS V2)
2. `IPAdapterInsightFaceLoader` — загружает InsightFace antelopev2 для извлечения эмбеддингов лица
3. `IPAdapterFaceID` — применяет FaceID адаптацию к модели через эмбеддинги лица

## Входы (IPAdapterUnifiedLoaderFaceID)

| Вход | Тип | Что подавать | Что будет если не то |
|------|-----|-------------|---------------------|
| `model` | MODEL | Выход CheckpointLoaderSimple (через LoRa цепочку) | Ошибка типов |

## Входы (IPAdapterInsightFaceLoader)

| Вход | Тип | Что подавать | Что будет если не то |
|------|-----|-------------|---------------------|
| *(нет входов, только параметры)* | — | — | — |

## Входы (IPAdapterFaceID)

| Вход | Тип | Что подавать | Что будет если не то |
|------|-----|-------------|---------------------|
| `model` | MODEL | Выход IPAdapterUnifiedLoaderFaceID (выход 0) | Без него не применится адаптация |
| `ipadapter` | IPADAPTER | Выход IPAdapterUnifiedLoaderFaceID (выход 1) | Не загрузится IP-Adapter |
| `image` | IMAGE | Референсное изображение лица (ref_face_1024.png) | Если не лицо — мусорные эмбеддинги |
| `insightface` (optional) | INSIGHTFACE | Выход IPAdapterInsightFaceLoader | Без InsightFace — нет извлечения эмбеддингов лица |

## Параметры (IPAdapterUnifiedLoaderFaceID)

| Параметр | Значение в наших тестах | Примечание |
|----------|------------------------|------------|
| `preset` | `FACEID PLUS V2` (faceid_v2_test.py) | В PhaseA используется `PLUS FACE` (через другой loader) |
| `lora_strength` | `0.6` | Сила встроенной LoRA |
| `provider` | `CPU` | CPU стабильнее по VRAM на 3090 |

## Параметры (IPAdapterInsightFaceLoader)

| Параметр | Значение в наших тестах | Примечание |
|----------|------------------------|------------|
| `model_name` | `antelopev2` | Стандартная модель InsightFace |
| `provider` | `CPU` | CPU provider |

## Параметры (IPAdapterFaceID)

| Параметр | Диапазон | Дефолт | Эффект при увеличении | Эффект при уменьшении | Наблюдалось в наших тестах |
|----------|----------|--------|----------------------|----------------------|--------------------------|
| `weight` | 0.0–2.0 | 1.0 | Сильнее идентичность лица | Слабее идентичность | `weight: 0.6` (faceid_v2_test). В facelora_config: 0.55 orbit/emotions, 0.5 bust |
| `weight_faceidv2` | 0.0–2.0 | 1.0 | Сильнее FaceID v2 адаптация | Слабее | `weight_faceidv2: 1.0` (faceid_v2_test) |
| `weight_type` | linear/ease in-out/... | linear | — | — | `weight_type: "linear"` |
| `combine_embeds` | concat/average | concat | — | — | `combine_embeds: "concat"` (faceid_v2_test — FaceID), в InstantID стеке — `average` |
| `start_at` | 0.0–1.0 | 0.0 | Позже начинает | Раньше | `start_at: 0.0` (faceid_v2_test). В facelora_config: 0.0 emotions, 0.0 bust |
| `end_at` | 0.0–1.0 | 1.0 | Дольше применяется | Раньше отключается | `end_at: 1.0` (faceid_v2_test). В facelora_config: 0.75 emotions, 0.7 bust |
| `embeds_scaling` | V only/K+V/K only/wio | V only | — | — | `embeds_scaling: "V only"` (faceid_v2_test — FaceID). В PhaseA IPAdapterAdvanced — `K+V` |

### PhaseA path (отдельно): IPAdapterUnifiedLoader + IPAdapterAdvanced

В PhaseA (gen_phaseA_sdxl.py) используется **другой loader** и **другая нода применения:**

| Нода | Параметр | Значение |
|------|----------|----------|
| `IPAdapterUnifiedLoader` | `preset` | `PLUS FACE` |
| `IPAdapterAdvanced` | `weight` | `0.7` (из unified_config_brunette.yaml identity.ip_adapter.weight) |
| | `weight_type` | `linear` |
| | `combine_embeds` | `concat` |
| | `start_at` | `0.0` |
| | `end_at` | `0.8` |
| | `embeds_scaling` | `K+V` (отличается от FaceID — там V only!) |

> ⚠️ weight в PhaseA 0.7 vs FaceID стек 0.6. embeds_scaling K+V (PhaseA) vs V only (FaceID). Это разные режимы!

## Зависимости от других нод

**FaceID стек (faceid_v2_test.py):**
- CheckpointLoaderSimple → CLIPSetLastLayer(-2) → IPAdapterUnifiedLoaderFaceID → IPAdapterFaceID → ApplyInstantIDAdvanced → KSampler
- IPAdapterInsightFaceLoader → (optional) IPAdapterFaceID.insightface

**PhaseA стек (gen_phaseA_sdxl.py):**
- CheckpointLoaderSimple → LoRA цепочка (RealSkin, DetailedEyes, HandsXL) → IPAdapterUnifiedLoader → IPAdapterAdvanced → FaceDetailer → SaveImage

## Известные баги / ловушки в нашем пайплайне

1. **FaceID PLUS V2 ≠ PLUS FACE:** preset разный — первый загружает ip-adapter-faceid-plusv2_sdxl.safetensors (FaceID), второй — ip-adapter-plus-face_sdxl_vit-h.safetensors (просто IP-Adapter Plus Face). См. facelora_config.yaml model.ipadapter_faceid.
2. **CPU provider жрёт CPU но бережёт VRAM:** InsightFace на CPU — сознательное решение для 3090 (24 GB VRAM).
3. **embeds_scaling разный:** V only в FaceID стеке, K+V в PhaseA. Смешивать нельзя.
4. **lora_strength 0.6** в IPAdapterUnifiedLoaderFaceID — встроенная LoRA, не путать с отдельными LoRA (RealSkin и др.), которые грузятся через LoraLoader.
5. **insightface — optional вход** в IPAdapterFaceID, но если не подать — эмбеддинги не извлекутся.

## Источник

- `faceid_v2_test.py` — строки 27-33: полный стек IPAdapterUnifiedLoaderFaceID + IPAdapterInsightFaceLoader + IPAdapterFaceID
- `gen_phaseA_sdxl.py` — строки 52-57: IPAdapterUnifiedLoader + IPAdapterAdvanced (PhaseA path)
- `unified_config_brunette.yaml` — identity.ip_adapter: model=ip-adapter-plus-face_sdxl_vit-h.safetensors, preset=PLUS FACE, weight=0.7, embeds_scaling=K+V
- `facelora_config.yaml` — identity_weights: faceid_weight=0.55/0.5, faceid_start_at=0.0, faceid_end_at=0.75/0.7
