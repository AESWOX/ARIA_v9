---
tags: [comfy-kb, comfyui, node, controlnet]
status: reference
---

# ControlNetApplyAdvanced

## Что делает (по факту кода/документации)

Применяет ControlNet conditioning к положительному и отрицательному промпту. В PhaseA используется **для body shots** (bust, styles) — когда видно тело. Слабая OpenPose ControlNet (strength=0.25) удерживает позу, не перебивая идентичность.

**Конвейер PhaseA (для body shots):**
ControlNetLoader (controlnet-openpose-sdxl-1.0) → DWPreprocessor → **[ControlNetApplyAdvanced]** → KSampler

## Входы

| Вход | Тип | Что подавать | Что будет если не то |
|------|-----|-------------|---------------------|
| `positive` | CONDITIONING | Исходный положительный CLIPTextEncode | Искажение conditioning |
| `negative` | CONDITIONING | Исходный отрицательный CLIPTextEncode | Искажение conditioning |
| `control_net` | CONTROL_NET | ControlNetLoader → controlnet-openpose-sdxl-1.0 | Не применится ControlNet |
| `image` | IMAGE | DWPreprocessor (поза из референсного изображения) | Контроль по не-позе даст мусор |

## Параметры

| Параметр | Диапазон | Дефолт | Эффект при увеличении | Эффект при уменьшении | Наблюдалось в наших тестах |
|----------|----------|--------|----------------------|----------------------|--------------------------|
| `strength` | 0.0–2.0 | 1.0 | Жёстче рамка позы | Мягче, модель может игнорировать | `strength: 0.25` (слабая — чтобы не перебить идентичность) |
| `start_percent` | 0.0–1.0 | 0.0 | Позже начинает | Сразу с первого шага | `start_percent: 0.0` |
| `end_percent` | 0.0–1.0 | 1.0 | Дольше удерживает позу | Раньше отпускает | `end_percent: 0.6` (свобода деталям на поздних шагах) |

## Зависимости от других нод

- **ControlNetLoader** — загружает `controlnet-openpose-sdxl-1.0`
- **DWPreprocessor** — извлекает позу из референса (resolution=512, bbox_detector=yolox_l.torchscript.pt)
- **IPAdapterAdvanced** — model подаётся напрямую в KSampler

**Важно:** ControlNetApplyAdvanced НЕ меняет model — только positive/negative conditioning.

## Известные баги / ловушки в нашем пайплайне

1. **strength=0.25 — очень слабая ControlNet:** OpenPose + слабый вес = поза-хинт. 0.7+ искажает идентичность.
2. **end_percent=0.6:** ControlNet отключается на 60% шагов — свобода для деталей лица/текстуры.
3. **Только для body shots (use_controlnet=true):** Для emotions/orbitals — выключена.
4. **DWPreprocessor vs OpenPosePreprocessor:** PhaseA использует DWPreprocessor (DWPose) — точнее.
5. **controlnet-openpose-sdxl-1.0 ≠ instantid_controlnet:** Разные модели. InstantID — 2.33 GB, OpenPose — ~1.5 GB.

## Источник

- `gen_phaseA_sdxl.py` — строки 172-197: ноды 90, 91, 92
- `unified_config_brunette.yaml` — controlnet.pose: model=controlnet-openpose-sdxl-1.0, strength=0.25, start_at=0.0, end_at=0.6
