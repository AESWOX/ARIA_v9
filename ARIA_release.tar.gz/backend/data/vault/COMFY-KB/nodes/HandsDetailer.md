---
tags: [comfy-kb, comfyui, node, postprocessing]
status: reference
---

# HandsDetailer

## Что делает (по факту кода/документации)

Дополнительный проход FaceDetailer для улучшения качества рук. В PhaseA включается **только когда use_hands=true** (для hairstyles, bust). Использует модель `hand_yolov8n.pt`.

**Конвейер PhaseA (когда руки в кадре):**
VAE Decode → FaceDetailer (face_yolov8m.pt) → **[FaceDetailer / HandsDetailer]** (hand_yolov8n.pt) → SaveImage

## Входы

| Вход | Тип | Что подавать | Что будет если не то |
|------|-----|-------------|---------------------|
| `image` | IMAGE | Выход FaceDetailer (уже улучшенное лицо) | Детекция рук на не-руках |
| `model` | MODEL | Модель после LoRA цепочки | Без модели — инпейнтинг не сработает |
| `clip` | CLIP | CLIP после LoRA цепочки | Без CLIP — промпт не применится |
| `vae` | VAE | VAE (sdxl_vae.safetensors) | Ошибка декодирования |
| `positive` | CONDITIONING | Положительный CLIPTextEncode | Плохое качество |
| `negative` | CONDITIONING | Отрицательный CLIPTextEncode | Плохое качество |
| `bbox_detector` | BBOX_DETECTOR | UltralyticsDetectorProvider → hand_yolov8n.pt | Руки не обнаружатся |
| `detailer_hook` | DETAILER_HOOK | None | — |
| `sam_model_opt` | SAM_MODEL | None | — |
| `segm_detector_opt` | SEGM_DETECTOR | None | — |

## Параметры

| Параметр | Диапазон | Дефолт | Эффект при увеличении | Эффект при уменьшении | Наблюдалось в наших тестах |
|----------|----------|--------|----------------------|----------------------|--------------------------|
| `guide_size` | 64–2048 | 256 | Детальнее референс | Меньше точность | `guide_size: 256` (руки мельче лиц) |
| `max_size` | 64–4096 | 512 | Выше макс разрешение | Ниже качество | `max_size: 512` |
| `feather` | 0–100 | 20 | Мягче переход | Чётче граница | `feather: 20` |
| `denoise` | 0.0–1.0 | 0.35 | Сильнее перерисовка рук | Слабее изменения | `denoise: 0.35` (выше, чем FaceDetailer 0.30) |
| `noise_mask` | enabled/disabled | enabled | — | — | `noise_mask: "enabled"` |
| `feather_mask` | disabled/enabled | disabled | — | — | `feather_mask: "disabled"` |
| `inpaint_model` | true/false | true | — | — | `inpaint_model: true` |
| `noise_mask_feather` | 0–100 | 20 | Мягче маска | Жёстче | `noise_mask_feather: 10` |
| `force_inpaint` | true/false | false | Всегда | Только при детекции | `force_inpaint: true` |
| `cycle` | 1–10 | 1 | Больше проходов | Один проход | `cycle: 1` |
| `wildcard` | string | "" | — | — | `wildcard: ""` |
| `dilate` | 0–50 | 10 | Шире область | Уже область | `dilate: 10` |
| `inpaint_mask` | true/false | true | — | — | `inpaint_mask: true` |

**Отличия от FaceDetailer:** guide_size 256 (vs 384), max_size 512 (vs 768), denoise 0.35 (vs 0.30).

## Зависимости от других нод

- **UltralyticsDetectorProvider** (отдельный экземпляр) → модель `hand_yolov8n.pt`
- **FaceDetailer** — HandsDetailer получает на вход image с выхода FaceDetailer

## Известные баги / ловушки в нашем пайплайне

1. **Руки детектятся не всегда:** hand_yolov8n.pt менее точен, чем face_yolov8m.pt.
2. **denoise=0.35 может убить текстуру:** Руки — мелкий элемент, есть риск потери деталей пальцев.
3. **Цепочка Face→Hands:** Если FaceDetailer испортил руки, HandsDetailer может их не найти.
4. **Дополнительный проход жрёт время:** +30-50% к времени генерации.
5. **Включение через use_hands:** Только для hairstyles и bust промптов.

## Источник

- `gen_phaseA_sdxl.py` — строки 140-164: нода 72 + нода 73
- `unified_config_brunette.yaml` — detailer.hands: model=hand_yolov8n.pt, guide_size=256, max_size=512, denoise=0.35
