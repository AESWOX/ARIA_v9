---
tags: [comfy-kb, comfyui, node, instantid]
status: reference
---

# ApplyInstantID (базовая)

## Что делает (по факту кода/документации)

Базовая нода ApplyInstantID — объединяет InstantIDModelLoader + InstantIDFaceAnalysis + ApplyInstantID. Принимает загруженную InstantID модель, эмбеддинги лица (InsightFace), положительный/отрицательный CLIP, и латентное изображение. Применяет InstantID-адаптацию через IP-Adapter механизм без отдельного control_net на входе.

> ⚠️ **В НАШЕМ ПАЙПЛАЙНЕ НЕ ИСПОЛЬЗУЕТСЯ.** Мы используем исключительно **ApplyInstantIDAdvanced** (см. [[ApplyInstantIDAdvanced]]). Базовая ApplyInstantID приведена для сравнения.

## Входы

| Вход | Тип | Что подавать | Что будет если не то |
|------|-----|-------------|---------------------|
| `model` | MODEL | Модель после загрузки чекпоинта (CheckpointLoaderSimple → LoRA цепочка) | Ошибка типов, пайплайн упадёт |
| `instantid` | INSTANTID | Выход InstantIDModelLoader (ip-adapter.bin) | Без этого нода не применит InstantID |
| `insightface` | INSIGHTFACE | Выход InstantIDFaceAnalysis (InsightFace детектор) | Без эмбеддингов лица — не сработает |
| `image` | IMAGE | Референсное изображение лица (ref_face_1024.png) | Если не изображение лица — эмбеддинг будет мусорным |
| `positive` | CONDITIONING | Закодированный положительный промпт (CLIPTextEncode) | Искажение результата |
| `negative` | CONDITIONING | Закодированный отрицательный промпт | Искажение результата |

## Параметры

| Параметр | Диапазон | Дефолт | Эффект при увеличении | Эффект при уменьшении | Наблюдалось в наших тестах |
|----------|----------|--------|----------------------|----------------------|--------------------------|
| `weight` | 0.0–2.0 | 1.0 | Более сильное натягивание черт референса | Более слабое влияние, больше свободы модели | [ГИПОТЕЗА — не проверено] |
| `start_at` | 0.0–1.0 | 0.0 | Позже начинает применять InstantID | Раньше начинает | [ГИПОТЕЗА — не проверено] |
| `end_at` | 0.0–1.0 | 1.0 | Дольше применяется в процессе шагов | Раньше заканчивается | [ГИПОТЕЗА — не проверено] |
| `noise` | 0.0–1.0 | 0.0 | Больше шума в адаптации | Меньше шума | [ГИПОТЕЗА — не проверено] |

> **Ключевое отличие от Advanced:** базовая ApplyInstantID **не имеет** входов `control_net` (IMAGE/CONTROL_NET) и параметров `cn_strength`, `combine_embeds`. Всё управление — только через weight/start_at/end_at. Advanced версия требует отдельного ControlNet на входе и image как отдельный вход для ControlNet.

## Зависимости от других нод

- **InstantIDModelLoader** — загружает `ip-adapter.bin` (1.57 GB) → подаётся в `instantid` вход
- **InstantIDFaceAnalysis** — загружает InsightFace antelopev2 → подаётся в `insightface` вход
- **CheckpointLoaderSimple** → цепочка LoRA → базовая модель на вход `model`
- **CLIPTextEncode** (×2) → positive и negative conditioning

## Известные баги / ловушки в нашем пайплайне

1. **Базовая vs Advanced:** В faceid_v2_test.py используется **ApplyInstantIDAdvanced**, не ApplyInstantID. Попытка скопировать workflow без карты control_net приведёт к ошибке "ApplyInstantIDAdvanced requires control_net input — use ApplyInstantID for basic mode".
2. **CPU provider:** InstantIDFaceAnalysis использует CPU provider (как в faceid_v2_test.py). На GPU может быть быстрее, но жрёт больше VRAM.
3. **Модель ControlNet:** instantid_controlnet.safetensors (2.33 GB) специфична для InstantID — обычные ControlNet не сработают корректно.

## Источник

- `faceid_v2_test.py` — используется ApplyInstantIDAdvanced (не базовая)
- `facelora_config.yaml` — конфигурация identity.weights для InstantID (instantid_weight, instantid_cn_strength и т.д.)
