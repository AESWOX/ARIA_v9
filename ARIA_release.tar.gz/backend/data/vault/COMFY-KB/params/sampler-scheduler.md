---
tags: [comfy-kb, comfyui, parameter, sampler]
status: reference
---

# Sampler & Scheduler

## Текущие значения в PhaseA

| Параметр | Значение |
|---|---|
| `sampler_name` | `dpmpp_2m_sde` |
| `scheduler` | `karras` |
| `steps` (base) | `30` |
| `steps` (hires) | `22` |

## Источники (VERIFIED)

```yaml
# unified_config_brunette.yaml lines 9-12
generation:
  steps: 30
  cfg: 6.0
  sampler: dpmpp_2m_sde
  scheduler: karras
```

```python
# gen_phaseA_sdxl.py — node 10 (base KSampler), lines 89-93
"steps": cfg["generation"]["steps"],          # 30
"cfg": cfg["generation"]["cfg"],              # 6.0
"sampler_name": cfg["generation"]["sampler"], # dpmpp_2m_sde
"scheduler": cfg["generation"]["scheduler"],  # karras
"denoise": 1.0

# node 12 (hires KSampler), lines 100-103
"steps": hires["steps"],                      # 22 (из unified_config line 18)
"denoise": hires["denoise"],                  # 0.35
# sampler и scheduler те же
```

```yaml
# facelora_config.yaml lines 99-104
base_steps: 30
base_cfg: 6.0
hires_steps: 20       # ⚠ отличается от unified_config (22)
hires_denoise: 0.35
sampler: dpmpp_2m_sde
scheduler: karras
```

```python
# faceid_v2_test.py line 34
# Та же связка, но CFG=4.0
"steps": 30, "cfg": 4.0,
"sampler_name": "dpmpp_2m_sde",
"scheduler": "karras"
```

## Характеристики связки `dpmpp_2m_sde + karras`

### Sampler: dpmpp_2m_sde

- **SDE variant** — добавляет стохастический шум на каждом шаге (в отличие от чистого ODE).
- Больше **вариативности** на каждом шаге → лучше детализация.
- Чуть **больше шумовой текстуры** → натуральнее кожа, волосы, ткань.
- Минус: менее детерминирован, чем euler/ddim — два прогона с одним seed дадут близкие, но не идентичные результаты.

### Scheduler: karras

- **Karras noise schedule** — более агрессивный noise schedule (больше шума в начале, быстрее очистка в конце).
- Лучше для **фотографического стиля**.
- Даёт более **контрастные, чистые изображения**.
- Хорошо сочетается с SDE-семплерами.

### Альтернативы для справки

| Sampler | Эффект |
|---|---|
| `euler` | Гладкий, стабильный, меньше деталей |
| `ddim` | Быстрый, наименее детальный |
| `dpmpp_2m_sde` | Детальный, фотографичный ✅ |
| `dpmpp_3m_sde` | Ещё более детальный, может oversharpen |
| `dpmpp_2m` (без SDE) | Менее вариативный, чем 2m_sde |

| Scheduler | Эффект |
|---|---|
| `karras` | Фотографичный, чистый ✅ |
| `normal` | Стандартный, предсказуемый |
| `sgm_uniform` | Похож на normal, чуть мягче |
| `exponential` | Резкая очистка, артефакты |

## Шаги: 30 base, 22 hires

- **30 шагов** — стандарт для SDXL. Достаточно для качественной детализации. Увеличение до 40+ не даёт заметного прироста.
- **22 шага** для hires pass — меньше, потому что изображение уже почти готово, нужно только уточнить детали (denoise=0.35).
- `facelora_config.yaml` указывает **20 шагов** для hires — незначительное расхождение, на практике ±2 шага не влияет.

## Связанные заметки

- [[cfg-guidance]]
- [[denoise-strength]]
- [[upscale]]
