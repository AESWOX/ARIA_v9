---
tags: [comfy-kb, comfyui, parameter]
status: reference
---

# Denoise Strength

## Текущие значения в PhaseA

| Pass | Значение | Источник |
|---|---|---|
| **Base** (первый KSampler) | `1.0` | `gen_phaseA_sdxl.py` line 93 |
| **Hires** (второй KSampler) | `0.35` | `gen_phaseA_sdxl.py` line 103, `unified_config_brunette.yaml` line 19 |

## Источники (VERIFIED)

```yaml
# unified_config_brunette.yaml lines 14-19
hires:
  enabled: true
  target: [1248, 1824]
  method: bicubic
  steps: 22
  denoise: 0.35
```

```python
# gen_phaseA_sdxl.py — node 10 (base KSampler)
"denoise": 1.0  # line 93

# node 12 (hires KSampler)
"denoise": hires["denoise"]  # 0.35, line 103
```

```yaml
# facelora_config.yaml line 102
hires_denoise: 0.35
```

## Роль параметра

Denoise контролирует, сколько шума добавляется на входе в KSampler.

- **denoise=1.0** — полный рендер из латентного шума. Используется для базовой генерации (первый проход).
- **denoise=0.35** — лёгкий рефайнмент. После upscale только уточняет детали, не меняя композицию.

## Почему 0.35 для Hires?

После upscale (832×1216 → 1248×1824, 1.5×) латентное изображение уже содержит всю структуру. Denoise 0.35:

- Сохраняет композицию и позу из base pass
- Добавляет высокочастотные детали (текстура кожи, волосы)
- Не "перерисовывает" сцену (избегает артефактов двойной генерации)
- Достаточно для апскейла без потери identity

## Практические диапазоны

| Диапазон | Эффект | Применение |
|---|---|---|
| 1.0 | Полная генерация | Base pass |
| 0.5–0.7 | Сильный рефайн | Смена стиля/позы на апскейле |
| 0.3–0.45 | Лёгкий рефайн | Hires fix, детализация |
| 0.15–0.25 | Микро-коррекция | Inpainting, FaceDetailer |
| < 0.15 | Почти нет изменений | Только шумовая текстура |

## Связанные заметки

- [[cfg-guidance]]
- [[upscale]]
- [[sampler-scheduler]]
