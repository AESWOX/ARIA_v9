---
tags: [comfy-kb, comfyui, parameter]
status: reference
---

# CFG Guidance (Classifier-Free Guidance)

**Текущее значение в PhaseA:** `6.0`

## Источники (VERIFIED)

| Источник | Значение | Контекст |
|---|---|---|
| `unified_config_brunette.yaml` line 10 | `cfg: 6.0` | Основной конфиг PhaseA |
| `gen_phaseA_sdxl.py` lines 90, 100 | `cfg["generation"]["cfg"]` | Оба KSampler (base + hires) |
| `facelora_config.yaml` line 100 | `base_cfg: 6.0` | FaceLoRA конфиг (не задаёт сам — берёт из workflow, там 6.0) |
| `faceid_v2_test.py` line 34 | `cfg: 4.0` | InstantID тестовый скрипт |

## Роль параметра

CFG определяет, насколько сильно модель следует за промптом в ущерб разнообразию.

- **6.0** — сбалансированное значение для SDXL. Хорошая адгеренция к промпту без oversaturation.
- **4.0** — используется в faceid_v2_test.py для InstantID. Более низкий CFG даёт модели больше свободы, что лучше сочетается с сильным Identity-preservation стеком (InstantID + FaceID v2).
- Типичный SDXL диапазон: **4–9**.
- Ниже 4: теряется адгеренция к промпту, возможен concept bleed.
- Выше 9: oversaturated цвета, жёсткие тени, "плакатный" вид.

## Использование в PhaseA

```python
# gen_phaseA_sdxl.py — node 10 (base KSampler)
"cfg": cfg["generation"]["cfg"]  # 6.0

# node 12 (hires KSampler) — тот же cfg
"cfg": cfg["generation"]["cfg"]  # 6.0
```

CFG **не меняется** между base и hires pass — одинаков для обоих KSampler.

## Тюнинг

- Для **фотографического стиля**: 5.0–6.5
- Для **стилизации/арта**: 7.0–9.0
- С **InstantID/FaceID**: снижать до 4.0–5.0 (иначе identity ломается)
- С **LoRA стеком**: 6.0 — безопасный дефолт

## Связанные заметки

- [[sampler-scheduler]]
- [[denoise-strength]]
- [[ipadapter-weight]]
