---
tags: [comfy-kb, comfyui, parameter, controlnet]
status: reference
---

# ControlNet Strength

## Текущие значения в PhaseA

| Параметр | PhaseA (OpenPose) | InstantID (faceid_v2_test) |
|---|---|---|
| `strength` | `0.25` | `0.7` |
| `start_at` | `0.0` | `0.0` |
| `end_at` | `0.6` | `0.9` |

## Источники (VERIFIED)

### PhaseA — OpenPose ControlNet (bust shots только)

```yaml
# unified_config_brunette.yaml lines 149-155
controlnet:
  pose:
    enabled: true
    model: controlnet-openpose-sdxl-1.0
    strength: 0.25
    start_at: 0.0
    end_at: 0.6
```

```python
# gen_phaseA_sdxl.py lines 222-241 (controlnet block)
cn_strength = controlnet_cfg.get("strength", 0.25)  # = 0.25
cn_start = controlnet_cfg.get("start_at", 0.0)      # = 0.0
cn_end = controlnet_cfg.get("end_at", 0.6)          # = 0.6
```

Применяется **только** для `bust` и `styles` (где тело видно, `use_controlnet=True`). Для emotions/orbit/hairstyles ControlNet **не используется** (`use_controlnet=False`).

### InstantID test — ControlNet отдельно

```python
# faceid_v2_test.py — node 12 (ApplyInstantIDAdvanced), line 31
cn_strength: 0.7
start_at: 0.0
end_at: 0.9
```

Здесь ControlNet — часть InstantID стека (не OpenPose, а `instantid_controlnet.safetensors`), и его задача — жёстко удерживать структуру лица.

## Почему 0.25 в PhaseA?

В PhaseA ControlNet используется **только** для слабого контроля позы верхней части тела:

- **0.25** — минимальное влияние. Достаточно для направления позы, но без искажения одежды/фона.
- **start=0.0, end=0.6** — ControlNet активен первые 60% шагов, затем модель финализирует детали свободно.

Это осознанное решение: сильный ControlNet (>0.5) с OpenPose на bust shots даёт артефакты наложения скелета на одежду и фон.

## Практические диапазоны

| Значение | Эффект | Применение |
|---|---|---|
| 0.0–0.3 | Слабый/фоновый контроль | OpenPose поза (PhaseA bust) |
| 0.3–0.6 | Умеренный контроль | Depth/Canny для композиции |
| 0.6–0.9 | Сильный контроль | InstantID структура лица |
| 0.9–1.0 | Жёсткий контроль | Точное копирование позы/рамки |

## Связанные заметки

- [[ipadapter-weight]]
- [[cfg-guidance]]
- [[sampler-scheduler]]
