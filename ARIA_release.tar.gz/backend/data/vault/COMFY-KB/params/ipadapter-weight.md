---
tags: [comfy-kb, comfyui, parameter, ipadapter]
status: reference
---

# IP-Adapter Weight

## Текущие значения в PhaseA

| Параметр | Значение | Источник |
|---|---|---|
| `weight` | `0.7` | `unified_config_brunette.yaml` line 32 |
| `weight_type` | `linear` | line 33 |
| `embeds_scaling` | `K+V` | line 34 |
| `start_at` | `0.0` | line 35 |
| `end_at` | `0.8` | line 36 |

## Источники (VERIFIED)

### PhaseA — IPAdapterPlus Face

```yaml
# unified_config_brunette.yaml lines 28-36
identity:
  method: ip-adapter
  ip_adapter:
    model: ip-adapter-plus-face_sdxl_vit-h.safetensors
    preset: PLUS FACE
    weight: 0.7
    weight_type: linear
    embeds_scaling: K+V
    start_at: 0.0
    end_at: 0.8
```

```python
# gen_phaseA_sdxl.py — node 5 (IPAdapterAdvanced), lines 77-81
"weight": ip_weight,           # = 0.7
"weight_type": ip_scaling,     # = "linear"
"start_at": ip_start,          # = 0.0
"end_at": ip_end,              # = 0.8
"embeds_scaling": ip_embeds,   # = "K+V"
```

### FaceID v2 — отдельный тест

```python
# faceid_v2_test.py — node 6, line 24
"weight": 0.6,
"weight_faceidv2": 1.0,
"start_at": 0.0, "end_at": 1.0,
"embeds_scaling": "V only"
```

### Orbit Angle Multiplier (facelora_config.yaml)

Multiplier на Identity-веса для orbit-блока в зависимости от угла:

```yaml
# facelora_config.yaml lines 76-94
orbit_angle_multipliers:
  - 1.00  # front facing
  - 0.95  # 22°
  - 0.75  # 45°
  - 0.55  # 67°
  - 0.40  # 90° profile
  - 0.25  # 112°
  - 0.15  # 135°
  - 0.08  # 157°
  - 0.00  # back of head
  - 0.08  # 157° left
  - 0.15  # 135° left
  - 0.25  # 112° left
  - 0.40  # 90° left profile
  - 0.55  # 67° left
  - 0.75  # 45° left
  - 0.95  # 22° left
```

## Логика значений

### `embeds_scaling`: K+V vs V only

| Режим | Эффект | Когда использовать |
|---|---|---|
| `K+V` | Полное влияние IP-адаптера на ключи и значения attention | PhaseA (баланс identity + поза) |
| `V only` | Только attention values — более слабое, но стабильное влияние | FaceID v2 (меньше distortion) |
| `K only` | Редко, специфические кейсы | — |

### Параметр weight

- **0.7** (IPAdapterPlus Face) — оптимальный баланс для SDXL лица. Identity хорошо держится, артефактов минимум.
- **0.6** (FaceID v2) — чуть слабее, но FaceID v2 дополнительно усиливается `weight_faceidv2: 1.0`.
- Типичный диапазон Stable Diffusion IP-Adapter: **0.3–1.0**.
- Выше 1.0: артефакты наложения, дублирование черт, "натянутое" лицо.
- Ниже 0.3: identity почти не сохраняется.

### start_at / end_at

В PhaseA IP-Adapter активен только с 0% до 80% шагов денойзинга (end_at=0.8). Это даёт модели последние 20% шагов доработать детали без привязки к референсу — лучше текстура кожи, меньше "пластика".

FaceID v2 (`end_at=1.0`) держит identity до конца — trade-off в пользу стабильности.

## Связанные заметки

- [[controlnet-strength]]
- [[cfg-guidance]]
- [[face-restore]]
