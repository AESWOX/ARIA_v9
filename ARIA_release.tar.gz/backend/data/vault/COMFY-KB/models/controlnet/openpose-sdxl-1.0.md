---
tags: [comfy-kb, controlnet, sdxl, model]
status: reference
---

# OpenPoseXL2.safetensors

**Тип:** ControlNet (SDXL) — OpenPose

## Назначение
OpenPose ControlNet для SDXL — контроль позы, скелета и положения тела персонажа по ключевым точкам (keypoints). Используется для точного позиционирования позы на основе референсного изображения.

## Где используется
- **Workflow:** PhaseB (блокер — ❌ ОТСУТСТВУЕТ)
- **Конфиг:** openpose ControlNet — обязательный компонент PhaseB
- **Нода:** ControlNetLoader (OpenPose)
- **Вес/Strength:** [ГИПОТЕЗА] 0.5 – 0.8

## Рекомендуемый диапазон weight/strength
0.4 – 0.8 [ГИПОТЕЗА].

## Совместимость
**SDXL.** Требует OpenPose препроцессор (detector).

## Проверено в бою
❌ **НЕТ** — файл отсутствует на B2. Является блокером PhaseB.

## Статус
❌ **ОТСУТСТВУЕТ НА B2.** Не найден в audit B2. Может быть заменён Union ControlNet (см. `controlnet-union-sdxl-1.0.md`), но это требует проверки совместимости с PhaseB.

## Размер на B2
N/A (файл отсутствует)
