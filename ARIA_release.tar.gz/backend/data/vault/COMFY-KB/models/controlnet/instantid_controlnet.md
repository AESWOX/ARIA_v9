---
tags: [comfy-kb, controlnet, instantid, model]
status: reference
---

# instantid_controlnet.safetensors

**Тип:** ControlNet (SDXL)

## Назначение
InstantID ControlNet — обеспечивает структурный контроль генерации на основе карты ключевых точек (keypoints) лица. Используется совместно с нодой `ApplyInstantIDAdvanced` для точного позиционирования черт лица и позы персонажа.

## Где используется
- **Workflow:** PhaseA — ApplyInstantIDAdvanced
- **Конфиг:** через InstantID workflow
- **Нода:** ApplyInstantIDAdvanced
- **Вес/Strength:** [ГИПОТЕЗА] 0.5 – 0.8 (зависит от пайплайна)

## Рекомендуемый диапазон weight/strength
0.4 – 0.8 [ГИПОТЕЗА]. Ниже 0.3 — контроль теряется. Выше 0.9 — жёсткая привязка к ключевым точкам, теряется вариативность.

## Совместимость
**SDXL.** InstantID ControlNet для XL-моделей. Требует InstantID ноды и препроцессинг keypoints (детектор лица).

## Проверено в бою
✅ Да. Используется в PhaseA через ApplyInstantIDAdvanced. Подтверждён audit B2.

## Размер на B2
2.33 GB (`instantid_controlnet.safetensors`)
