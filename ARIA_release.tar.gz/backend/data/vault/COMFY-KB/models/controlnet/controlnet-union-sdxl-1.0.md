---
tags: [comfy-kb, controlnet, sdxl, model]
status: reference
---

# controlnet-union-sdxl-1.0

**Тип:** ControlNet (SDXL) — Union / ProMax

## Назначение
Универсальный Union ControlNet SDXL (ProMax-версия). Способен заменять несколько специализированных ControlNet'ов, включая OpenPose, Canny, Depth, Normal и др. Используется как универсальный контроллер структуры. Может заменять OpenPose в случае отсутствия OpenPoseXL2.

## Где используется
- **Workflow:** PhaseA / эксперименты
- **Конфиг:** через Union ControlNet Loader
- **Нода:** ControlNetLoader (Union mode)
- **Вес/Strength:** [ГИПОТЕЗА] 0.5 – 0.8

## Рекомендуемый диапазон weight/strength
0.4 – 0.8 [ГИПОТЕЗА]. Union ControlNet поддерживает множественные типовые пресеты внутри одного файла.

## Совместимость
**SDXL.** Состоит из двух файлов по 2.34 GB каждый (разные режимы внутри Union). Совместим со стандартным ControlNetLoader.

## Проверено в бою
⚠️ Частично. Присутствует на B2, загружается, но точная конфигурация использования требует уточнения.

## Размер на B2
2.34 GB + 2.34 GB (два файла в `controlnet-union-sdxl-1.0/`)
