---
tags: [comfy-kb, ipadapter, sdxl, model]
status: reference
---

# ip-adapter-faceid-plusv2_sdxl.bin

**Тип:** IP-Adapter (SDXL, FaceID v2)

## Назначение
FaceID Plus v2 для передачи идентичности лица. Используется в отдельном скрипте `faceid_v2_test.py` для тестирования и в некоторых пайплайнах как альтернатива основному IP-Adapter PLUS FACE. Отличается от обычного IP-Adapter тем, что использует FaceID-эмбеддинги вместо CLIP-изображений.

## Где используется
- **Workflow:** Тестовый скрипт `faceid_v2_test.py` / опционально в PhaseA
- **Конфиг:** weight = 0.6
- **Нода:** Apply IP-Adapter FaceID
- **Вес/Strength:** 0.6

## Рекомендуемый диапазон weight/strength
0.4 – 0.75 (из кода: 0.6). Выше 0.8 — фотографический шум, галлюцинации текстуры. Ниже 0.3 — идентичность не читается.

## Совместимость
**SDXL + FaceID model.** Требует специальный `ip-adapter-faceid-plusv2` лоадер. Формат `.bin` (не `.safetensors`). Несовместим со стандартными IP-Adapter нодами.

## Проверено в бою
✅ Да. Проверен в скрипте `faceid_v2_test.py`. Подтверждён audit B2.

## Размер на B2
1.39 GB (`ip-adapter-faceid-plusv2_sdxl.bin`)
