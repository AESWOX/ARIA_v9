---
tags: [comfy-kb, ipadapter, sdxl, model]
status: reference
---

# ip-adapter_sdxl_vit-h.safetensors

**Тип:** IP-Adapter (SDXL, ViT-H)

## Назначение
Базовая версия SDXL IP-Adapter с ViT-H энкодером. Альтернатива `ip-adapter-plus-face_sdxl_vit-h`. Используется как fallback, когда PLUS FACE не требуется (например, для стилизации без привязки к лицу) или для A/B-сравнения.

## Где используется
- **Workflow:** PhaseA (альтернатива основному IP-Adapter) / эксперименты
- **Конфиг:** не указан в основном cfg (используется как замена)
- **Нода:** Apply IP-Adapter
- **Вес/Strength:** [ГИПОТЕЗА] 0.5 – 0.7 (экспериментально)

## Рекомендуемый диапазон weight/strength
0.4 – 0.8 [ГИПОТЕЗА]. Без пресета FACE даёт более общее влияние референса, не фокусируясь на лице.

## Совместимость
**SDXL + ViT-H image encoder.** Требует CLIP-ViT-H.

## Проверено в бою
⚠️ Частично. Предположительно использовался на ранних итерациях PhaseA. Подтверждён audit B2, но в текущем конфиге не указан.

## Размер на B2
666 MB (`ip-adapter_sdxl_vit-h.safetensors`)
