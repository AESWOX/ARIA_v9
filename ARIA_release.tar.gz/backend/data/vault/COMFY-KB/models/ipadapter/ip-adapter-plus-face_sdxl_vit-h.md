---
tags: [comfy-kb, ipadapter, sdxl, model]
status: reference
---

# ip-adapter-plus-face_sdxl_vit-h.safetensors

**Тип:** IP-Adapter (SDXL, ViT-H)

## Назначение
Основной IP-Adapter PhaseA для переноса черт лица с референсного изображения. Используется с PRESET "PLUS FACE" (специализированный пресет для лиц). Обеспечивает сохранение идентичности при генерации портретов.

## Где используется
- **Workflow:** PhaseA — IP-Adapter нода (Apply IP-Adapter)
- **Конфиг:** weight = 0.7, preset = PLUS FACE
- **Нода:** IP-Adapter Advanced / Apply IP-Adapter
- **Вес/Strength:** 0.7

## Рекомендуемый диапазон weight/strength
0.5 – 0.85 (из кода PhaseA: 0.7). Ниже 0.4 — потеря сходства. Выше 0.9 — перекос, артефакты лица, «приклеенная маска».

## Совместимость
**SDXL + ViT-H image encoder.** Требует CLIP-ViT-H (большой энкодер). Несовместим с SD1.5.

## Проверено в бою
✅ Да. Используется во всех генерациях PhaseA. Подтверждён audit B2.

## Размер на B2
808 MB (`ip-adapter-plus-face_sdxl_vit-h.safetensors`)
