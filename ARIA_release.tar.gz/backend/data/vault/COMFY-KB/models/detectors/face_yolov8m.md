---
tags: [comfy-kb, detector, model]
status: reference
---

# face_yolov8m.pt

**Тип:** Detector (Ultralytics YOLOv8m)

## Назначение
Детектор лиц на базе Ultralytics YOLOv8m. Используется в ноде `FaceDetailer` для обнаружения лиц на изображении перед передачей в IP-Adapter / ControlNet. Определяет bounding box лица и confidence score.

## Где используется
- **Workflow:** PhaseA — FaceDetailer (препроцессинг перед IP-Adapter)
- **Конфиг:** Ultralytics face detector (модель среднего размера — medium)
- **Нода:** FaceDetailer (загрузка через UltralyticsDetectorProvider)
- **Вес/Strength:** N/A (детектор, не адаптер)

## Рекомендуемый диапазон weight/strength
Не применимо — детектор работает на confidence threshold (обычно 0.3 – 0.5).

## Совместимость
**SDXL / SD1.5** — не зависит от модели генерации. YOLOv8 — универсальный детектор.

## Проверено в бою
✅ Да. Используется в PhaseA для FaceDetailer. Подтверждён audit B2.

## Размер на B2
49.6 MB (`face_yolov8m.pt`)
