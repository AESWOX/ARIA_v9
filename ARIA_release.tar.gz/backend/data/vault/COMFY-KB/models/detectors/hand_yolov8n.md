---
tags: [comfy-kb, detector, model]
status: reference
---

# hand_yolov8n.pt

**Тип:** Detector (Ultralytics YOLOv8n)

## Назначение
Детектор рук на базе Ultralytics YOLOv8n (nano — лёгкая версия). Используется в ноде `HandsDetailer` для обнаружения кистей рук на изображении с целью последующей коррекции анатомии (совместно с LoRA HandsXL_v1).

## Где используется
- **Workflow:** PhaseA — HandsDetailer (препроцессинг перед LoRA-коррекцией рук)
- **Конфиг:** Ultralytics hand detector (лёгкая модель — nano)
- **Нода:** HandsDetailer (загрузка через UltralyticsDetectorProvider)
- **Вес/Strength:** N/A (детектор, не адаптер)

## Рекомендуемый диапазон weight/strength
Не применимо — confidence threshold обычно 0.3 – 0.5.

## Совместимость
**SDXL / SD1.5** — детектор, не зависит от модели генерации.

## Проверено в бою
✅ Да. Используется в PhaseA для HandsDetailer. Подтверждён audit B2.

## Размер на B2
6.2 MB (`hand_yolov8n.pt`)
