---
tags: [comfy-kb, checkpoint, sdxl, model]
status: reference
---

# bigLust_v16.safetensors

**Тип:** Checkpoint (SDXL)

## Назначение
Основной чекпоинт PhaseA пайплайна. Указан в конфиге как `cfg.checkpoint.name`. Отвечает за базовую генерацию изображения — стиль, композицию, качество. Вся цепочка PhaseA строится вокруг этого чекпоинта: IP-Adapter face, LoRAs, ControlNet InstantID применяются поверх него.

## Где используется
- **Workflow:** PhaseA (основной пайплайн генерации)
- **Конфиг:** `cfg.checkpoint.name = "bigLust_v16.safetensors"`
- **Нода:** Load Checkpoint (загрузка в начале пайплайна)
- **Вес/Strength:** N/A (чекпоинт — базовая модель, не применяется с weight)

## Рекомендуемый диапазон weight/strength
Не применимо — чекпоинт является базовой моделью, а не адаптером. Параметры CFG scale в пайплайне задаются отдельно.

## Совместимость
**SDXL** — модель SDXL 1.0 база. Несовместима с SD1.5-нодами и LoRAs для SD1.5.

## Проверено в бою
✅ Да. Чекпоинт используется во всех генерациях PhaseA. Подтверждён audit B2.

## Размер на B2
6.46 GB (`bigLust_v16.safetensors`)
