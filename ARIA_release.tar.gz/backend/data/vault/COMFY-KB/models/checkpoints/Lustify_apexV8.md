---
tags: [comfy-kb, checkpoint, sdxl, model]
status: reference
---

# Lustify_apexV8.safetensors

**Тип:** Checkpoint (SDXL)

## Назначение
Альтернативный чекпоинт PhaseA. Указан в конфиге как `cfg.checkpoint.alt_name`. Используется как замена `bigLust_v16` для экспериментов или A/B-сравнения. Подгружается в той же ноде Load Checkpoint при переключении конфига.

## Где используется
- **Workflow:** PhaseA (опциональная замена чекпоинта)
- **Конфиг:** `cfg.checkpoint.alt_name = "Lustify_apexV8.safetensors"`
- **Нода:** Load Checkpoint (альтернативный вариант)
- **Вес/Strength:** N/A (чекпоинт)

## Рекомендуемый диапазон weight/strength
Не применимо.

## Совместимость
**SDXL** — базовая SDXL модель.

## Проверено в бою
✅ Да. Подтверждён audit B2. Используется как alt.

## Размер на B2
6.46 GB (`Lustify_apexV8.safetensors`)
