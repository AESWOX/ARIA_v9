---
tags: [comfy-kb, index, reference]
status: reference
---

# ComfyUI Knowledge Base — INDEX

> Дата: 2026-07-13 | Статус: curated reference (проверено на link/syntax совместимость 2026-07-22)

---

## Nodes (nodes/)

| Нода | Используется в |
|------|---------------|
| ApplyInstantID | faceid_v2_test.py |
| ApplyInstantIDAdvanced | осн. ID нода faceid_v2_test.py |
| IPAdapterFaceID | faceid_v2_test.py + PhaseA IP-Adapter |
| FaceDetailer | PhaseA — рефайнмент лица |
| HandsDetailer | PhaseA — опц. рефайнмент рук |
| UltralyticsDetectorProvider | PhaseA — фикс 10.07 |
| ControlNetApplyAdvanced | PhaseA — слабый OpenPose |
| KSampler | PhaseA — 2 шт (base + hires) |

**PhaseA**: Checkpoint -> LoRA stack -> IP-Adapter -> FaceDetailer -> KSampler x 2
**FaceID test**: Checkpoint -> IPAdapterFaceID -> ApplyInstantIDAdvanced -> KSampler

## Models (models/)

Checkpoints: bigLust_v16 (осн.), Lustify_apexV8 (альт.)
LoRAs: RealSkin_xxXL_v1 (0.6), DetailedEyes_V3 (0.5), HandsXL_v1 (0.45)
IP-Adapters: ip-adapter-plus-face (PhaseA, 0.7), ip-adapter-faceid-plusv2 (FaceID, 0.6)
ControlNets: instantid_controlnet, union-sdxl-1.0, **openpose - ОТСУТСТВУЕТ**
Detectors: face_yolov8m.pt, hand_yolov8n.pt

## Params (params/)

| Param | Value |
|-------|-------|
| CFG | 6.0 (PhaseA) / 4.0 (FaceID) |
| Denoise hires | 0.35 |
| IP-Adapter W | 0.7 / 0.6 |
| CN Strength | 0.25 / 0.7 |
| Sampler | dpmpp_2m_sde + karras |

## Postprocessing (postprocessing/)

| Файл | Статус в PhaseA |
|------|----------------|
| [upscale.md](postprocessing/upscale.md) | 4x-UltraSharp, 1.5&times; bicubic внутри пайплайна |
| [face-restore.md](postprocessing/face-restore.md) | Нет отдельного шага — FaceDetailer заменяет |
| [frequency-separation.md](postprocessing/frequency-separation.md) | Не используется (был в BILLY проекте) |

## Quality & Consistency (quality-and-consistency/)

| Файл | Назначение |
|------|-----------|
| [face-similarity-playbook.md](quality-and-consistency/face-similarity-playbook.md) | Как мерять и фиксить identity drift |
| [known-good-configs.md](quality-and-consistency/known-good-configs.md) | Рабочие комбинации параметров — пока пуст |
| [failure-patterns.md](quality-and-consistency/failure-patterns.md) | 8 известных паттернов поломок |

## Generation Log (generation-log/)

| Дата | Что тестировалось |
|------|------------------|
| [2026-07-08](generation-log/2026-07-08-b2-test-generations.md) | B2 test generations (16 PNG, 45 MB, до фикса ONNX) |

---

## Связанные документы

- [audit-b2-2026-07-13.md](../03-PROJECTS/AI-Influencer/audit-b2-2026-07-13.md)
- [Decision-Log.md](../DECISIONS/Decision-Log.md)
- [Statuses.md](../VAULT/Statuses.md)
