---
created: 2026-06-27
tags: [quant, trading, loop-engineering, signals]
---

# Quant-Trading

> Квант-трейдинг система на Loop Engineering. По фреймворку Roan.

## Архитектура (5 стадий)

```
📥 Data Ingestion → 🧠 Signal Generation → ✅ Verification → 💹 Execution → ⚠️ Risk Monitoring
       ↑                                                                           ↓
       └─────────────────── Lessons write back → SKILL.md ─────────────────────────┘
```

## 6 компонентов для трейдинга

| Компонент | В трейдинге | В Hermes |
|---|---|---|
| **Automation** | Cron pull данных каждую минуту/час | `cronjob` |
| **Skill** | alpha_research_skill.md — правила, уроки | `skill_manage` |
| **State** | STATE.md — последние сигналы, позиции | `memory` + `session_search` |
| **Verifier** | Отдельный агент проверяет сигнал (другая модель!) | `delegate_task` |
| **Worktrees** | Параллельные бэктесты, риск-мониторинг | Изолированные terminal |
| **Connectors** | MCP — broker API, Telegram, Slack | Gateway + tools |

## Ключевые правила (из статьи Roan)
- Sharpe > 1.5 за последние 30 трейдов
- Max drawdown < 5%
- Stop condition проверяется НЕ агентом, а кодом
- Maker/Checker split — разные модели для генерации и верификации
- Каждый loss → новая запись в SKILL.md

## Статус в нашем стеке
⚪ **План** — система не развёрнута, методология готова.

## Связи
- [[Loop-Engineering]] — базовый фреймворк
- [[Hermes Agent]] — инфраструктура готова
