---
created: 2026-06-27
tags: [loop-engineering, ai-agents, automation, quant-trading]
source: https://x.com/RohOnChain/status/2069838199636275684
---

# Loop Engineering

> Фреймворк автономных AI-циклов. Автор: Roan (RohOnChain).

## Концепция
Перестать быть «человеком внутри цикла» (вручную промптишь AI) →
стать **архитектором цикла**, который работает автономно.

Цитата Boris Cherny (глава Claude Code в Anthropic):
> *«Я больше не промпчу Claude. У меня есть loops, которые промптят Claude и решают что делать. Моя работа — писать loops.»*

## 6 компонентов

| # | Компонент | Описание | В Hermes |
|---|---|---|---|
| 1 | **Automation** | Сердцебиение — cron, webhook, `/loop` или `/goal` | `cronjob` ✅ |
| 2 | **Skill** | SKILL.md — процедурная память, конвенции, уроки | `skill_manage` ✅ |
| 3 | **State file** | STATE.md — выживает между запусками агента | `memory` + `session_search` ✅ |
| 4 | **Verifier** | Отдельный агент (другая модель) проверяет выход | `delegate_task` ✅ |
| 5 | **Worktrees** | Изолированные директории для параллельных агентов | `delegate_task` terminal sessions ✅ |
| 6 | **Connectors (MCP)** | API к бирже, БД, Telegram, Slack | Gateway + tools ✅ |

## 5 стадий Quant Trading Loop

```
📥 Data Ingestion → 🧠 Signal Generation → ✅ Verification → 💹 Execution → ⚠️ Risk Monitoring
       ↑                                                                           ↓
       └─────────────────── Lessons write back to SKILL.md ────────────────────────┘
```

## Применение в этом Vault
Этот Vault сам работает как Loop Engineering:
- `cronjob` (Automation) → проверяет новые источники
- `skills` (Skill) → хранят правила обработки
- `SECOND_BRAIN/` (State) — хранилище знаний
- `delegate_task` (Verifier) — проверка фактов
- [[Hermes Agent]] — архитектор loop'а

## Связи
- [[Second-Brain]] — применение Loop Engineering к знаниям
- [[SIGNALS/Quant Trading]] — трейдинговая реализация
- [[Hermes Agent]] — наша реализация loop'ов
