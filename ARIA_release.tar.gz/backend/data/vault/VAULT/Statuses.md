---
tags: [wiki, hermes, runpod, godtier, b2, comfyui, config, quant-trading, loop-engineering]
created: 2026-07-06
updated: 2026-07-06 23:00
---
# Statuses — текущее состояние конфига Hermes
*Обновлено: 2026-07-06 23:00 (полный фикс aux провайдеров + компрессии)*

## Конфиг
- **Модель:** `deepseek-v4-flash` (config.yaml `model.default`)
- **Provider:** `deepseek` — **жив**, текущая сессия работает
- **Fallback chain:** `[]` (пустой — Nous заблокирован)
- **Guardrails:** hard_stop_enabled=true, exact_failure: warn@2→stop@5
- **Disabled toolsets:** browser, computer_use, video, video_gen, moa
- **Obsidian MCP:** активен, vault=SECOND_BRAIN

## Провайдеры (исправлено 2026-07-06)
| Секция | Провайдер | Модель | Статус |
|--------|-----------|--------|--------|
| **Main** | deepseek | deepseek-v4-flash | ✅ работает |
| **Delegation** | groq | meta-llama/llama-4-scout-17b-16e-instruct | ✅ исправлено (был мёртвый deepseek) |
| **Compression** | google (gemini-aux-compression) | gemini-2.5-flash (7-key pool) | ✅ threshold 0.1 (понижен) |
| **Vision** | google | gemini-2.5-flash | ✅ |
| **Vision fallback** | google | gemini-2.5-flash | ✅ исправлено (был Groq 403) |
| **web_extract** | groq-aux-webextract | meta-llama/llama-4-scout-17b-16e-instruct | ✅ |
| **skills_hub** | groq-aux-skills-hub | meta-llama/llama-4-scout-17b-16e-instruct | ✅ исправлено |
| **approval** | groq-aux-approval | meta-llama/llama-4-scout-17b-16e-instruct | ✅ исправлено |
| **mcp** | groq-aux-mcp | meta-llama/llama-4-scout-17b-16e-instruct | ✅ исправлено |
| **title_generation** | groq-aux-title | meta-llama/llama-4-scout-17b-16e-instruct | ✅ исправлено |
| **tts_audio_tags** | groq-aux-tts-audio-tags | meta-llama/llama-4-scout-17b-16e-instruct | ✅ исправлено |
| **triage_specifier** | groq-aux-triage-specifier | meta-llama/llama-4-scout-17b-16e-instruct | ✅ исправлено |
| **kanban_decomposer** | groq-aux-kanban-decomposer | meta-llama/llama-4-scout-17b-16e-instruct | ✅ исправлено |
| **profile_describer** | groq-aux-profile-describer | meta-llama/llama-4-scout-17b-16e-instruct | ✅ исправлено |
| **curator** | alibaba (aux-curator) | qwen3-max-extended | ✅ |
| **background_review** | huggingface | microsoft/Phi-3.5-mini-instruct | ✅ |

## Ключи (проверено 2026-07-06 23:00)
- **Groq (10 keys):** **10/10 HTTP 200** ✅ — ротация работает, все живые
- **Google AI Studio (6 keys):** Gemini free tier (429 rate limit — норма)
- **DeepSeek (4 keys):** — возможно мёртвы, но main через них работает
- **Другие:** ALIBABA_API_KEY, GITHUB_TOKEN, HF_TOKEN, OPENROUTER_API_KEY
- **Источник:** `AppData/Local/hermes/.env` (runtime) + `~/.hermes/.env.local` (user)

## Модели Groq (доступные)
- `meta-llama/llama-4-scout-17b-16e-instruct` — основная для aux
- `llama-3.3-70b-versatile` — альтернатива
- `qwen/qwen3-32b` — альтернатива
- `llama-3.1-8b-instant` — быстрая

## История фиксов (2026-07-06)
1. **vision_fallback** — переведён с Groq (403) на Google Gemini
2. **Все groq-aux-* провайдеры** — модель с `openai/gpt-oss-120b` (не существует) → `meta-llama/llama-4-scout-17b-16e-instruct`
3. **Delegation** — переведён с мёртвого DeepSeek на Groq (бесплатно)
4. **Compression threshold** — понижен с 0.3 до 0.1 для раннего триггера
5. **Disabled toolsets** — browser, computer_use, video, video_gen, moa отключены

## Cron jobs (3 активных)
| ID | Name | Schedule | Mode |
|----|------|----------|------|
| `6ca19bcca6c0` | obsidian-daily-backup | `0 4 * * *` | no-agent (script) |
| `82d8746752a5` | state-db-backup | `0 5 * * *` | no-agent (script) |
| `2baebd8a8ddd` | budget-watchdog | `every 10m` | LLM-driven |

## Vault структура
- `00-RAW/` — сырые логи, архивы
- `01-WIKI/` — Wiki (50+ файлов)
- `03-PROJECTS/` — Decision-Log.md + AI-Influencer/
