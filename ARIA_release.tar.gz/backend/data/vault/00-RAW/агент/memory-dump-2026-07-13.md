---
status: raw
tags: [raw, агент]
---
# Memory Dump — 2026-07-13

## MEMORY.md (4978 bytes / 8000 limit — 62.2%)

1. PhaseA ComfyUI deploy (brunette): B2 path = b2:ALEX.STORAGE/deploy/. Ключевые файлы: checkpoints/bigLust_v16.safetensors (6.46 GiB), checkpoints/Lustify_apexV8.safetensors (6.46 GiB), vae/sdxl_vae.safetensors (319 MB), ipadapter/sdxl_models/ip-adapter-plus-face_sdxl_vit-h.safetensors (808 MB), loras/RealSkin_xxXL_v1.safetensors (5.2 MB), loras/DetailedEyes_V3.safetensors (88.8 MB), ultralytics/bbox/face_yolov8m.pt (49.6 MB), ultralytics/bbox/face_yolov8m.onnx (98.8 MB). ПОЛНЫЙ ИНВЕНТАРЬ: ~/Desktop/deploy_phaseA/PHASEA_INVENTORY.md. Критические проблемы: (1) gen_phaseA_sdxl.py:151 использует ONNXDetectorProvider который крашится — нужно заменить на UltralyticsDetectorProvider + face_yolov8m.pt, (2) HandsXL_v1.safetensors отсутствует на B2, (3) hand_yolov8n.pt отсутствует, (4) controlnet-openpose-sdxl-1.0 отсутствует (есть только controlnet-union-sdxl-1.0), (5) venv_comfy на B2 пустой (10 MB, только pip) — создан с --system-site-packages.

2. Node mapping PhaseA (brunette): [1]CheckpointLoaderSimple→bigLust_v16, [2]CLIPSetLastLayer(skip=-2), [3]IPAdapterUnifiedLoader(preset=PLUS FACE portraits), [4]LoadImage→ref_face_1024.png, [5]IPAdapterAdvanced(weight=0.18-0.55,linear,K+V,0.0-0.8), [6][7]CLIPTextEncode(pos/neg), [8]VAELoader→sdxl_vae, [9]EmptyLatentImage(832×1216), [10]KSampler(30steps,cfg6,dpmpp_2m_sde,karras), [11]LatentUpscale(1248×1824,bicubic), [12]KSampler(22steps,denoise0.35), [13]VAEDecode, [70]ДЕТЕКТОР ЛИЦ (должен быть UltralyticsDetectorProvider+face_yolov8m.pt), [71]FaceDetailer(31param), [72]ДЕТЕКТОР РУК(UltralyticsDetectorProvider+hand_yolov8n.pt), [73]FaceDetailer(руки), [90]ControlNetLoader→controlnet-openpose-sdxl-1.0, [91]DWPreprocessor, [92]ControlNetApplyAdvanced, [14]SaveImage. LoRA stack: [20]RealSkin_xxXL(0.6)+[21]DetailedEyes(0.5)+опционально[22]HandsXL(0.6). Полный мапинг: PHASEA_INVENTORY.md Part 4.

3. Пины зависимостей для PhaseA venv: torch==2.6.0+cu130, torchvision==0.21.0+cu130, numpy==1.26.4, Pillow==10.4.0, opencv-python-headless==4.10.0.84, ultralytics==8.3.70, onnxruntime-gpu==1.19.2, insightface==0.7.3, segment-anything==1.0, PyYAML==6.0.2. Полный список: PHASEA_INVENTORY.md Part 5.

4. Правило деплоя ComfyUI: перед каждым утверждением — обратная verify-команда. 'Тест прошёл' только если find output/ -name '*.png' | wc -l > 0. 'Venv готов' только если pip list --path=... | wc -l > 20. 'Модели на B2' только если rclone ls | grep для каждого файла. Три одинаковых фейла подряд → смена стратегии. ONNXDetectorProvider в Impact-Pack НЕСОВМЕСТИМ с YOLOv8 .onnx (Caffe vs RGB препроцессинг) — всегда использовать UltralyticsDetectorProvider с .pt.

5. Скрипты деплоя: ~/Desktop/WORK/SCRIPTS/runpod/deploy_pod.py (создание), terminate_pod.py (удаление). Ключ API в ~/Desktop/WORK/APY/RUNPOD/RUNPOD_2.txt. Template: 2lv7ev3wfp. Генерация: ~/Desktop/deploy_phaseA/gen_phaseA_sdxl.py (893 строки), конфиг: unified_config_brunette.yaml, промпты: prompts_brunette.yaml (387 строк). Промпты: 17 эмоций + 15 орбиталей + 10 причёсок + 7 bust-sfw + 7 bust-nsfw + 13 styles + lighting/age вариации.

6. Протокол BLOCKED: когда что-то не работает после 3 попыток — сказать 'BLOCKED: <конкретная причина>', записать в deploy_state.json, предложить варианты. НИКОГДА не фабриковать успех. BLOCKED лучше чем ложный '3.2 MB PNG'. Даже под давлением 'не задавай вопросы' — статус-репорт с эскалацией это не вопрос.

7. Файлы защиты от compaction: ~/Desktop/deploy_phaseA/deploy_state.json (объективное состояние деплоя, переживает compaction), preflight_check.py (GO/NO-GO до старта пода), preflight_result.json (результат последнего pre-flight). При старте сессии ВСЕГДА читать deploy_state.json — не доверять compaction memo.

8. PhaseA weight_base from prompts_brunette.yaml: 0.5 (ip_adapter.weight_base). ControlNet model: controlnet-openpose-sdxl-1.0/OpenPoseXL2.safetensors (correct). detailer.face.model: face_yolov8m.pt (ok). detailer.hands.model: hand_yolov8n.pt (generic COCO, needs replacement with real hand detector).

9. CivitAI API token: CIVITAI_TOKEN in ~/Desktop/WORK/.env. Token format: alphanumeric string.

---

## USER.md (0 bytes — empty)

No user profile data stored.

---

Dump created: 2026-07-13
Memory cleared: yes
