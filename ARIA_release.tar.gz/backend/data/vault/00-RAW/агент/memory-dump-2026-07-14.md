---
status: raw
tags: [raw, агент]
---
# Memory Dump — 2026-07-14

> Dumped by scheduled cron job. Memory was at ~71% of 8000-char limit.
> Both MEMORY.md (memory) and USER.md (user profile) are included.

---

## MEMORY.md (13 entries)

1. RunPod: под грузится ~1 минуту. НЕ надо поллинговать статус, SSH, proxy. Просто создал — через минуту всё работает. Не тратить время на проверки готовности.

2. After completing work on a RunPod pod, terminate it immediately — do not wait for user command. Running pods cost money per minute.

3. B2 Phase A архивы: b2:ALEX.STORAGE/deploy/archives/ — 4 файла: comfyui-models.tar.zst (34.2 GB), comfyui-venv.tar.zst (4.1 GB), comfyui-engine.tar.zst (75 MB), phaseA-full.tar.zst (103 MB)

4. Restore Phase A: apt-get install zstd → rclone copy c B2 → tar -xf 4 архивов. ~86 секунд.

5. fuser -k 8188/tcp убивает RunPod proxy. Использовать только kill $(pgrep -f 'python3 main.py') для остановки ComfyUI.

6. zstd -10 оптимальный баланс скорости/сжатия. zstd -19 в 10× медленнее.

7. Никогда не качать GB-архивы локально для проверки содержимого. Использовать `rclone cat <bucket>/<path> | zstd -d --stdout | tar -tvf - | grep/wc/head/tail` — стриминг без скачивания. Чек-сумму (sha256sum) брать со стрима rclone cat. Для проверки состава архива — head/tail listing + wc -l + grep на конкретные пути. Весь вывод — сырые строки, без python-summary между tar и пользователем.

8. CONTENT branch created in Obsidian: CONTENT/STORY-TEMPLATE/ (template+quality+gates+example), CONTENT/TREND-RESEARCH/ (Pornhub data + pending subagent data), CONTENT/STORY-DATABASE/ (Solo/Lesbian/Trans/Top50/Tags structure). 3 subagents researching top-20+ sites, viral patterns, and studio archetypes. Awaiting their data to begin 1000 story generation. Main INDEX.md updated with CONTENT branch (10th vault branch).

9. Протокол верификации: claim-слова требуют сырого tool output в том же сообщении. Питон-прослойка между response и текстом запрещена. Числа — только из tool call этого хода. MODEL ROUTING: delegate_task без per-call модели — при ESCALATE-триггере агент пишет рекомендацию сменить delegation.model в config.yaml, ждёт при необратимых действиях.

10. [ИСПРАВЛЕНО 15.07] Диагноз B2/rclone-зависания на этом ПК: НЕ DNS, НЕ файрвол, НЕ прокси, НЕ B2-специфичная блокировка. Причина: низкий исходящий throughput канала (~70-125 KiB/s / ~1 Mbps) на ВСЕ внешние хосты одинаково (B2, OVH, Hetzner) — проблема провайдера/роутера/линии на хосте, не софта. rclone работает нормально при --timeout 3600s (не 60s дефолт) — просто медленно. 4.4GB venv ~10ч, 78MB engine ~10 мин. НЕ переносить на RunPod без необходимости — переносить только если 10ч ожидания неприемлемо, не из-за «недоступности» B2. Прошлая версия диагноза (DPI/прокси на сети) была ОШИБОЧНОЙ — curl --noproxy «помог» случайно/непоказательно, не из-за обхода прокси. Урок: если фикс необъясним логикой диагноза (--noproxy не может влиять на сетевой DPI) — это сигнал, что диагноз неверный, а не что фикс сработал.

11. SELF-REFERENTIAL правило VERIFY OR DIE не держится при самоприменении: guard.py поймал 7 нарушений (claim-слова без tool output, нет ESCALATE-строки) в первом же финальном отчёте ПОСЛЕ добавления правила. Текстовая инструкция снижает частоту, но не гарантирует самопроверку в финальных сообщениях — эта категория текста структурно тянет к claim-формулировкам. guard.py ДОЛЖЕН прогоняться вручную пользователем после каждого сообщения с таблицей/отчётом — не опционально, подтверждено повторным провалом.

12. Gemini фикс 14.07: установлен google-genai SDK (не deprecated), config auxiliary.vision.provider=gemini (SDK вместо REST API), key_env_pool на 9 ключей. Из .env удалены GOOGLE_API_KEY_2 (дубль), GOOGLE_API_KEY_3 (AIzaSy), GOOGLE_API_KEY_6 (битый). GOOGLE_API_KEY_4→GEMINI_API_KEY_8, GOOGLE_API_KEY_5→GEMINI_API_KEY_9. Итого 10 AQ. ключей в пуле. AQ. ключи НЕ работают через REST API — только через SDK. КРИТИЧНО: использовать gemini-2.5-flash (не 2.0-flash — он постоянно 429). 6 рабочих ключей: GEMINI_API_KEY_2,3,4,5,8,9. GEMINI_API_KEY_6,7 — 404 (модель не для новых юзеров). Старый google.generativeai SDK работает, но deprecated. Оба SDK (старый и новый) работают с gemini-2.5-flash.

---

## USER.md (3 entries)

1. Язык: Русский — пользователь говорит по-русски, отвечать на русском.

2. Пользователь предпочитает русский язык. После работы на RunPod — терминейтить под немедленно, не ждать команды. Если нет ответа 5+ минут — всё равно терминейтить.

3. Story-driven format approved: short description + 0-3s hook + full story + 10 narrative frames + 5 developments. First 3 frames must hook. Tags by character (mia/sasha/nadia) + branch (solo/lesbian/girl-trans) + pattern (almost-caught, first-time, public-risk, ritual)

---

**Total**: 5670 chars memory + 696 chars user profile = 6366 chars
**Limit**: 8000 chars
**Usage**: ~71%
**Action**: Dumped and cleared.
