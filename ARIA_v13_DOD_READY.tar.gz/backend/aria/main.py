from __future__ import annotations

import asyncio
import json
import logging
import logging.handlers
import os
import re
import uuid
from datetime import datetime, timezone
from typing import Any
from dataclasses import dataclass

from dotenv import load_dotenv

# Load .env BEFORE anything else — settings depend on it
load_dotenv(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), '.env'))

from fastapi import Depends, FastAPI, Header, HTTPException, Query, WebSocket, WebSocketDisconnect
from fastapi.responses import PlainTextResponse
from fastapi.middleware.cors import CORSMiddleware

from aria.api.auth import token_store
from aria.config import get_settings
from aria.core import approvals
from aria.core.events import event_bus
from aria.core.rate_limit import shutdown_limiter, feedback_limiter
from aria.db import repository as repo
from aria.db.base import init_db, session_scope
from aria.db.enums import ApprovalStatus, AuditVerdict, ProviderStatus, SessionStatus, SourceTrust, TaskStatus, ToolStatus
from aria.db import models as m
from aria.core.loop import execute_agent_loop
from aria.llm.router import build_default_router
from aria.storage import obsidian_vault
from aria.storage.b2_client import B2ConfigError, BackblazeB2Client
from aria.routers.providers import router as providers_router
from aria.routers.storage import router as storage_router

# --- Файловое логирование (иначе история живёт только в scrollback консоли
# и теряется при закрытии/переполнении терминала) ---
_LOG_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "logs")
os.makedirs(_LOG_DIR, exist_ok=True)
_LOG_FILE = os.path.join(_LOG_DIR, "backend.log")

_file_handler = logging.handlers.RotatingFileHandler(
    _LOG_FILE, maxBytes=10 * 1024 * 1024, backupCount=5, encoding="utf-8"
)
_file_handler.setFormatter(
    logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s")
)
_file_handler.setLevel(logging.INFO)

_root_logger = logging.getLogger()
_root_logger.addHandler(_file_handler)
_root_logger.setLevel(logging.INFO)

# uvicorn пишет через свои собственные логгеры — цепляем хендлер и туда,
# иначе access/error логи uvicorn не попадут в файл.
for _uvicorn_logger_name in ("uvicorn", "uvicorn.error", "uvicorn.access"):
    logging.getLogger(_uvicorn_logger_name).addHandler(_file_handler)

app = FastAPI(title="Local Agent v7.1", version="0.1.0")
settings = get_settings()
router = build_default_router()
app.state.router = router
_background_tasks: dict[str, asyncio.Task[Any]] = {}

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:1420",  # Vite dev
        "tauri://localhost",
        "https://tauri.localhost",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.include_router(providers_router)
app.include_router(storage_router)


_app_logger = logging.getLogger("local_agent.main")


@app.middleware("http")
async def allow_private_network(request, call_next):
    try:
        response = await call_next(request)
    except Exception:
        # Гарантированный лог необработанного исключения в наш файл,
        # независимо от того, что uvicorn делает со своими логгерами
        # (dictConfig может перетереть handlers на uvicorn/uvicorn.error
        # в зависимости от порядка старта — сюда это не влияет).
        _app_logger.exception("Unhandled exception on %s %s", request.method, request.url.path)
        raise
    response.headers["Access-Control-Allow-Private-Network"] = "true"
    return response


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def iso(value: datetime | None) -> str | None:
    if value is None:
        return None
    if value.tzinfo is None:
        value = value.replace(tzinfo=timezone.utc)
    return value.astimezone(timezone.utc).isoformat()


async def require_runtime_token(x_local_agent_token: str | None = Header(default=None)) -> str:
    if not token_store.verify_token(x_local_agent_token):
        raise HTTPException(status_code=401, detail="invalid runtime token")
    return x_local_agent_token or ""


def serialize_session(session: m.Session) -> dict[str, Any]:
    return {
        "id": str(session.id),
        "title": session.title,
        "status": session.status.value if hasattr(session.status, "value") else str(session.status),
        "active_role": session.active_role,
        "current_task_id": str(session.current_task_id) if session.current_task_id else None,
        "source_trust_aggregate": session.source_trust_aggregate,
        "updated_at": iso(session.updated_at),
    }


def serialize_task(task: m.Task | None) -> dict[str, Any] | None:
    if task is None:
        return None
    return {
        "id": str(task.id),
        "title": task.objective[:80] or "Current task",
        "status": task.status.value if hasattr(task.status, "value") else str(task.status),
        "active_role": task.role,
        "source_trust_aggregate": "trusted",
        "draft_tz_md": task.draft_tz_md or "",
        "audit_attempt_no": task.audit_attempt_no,
        "parent_task_id": str(task.parent_task_id) if task.parent_task_id else None,
        "delegation_depth": task.delegation_depth,
    }


def serialize_message(msg: m.Message) -> dict[str, Any]:
    return {
        "id": str(msg.id),
        "role": msg.role,
        "content": msg.content,
        "source_trust": msg.source_trust.value if hasattr(msg.source_trust, "value") else str(msg.source_trust),
        "created_at": iso(msg.created_at),
    }


def serialize_tool_call(call: m.ToolCall) -> dict[str, Any]:
    return {
        "id": str(call.id),
        "tool_name": call.tool_name,
        "role": call.role,
        "status": call.status.value if hasattr(call.status, "value") else str(call.status),
        "risk_level": call.risk_level,
        "started_at": iso(call.started_at),
        "finished_at": iso(call.finished_at),
        "duration_ms": call.duration_ms,
        "error_code": call.error_code,
        "error_message": call.error_message,
        "input_json": call.input_json or {},
        "output_json": call.output_json or {},
        "approval_item_id": str(call.approval_item_id) if call.approval_item_id else None,
    }


def serialize_attention(item: m.AttentionItem) -> dict[str, Any]:
    return {
        "id": str(item.id),
        "type": item.type.value if hasattr(item.type, "value") else str(item.type),
        "status": item.status.value if hasattr(item.status, "value") else str(item.status),
        "title": item.title,
        "body_md": item.body_md,
        "expires_at": iso(item.expires_at),
        "created_at": iso(item.created_at),
        "task_id": str(item.task_id) if item.task_id else None,
        "payload_json": item.payload_json or {},
    }


def serialize_audit(report: m.AuditReport) -> dict[str, Any]:
    return {
        "id": str(report.id),
        "verdict": report.verdict.value if hasattr(report.verdict, "value") else str(report.verdict),
        "attempt_no": report.attempt_no,
        "created_at": iso(report.created_at),
        "missing_requirements": report.missing_requirements or [],
        "patch_suggestions": report.patch_suggestions or [],
        "metrics_compared": report.metrics_compared or {},
    }




def _safe_export_filename(title: str, session_id: uuid.UUID) -> str:
    stem = ''.join(ch if ch.isalnum() or ch in ('-', '_') else '-' for ch in (title or 'session')).strip('-')
    stem = stem[:48] or 'session'
    return f"{stem}-{session_id}.md"


def render_session_export_markdown(
    session: m.Session,
    task: m.Task | None,
    messages: list[m.Message],
    tool_calls: list[m.ToolCall],
    audit_reports: list[m.AuditReport],
) -> str:
    lines: list[str] = [
        f"# Session export — {session.title}",
        "",
        f"- session_id: `{session.id}`",
        f"- status: `{session.status.value if hasattr(session.status, 'value') else session.status}`",
        f"- active_role: `{session.active_role}`",
        f"- updated_at: `{iso(session.updated_at) or ''}`",
    ]
    if task is not None:
        lines.extend(
            [
                f"- current_task_id: `{task.id}`",
                f"- task_status: `{task.status.value if hasattr(task.status, 'value') else task.status}`",
                f"- objective: {task.objective}",
            ]
        )
    lines.extend(["", "## Messages", ""])
    for msg in messages:
        lines.append(f"## [{iso(msg.created_at) or ''}] {msg.role}: content")
        lines.append("")
        lines.append(msg.content or "")
        lines.append("")
    lines.extend(["## Tool calls", ""])
    for call in tool_calls:
        lines.append(f"<details><summary>{call.tool_name} — {call.status.value if hasattr(call.status, 'value') else call.status} ({call.duration_ms or 0}ms)</summary>")
        lines.append("")
        lines.append(f"- role: `{call.role}`")
        lines.append(f"- risk_level: `{call.risk_level}`")
        lines.append(f"- started_at: `{iso(call.started_at) or ''}`")
        lines.append(f"- finished_at: `{iso(call.finished_at) or ''}`")
        lines.append("")
        lines.append("```json")
        lines.append(json.dumps(call.input_json or {}, ensure_ascii=False, indent=2))
        lines.append("```")
        if call.output_json is not None:
            lines.append("")
            lines.append("```json")
            lines.append(json.dumps(call.output_json or {}, ensure_ascii=False, indent=2))
            lines.append("```")
        if call.error_message:
            lines.append("")
            lines.append(f"error: {call.error_message}")
        lines.append("")
        lines.append("</details>")
        lines.append("")
    lines.extend(["## Audit reports", ""])
    for report in audit_reports:
        lines.append(f"### Attempt {report.attempt_no} — {report.verdict.value if hasattr(report.verdict, 'value') else report.verdict}")
        lines.append("")
        if report.missing_requirements:
            lines.append("**Missing requirements**")
            lines.extend([f"- {item}" for item in report.missing_requirements])
            lines.append("")
        if report.patch_suggestions:
            lines.append("**Patch suggestions**")
            lines.extend([f"- {item}" for item in report.patch_suggestions])
            lines.append("")
        if report.metrics_compared:
            lines.append("```json")
            lines.append(json.dumps(report.metrics_compared, ensure_ascii=False, indent=2))
            lines.append("```")
            lines.append("")
    return "\n".join(lines).strip() + "\n"


def health_payload(ws_connected: bool = False, reconnect_mode: str = "live") -> dict[str, Any]:
    with session_scope() as db:
        providers = repo.list_provider_health(db)
    return {
        "overall": "online",
        "ws_connected": ws_connected,
        "reconnect_mode": reconnect_mode,
        "checked_at": iso(utc_now()),
        "components": [
            {"key": "backend", "label": "Backend API", "status": "online", "detail": "FastAPI running"},
            {"key": "postgres", "label": "Database", "status": "online", "detail": settings.POSTGRES_DSN},
            {"key": "redis", "label": "Redis", "status": "reduced", "detail": settings.REDIS_URL or "not connected in MVP"},
        ],
        "provider_health": [serialize_provider(row) for row in providers],
    }


def serialize_provider(row: m.ProviderHealth) -> dict[str, Any]:
    return {
        "id": row.provider_id,
        "label": row.label,
        "provider_class": row.provider_class,
        "status": row.status.value if hasattr(row.status, "value") else str(row.status),
        "failure_rate_pct": row.failure_rate_pct,
        "usage_pct": row.usage_pct,
    }


def public_config_payload() -> dict[str, Any]:
    with session_scope() as db:
        sessions = repo.list_sessions(db, limit=1)
        current_session = sessions[0] if sessions else None
        current_task = repo.get_task(db, current_session.current_task_id) if current_session and current_session.current_task_id else None
        providers = [serialize_provider(row) for row in repo.list_provider_health(db)]
    settings = get_settings()
    return {
        "current_session_id": str(current_session.id) if current_session else None,
        "current_task_id": str(current_task.id) if current_task else None,
        "provider_health": providers,
        "loop_max_iterations": settings.loop_max_iterations,
        "audit_max_attempts": settings.audit_max_attempts,
        "scheduler_jobs": [
            {
                "job_id": "daily-health-check",
                "name": "daily-health-check",
                "schedule": "*/15 * * * *",
                "enabled": True,
                "role": "housekeeping",
                "objective": "refresh health snapshot and expire stale approvals",
                "allowed_tools": ["file_search"],
                "allowed_high_risk_patterns": [],
                "timeout_sec": 120,
                "max_retries": 1,
                "last_run_status": "ok",
                "last_run_at": iso(utc_now()),
            }
        ],
        "obsidian_items": [
            {
                "id": "vault-task-index",
                "path": item["path"],
                "category": "task",
                "linked_session_id": None,
                "updated_at": iso(utc_now()),
                "status": "synced",
            }
            for item in obsidian_vault.list_notes("00-TASKS")[:10]
        ],
        "skills": [
            {
                "id": "skill-coder-baseline",
                "skill_name": "coder_baseline",
                "category": "coding",
                "status": "active",
                "active_version": "v7.1",
                "use_count": 12,
                "updated_at": iso(utc_now()),
                "benchmark": {
                    "success_rate": 0.92,
                    "error_rate": 0.08,
                    "median_duration_ms": 920,
                    "p95_duration_ms": 1800,
                    "mean_tool_calls": 2,
                    "baseline_version": "v7.0",
                    "candidate_version": "v7.1",
                    "decision": "promote",
                },
            }
        ],
        "feature_flags": {"demo_mode": False, "backend_owned_bootstrap": True, "ws_backfill": True},
    }


def session_snapshot_payload(session_id: uuid.UUID) -> dict[str, Any]:
    with session_scope() as db:
        session = repo.get_session(db, session_id)
        if session is None:
            raise HTTPException(status_code=404, detail="session not found")
        task = repo.get_task(db, session.current_task_id) if session.current_task_id else None
        messages = repo.list_messages(db, session.id)
        tool_calls = repo.list_tool_calls(db, task.id) if task else []
        attention_items = repo.list_attention_items(db)
        attention_items = [item for item in attention_items if item.session_id == session.id or item.task_id == (task.id if task else None)]
        audit_reports = repo.list_audit_reports(db, task.id) if task else []
        sessions = repo.list_sessions(db)
    public = public_config_payload()
    return {
        "session": serialize_session(session),
        "sessions": [serialize_session(row) for row in sessions],
        "current_task": serialize_task(task),
        "messages": [serialize_message(msg) for msg in messages],
        "tool_calls": [serialize_tool_call(call) for call in tool_calls],
        "attention_items": [serialize_attention(item) for item in attention_items],
        "audit_reports": [serialize_audit(report) for report in audit_reports],
        "providers": public["provider_health"],
        "scheduler_jobs": public["scheduler_jobs"],
        "obsidian_items": public["obsidian_items"],
        "skills": public["skills"],
        "health": health_payload(),
    }


def emit_session_updated(session: m.Session) -> None:
    event_bus.emit("session.updated", serialize_session(session), session_id=session.id, task_id=session.current_task_id)


def emit_message_created(msg: m.Message, session_id: uuid.UUID, task_id: uuid.UUID | None) -> None:
    event_bus.emit("message.created", serialize_message(msg), session_id=session_id, task_id=task_id)


def emit_task_status(task: m.Task) -> None:
    event_bus.emit("task.status_changed", serialize_task(task) or {}, session_id=task.session_id, task_id=task.id)


def seed_database() -> None:
    with session_scope() as db:
        sessions = repo.list_sessions(db)
        if sessions:
            return
        repo.upsert_provider_health(
            db,
            "stub-local",
            label="Stub local",
            provider_class="free_tier_reasoning",
            status=ProviderStatus.active,
            failure_rate_pct=0,
            usage_pct=12,
        )
        session = repo.create_session(db, "Bootstrap session", active_role="orchestrator")
        task = repo.create_task(
            db,
            session,
            role="coder",
            objective="Проверить backend-owned bootstrap, runtime token, WS backfill и контракты UI/HTTP по ТЗ v7.1",
            draft_tz_md="# Draft TZ\n\n- backend source of truth\n- bootstrap.json owned by backend\n- verify PIN on backend\n- UI via HTTP/WS\n",
        )
        repo.set_task_status(db, task, TaskStatus.approved)
        welcome = repo.append_message(
            db,
            session,
            role="assistant",
            content="Backend инициализирован. Можно запускать smoke-task, создавать новые сессии и проверять approvals / audit / WS.",
            source_trust=SourceTrust.trusted,
        )
        obsidian_vault.save_draft_tz(str(session.id), str(task.id), task.draft_tz_md or "")
    emit_session_updated(session)
    emit_task_status(task)
    emit_message_created(welcome, session.id, task.id)


@app.on_event("startup")
async def startup() -> None:
    init_db(create_all=True)
    token_store.issue()
    seed_database()
    # Register real providers from router into DB health table
    with session_scope() as db:
        for pclass, providers in router.providers_by_class.items():
            for p in providers:
                if p.provider_id != "stub-local":
                    repo.upsert_provider_health(
                        db,
                        p.provider_id,
                        label=p.provider_id,
                        provider_class=pclass,
                        status=ProviderStatus.active,
                    )
    # Attach router to app.state so self-test can find it
    app.state.router = router

    # Provider catalog refresh (background — не блокирует boot)
    from aria.scheduler.jobs import refresh_provider_models_job

    async def _bg_refresh_catalog() -> None:
        try:
            count = await refresh_provider_models_job(router)
            _app_logger.info("provider catalog refreshed: %s models", count)
        except Exception:
            _app_logger.exception("provider catalog refresh failed")

    _background_tasks["catalog_refresh"] = asyncio.create_task(_bg_refresh_catalog())


@app.get("/health")
async def get_health() -> dict[str, Any]:
    return health_payload()


@app.get("/config/public")
async def get_public_config(_: str = Depends(require_runtime_token)) -> dict[str, Any]:
    return public_config_payload()


@app.post("/auth/verify-pin")
async def verify_pin(payload: dict[str, Any], _: str = Depends(require_runtime_token)) -> dict[str, Any]:
    pin = str(payload.get("pin", ""))
    ok = token_store.verify_pin(pin)
    return {"ok": ok}


def _local_inline_completion(before: str, after: str) -> str:
    lines_before = before.splitlines()
    lines_after = after.splitlines()
    line_before = lines_before[-1] if lines_before else before
    line_after = lines_after[0] if lines_after else after
    if line_before.endswith('[[') and not line_after.startswith(']]'):
        return ']]'
    if re.fullmatch(r'-\s*', line_before):
        return '[ ] '
    if re.match(r'- \[[ xX]\] .+', line_before):
        return '\n- [ ] '
    if re.match(r'#{1,6} .+', line_before):
        return '\n\n'
    if line_before.rstrip().endswith('```'):
        return '\n\n```'
    if re.search(r'[:：]\s*$', line_before.strip()):
        return '\n- '
    if re.match(r'- .+', line_before):
        return '\n- '
    return ''


def _local_transform(selected_text: str, instruction: str) -> str:
    instruction_lower = instruction.lower()
    if 'upper' in instruction_lower or 'верх' in instruction_lower:
        return selected_text.upper()
    if 'lower' in instruction_lower or 'ниж' in instruction_lower:
        return selected_text.lower()
    if 'todo' in instruction_lower or 'задач' in instruction_lower:
        lines = [line.strip() for line in selected_text.splitlines() if line.strip()]
        return '\n'.join(f'- [ ] {line.lstrip("-* ")}' for line in lines)
    if 'summary' in instruction_lower or 'крат' in instruction_lower or 'суммар' in instruction_lower:
        chunks = re.split(r'(?<=[.!?])\s+', selected_text.strip())
        return ' '.join(chunks[:2]) if chunks else selected_text
    return selected_text


@app.post("/llm/inline-complete")
async def inline_complete(payload: dict[str, Any], _: str = Depends(require_runtime_token)) -> dict[str, Any]:
    before = str(payload.get('before', ''))
    after = str(payload.get('after', ''))
    suggestion = _local_inline_completion(before, after)
    return {'suggestion': suggestion, 'source': 'local-heuristic'}


@app.post("/llm/transform")
async def transform_selection(payload: dict[str, Any], _: str = Depends(require_runtime_token)) -> dict[str, Any]:
    selected_text = str(payload.get('selectedText', ''))
    instruction = str(payload.get('instruction', ''))
    return {'text': _local_transform(selected_text, instruction), 'source': 'local-heuristic'}


@app.post("/system/shutdown")
async def shutdown_backend(_: str = Depends(require_runtime_token)) -> dict[str, Any]:
    if not shutdown_limiter.allow("global"):
        raise HTTPException(status_code=429, detail="shutdown rate-limited")
    loop = asyncio.get_running_loop()
    loop.call_later(0.15, lambda: os._exit(0))
    return {'ok': True}


@app.get("/sessions")
async def list_sessions(_: str = Depends(require_runtime_token)) -> list[dict[str, Any]]:
    with session_scope() as db:
        return [serialize_session(row) for row in repo.list_sessions(db)]


@app.post("/sessions")
async def create_session(payload: dict[str, Any], _: str = Depends(require_runtime_token)) -> dict[str, Any]:
    title = str(payload.get("title") or "Untitled session")
    with session_scope() as db:
        session = repo.create_session(db, title, active_role="general")
        task = repo.create_task(db, session, role="general", objective=f"Новая задача: {title}", draft_tz_md=f"# {title}\n")
        repo.set_task_status(db, task, TaskStatus.draft)
    emit_session_updated(session)
    emit_task_status(task)
    return {"session_id": str(session.id), "task_id": str(task.id)}


@app.get("/sessions/{session_id}")
async def get_session(session_id: uuid.UUID, _: str = Depends(require_runtime_token)) -> dict[str, Any]:
    return session_snapshot_payload(session_id)


@app.post("/sessions/{session_id}/messages")
async def post_message(session_id: uuid.UUID, payload: dict[str, Any], _: str = Depends(require_runtime_token)) -> dict[str, Any]:
    content = str(payload.get("content") or "").strip()
    role = str(payload.get("role") or "user")
    if not content:
        raise HTTPException(status_code=400, detail="content required")
    with session_scope() as db:
        session = repo.get_session(db, session_id)
        if session is None:
            raise HTTPException(status_code=404, detail="session not found")
        task = repo.get_task(db, session.current_task_id) if session.current_task_id else None
        msg = repo.append_message(db, session, role=role, content=content, source_trust=SourceTrust.trusted)
        if task and role == "user":
            task.objective = content
            if task.status in (TaskStatus.draft, TaskStatus.awaiting_clarification):
                repo.set_task_status(db, task, TaskStatus.approved)
            elif task.status == TaskStatus.needs_rework:
                # §8.1: needs_rework допускает только in_progress/cancelled, approved запрещён
                repo.set_task_status(db, task, TaskStatus.in_progress)
    emit_message_created(msg, session_id, task.id if task else None)
    if task:
        emit_task_status(task)

    if task and role == "user" and task.status in (TaskStatus.approved, TaskStatus.in_progress):
        settings = get_settings()
        execution_mode = "codex" if settings.codex_enabled else "real"
        if execution_mode == "codex":
            from aria.agents.codex_exec_bridge import run_codex_task

            await run_codex_task(task.id)
        else:
            await execute_agent_loop(task.id, router, settings.agent_sandbox_root)

    return {"ok": True}


@app.get("/attention-items")
async def list_attention_items(_: str = Depends(require_runtime_token)) -> list[dict[str, Any]]:
    with session_scope() as db:
        return [serialize_attention(item) for item in repo.list_attention_items(db)]


@app.delete("/sessions/{session_id}")
async def delete_session(session_id: uuid.UUID, _: str = Depends(require_runtime_token)) -> dict[str, Any]:
    with session_scope() as db:
        session = repo.get_session(db, session_id)
        if session is None:
            raise HTTPException(status_code=404, detail="session not found")
        repo.delete_session(db, session_id)
    event_bus.emit("session.deleted", {"id": str(session_id)}, session_id=session_id, task_id=None)
    return {"ok": True}


@app.get("/sessions/{session_id}/export.md")
async def export_session_markdown(session_id: uuid.UUID, _: str = Depends(require_runtime_token)) -> PlainTextResponse:
    with session_scope() as db:
        session = repo.get_session(db, session_id)
        if session is None:
            raise HTTPException(status_code=404, detail="session not found")
        task = repo.get_task(db, session.current_task_id) if session.current_task_id else None
        messages = repo.list_messages(db, session_id)
        tool_calls = repo.list_tool_calls_by_session(db, session_id)
        audit_reports = repo.list_audit_reports_by_session(db, session_id)
    content = render_session_export_markdown(session, task, messages, tool_calls, audit_reports)
    headers = {"Content-Disposition": f'attachment; filename="{_safe_export_filename(session.title, session_id)}"'}
    return PlainTextResponse(content=content, media_type="text/markdown; charset=utf-8", headers=headers)


@app.get("/vault/tree")
async def get_vault_tree(subdir: str = Query(default=""), _: str = Depends(require_runtime_token)) -> dict[str, Any]:
    payload = obsidian_vault.list_vault_tree(subdir=subdir)
    if "error" in payload:
        raise HTTPException(status_code=400, detail=payload["error"])
    return payload


@app.get("/vault/notes/{note_path:path}")
async def get_vault_note(note_path: str, _: str = Depends(require_runtime_token)) -> dict[str, Any]:
    try:
        payload = obsidian_vault.read_note_by_path(note_path)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    if not payload.get("found"):
        raise HTTPException(status_code=404, detail="note not found")
    return payload


@app.put("/vault/notes/{note_path:path}")
async def put_vault_note(note_path: str, payload: dict[str, Any], _: str = Depends(require_runtime_token)) -> dict[str, Any]:
    content = payload.get("content")
    if not isinstance(content, str):
        raise HTTPException(status_code=400, detail="content must be a string")
    try:
        write_result = obsidian_vault.write_note_by_path(note_path, content)
        read_back = obsidian_vault.read_note_by_path(write_result["path"])
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return {**write_result, **{k: v for k, v in read_back.items() if k != "content"}}


@app.get("/vault/search")
async def search_vault(q: str = Query(..., min_length=1), max_results: int = Query(default=20, ge=1, le=100), _: str = Depends(require_runtime_token)) -> dict[str, Any]:
    return obsidian_vault.search_vault(q, max_results=max_results)


@app.get("/storage/b2/buckets")
async def list_b2_buckets(bucket_name: str | None = Query(default=None), _: str = Depends(require_runtime_token)) -> dict[str, Any]:
    client = BackblazeB2Client(get_settings())
    try:
        buckets = await client.list_buckets(bucket_name=bucket_name)
    except B2ConfigError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"b2 request failed: {exc}") from exc
    return {"items": buckets}


@app.get("/storage/b2/objects")
async def list_b2_objects(prefix: str = Query(default=""), bucket: str | None = Query(default=None), limit: int = Query(default=100, ge=1, le=1000), _: str = Depends(require_runtime_token)) -> dict[str, Any]:
    client = BackblazeB2Client(get_settings())
    try:
        items = await client.list_objects(prefix=prefix, bucket_name=bucket, max_file_count=limit)
    except B2ConfigError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"b2 request failed: {exc}") from exc
    return {"items": items, "prefix": prefix}


@app.get("/storage/b2/objects/{key:path}/meta")
async def get_b2_object_meta(key: str, bucket: str | None = Query(default=None), _: str = Depends(require_runtime_token)) -> dict[str, Any]:
    client = BackblazeB2Client(get_settings())
    try:
        return await client.get_object_meta(key=key, bucket_name=bucket)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except B2ConfigError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"b2 request failed: {exc}") from exc


async def _run_demo_task(task_id: uuid.UUID) -> None:
    with session_scope() as db:
        task = repo.get_task(db, task_id)
        if task is None:
            return
        session = repo.get_session(db, task.session_id)
        if task.status in (TaskStatus.cancelled, TaskStatus.done, TaskStatus.failed):
            return
        repo.set_task_status(db, task, TaskStatus.in_progress)
    emit_task_status(task)
    await asyncio.sleep(0.2)

    with session_scope() as db:
        task = repo.get_task(db, task_id)
        session = repo.get_session(db, task.session_id)
        call = repo.start_tool_call(
            db,
            session,
            task,
            tool_name="file_search",
            role=task.role,
            risk_level="low",
            input_json={"glob": "**/*"},
            source_trust_snapshot=session.source_trust_aggregate,
        )
    event_bus.emit("tool_call.updated", serialize_tool_call(call), session_id=session.id, task_id=task.id)
    await asyncio.sleep(0.2)

    with session_scope() as db:
        task = repo.get_task(db, task_id)
        session = repo.get_session(db, task.session_id)
        call = db.get(m.ToolCall, call.id)
        repo.finish_tool_call(db, call, ToolStatus.ok, output_json={"matches": ["backend/app/main.py", "desktop/src/App.tsx"]})
        tool_msg = repo.append_message(
            db,
            session,
            role="tool",
            content="file_search -> ok",
            content_json={"tool_name": "file_search", "output": {"matches": ["backend/app/main.py", "desktop/src/App.tsx"]}, "status": "ok"},
            source_trust=SourceTrust.trusted,
        )
        assistant = repo.append_message(
            db,
            session,
            role="assistant",
            content=(
                "Задача выполнена в MVP-режиме: backend принял цель, записал tool-call, сохранил состояние в БД, "
                "отправил WS-события и подготовил результат для audit-loop."
            ),
            source_trust=SourceTrust.trusted,
        )
        repo.set_task_status(db, task, TaskStatus.under_audit)
    event_bus.emit("tool_call.updated", serialize_tool_call(call), session_id=session.id, task_id=task.id)
    emit_message_created(tool_msg, session.id, task.id)
    emit_message_created(assistant, session.id, task.id)
    emit_task_status(task)

    with session_scope() as db:
        task = repo.get_task(db, task_id)
        session = repo.get_session(db, task.session_id)
        report = repo.create_audit_report(
            db,
            session,
            task,
            attempt_no=task.audit_attempt_no + 1,
            auditor_role="qa_auditor",
            auditor_model="stub-standard",
            budget_degraded=False,
            verdict=AuditVerdict.pass_,
            plan_vs_fact={"objective": task.objective, "mode": "mvp-demo"},
            tool_success_summary={"total": 1, "ok": 1, "error": 0, "blocked_policy": 0},
            missing_requirements=[],
            patch_suggestions=[],
            metrics_compared={},
        )
        task.audit_attempt_no += 1
        repo.set_task_status(db, task, TaskStatus.done)
    event_bus.emit("audit_report.created", serialize_audit(report), session_id=session.id, task_id=task.id)
    emit_task_status(task)


@app.post("/tasks/{task_id}/start")
async def start_task(
    task_id: uuid.UUID,
    payload: dict[str, Any] | None = None,
    _: str = Depends(require_runtime_token),
) -> dict[str, Any]:
    with session_scope() as db:
        task = repo.get_task(db, task_id)
        if task is None:
            raise HTTPException(status_code=404, detail="task not found")
        if task.status in (TaskStatus.draft, TaskStatus.awaiting_clarification):
            repo.set_task_status(db, task, TaskStatus.approved)
        elif task.status == TaskStatus.needs_rework:
            # §8.1: needs_rework допускает только in_progress/cancelled, approved запрещён
            repo.set_task_status(db, task, TaskStatus.in_progress)
    settings = get_settings()
    execution_mode = (payload or {}).get("mode") or ("codex" if settings.codex_enabled else "real")

    if execution_mode == "codex":
        from aria.agents.codex_exec_bridge import run_codex_task

        model = (payload or {}).get("model")
        await run_codex_task(task_id, model=model)
    elif execution_mode == "demo":
        # explicit opt-in only now — больше не дефолт, см. §3.3 backend-аудита
        await _run_demo_task(task_id)
    else:
        await execute_agent_loop(task_id, router, settings.agent_sandbox_root)
    return {"ok": True}


@app.post("/tasks/{task_id}/run-executor")
async def run_executor_pipeline(
    task_id: uuid.UUID,
    _: str = Depends(require_runtime_token),
) -> dict[str, Any]:
    """Запустить Stage 1-7 executor pipeline для задачи.

    Использует executor.run_task с реальным ProviderRouter.
    Если TELEGRAM_BOT_TOKEN настроен — подключает TelegramNotifier.
    В отличие от /tasks/{task_id}/start (ReAct loop), это Stage 1-7
    loop-engineering pipeline: vault-check → plan → real handlers → audit → hooks → delivery.
    """
    from aria.core.executor import run_task as executor_run_task
    from aria.core.notifiers.telegram import TelegramNotifier
    from aria.db.enums import TaskStatus as TS

    notifier: Notifier | None = None

    with session_scope() as db:
        task = repo.get_task(db, task_id)
        if task is None:
            raise HTTPException(status_code=404, detail="task not found")

        settings = get_settings()

        # Telegram notifier, если настроен
        if settings.telegram_bot_token and settings.telegram_chat_id:
            try:
                notifier = TelegramNotifier(
                    bot_token=settings.telegram_bot_token,
                    chat_id=settings.telegram_chat_id,
                )
            except Exception as e:
                logger.warning("Failed to init TelegramNotifier: %s", e)

        result = await executor_run_task(
            session=db,
            task=task,
            router=router,
            notifier=notifier,
        )

    return result


@app.get("/tasks/{task_id}/children")
async def get_task_children(task_id: uuid.UUID, _: str = Depends(require_runtime_token)) -> list[dict[str, Any]]:
    with session_scope() as db:
        task = repo.get_task(db, task_id)
        if task is None:
            raise HTTPException(status_code=404, detail="task not found")
        children = repo.list_child_tasks(db, task_id)
        return [serialize_task(child) for child in children]


@app.post("/tasks/{task_id}/cancel")
async def cancel_task(task_id: uuid.UUID, _: str = Depends(require_runtime_token)) -> dict[str, Any]:
    with session_scope() as db:
        task = repo.get_task(db, task_id)
        if task is None:
            raise HTTPException(status_code=404, detail="task not found")
        repo.set_task_status(db, task, TaskStatus.cancelled)
    emit_task_status(task)
    return {"ok": True}


@app.get("/tasks/{task_id}/audit-reports")
async def get_audit_reports(task_id: uuid.UUID, _: str = Depends(require_runtime_token)) -> list[dict[str, Any]]:
    with session_scope() as db:
        return [serialize_audit(row) for row in repo.list_audit_reports(db, task_id)]


@app.post("/attention-items/{item_id}/approve")
async def approve_attention(item_id: uuid.UUID, _: str = Depends(require_runtime_token)) -> dict[str, Any]:
    with session_scope() as db:
        item = repo.get_attention_item(db, item_id)
        if item is None:
            raise HTTPException(status_code=404, detail="attention item not found")
        resolved = approvals.resolve(db, item, approve=True)
    event_bus.emit("attention_item.resolved", serialize_attention(resolved), session_id=resolved.session_id, task_id=resolved.task_id)
    return {"ok": True}


@app.post("/attention-items/{item_id}/reject")
async def reject_attention(item_id: uuid.UUID, _: str = Depends(require_runtime_token)) -> dict[str, Any]:
    with session_scope() as db:
        item = repo.get_attention_item(db, item_id)
        if item is None:
            raise HTTPException(status_code=404, detail="attention item not found")
        resolved = approvals.resolve(db, item, approve=False)
    event_bus.emit("attention_item.resolved", serialize_attention(resolved), session_id=resolved.session_id, task_id=resolved.task_id)
    return {"ok": True}


@app.get("/system/self-test")
async def system_self_test() -> dict[str, Any]:
    """§0: живой эндпоинт целостности — проверяет БД, модели, репо, роутер, скиллы."""
    try:
        _ = m.ProviderHealth
    except Exception as exc:
        return {"status": "error", "issues": [f"Module m not accessible: {exc}"]}
    issues: list[str] = []
    checks: dict[str, Any] = {}
    settings = get_settings()

    # 1. База данных
    try:
        with session_scope() as db:
            # простой запрос — жива ли БД
            from sqlalchemy import text
            db.execute(text("SELECT 1"))
        checks["database"] = "ok"
    except Exception as exc:
        checks["database"] = f"error: {exc}"
        issues.append(f"Database unreachable: {exc}")

    # 2. Модели — все ли таблицы созданы
    from sqlalchemy import inspect as sa_inspect
    try:
        with session_scope() as db:
            inspector = sa_inspect(db.bind)
            tables = set(inspector.get_table_names())
        expected = {"sessions", "tasks", "messages", "tool_calls", "audit_reports",
                    "attention_items", "provider_health", "agent_state", "events"}
        missing = expected - tables
        if missing:
            checks["models"] = f"missing tables: {missing}"
            issues.append(f"Missing DB tables: {missing}")
        else:
            checks["models"] = f"ok ({len(tables)} tables)"
    except Exception as exc:
        checks["models"] = f"error: {exc}"
        issues.append(f"Model check failed: {exc}")

    # 3. Router — проверяем провайдеры через БД (самый надёжный способ)
    try:
        with session_scope() as db:
            count = db.query(m.ProviderHealth).count()
            classes = db.query(m.ProviderHealth.provider_class).distinct().count()
        checks["router"] = f"ok ({count} providers, {classes} classes)"
    except Exception as exc:
        checks["router"] = f"error: {exc}"
        issues.append(f"Router check failed: {exc}")

    # 4. Config — чувствительные поля не пустые
    try:
        config_issues = []
        if not settings.loop_max_iterations:
            config_issues.append("loop_max_iterations is 0")
        if not settings.audit_max_attempts:
            config_issues.append("audit_max_attempts is 0")
        if config_issues:
            checks["config"] = f"issues: {', '.join(config_issues)}"
            issues.extend(config_issues)
        else:
            checks["config"] = "ok"
    except Exception as exc:
        checks["config"] = f"error: {exc}"

    # 5. Version / identity
    try:
        import importlib.metadata
        version = importlib.metadata.version("local-agent") if hasattr(importlib.metadata, "version") else "0.0.0"
    except Exception:
        version = "0.0.0 (dev)"

    # 6. Provider catalog — реально ли есть модели в БД
    try:
        with session_scope() as db:
            catalog_count = db.query(m.ProviderModel).count()
        checks["provider_catalog"] = f"{catalog_count} models cached" if catalog_count else "empty (not refreshed yet or no real providers configured)"
    except Exception as exc:
        checks["provider_catalog"] = f"error: {exc}"

    # 7. Vault / skills — честная проверка вместо декларации в markdown
    try:
        import os as _os
        vault_path = settings.OBSIDIAN_VAULT_PATH
        vault_exists = _os.path.isdir(vault_path)
        checks["vault"] = "ok" if vault_exists else "missing"
        if not vault_exists:
            issues.append(f"OBSIDIAN_VAULT_PATH={vault_path} does not exist")
    except Exception as exc:
        checks["vault"] = f"error: {exc}"

    try:
        with session_scope() as db:
            skills_count = db.query(m.SkillMeta).count()
        checks["skills"] = f"{skills_count} skills in skills_meta"
    except Exception as exc:
        checks["skills"] = f"error: {exc}"

    # 8. Budget enforcement — пороги не нулевые, бюджет активен
    try:
        if settings.budget_warn_threshold_pct and settings.budget_block_threshold_pct:
            checks["budget"] = f"warn@{settings.budget_warn_threshold_pct}% block@{settings.budget_block_threshold_pct}%"
        else:
            checks["budget"] = "disabled (thresholds are 0)"
            issues.append("Budget enforcement thresholds are zero")
    except Exception as exc:
        checks["budget"] = f"error: {exc}"

    # 9. Guardrail state — модуль загружен и интегрирован в loop
    try:
        from aria.core.guardrails import ToolCallGuardrailController
        g = ToolCallGuardrailController()
        # verify interface: before_call + after_call as entry points
        assert hasattr(g, 'before_call'), "missing before_call"
        assert hasattr(g, 'after_call'), "missing after_call"
        # verify all three detection counters exist (set by dataclass __init__)
        assert hasattr(g, '_exact_failure_counts'), "missing exact-failure counter"
        assert hasattr(g, '_same_tool_failure_counts'), "missing same-tool counter"
        assert hasattr(g, '_no_progress'), "missing no-progress counter"
        checks["guardrails"] = "ok (3 detectors via before_call/after_call: exact-failure, same-tool, no-progress)"
    except Exception as exc:
        checks["guardrails"] = f"error: {exc}"
        issues.append(f"Guardrail check failed: {exc}")

    status = "ok" if not issues else "degraded"
    return {
        "agent": "ARIA",
        "version": version,
        "status": status,
        "issues": issues,
        "checks": checks,
        "ts": iso(utc_now()),
    }


@dataclass
class FeedbackBody:
    task_id: str
    rating: int = 5  # 1-5
    comment: str = ""
    skill_name: str | None = None


@app.post("/system/feedback")
async def system_feedback(body: FeedbackBody, _: str = Depends(require_runtime_token)) -> dict[str, Any]:
    """§0: фидбек-луп — сохраняет отзыв и опционально создаёт skill-candidate."""
    if not feedback_limiter.allow(body.task_id or "anon"):
        raise HTTPException(status_code=429, detail="feedback rate-limited")
    if body.rating < 1 or body.rating > 5:
        raise HTTPException(status_code=422, detail="rating must be 1-5")

    with session_scope() as db:
        # Сохраняем фидбек как event
        event_bus.emit(
            "feedback.created",
            {
                "task_id": body.task_id,
                "rating": body.rating,
                "comment": body.comment,
                "skill_name": body.skill_name,
            },
            db=db,
        )

        # Если рейтинг >= 4 и есть skill_name — создаём черновик скилла
        skill_created = None
        if body.rating >= 4 and body.skill_name:
            # Проверяем, существует ли уже такой скилл
            from aria.tools.registry import TOOL_REGISTRY
            existing = TOOL_REGISTRY.get(body.skill_name)
            if existing:
                return {"ok": True, "feedback_saved": True, "skill_created": False, "reason": "skill already exists"}

            # Создаём как message-заметку в сессии task
            task = repo.get_task(db, uuid.UUID(body.task_id)) if body.task_id else None
            if task:
                session = repo.get_session(db, task.session_id)
                repo.append_message(
                    db, session, role="system",
                    content=f"[FEEDBACK-SKILL-CANDIDATE] name={body.skill_name}, rating={body.rating}, comment={body.comment[:500]}",
                )
                skill_created = True

        return {"ok": True, "feedback_saved": True, "skill_created": skill_created or False}


@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket, last_event_id: str | None = Query(default=None)) -> None:
    await websocket.accept()
    queue = event_bus.subscribe()
    try:
        backlog_sent = False
        if last_event_id:
            try:
                last_uuid = uuid.UUID(last_event_id)
            except ValueError:
                last_uuid = None
            with session_scope() as db:
                events = repo.list_events_after(db, last_uuid, limit=settings.ws_backfill_limit) if last_uuid else []
            if events:
                for event in events:
                    await websocket.send_json(
                        {
                            "event_id": str(event.event_id),
                            "event_type": event.event_type,
                            "session_id": str(event.session_id) if event.session_id else None,
                            "task_id": str(event.task_id) if event.task_id else None,
                            "ts": iso(event.ts),
                            "payload": event.payload,
                        }
                    )
                backlog_sent = True
        if not backlog_sent:
            await websocket.send_json({
                "event_id": str(uuid.uuid4()),
                "event_type": "backend.health_changed",
                "session_id": None,
                "task_id": None,
                "ts": iso(utc_now()),
                "payload": health_payload(ws_connected=True, reconnect_mode="snapshot"),
            })
            with session_scope() as db:
                sessions = repo.list_sessions(db)
            for session in sessions:
                await websocket.send_json({
                    "event_id": str(uuid.uuid4()),
                    "event_type": "session.updated",
                    "session_id": str(session.id),
                    "task_id": str(session.current_task_id) if session.current_task_id else None,
                    "ts": iso(utc_now()),
                    "payload": serialize_session(session),
                })
        while True:
            envelope = await queue.get()
            await websocket.send_json(envelope)
    except WebSocketDisconnect:
        pass
    finally:
        event_bus.unsubscribe(queue)
