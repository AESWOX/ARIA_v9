"""HTTP API facade.

Текущая реализация проекта исторически держит реальные FastAPI routes в `app.main`.
Этот модуль добавлен как структурный якорь под ТЗ v7.1 и как очевидная точка для
последующего вынесения HTTP router'ов из монолитного entrypoint.
"""

from aria.main import app, approve_attention, cancel_task, create_session, delete_session, export_session_markdown, get_audit_reports, get_b2_object_meta, get_b2_buckets, get_health, get_public_config, get_session, get_vault_note, get_vault_tree, list_attention_items, list_b2_objects, list_sessions, post_message, put_vault_note, reject_attention, search_vault, start_task, verify_pin

__all__ = [
    "app",
    "get_health",
    "get_public_config",
    "verify_pin",
    "list_sessions",
    "create_session",
    "get_session",
    "delete_session",
    "export_session_markdown",
    "post_message",
    "list_attention_items",
    "get_vault_tree",
    "get_vault_note",
    "put_vault_note",
    "search_vault",
    "get_b2_buckets",
    "list_b2_objects",
    "get_b2_object_meta",
    "start_task",
    "cancel_task",
    "get_audit_reports",
    "approve_attention",
    "reject_attention",
]
