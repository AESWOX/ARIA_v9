"""WebSocket API facade.

WS endpoint пока реализован в `app.main`. Этот модуль — совместимая точка входа
для дальнейшего выделения websocket/backfill слоя в отдельный router/service.
"""

from aria.main import websocket_endpoint

__all__ = ["websocket_endpoint"]
