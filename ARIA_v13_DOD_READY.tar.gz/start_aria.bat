@echo off
setlocal enabledelayedexpansion
title ARIA Launcher

REM ============================================================
REM  start_aria.bat — единый запуск/перезапуск ARIA
REM    backend (FastAPI/uvicorn через run_aria.py)
REM    + desktop (Tauri dev)
REM
REM  Использование:
REM    start_aria.bat          — запуск
REM    start_aria.bat restart  — убить всё + перезапуск
REM    start_aria.bat stop     — только убить процессы
REM ============================================================

set "ROOT=%~dp0"
set "BACKEND_DIR=%ROOT%backend"
set "DESKTOP_DIR=%ROOT%desktop"
set "VENV_DIR=%BACKEND_DIR%\.venv"
set "HTTP_PORT=8765"
set "HTTP_HOST=127.0.0.1"
set "BACKEND_TITLE=ARIA Backend"
set "DESKTOP_TITLE=ARIA Desktop"

:parse_args
if /I "%1"=="stop"   goto stop
if /I "%1"=="kill"   goto stop
if /I "%1"=="restart" goto stop  REM продолжит после :start

REM ============================================================
REM  STOP / KILL — убить все процессы ARIA
REM ============================================================
:stop
echo.
echo === Останавливаю ARIA процессы... ===

echo [*] Ищу %BACKEND_TITLE% ...
taskkill /F /FI "WINDOWTITLE eq %BACKEND_TITLE%*" 2>nul
if errorlevel 1 (
    echo     - не найден (уже остановлен)
) else (
    echo     - остановлен
)

echo [*] Ищу %DESKTOP_TITLE% ...
taskkill /F /FI "WINDOWTITLE eq %DESKTOP_TITLE%*" 2>nul
if errorlevel 1 (
    echo     - не найден (уже остановлен)
) else (
    echo     - остановлен
)

REM --- Добиваем процессы на порту (если висят без окна) ---
echo [*] Проверяю порт %HTTP_PORT% ...
netstat -ano | findstr ":%HTTP_PORT% " >nul 2>nul
if errorlevel 1 (
    echo     - порт свободен
) else (
    echo     - нахожу PID и убиваю...
    for /f "tokens=5" %%a in ('netstat -ano ^| findstr ":%HTTP_PORT% "') do (
        set "PID=%%a"
        set "PID=!PID:/=!"
        if not "!PID!"=="" (
            taskkill /F /PID !PID! 2>nul
            echo     - процесс !PID! на порту %HTTP_PORT% убит
        )
    )
)

REM --- Добиваем node/tauri процессы без окна ---
echo [*] Ищу tauri процессы ...
taskkill /F /IM "node.exe" /FI "WINDOWTITLE ne" 2>nul
rem ^ тихо, не фатально

if /I "%1"=="stop" goto :eof
if /I "%1"=="kill" goto :eof
if /I "%1"=="restart" echo. & echo === Перезапуск... ===

REM ============================================================
REM  START — проверка и запуск
REM ============================================================
:start
echo.
echo === ARIA Launcher ===
echo Root:    %ROOT%
echo Backend: %BACKEND_DIR%
echo Desktop: %DESKTOP_DIR%
echo Port:    %HTTP_HOST%:%HTTP_PORT%
echo.

REM ---------- Проверка venv ----------
if not exist "%VENV_DIR%\Scripts\python.exe" (
    echo [!] venv не найден по пути: %VENV_DIR%
    echo     Создаю новый venv и ставлю зависимости...
    python -m venv "%VENV_DIR%"
    if errorlevel 1 (
        echo [X] Не удалось создать venv. Проверь, что python установлен и в PATH.
        pause
        exit /b 1
    )
    call "%VENV_DIR%\Scripts\activate.bat"
    pip install -r "%BACKEND_DIR%\requirements.txt"
    call "%VENV_DIR%\Scripts\deactivate.bat"
)

REM ---------- Проверка .env (копировать .env.example → .env если нет) ----------
if not exist "%BACKEND_DIR%\.env" (
    if exist "%BACKEND_DIR%\.env.example" (
        echo [!] backend\.env не найден. Копирую .env.example -^> .env
        copy "%BACKEND_DIR%\.env.example" "%BACKEND_DIR%\.env" >nul
    ) else (
        echo [!] ВНИМАНИЕ: ни .env, ни .env.example не найдены в backend\
    )
)

REM ---------- Проверка node_modules ----------
if not exist "%DESKTOP_DIR%\node_modules" (
    echo [!] desktop\node_modules не найден. Ставлю npm-зависимости...
    pushd "%DESKTOP_DIR%"
    call npm install
    popd
)

REM ---------- Запуск backend ----------
echo.
echo [*] Запускаю backend на %HTTP_HOST%:%HTTP_PORT% ...
start "%BACKEND_TITLE%" cmd /k "cd /d "%BACKEND_DIR%" && call "%VENV_DIR%\Scripts\activate.bat" && python run_aria.py --port %HTTP_PORT%"

REM ---------- Пауза, чтобы backend начал подниматься ----------
timeout /t 3 /nobreak >nul

REM ---------- Запуск desktop (Tauri dev) ----------
echo [*] Запускаю desktop (Tauri dev) ...
start "%DESKTOP_TITLE%" cmd /k "cd /d "%DESKTOP_DIR%" && npm run tauri"

echo.
echo === Запущено. Окна: "%BACKEND_TITLE%" + "%DESKTOP_TITLE%" ===
echo Для остановки:  %~nx0 stop
echo Для перезапуска: %~nx0 restart
echo.
pause
